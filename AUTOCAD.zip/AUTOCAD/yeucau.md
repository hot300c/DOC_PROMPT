Tôi muốn: 

input: 
file autocad (3D).

Nhưng file này phải mở bằng tool autocad mới thấy được nội dung. 
Vậy thì tôi có thể mở file để đọc được và thấy được bản thiết kế 3D đó là khả thi không


Output: 
Muốn là AI trả ra các file 2D:

Nếu như sau khi AI nhận dạng hình và không thấy các navigator (chỉ định) tên của thành phần đó thì:
tự định danh tên các thành phần trong từng thành phần của file.

Ngược lại, nếu có tên thì phải dùng tên đó cho thành phần khi output ra luôn.


Rule:
File autocad hiện tại của khách hàng phức tạp, theo kinh nghiệm của tôi, thì sử dụng 
các library trên thị trường sẽ parse không tốt.
Nên dùng cổng API của tool ngoài (AUTOCAD VIEWER) 
Nhận dạng AUTOCAD của Mitsubisi thì gọi cổng API của hãng xyz để ra ...
Còn của AUTOCAD của

