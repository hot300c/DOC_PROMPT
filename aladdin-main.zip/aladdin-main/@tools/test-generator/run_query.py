#!/usr/bin/env python
import os
import numbers
import click
import yaml
import decimal
import traceback
from dotenv import load_dotenv

from datetime import datetime

from urllib.parse import quote
from sqlalchemy import create_engine
from sqlalchemy import text

# Tables whose data should have existed already
IGNORE_TABLES = [
    "L_SettingUsage", "Menu", "Settings","L_Shift","DOC_ComboValues", "Facility", "INV_ProductSubLink",
    "L_Batch", "L_Counter", "L_Country", "L_Customer", "L_Department", "L_DepartmentRoom", "L_DinhNghiaLieuDung",
    "L_DoiTuongSuDungVaccine", "L_DoiTuongTinhTien", "L_Formula", "L_HangSanXuat", "L_HeSo", "L_HeSoMuiTiem", "L_HinhThucThanhToan",
    "L_ICD10", "L_ICD10Catelogy", "L_ICD10Group", "L_InjuredTime", "L_InventoryStock", "L_INV_StockGroup", "L_INV_StockGroupShipment",
    "L_INV_StockType", "L_INV_StockChildren", "L_INVInType", "L_INVOutType", "L_INVInOutTypeStockLink", "L_KhuTiepNhan", "L_LieuLuong_Vaccine",
    "L_MaTablePermissions", "L_MoiQuanHe", "L_NguonTiepNhan", "L_NhomBenhVaccine", "L_NhomBenhVaccineDetail", "L_NuocSanXuat", "L_PayType",
    "L_Product", "L_ProductNganh", "L_ProductNhom", "L_Product_NhomBenhVaccine", "L_ProductPrice", "L_ProductType", "L_Service", "L_ServicePackage",
    "L_ServicePrice", "L_Service_VIPExamination", "L_ShiftDaily", "L_Specialist", "L_Unit", "L_UnitDinhNghia", "L_UnitDinhNghiaQuyDoi", "L_UoM",
    "L_Utilities", "L_Vaccine_NhomBenh_PhacDo", "L_Vaccine_NhomBenh_PhacDo_Detail", "L_Vaccine_Phacdo", "L_Vaccine_Phacdo_Detail",
    "L_Vaccine_TuongTacVaccine", "L_Vendor", "MDM_Ethnicity", "MDM_District", "MDM_Occupation", "MDM_Province", "MDM_Ward", "Vaccine_CauHoiKhamBenh",
    "Permissions", "Roles", "StockProductPermissons", "Security..StoctVendorPermissions", "RolePermissions", "UserFacility", "UserRoles"
]

IGNORE_COLUMNS = [
    'Logo',
    'FormatCungCapDichVu',
    'CheckSum_PatientHospitalID',
    'IPUser',
    'MacAddressUser',
    'CreatedBy', 'CreatedOn', 'ModifiedBy', 'ModifiedOn',
    'NoteForDev', 'Note'
]


def create_sql_engine(dbname):
    load_dotenv()
    username = os.getenv('DATABASE_USERNAME', 'postgres')
    password = quote(os.getenv('DATABASE_PASSWORD', 'test'))
    host = os.getenv('DATABASE_HOST', '116.103.110.58')
    port = os.getenv('DATABASE_PORT', '14433')
    url = f"mssql+pymssql://{username}:{password}@{host}:{port}/{dbname}"

    return create_engine(url)

@click.command()
@click.option('-i', '--input_file', required=True, help='Input YAML file to convert', type=click.Path(exists=True))
@click.option('-o', '--output_file',
              required=True,
              help='Output YAML file to convert')
@click.option('--args', required=False, help='List of arguments @key=value separated by comma')
def run(input_file, output_file, args):
    """
    Generate YAML data output file from queries in input file.

    \b
    Input file format:
        - table: table_name
          database: database_name
          query: QUERY STRING 1
        - table: another_table_name
          database: another_database_name
          query: QUERY STRING 2
    Output file format:
        - table: table_name
          database: database_name
          rows:
            - column1: value10
              column2: value20
            - column1: value11
        - table: another_table_name
          database: another_database_name
          rows:
            - column1: value10
              column2: value20
            - column1: value11
    """
    data = yaml.load(open(input_file), Loader=yaml.FullLoader)

    args_dict = parse_args(args) if args else {}
    output = list()
    #data = data[:3]
    for input_case in data:
        database_name = input_case["database"]
        table_name = input_case["table"]
        engine = create_sql_engine(database_name)
        if (table_name in IGNORE_TABLES):
            continue
        with engine.connect() as con:
            query = input_case["query"]
            for k, v in args_dict.items():
                query = query.replace(k, v)

            try:
                result = con.execute(text(query))
                results_as_dict = result.mappings().all()
            except Exception as e:
                print('***********************************')
                print('Error querying table: ' + table_name)
                traceback.print_exc(limit=0)
                continue
            output_case = {
                "database": database_name,
                "table": table_name,
                "rows": [copy_row(x) for x in results_as_dict]
            }
            output.append(output_case)
        engine.dispose()

    with open(output_file, 'w', encoding='utf-8') as writer:
        yaml.safe_dump(output, writer, allow_unicode=True, sort_keys=False)


def copy_row(row):
    return {
        x: convert(row[x])
        for x in row if x not in IGNORE_COLUMNS and row[x] is not None and row[x] != ''
    }


def convert(n):
    if isinstance(n, numbers.Number):
        if isinstance(n, decimal.Decimal):
            return float(n)
        return n
    elif isinstance(n, datetime):
        return n.strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3]
    return str(n)


def parse_args(args):
    parts = args.split(',')
    result = dict()
    for part in parts:
        param = part.split('=')
        key = param[0].strip()
        value = param[1].strip()
        result[key] = value
    return result


if __name__ == '__main__':
    run()
