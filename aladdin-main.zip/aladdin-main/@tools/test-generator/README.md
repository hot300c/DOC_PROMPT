# Test Generator

File script [run_query.py](./@scripts/run_query.py) có thể dùng để generate ra data test tự động. Để chạy script này, thực hiện các bước sau:


## 1. Setup environment

Lưu ý bước này chỉ cần thực hiện một lần duy nhất.

1. Đảm bảo các library cho script Python được install:
   ```bash
   pip install -r requirements.txt
   ```

   Nếu pip không được phép cài đặt system wide packages hoặc không muốn cài đặt các packages này system wide, thêm
   flag `--user` cho query:
   ```bash
   pip install --user -r requirements.txt
   ```

   Ngoài ra có thể setup virtual environment bằng [venv](https://docs.python.org/3/library/venv.html).

2. Tạo file `.env` trong folder `UnitTests` hoặc folder `scripts` với nội dung như sau, lưu ý sửa credentials cho đúng:
   ```bash
   DATABASE_USERNAME=username
   DATABASE_PASSWORD=password
   DATABASE_HOST=116.103.110.58
   DATABASE_PORT=14433
   ```

## 2. Chạy script generate

1. Generate file `.yaml` chứa input query bằng cách truy cập theo đường
   dẫn `https://sp-converter-qx2hizakkq-uc.a.run.app/convert/{ĐatabaseName}/{StoredProcedureName}`.
   V.D: https://sp-converter-qx2hizakkq-uc.a.run.app/convert/QAHosGenericDB/ws_DOC_TemplateVatTu_GetByProductID. Lưu
   file input về máy với định dạng `.yaml` và tên bất kỳ (ví dụ `input.yaml`). File input này cần có format như sau:
   ```yaml
   - table: table_name
     database: database_name
     query: QUERY STRING 1
   - table: another_table_name
     database: another_database_name
     query: QUERY STRING 2
   ```


2. Chạy file input được lưu ở bước 1 với script [./@scripts/run_query.py](./@scripts/run_query.py).
   ```bash
   python run_query.py --input_file input.yaml --output_file ws_StoredProcedureName.yaml
   ```
   Hoặc,
   ```bash
   python run_query.py -i input.yaml -o ws_StoredProcedureName.yaml
   ```

   Nếu input_file chứa các query có chứa các params dưới dạng `@params` (ví
   dụ `SELECT * FROM QAHosGenericDB.dbo.CN_ClinicalSessions WHERE PatientID = @PatientID AND FacilityID = @FacilityID`),
   có thể thêm flag `--args @param1='abc',@param2=123` để chỉ định giá trị cho các params này (lưu ý quote các giá trị
   không phải là số bằng single-quote `''`). Ví dụ như sau:
   ```bash
   python run_query.py -i input.yaml -o ws_StoredProcedureName.yaml --args "@PatientID='06B7531E-AD0D-4ED9-91E6-0058FC18014A',@FacilityID=80"
   ```

   Xem cụ thể cách dùng script bằng cách chạy lệnh sau:
   ```bash
   python run_query.py --help
   ```

