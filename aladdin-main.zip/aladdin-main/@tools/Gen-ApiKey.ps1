param(
    [Parameter(HelpMessage='API Key Name', Mandatory=$True)]
    [string]$Name,
    [Parameter(HelpMessage='API Key Role', Mandatory=$True)]
    [string]$Role
)

if (-not $Name) {
    Write-Error "Name parameter is required."
    exit 1
}

if (-not $Role) {
    Write-Error "Role parameter is required."
    exit 1
}

Write-Host "+ API key '$Name' with '$Role' role:" -ForegroundColor Cyan

# Generate apiKey as a random 32-byte token and convert it to a Base64 string
$bytes = New-Object byte[] 32
[System.Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($bytes)
$apiKey = [Convert]::ToBase64String($bytes)
Write-Host $apiKey

# Generate a hash of the API key using SHA256
$sha256 = [System.Security.Cryptography.SHA256]::Create()
$hashBytes = $sha256.ComputeHash([System.Text.Encoding]::UTF8.GetBytes($apiKey))
$hash = [BitConverter]::ToString($hashBytes) -replace '-', ''
$hash = $hash.ToLowerInvariant()

# Generate SQL insert statement for the API key
Write-Host "`n+ SQL INSERT statement:" -ForegroundColor Cyan
Write-Host "INSERT INTO [Security]..[ApiKeys] (KeyHash, Name, Role)"
Write-Host "VALUES ('$hash', '$Name', '$Role')"
