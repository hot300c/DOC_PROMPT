# Aladdin AI Tool

## Description

This is a script utilizing Anthropic AI to help with conversion from T-SQL stored procedure to C# code.

## Setup

1. Install [Python](https://www.python.org/)

2. Install packages requirement.
   ```bash
   pip install -r requirements.txt
   ```

3. Create an `.env` file containing the API key for the Anthropic model.
   ```bash
   ANTHROPIC_API_KEY="api_key"
   ```

4. Setup git submodule.
   ```bash
   git submodule update --init --recursive
   ```

## File purpose

* `examples.yaml` contains converted stored procedures that will be used as examples to feed the model. It already contains some examples, you don't have to edit this file.

* `convertables.yaml` contains stored procedures that you wish to convert. Add stored procedures you wish to convert to this file.

* `convert.py` is the convert script. It feeds example one by one to the AI.

* `convert_prebuilt.py` is another convert script. It feeds all examples at once to the AI. Recommend using this script.

## Usage

```console
$ python convert_prebuilt.py -h
usage: convert_prebuilt.py [-h] [--force] [--output OUTPUT]

options:
  -h, --help            show this help message and exit
  --force, -f           By default the script will skip converting files existed in output folder. Set this flag to force overwrite existing files.
  --output OUTPUT, -o OUTPUT
                        Output folder relative to executing directory. Default to WebService.Handlers
```

## Note

Currently only support converting stored procedure. Converting functions is a bit more tricky due to current file structure. Doing refactoring to make this easier.
