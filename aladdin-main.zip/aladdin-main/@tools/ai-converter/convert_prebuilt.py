import os
import prompts
import logging
import argparse
import time
from anthropic import Anthropic
from dotenv import load_dotenv

from conversation import ConversationHistory
from common import get_abs_path, load_yaml, log_tokens_info

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

conversation_history = ConversationHistory()

def build_one_giant_prompt():
    examples = load_yaml("examples.yaml")

    messages = [prompts.INITIAL_PROMPT]

    # Seed examples
    example_procedures = examples.get("Procedures", {})
    for db, procedures in example_procedures.items():
        for procedure in procedures:
            logger.info(f"[>] Added example: {procedure}")
            sql_path = get_abs_path(f"../qas-db/{db}/Procedures/{procedure}.sql")
            csharp_path = get_abs_path(f"../WebService.Handlers/{db}/{procedure}.cs")
            with open(sql_path, encoding='utf-8') as sql_file, open(csharp_path, encoding='utf-8') as csharp_file:
                sql = sql_file.read()
                csharp = csharp_file.read()
            messages.append(prompts.EXAMPLE_PROMPT.format(sql=sql, csharp=csharp))

    messages.append(prompts.ENTITIES_EXAMPLE_PROMPT)
    # Example done
    messages.append(prompts.DONE_EXAMPLE_PROMPT)
    return "\n".join(messages)

def get_message(client: Anthropic, examples, message: str, **kwargs):
    if kwargs:
        message = message.format(**kwargs)

    prompt_messages = conversation_history._create_message(examples, "user", True)

    convert_messages = conversation_history._create_message(message, "user", False)

    continue_messages = conversation_history._create_message(prompts.CONTINUE, "user", False)

    # Conversation to feed into the model
    messages = [prompt_messages, convert_messages]

    # Resulting code, might be concatenation of multiple replies
    resulting_code = ""

    start = time.time()

    while True:
        response = client.messages.create(
            model="claude-3-5-sonnet-20241022",
            messages=messages,
            max_tokens=8192,
            temperature=0,
            extra_headers={"anthropic-beta": "prompt-caching-2024-07-31"}
        )
        assistant_reply = response.content[0].text
        end = time.time()
        log_tokens_info(response, end - start)
        resulting_code += assistant_reply

        # Continue if max tokens reached
        if response.stop_reason != "max_tokens":
            break
        logger.info("Continue due to max tokens...")
        messages.append(conversation_history._create_message(assistant_reply, "assistant", False))
        messages.append(continue_messages)

    return resulting_code


def main():
    output = get_abs_path("../WebService.Handlers")

    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--force", "-f", action="store_true",
        help="By default the script will skip converting files existed in output folder. Set this flag to force overwrite existing files."
    )
    parser.add_argument("--output", "-o", default=output, help="Output folder relative to executing directory. Default to WebService.Handlers")
    args = parser.parse_args()

    convertables = load_yaml("convertables.yaml")

    load_dotenv()

    client = Anthropic(api_key=os.getenv("ANTHROPIC_API_KEY"))

    examples = build_one_giant_prompt()

    # Convert procedures
    convert_procedures = convertables.get("Procedures", {})
    for db, procedures in convert_procedures.items():
        for procedure in procedures:
            logger.info(f"[>] Converting SQL: {procedure}")
            csharp_path = os.path.join(args.output, f"{db}/{procedure}.cs")
            os.makedirs(os.path.dirname(csharp_path), exist_ok=True)
            if not args.force and os.path.exists(csharp_path):
                logger.warning(f"[!] Skipping {procedure} as it already exists.")
                continue

            sql_path = get_abs_path(f"../qas-db/{db}/Procedures/{procedure}.sql")
            with open(sql_path, "r", encoding='utf-8') as sql_file:
                sql = sql_file.read()
            response = get_message(client, examples, prompts.CONVERT_PROMPT,
                                   database=db, sql=sql, output=prompts.OUTPUT)
            with open(csharp_path, "w", encoding="utf-8") as csharp_file:
                csharp_file.write(response)


if __name__ == "__main__":
    main()
