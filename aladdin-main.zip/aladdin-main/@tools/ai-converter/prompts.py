
INITIAL_PROMPT = """
Given a definition of a SQL stored procedure, convert it to C# class and output with the following prototype:
You will be provided with some initial examples to learn from. Be prepared to consume the first example.
"""

EXAMPLE_PROMPT = """
Here is one example:
SQL stored procedure:
{sql}
Converted C# class:
{csharp}
"""

ENTITIES_EXAMPLE_PROMPT = """
Here are also some examples of converting SQL names to LINQ name:
- Table CN_Diagnosis will be CnDiagnosis
- Table BIL_Invoice will be BilInvoices
- Table L_ICD10 will be LIcd10
- Table L_Product will be LProducts

Some requirements:
- In which the class name and property name are the LINQ2DB equivalent of the stored procedure.
- Map the properties of the corresponding Entity via LINQ2DB code
"""

DONE_EXAMPLE_PROMPT = """
That's all the examples. Be prepared to consume the first SQL stored procedure to convert.
"""

CONVERT_PROMPT = """
Here is a SQL stored procedure to convert. The database name is {database}:
{sql}

Some requirements:
- The class name should be the same as the stored procedure name.
- Do NOT attempt to implement any unknown stored procedures or functions, assume there is already an equivalent implementation with the same name.
- Do NOT output any prototype for unknown stored procedures or functions.
- Do NOT include any explanation or comments in the output.
- Do include any additional necessary `using` directives.
- Do optimization as needed.
- Do only output raw code without any additional message or markdown syntax. Do NOT use any ```csharp code block.
- Do NOT generate partially completed code. For example, comments like these are not allowed instead of code:
    ```
    // Continue implementing remaining logic following stored procedure flow
    // This includes temp table operations, updates and final result selection
    ```

Output the C# class with the following prototype:
{output}
"""

OUTPUT = """
using Aladdin.Entities;

namespace Aladdin.WebService.Handlers.Database_Name;

public class Stored_Procedure_Name(AladdinDataConnection db) : IHandler
{
    public DataSet Handle(Dictionary<string, object> parameters) { }
}
In which the Handle function is the LINQ2DB equivalent of the stored procedure.
"""

CONTINUE = """
Continue with the generation.
"""
