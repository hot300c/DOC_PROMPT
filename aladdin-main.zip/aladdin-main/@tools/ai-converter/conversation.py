
class ConversationHistory:
    def __init__(self):
        self.turns = []

    def add_turn_assistant(self, content):
        message = self._create_message(content, "assistant", False)
        self.turns.append(message)

    def add_turn_user(self, content, cache=True):
        message = self._create_message(content, "user", cache)

        self.turns.append(message)

    def get_message_with_context(self, content):
        """Do not append these messages into turn history."""
        message = self._create_message(content, "user", False)
        return self.turns + [message]

    def _create_message(self, content, role, cache):
        content = {"type": "text", "text": content}
        if cache:
            content["cache_control"] = {"type": "ephemeral"}

        message = {
            "role": role,
            "content": [content]
        }
        return message

    def get_turns(self):
        return self.turns

