import os
import yaml
import logging
from anthropic.types import Message

logger = logging.getLogger(__name__)

def get_abs_path(path):
    return os.path.abspath(os.path.join(os.path.dirname(__file__), path))


def load_yaml(file_path):
    with open(get_abs_path(file_path)) as f:
        return yaml.safe_load(f)

def log_tokens_info(response: Message, elapsed_time: float):
    # Print token usage information
    input_tokens = response.usage.input_tokens
    output_tokens = response.usage.output_tokens
    stop_reason = response.stop_reason
    if stop_reason == "max_tokens":
        logger.warning("Stop reason is max_tokens.")
    input_tokens_cache_read = getattr(response.usage, 'cache_read_input_tokens', '---')
    input_tokens_cache_create = getattr(response.usage, 'cache_creation_input_tokens', '---')
    logger.info("User input tokens: %s", input_tokens)
    logger.info("Output tokens: %s", output_tokens)
    logger.info("Input tokens (cache read): %s", input_tokens_cache_read)
    logger.info("Input tokens (cache write): %s", input_tokens_cache_create)

    # Calculate the percentage of input prompt cached
    total_input_tokens = input_tokens + (int(input_tokens_cache_read) if input_tokens_cache_read != '---' else 0)
    percentage_cached = (int(input_tokens_cache_read) / total_input_tokens * 100 if input_tokens_cache_read != '---' and total_input_tokens > 0 else 0)

    logger.info(f"{percentage_cached:.1f}% of input prompt cached ({total_input_tokens} tokens)")
    logger.info(f"Time taken: {elapsed_time:.2f} seconds")
