using LinqToDB;

namespace Aladdin.Entities;

public class DataContextWrapper(IDataContext dataContext)
{
    protected ITable<T> GetTable<T>() where T : class
    {
        return dataContext.GetTable<T>();
    }
}
