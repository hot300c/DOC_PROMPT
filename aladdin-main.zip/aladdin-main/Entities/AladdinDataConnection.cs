using LinqToDB;
using LinqToDB.Data;

namespace Aladdin.Entities;

public class AladdinDataConnection(DataOptions<AladdinDataConnection> options) : DataConnection(options.Options)
{
    public ApplicationDb Application => new(this);

    public DocsDb Docs => new(this);

    // ReSharper disable once InconsistentNaming
    public HRDb HR => new(this);

    // ReSharper disable once UnusedMember.Global
    public HistoryDb History => new(this);

    // ReSharper disable once UnusedMember.Global
    public IntegrationDb Integration => new(this);

    // ReSharper disable once InconsistentNaming
    public QAHosGenericDBDb QAHosGenericDB => new(this);

    public ReportsDb Reports => new(this);

    public SecurityDb Security => new(this);

    // ReSharper disable once InconsistentNaming
    public FWDb FW => new(this);
}
