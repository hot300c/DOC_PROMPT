using System.Collections.Immutable;

namespace Aladdin.Entities;

public static class Constants
{
    public enum ServiceType
    {
        Pediatric = 13 // Khám nhi
    }

    private enum ServiceTypeHospitalId
    {
        GeneralExamination = 1,
        LabTest = 2,
        DiagnosticImaging = 3,
        Ultrasound = 4
    }

    public static readonly ImmutableList<int> PediatricServiceTypeHospitalIds
        = ImmutableList.Create(
            (int)ServiceTypeHospitalId.DiagnosticImaging,
            (int)ServiceTypeHospitalId.Ultrasound,
            (int)ServiceTypeHospitalId.LabTest
        );

    public enum PediatricServiceRoomId
    {
        KhamNhi = 72,
        CanDo = 73
    }

    public enum DoiTuongTinhTien
    {
        Default = 99
    }

    public static class OrganSystem
    {
        public const string TuanHoan = "Tuần hoàn";
        public const string HoHap = "Hô hấp";
        public const string TieuHoa = "Tiêu hóa";
        public const string ThanTietNieu = "Thận - Tiết niệu - Sinh dục";
        public const string Khac = "Khác";
    }
}
