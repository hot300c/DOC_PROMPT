﻿using BenchmarkDotNet.Running;

namespace Aladdin.Benchmarks;

public static class Program
{
    // // Debug
    // private static void Main(string[] args) => BenchmarkSwitcher.FromAssembly(typeof(Program).Assembly)
    //     .Run(args, new DebugInProcessConfig());
    public static void Main() => BenchmarkRunner.Run<WhereInBenchmark>();
}
