using System.Linq.Expressions;
using System.Reflection;
using BenchmarkDotNet.Attributes;
using LinqToDB;
using LinqToDB.Tools;
using Aladdin.Entities;
using Aladdin.Services;

namespace Aladdin.Benchmarks;

public static class SqlExprV1
{
    // Possible buckets
    private static readonly int[] s_buckets = [2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048];

    // Turn a CLR value into a MemberExpression, which linq2db always parameterizes.
    private static Expression AsParam<T>(T value)
    {
        Expression<Func<T>> e = () => value; // Capture g
        return e.Body; // -> MemberExpression
    }

    // The original WhereIn implementation, we keep it here as a baseline
    private static IQueryable<TEntity> WhereInV1<TEntity, TProp>(this IQueryable<TEntity> source,
        Expression<Func<TEntity, TProp>> selector,
        IEnumerable<TProp> values)
    {
        List<TProp> valueList = values.ToList();
        if (valueList.Count == 0)
        {
            return source.Where(_ => false);
        }

        ParameterExpression e = Expression.Parameter(typeof(TEntity));
        InvocationExpression lhs = Expression.Invoke(selector, e);
        Expression body;

        if (valueList.Count == 1)
        {
            body = Expression.Equal(lhs, AsParam(valueList[0]));
        }
        else
        {
            int bucket = s_buckets.First(b => b >= valueList.Count);
            while (valueList.Count < bucket)
            {
                valueList.Add(valueList[^1]);
            }

            NewArrayExpression arrayExpr = Expression.NewArrayInit(
                typeof(TProp),
                valueList.Select(AsParam));

            MethodInfo inMethod = ((Func<int, int[], bool>)SqlExtensions.In)
                .Method.GetGenericMethodDefinition()
                .MakeGenericMethod(typeof(TProp));

            body = Expression.Call(inMethod, lhs, arrayExpr);
        }

        Expression<Func<TEntity, bool>> predicate = Expression.Lambda<Func<TEntity, bool>>(body, e);
        return source.Where(predicate);
    }

    // Nullable column, non-nullable values
    public static IQueryable<TEntity> WhereInV1<TEntity, TProp>(
        this IQueryable<TEntity> source,
        Expression<Func<TEntity, TProp?>> selector,
        IEnumerable<TProp> values
    ) where TProp : struct =>
        // Just cast each value to nullable and forward to the main method
        source.WhereInV1(selector, values.Select(v => (TProp?)v));
}

[MemoryDiagnoser]
public class WhereInBenchmark
{
    private static readonly AladdinDataConnection s_db =
        new(new DataOptions<AladdinDataConnection>(new DataOptions().UseSqlServer(
            "Data Source=localhost,1433;User ID=sa;Password=sqlserver@123456;Trust Server Certificate=True;MultipleActiveResultSets=True")));

    private int[] s_values;

    [Params(1, 2, 6, 50, 100, 600, 1500)] public int N;

    [GlobalSetup]
    public void Setup() => s_values = Enumerable.Range(0, N).ToArray();

    [Benchmark(Baseline = true)]
    public object? V1()
        => s_db.QAHosGenericDB.CnClinicalSessions.WhereInV1(x => x.BloodId, s_values).ToString();

    [Benchmark]
    public object? V2()
        => s_db.QAHosGenericDB.CnClinicalSessions.WhereIn(x => x.BloodId, s_values).ToString();
}
