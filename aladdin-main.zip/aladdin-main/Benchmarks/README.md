# Benchmark

## Run benchmark

```bash
dotnet run -c Release --project Benchmarks
```
