# Kiến trúc Dự án

## Tổng quan

Tài liệu này cung cấp tổng quan về kiến trúc của ứng dụng web Genie.

## Thiết kế Tổng thể

- **Frontend**: Xây dựng bằng Next.js và React
- **Backend**: Xây dựng bằng ASP.NET với môi trường test tại `https://test-aladdin.vnvc.info`

## Sơ đồ Kiến trúc

![diagram](./diagram.gif)

## Cấu trúc thư mục

```
genie
├── app/
│   ├── dang-nhap/
│   │   ├── _actions/
│   │   │   └── login.ts
│   │   ├── _components/
│   │   │   └── login-form.tsx
│   │   ├── _hooks/
│   │   │   └── use-login.ts
│   │   ├── _utils/
│   │   │   ├── definitions/
│   │   │   │    ├── api.ts
│   │   │   │    └── schema.ts
│   │   │   └── fetch-user.ts
│   │   └── page.tsx
│   └── co-so/
│   │   └── page.tsx
│   └── (main)/
│       └── layout.tsx
├── components/
│   ├── ui/
│   │   └── button.tsx
│   └── header.tsx
├── lib/
│   ├── services/
│   └── utils/
├── actions/
│   └── logout.ts
├── hooks/
│   ├── use-keyboard-shortcut.test.tsx
│   └── use-keyboard-shortcut.ts
├── store/
│   ├── index.ts
│   └── slices/
│       └── user-slice.ts
│       └── auth-slice.ts
```

## Các Thành phần Chính

- **Quy ước Đặt tên File/Thư mục**:

  - Tuân thủ quy tắc đặt tên bằng chữ thường và ngăn cách bằng dấu gạch ngang để cải thiện khả năng đọc và bảo trì code
  - Ví dụ: `my-component.js`, `utils-functions.ts`
  - Sử dụng dấu gạch dưới (`_`) cho các thư mục private trong Next.js để chỉ ra rằng chúng không trực tiếp truy cập được như routes
  - Ví dụ: `_actions`, `_components`, `_hooks`, `_utils`

- **Thư mục App**:

  - Chứa các trang chính và cấu trúc layout của ứng dụng web. Mỗi thư mục trong `app` đại diện cho một route. Ví dụ:
    - `app/page.tsx`: Trang chủ ("/").
    - `app/co-so/page.tsx`: Trang chọn cơ sở ("/co-so").
    - `app/dang-nhap/page.tsx`: Trang đăng nhập ("/dang-nhap").
  - Hỗ trợ layouts, nested routing, và server components cho routing linh hoạt.
  - **Tổ chức thư mục con**: Mỗi thư mục route (ví dụ: `app/dang-nhap`) có thể bao gồm:
    - `_actions`: Chứa các hàm xử lý phía server dành riêng cho route đó. Ví dụ, `app/dang-nhap/_actions/login.ts` xử lý các hành động liên quan đến đăng nhập.
    - `_components`: Chứa các components chỉ sử dụng trong route đó. Ví dụ, `app/dang-nhap/_components/login-form.tsx` là một component độc quyền cho trang đăng nhập.
    - `_utils`: Chứa các utility functions dành riêng cho route đó, thường được tổ chức thành các thư mục con. Ví dụ, `app/dang-nhap/_utils/definitions` có thể bao gồm `api.ts`, `schema.ts`, và `fetch-user.ts` cho các chức năng liên quan.
    - `_hooks`: Chứa các custom hooks dành riêng cho route đó. Ví dụ, `app/dang-nhap/_hooks/use-login.ts` có thể xử lý trạng thái và hiệu ứng liên quan đến chức năng đăng nhập.

- **Components**:

  - Components UI có thể tái sử dụng được đặt trong thư mục `components`. Những components này có thể được sử dụng trên nhiều route và layout khác nhau.
  - Đối với các components chỉ dành riêng cho một trang cụ thể, định nghĩa chúng trong thư mục `_components` của trang đó (ví dụ, `app/dang-nhap/_components/login-form.tsx`).

- **Lib**:

  - Thư mục `lib` chứa các utility functions và services cho mục đích chung. Ví dụ:
    - `lib/services`: Các hàm tương tác với API bên ngoài.
    - `lib/utils`: Các hàm helper và utilities dùng chung.

- **Actions**:

  - **Next.js Actions** là các hàm xử lý logic phía server trực tiếp. Actions đơn giản hóa việc lấy dữ liệu, xử lý biểu mẫu và các tác vụ phía server bằng cách cho phép các nhà phát triển giữ những hàm này gần với mã UI của họ.
  - Đối với các actions có thể tái sử dụng, đặt chúng trong thư mục `actions`, giúp dễ dàng nhập khẩu ở các phần khác nhau của ứng dụng. Ví dụ:
    - `actions/logout.ts`: Chứa logic phía server liên quan đến chức năng đăng xuất.
  - Actions có thể được định nghĩa bằng `export async function` và gọi trực tiếp từ các components, cho phép tương tác sạch sẽ giữa server và client.

- **Hooks**:

  - Custom hooks dùng chung được đặt trong thư mục `hooks` global.
  - Đối với các hooks chỉ dành riêng cho một route cụ thể, định nghĩa chúng trong thư mục `_hooks` của route đó (ví dụ, `app/login/_hooks/use-login.ts`).
  - Cấu trúc này giúp giữ cho logic cụ thể của route được đóng gói và các hooks có thể tái sử dụng được tách biệt.

- **Quản lý State**: Có thể tương lai mình có thể bỏ cái redux

  - Ứng dụng sử dụng Redux để quản lý state.
  - State global được định nghĩa trong thư mục `store`, bao gồm các actions, reducers, và selectors.
  - Mỗi tính năng có thể có slice riêng trong state, được định nghĩa trong các tệp riêng biệt trong thư mục `store`.
  - Cấu trúc ví dụ:
    - `store/`
      - `index.ts`: Cấu hình store Redux.
      - `slices/`
        - `user-slice.ts`: Quản lý state liên quan đến người dùng.
        - `auth-slice.ts`: Quản lý state liên quan đến xác thực.
  - Sử dụng các hooks `useSelector` và `useDispatch` từ `react-redux` để tương tác với state trong các components.

- **Testing**:

  - Ứng dụng sử dụng kết hợp nhiều loại testing:

    1. **Unit Testing với Jest**:

       - Các tệp test đi kèm với component hoặc hook
       - Tuân theo quy tắc đặt tên `*.test.ts` hoặc `*.test.tsx`
       - Cấu trúc ví dụ:
         ```
         components/
         ├── ui/
         │   ├── button.tsx
         │   └── button.test.tsx
         hooks/
         ├── use-keyboard-shortcut.ts
         └── use-keyboard-shortcut.test.tsx
         ```

    2. **E2E Testing với Playwright**:

       - Đặt trong thư mục `playwright/`
       - Chạy tests:

         ```bash
         # Chạy với UI mode
         yarn pw:open:local
         ```

       - Best practices:
         - Sử dụng page objects pattern
         - Tổ chức tests theo user flows
         - Sử dụng fixtures cho test data
         - Setup test environment trước mỗi test
