"use server";
import { Permission } from "@/app/lib/definitions/setting";
import { cachePost } from "@/app/lib/network/cache-http";

export const getPermissionsList = async (facId: string) => {
  return cachePost<
    Record<string, number | null>,
    { table: Permission[] | undefined }
  >({
    url: "/DataAccess",
    payload: [
      {
        category: "Security",
        command: "ws_Permissions_List",
        parameters: {
          FacID: facId,
        },
      },
    ],
    cacheKey: `permissions-${facId}`,
    ttl: 3600,
    transform: (data) =>
      (data.table || []).reduce(
        (acc, pm) => {
          if (pm.key) {
            const upperKey = pm.key.toUpperCase();
            acc[upperKey] = 1;
          }
          return acc;
        },
        {} as Record<string, number | null>,
      ),
  });
};
