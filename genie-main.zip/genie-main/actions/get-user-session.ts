"use server";
import { cookies } from "next/headers";

interface UserSession {
  userId: string;
  facId: string;
  sessionId: string;
  customerId: string;
}

export async function getUserSession(): Promise<UserSession> {
  const cookieStore = await cookies();
  const userId = cookieStore.get("u")?.value!;
  const facId = cookieStore.get("facId")?.value!;
  const sessionId = cookieStore.get("s")?.value!;
  const customerId = cookieStore.get("customerId")?.value!;
  return { userId, facId, sessionId, customerId };
}
