"use server";
import { getUserSession } from "@/actions/get-user-session";
import { revalidateTag } from "next/cache";
import { cookies } from "next/headers";

export async function deleteFacIdCookie() {
  const { userId, facId } = await getUserSession();
  revalidateTag(`menu-${userId}-${facId}`);
  revalidateTag(`user-permissions-${userId}-${facId}`);
  const cookieStore = await cookies();
  cookieStore.delete("facId");
}
