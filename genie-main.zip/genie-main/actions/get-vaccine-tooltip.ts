"use server";
import { VaccineNoiDungTooltip } from "@/app/lib/definitions/vaccine";
import { QAHOSGENERICDB } from "@/app/lib/enums";
import { cachePost } from "@/app/lib/network/cache-http";

export const getVaccineTooltipList = async () => {
  return cachePost<
    Record<string, string>,
    { table: VaccineNoiDungTooltip[] | undefined }
  >({
    url: "/DataAccess",
    payload: [
      {
        category: QAHOSGENERICDB,
        command: "ws_VaccineTooltip_HTML",
      },
    ],
    cacheKey: `ws_VaccineTooltip_HTML`,
    ttl: 600, // 10 minutes
    transform: (data) =>
      (data.table || []).reduce(
        (acc, tooltip) => {
          acc[tooltip.maChung] = tooltip.noiDungHTML || tooltip.noiDung;
          return acc;
        },
        {} as Record<string, string>,
      ),
  });
};
