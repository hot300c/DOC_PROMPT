"use server";
import {
  BaseSetting,
  OriginalBaseSetting,
} from "@/app/lib/definitions/setting";
import { cachePost } from "@/app/lib/network/cache-http";

export const getSettingsList = async (facId: string) => {
  return cachePost<BaseSetting[], { table: OriginalBaseSetting[] | undefined }>(
    {
      url: "/DataAccess",
      payload: [
        {
          category: "Application",
          command: "ws_Settings_ListByFacID",
          parameters: {
            FacID: facId,
          },
        },
      ],
      cacheKey: `ws_Settings_ListByFacID-${facId}`,
      ttl: 600, // 10 minutes
      transform: (data) =>
        (data.table || []).map((s) => ({
          category: s.category,
          name: s.name,
          value: s.value,
        })),
    },
  );
};
