"use server";
import { Permission } from "@/app/lib/definitions/setting";
import { cachePost } from "@/app/lib/network/cache-http";

export const getUserPermissionsList = async (facId: string, userId: string) => {
  return cachePost<
    Record<string, number | null>,
    { table: Permission[] | undefined }
  >({
    url: "/DataAccess",
    payload: [
      {
        category: "Security",
        command: "ws_UserPermissions_List",
        parameters: {
          FacID: facId,
        },
      },
    ],
    cacheKey: `user-permissions-${userId}-${facId}`,
    ttl: 3600,
    transform: (data) =>
      (data.table || []).reduce(
        (acc, pm) => {
          if (pm.key) {
            const upperKey = pm.key.toUpperCase();
            acc[upperKey] = 1;
          }
          return acc;
        },
        {} as Record<string, number | null>,
      ),
  });
};
