export const Loading = () => {
  return (
    <div
      className={`fixed inset-0 flex items-center justify-center z-100 !pointer-events-auto`}
    >
      <div className="flex items-center justify-center space-x-2 w-[250px] h-[60px] text-black bg-slate-100 border-2 border-[#ffcc00] rounded-md">
        <p className=" text-black flex items-center">Đang tải dữ liệu...</p>
      </div>
    </div>
  );
};
