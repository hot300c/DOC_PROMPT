"use client";

import FacilityInfo from "@/components/facilityInfo";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { useEffect, useState } from "react";

export default function Layout({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const currentTab = pathname.split("/").pop() || "thong-tin-can-han-het-han";
  const [tabParams, setTabParams] = useState<Map<string, string>>(new Map());

  useEffect(() => {
    if (searchParams.size) {
      setTabParams((tabParams) => {
        tabParams.set(pathname, searchParams.toString());
        return tabParams;
      });
    }
  }, [pathname, searchParams]);

  const handleTabChange = (value: string) => {
    let path = `/duoc/bang-thong-tin/${value}`;
    const params = tabParams.get(path);
    if (params) {
      path += `?${params}`;
    }
    router.push(path);
  };

  return (
    <div className="flex flex-col h-full">
      <div className="flex-none">
        <FacilityInfo page={"DƯỢC | BẢNG THÔNG TIN"} />
        <Tabs value={currentTab} onValueChange={handleTabChange}>
          <TabsList>
            <TabsTrigger value="thong-tin-can-han-het-han">
              Thông Tin Thuốc Hết Hạn Và Cận Hạn
            </TabsTrigger>
            <TabsTrigger value="thong-tin-thuoc-can-nhap">
              Thông Tin Thuốc Cần Nhập
            </TabsTrigger>
            <TabsTrigger value="tra-cuu-lich-su-gia-nhap">
              Tra Cứu Lịch Sử Giá Nhập
            </TabsTrigger>
          </TabsList>
        </Tabs>
      </div>
      <div className="flex-1 overflow-y-auto p-2">{children}</div>
    </div>
  );
}
