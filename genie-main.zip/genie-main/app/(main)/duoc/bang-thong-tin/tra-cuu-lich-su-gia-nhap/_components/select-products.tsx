import { TableSelect } from "@/components/select/table-select";
import { DataTableColumnHeaderSort } from "@/components/ui/dataTable";
import { ColumnDef } from "@tanstack/react-table";
import React, { useMemo } from "react";
import { StockProductPermission } from "../_utils/definitions/tra-cuu-lich-su-gia-nhap.response";

type Props = {
  list: StockProductPermission[];
  value: string | undefined;
  onChange: (value: string) => void;
};

const PRODUCT_COLUMN_COMBOBOX: ColumnDef<StockProductPermission>[] = [
  {
    id: "productID",
    accessorKey: "productID",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Mã PM" />
    ),
  },
  {
    id: "hospitalCode",
    accessorKey: "hospitalCode",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Mã BV" />
    ),
  },
  {
    id: "hospitalName",
    accessorKey: "hospitalName",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Tên SP" />
    ),
  },
  {
    id: "unitName",
    accessorKey: "unitName",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="ĐVT" />
    ),
  },
];

const SelectProducts: React.FC<Props> = ({ list, value, onChange }) => {
  const selectedItem = useMemo(
    () => list.find((v) => v.productID == value),
    [value, list],
  );

  return (
    <TableSelect
      placeholderSearch="--Chọn thuốc--"
      placeholder="--Chọn thuốc--"
      className="w-64"
      classNamePopover="w-auto min-w-64"
      data={list}
      value={selectedItem}
      labelKey="hospitalName"
      valueKey="productID"
      onChange={(value) => onChange(value.productID.toString())}
      columns={PRODUCT_COLUMN_COMBOBOX}
    />
  );
};

export default SelectProducts;
