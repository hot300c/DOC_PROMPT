"use client";
import { DATE_FORMAT } from "@/app/lib/enums";
import { InputDatePicker } from "@/components/input-date-picker";
import { Button } from "@/components/ui/button";
import { Form, FormField } from "@/components/ui/form";
import { Label } from "@/components/ui/label";
import { zodResolver } from "@hookform/resolvers/zod";
import { format } from "date-fns";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { useEffect, useState } from "react";
import { useForm, useWatch } from "react-hook-form";
import { StockProductPermission } from "../_utils/definitions/tra-cuu-lich-su-gia-nhap.response";
import {
  traCuuLichSuGiaNhapFormSchema,
  TraCuuLichSuGiaNhapFormValues,
} from "../_utils/schema";
import { ws_StockProductPermissons_GetNhapKho } from "../_utils/services/tra-lich-su-gia-nhap.api";
import SelectProducts from "./select-products";
import SelectStocks from "./select-stocks";

export type InventoryFilterParams = {
  stockId: string;
  expireInDays: number;
};

interface TraCuuLichSuGiaNhapFilterFormProps {
  inventoryList: { stockID: string; name: string }[];
}

const TraCuuLichSuGiaNhapFilterForm = ({
  inventoryList,
}: TraCuuLichSuGiaNhapFilterFormProps) => {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const [productList, setProductList] = useState<StockProductPermission[]>([]);
  const form = useForm<TraCuuLichSuGiaNhapFormValues>({
    resolver: zodResolver(traCuuLichSuGiaNhapFormSchema),
    defaultValues: {
      stockID: searchParams.get("stockID") ?? "",
      productID: searchParams.get("productID") ?? "",
      tuNgay:
        searchParams.get("tuNgay") ??
        format(new Date(), DATE_FORMAT.YYYY_MM_DD),
      denNgay:
        searchParams.get("denNgay") ??
        format(new Date(), DATE_FORMAT.YYYY_MM_DD),
    },
  });

  function setQueryRouter(values: TraCuuLichSuGiaNhapFormValues) {
    const filteredValues = Object.fromEntries(
      Object.entries({
        ...searchParams,
        stockID: values.stockID.toString(),
        productID: values.productID.toString(),
        tuNgay: values.tuNgay,
        denNgay: values.denNgay,
      }).filter(([_, value]) => value),
    );
    const query = new URLSearchParams(
      filteredValues as Record<string, string>,
    ).toString();
    router.push(pathname + "?" + query);
  }

  const onSubmit = (values: TraCuuLichSuGiaNhapFormValues) => {
    setQueryRouter(values);
  };

  const stockID = useWatch({
    control: form.control,
    name: "stockID",
  });
  useEffect(() => {
    const fetchProductList = async (stockID: string) => {
      try {
        const products = await ws_StockProductPermissons_GetNhapKho(stockID);
        setProductList(products);
      } catch (error) {
        console.error("Failed to fetch product list:", error);
      }
    };

    if (stockID) {
      void fetchProductList(stockID);
    }
  }, [stockID]);
  return (
    <Form {...form}>
      <form
        className="flex flex-col gap-2 mt-auto"
        onSubmit={form.handleSubmit(onSubmit)}
      >
        <div className="flex gap-2">
          <div className="flex items-center">
            <Label className="whitespace-nowrap w-15">Từ ngày</Label>
            <FormField
              control={form.control}
              name="tuNgay"
              render={({ field }) => (
                <InputDatePicker
                  value={new Date(field.value)}
                  onChange={(date) => {
                    if (date) {
                      field.onChange(format(date, DATE_FORMAT.YYYY_MM_DD));
                    }
                  }}
                />
              )}
            />
          </div>
          <div className="flex items-center">
            <Label className="whitespace-nowrap w-15">Đến ngày</Label>
            <FormField
              control={form.control}
              name="denNgay"
              render={({ field }) => (
                <InputDatePicker
                  value={new Date(field.value)}
                  onChange={(date) => {
                    if (date) {
                      field.onChange(format(date, DATE_FORMAT.YYYY_MM_DD));
                    }
                  }}
                />
              )}
            />
          </div>
        </div>
        <div className="flex gap-2">
          <div className="flex items-center">
            <Label className="whitespace-nowrap">Chọn kho: </Label>
            <FormField
              control={form.control}
              name="stockID"
              render={({ field }) => (
                <SelectStocks
                  list={inventoryList}
                  onChange={(value) => {
                    field.onChange(value);
                  }}
                  value={field.value}
                />
              )}
            />
          </div>
          <div className="flex items-center">
            <Label className="whitespace-nowrap">Chọn thuốc: </Label>
            <FormField
              control={form.control}
              name="productID"
              render={({ field }) => (
                <SelectProducts
                  list={productList}
                  onChange={(value) => {
                    field.onChange(value);
                  }}
                  value={field.value}
                />
              )}
            />
          </div>
          <div className="flex items-center">
            <Button type="submit" className=" text-white px-4 py-2 rounded">
              Tìm
            </Button>
          </div>
        </div>
      </form>
    </Form>
  );
};

export default TraCuuLichSuGiaNhapFilterForm;
