import { LichSuNhapThuocDTO } from "../_utils/definitions/tra-cuu-lich-su-gia-nhap.dto";
import { lichSuNhapThuocRespToDto } from "../_utils/services/tra-cu-lich-su-gia-nhap.mapper";
import { ws_TraCuuNhapThuoc } from "../_utils/services/tra-lich-su-gia-nhap.api";
import TraCuuLichSuGiaNhapPresentation from "./tra-cuu-lich-su-gia-nhap-presentation";

interface TraCuuLichSuGiaNhapContainerProps {
  stockID: string;
  productID: string;
  tuNgay: string;
  denNgay: string;
}

const TraCuuLichSuGiaNhapContainer = async ({
  stockID,
  productID,
  tuNgay,
  denNgay,
}: TraCuuLichSuGiaNhapContainerProps) => {
  let data: LichSuNhapThuocDTO[] = [];

  if (productID && stockID && denNgay && tuNgay) {
    const res = await ws_TraCuuNhapThuoc({
      denNgay: denNgay,
      productID: productID,
      stockID: stockID,
      tuNgay: tuNgay,
    });
    data = res.map((item) => lichSuNhapThuocRespToDto(item));
  }
  return (
    <div className="flex-1  max-h-screen overflow-y-auto">
      <TraCuuLichSuGiaNhapPresentation data={data} />
    </div>
  );
};

export default TraCuuLichSuGiaNhapContainer;
