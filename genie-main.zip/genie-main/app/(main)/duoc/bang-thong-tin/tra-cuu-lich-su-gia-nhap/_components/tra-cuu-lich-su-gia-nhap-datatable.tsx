"use client";
import { DATE_FORMAT } from "@/app/lib/enums";
import {
  DataTable,
  DataTableColumnHeaderSort,
} from "@/components/ui/dataTable";
import { ColumnDef } from "@tanstack/react-table";
import { format } from "date-fns";
import { LichSuNhapThuocDTO } from "../_utils/definitions/tra-cuu-lich-su-gia-nhap.dto";

export interface TraCuuLichSuGiaNhapDataTableProps {
  data: LichSuNhapThuocDTO[];
}

const columns: ColumnDef<LichSuNhapThuocDTO>[] = [
  {
    id: "vendorName",
    accessorKey: "vendorName",
    header: ({ column }) => (
      <DataTableColumnHeaderSort
        column={column}
        title="Nhà cung cấp"
        className="justify-start"
      />
    ),
    enableSorting: true,
  },
  {
    id: "ngayNhap",
    accessorKey: "ngayNhap",
    header: ({ column }) => (
      <DataTableColumnHeaderSort
        column={column}
        title="Ngày nhập"
        className="justify-start"
      />
    ),
    cell: ({ row }) => {
      return <div>{format(row.original.ngayNhap, DATE_FORMAT.DD_MM_YYYY)}</div>;
    },
  },
  {
    id: "giaNhap",
    accessorKey: "giaNhap",
    header: ({ column }) => (
      <DataTableColumnHeaderSort
        column={column}
        title="Giá nhập(VNĐ)"
        className="justify-start"
      />
    ),
    enableSorting: true,
  },
];

const TraCuuLichSuGiaNhapDataTable: React.FC<
  TraCuuLichSuGiaNhapDataTableProps
> = ({ data }) => {
  return (
    <div className="flex-1 flex flex-col h-full">
      <DataTable
        className="w-full border overflow-y-auto"
        columns={columns}
        data={data}
        columnVisibilityInit={{ search: false }}
        enableColumnFilter={true}
        enablePaging={false}
        enableFooter={true}
      />
    </div>
  );
};

export default TraCuuLichSuGiaNhapDataTable;
