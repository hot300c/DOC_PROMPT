import { TableSelect } from "@/components/select/table-select";
import { DataTableColumnHeaderSort } from "@/components/ui/dataTable";
import { ColumnDef } from "@tanstack/react-table";
import React, { useMemo } from "react";

type Stocks = { stockID: string; name: string };
type Props = {
  list: Stocks[];
  value: string;
  onChange: (value: string) => void;
};

const STOCK_COLUMN_COMBOBOX: ColumnDef<Stocks>[] = [
  {
    id: "stockID",
    accessorKey: "stockID",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="StockID" />
    ),
  },
  {
    id: "name",
    accessorKey: "name",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Name" />
    ),
  },
];

const SelectStocks: React.FC<Props> = ({ list, value, onChange }) => {
  const selectedItem = useMemo(
    () => list.find((v) => v.stockID == value),
    [value, list],
  );

  return (
    <TableSelect
      placeholderSearch="--Chọn kho--"
      placeholder="--Chọn kho--"
      className="w-64"
      classNamePopover="w-auto min-w-64"
      data={list}
      value={selectedItem}
      labelKey="name"
      valueKey="stockID"
      onChange={(value) => onChange(value.stockID.toString())}
      columns={STOCK_COLUMN_COMBOBOX}
    />
  );
};

export default SelectStocks;
