"use client";

import { LichSuNhapThuocDTO } from "../_utils/definitions/tra-cuu-lich-su-gia-nhap.dto";
import TraCuuLichSuGiaNhapDataTable from "./tra-cuu-lich-su-gia-nhap-datatable";

type TraCuuLichSuGiaNhapPresentationProps = {
  data: LichSuNhapThuocDTO[];
};

const TraCuuLichSuGiaNhapPresentation = ({
  data,
}: TraCuuLichSuGiaNhapPresentationProps) => {
  return <TraCuuLichSuGiaNhapDataTable data={data} />;
};
export default TraCuuLichSuGiaNhapPresentation;
