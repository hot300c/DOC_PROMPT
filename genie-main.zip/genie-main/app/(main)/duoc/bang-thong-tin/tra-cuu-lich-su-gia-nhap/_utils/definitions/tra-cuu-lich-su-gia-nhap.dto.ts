export type LichSuNhapThuocDTO = {
  productID: number;
  productName: string;
  vendorID: number;
  vendorName: string;
  ngayNhap: string;
  giaNhap: number;
};
