import { getUserSession } from "@/actions/get-user-session";
import * as httpService from "@/app/lib/network/http";
import {
  LichSuNhapThuocRESP,
  StockProductPermission,
} from "../definitions/tra-cuu-lich-su-gia-nhap.response";

export const ws_StockProductPermissons_GetNhapKho = async (
  stockID: string,
): Promise<StockProductPermission[]> => {
  const { facId } = await getUserSession();
  const response = await httpService.post("/DataAccess", [
    {
      category: "Security",
      command: "ws_StockProductPermissons_GetNhapKho",
      parameters: {
        FacID: facId,
        StockID: stockID,
        Action: 2,
      },
    },
  ]);
  return response.data.table;
};

type LichSuNhapThuocParams = {
  productID: string;
  stockID: string;
  tuNgay: string;
  denNgay: string;
};

export const ws_TraCuuNhapThuoc = async (
  params: LichSuNhapThuocParams,
): Promise<LichSuNhapThuocRESP[]> => {
  try {
    const { facId } = await getUserSession();
    const response = await httpService.post("/DataAccess", [
      {
        category: "QAHosGenericDB",
        command: "ws_TraCuuNhapThuoc",
        parameters: {
          FacID: facId,
          StockID: params.stockID,
          ProductID: params.productID,
          TuNgay: params.tuNgay,
          DenNgay: params.denNgay,
        },
      },
    ]);
    return response.data.table || [];
  } catch (error) {
    return [];
  }
};
