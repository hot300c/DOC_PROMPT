import { z } from "zod";

export const traCuuLichSuGiaNhapFormSchema = z
  .object({
    stockID: z.string().min(1),
    productID: z.string().min(1),
    tuNgay: z.string(),
    denNgay: z.string(),
  })
  .strict();

export type TraCuuLichSuGiaNhapFormValues = z.infer<
  typeof traCuuLichSuGiaNhapFormSchema
>;
