export type StockProductPermission = {
  productID: string;
  hospitalCode: string;
  hospitalName: string;
  donGiaGanNhat: number;
  donGiaQuyCachGanNhat: number;
  hospitalNameCode: string;
  formula: string;
  drugType: string;
  unitID: number;
  unitName: string;
  hangSanXuat_name: string;
  productType_Name: string;
  content: string;
  countryName: string;
  duongDung: string;
  productTypeID: number;
};

export type LichSuNhapThuocRESP = {
  productID: number;
  productName: string;
  vendorID: number;
  vendorName: string;
  ngayNhap: string;
  giaNhap: number;
};
