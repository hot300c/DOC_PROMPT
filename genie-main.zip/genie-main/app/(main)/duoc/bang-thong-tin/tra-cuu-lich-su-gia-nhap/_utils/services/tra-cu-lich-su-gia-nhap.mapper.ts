import { LichSuNhapThuocDTO } from "../definitions/tra-cuu-lich-su-gia-nhap.dto";
import { LichSuNhapThuocRESP } from "../definitions/tra-cuu-lich-su-gia-nhap.response";

export const lichSuNhapThuocRespToDto = (
  res: LichSuNhapThuocRESP,
): LichSuNhapThuocDTO => {
  return {
    productID: res.productID,
    productName: res.productName,
    vendorID: res.vendorID,
    vendorName: res.vendorName,
    ngayNhap: res.ngayNhap,
    giaNhap: Math.round(res.giaNhap),
  };
};
