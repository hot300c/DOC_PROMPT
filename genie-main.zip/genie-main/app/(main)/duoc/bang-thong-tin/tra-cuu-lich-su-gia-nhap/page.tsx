import { Suspense } from "react";
import { Loading } from "../../(base_components)/loading";
import TraCuuLichSuGiaNhapContainer from "./_components/tra-cuu-lich-su-gia-nhap-container";
import TraCuuLichSuGiaNhapFilterForm from "./_components/tra-cuu-lich-su-gia-nhap-filter-form";
import { TraCuuLichSuGiaNhapFormValues } from "./_utils/schema";
import { ws_UserStockPermissions_Get } from "../../shared/_utils/services/apis";

interface PageProps {
  searchParams: Promise<TraCuuLichSuGiaNhapFormValues>;
}

export default async function TraCuuLichSuGiaNhapPage({
  searchParams,
}: PageProps) {
  const inventoryListResp = await ws_UserStockPermissions_Get({
    actionType: 2,
    stockId: "",
  });

  const { denNgay, productID, stockID, tuNgay } = await searchParams;
  const inventoryList = inventoryListResp.map((item) => ({
    stockID: item.stockID.toString(),
    name: item.name,
  }));
  return (
    <div className="flex-1 flex flex-col space-y-2 h-full">
      <div className="flex-none">
        <TraCuuLichSuGiaNhapFilterForm inventoryList={inventoryList} />
      </div>

      <Suspense
        fallback={<Loading />}
        key={`${stockID}-${productID}-${tuNgay}-${denNgay}`}
      >
        <TraCuuLichSuGiaNhapContainer
          stockID={stockID}
          denNgay={denNgay}
          productID={productID}
          tuNgay={tuNgay}
        />
      </Suspense>
    </div>
  );
}
