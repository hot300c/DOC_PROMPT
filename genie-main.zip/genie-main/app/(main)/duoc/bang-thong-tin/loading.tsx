export { Loading as default } from "../(base_components)/loading";
