import { NotifyModelDTO } from "../_utils/definitions/bang-thong-tin.dto";
import ThongTinThuocCanHanHetHanPresentation from "./thong-tin-thuoc-can-han-het-han-presentation";
interface PageProps {
  dataCanHan: NotifyModelDTO[];
  dataHetHan: NotifyModelDTO[];
}
const ThongTinCanHanHetHanContainer = async ({
  dataCanHan,
  dataHetHan,
}: PageProps) => {
  return (
    <ThongTinThuocCanHanHetHanPresentation
      dataCanHan={dataCanHan}
      dataHetHan={dataHetHan}
    />
  );
};

export default ThongTinCanHanHetHanContainer;
