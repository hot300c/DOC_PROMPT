"use client";
import { useEffect, useState } from "react";
import { useThongTinThuocCanHanHetHanContext } from "../_context/thong-tin-thuoc-can-han-het-han-context";
import { NotifyModelDTO } from "../_utils/definitions/bang-thong-tin.dto";
import ThongTinThuocCanHanHetHanDataTable from "./thong-tin-thuoc-can-han-datatable";
type ThongTinThuocCanHanHetHanPresentationProps = {
  dataCanHan: NotifyModelDTO[];
  dataHetHan: NotifyModelDTO[];
};
const ThongTinThuocCanHanHetHanPresentation = ({
  dataCanHan,
  dataHetHan,
}: ThongTinThuocCanHanHetHanPresentationProps) => {
  const [filteredDataCanHan, setFilteredDataCanHan] =
    useState<NotifyModelDTO[]>(dataCanHan);
  const [filteredDataHetHan, setFilteredDataHetHan] =
    useState<NotifyModelDTO[]>(dataHetHan);

  const { searchText } = useThongTinThuocCanHanHetHanContext();
  useEffect(() => {
    setFilteredDataCanHan(
      dataCanHan.filter(
        (item) =>
          item.hospitalName.toLowerCase().includes(searchText.toLowerCase()) ||
          item.batch.toLowerCase().includes(searchText.toLowerCase()),
      ),
    );
    setFilteredDataHetHan(
      dataHetHan.filter(
        (item) =>
          item.hospitalName.toLowerCase().includes(searchText.toLowerCase()) ||
          item.batch.toLowerCase().includes(searchText.toLowerCase()),
      ),
    );
  }, [searchText, dataCanHan, dataHetHan]);

  return (
    <div className="flex flex-row h-full space-x-4">
      <fieldset className="border border-gray-300 p-2 rounded-md w-1/2">
        <legend className=" px-2">Hết Hạn</legend>
        <ThongTinThuocCanHanHetHanDataTable data={filteredDataHetHan} />
      </fieldset>
      <fieldset className="border border-gray-300 p-2 rounded-md w-1/2">
        <legend className=" px-2">Cận Hạn</legend>
        <ThongTinThuocCanHanHetHanDataTable data={filteredDataCanHan} />
      </fieldset>
    </div>
  );
};
export default ThongTinThuocCanHanHetHanPresentation;
