"use client";
import {
  DataTable,
  DataTableColumnHeaderSort,
} from "@/components/ui/dataTable";
import { ColumnDef } from "@tanstack/react-table";

import { DATE_FORMAT } from "@/app/lib/enums";
import { format } from "date-fns";
import { NumericFormat } from "react-number-format";
import { NotifyModelDTO } from "../_utils/definitions/bang-thong-tin.dto";

export interface ThongTinThuocCanHanHetHanDataTableProps {
  data: NotifyModelDTO[];
}

const columns: ColumnDef<NotifyModelDTO>[] = [
  {
    id: "hospitalName",
    accessorKey: "hospitalName",
    header: ({ column }) => (
      <DataTableColumnHeaderSort
        column={column}
        title="Tên thuốc"
        className="justify-start"
      />
    ),
    cell: ({ row }) => (
      <div className="text-left">{row.original.hospitalName}</div>
    ),
    enableSorting: true,
  },
  {
    id: "formula",
    accessorKey: "formula",
    header: ({ column }) => (
      <DataTableColumnHeaderSort
        column={column}
        title="Hoạt chất"
        className="justify-start"
      />
    ),
  },
  {
    id: "unitName",
    accessorKey: "unitName",
    header: ({ column }) => (
      <DataTableColumnHeaderSort
        column={column}
        title="ĐVT"
        className="justify-start"
      />
    ),
    enableSorting: true,
  },
  {
    id: "batch",
    accessorKey: "batch",
    header: ({ column }) => (
      <DataTableColumnHeaderSort
        column={column}
        title="Số lô"
        className="justify-start"
      />
    ),
    enableSorting: true,
  },
  {
    id: "avgPrice",
    accessorKey: "avgPrice",
    header: ({ column }) => (
      <DataTableColumnHeaderSort
        column={column}
        title="Đơn giá"
        className="justify-start"
      />
    ),
    cell: ({ row }) => {
      return (
        <div className="text-right">
          <NumericFormat
            className="flex-1"
            value={row.original.avgPrice}
            thousandSeparator="."
            decimalSeparator=","
            decimalScale={2}
            fixedDecimalScale
            displayType="text"
          />
        </div>
      );
    },
    enableSorting: true,
  },
  {
    id: "expDate",
    accessorKey: "expDate",
    header: ({ column }) => (
      <DataTableColumnHeaderSort
        column={column}
        title="Hạn dùng"
        className="justify-start"
      />
    ),
    cell: ({ row }) => {
      return <div>{format(row.original.expDate, DATE_FORMAT.DD_MM_YYYY)}</div>;
    },
    enableSorting: true,
  },
  {
    id: "qty",
    accessorKey: "qty",
    header: ({ column }) => (
      <DataTableColumnHeaderSort
        column={column}
        title="Tồn kho"
        className="justify-start"
      />
    ),
    cell: ({ row }) => {
      return (
        <div className="text-right">
          <NumericFormat
            className="flex-1"
            value={row.original.qty}
            thousandSeparator="."
            decimalSeparator=","
            decimalScale={4}
            fixedDecimalScale
            displayType="text"
          />
        </div>
      );
    },
    enableSorting: true,
  },
];

const ThongTinThuocCanHanHetHanDataTable: React.FC<
  ThongTinThuocCanHanHetHanDataTableProps
> = ({ data }) => {
  return (
    <div className="flex-1 flex flex-col h-full">
      <DataTable
        className="w-full border overflow-y-auto"
        columns={columns}
        data={data}
        columnVisibilityInit={{ search: false }}
        enableColumnFilter={true}
        enablePaging={false}
        enableFooter={true}
      />
    </div>
  );
};

export default ThongTinThuocCanHanHetHanDataTable;
