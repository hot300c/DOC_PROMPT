"use client";
import { Select } from "@/components/select/select";
import { Button } from "@/components/ui/button";
import { Form, FormField } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { zodResolver } from "@hookform/resolvers/zod";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { useForm } from "react-hook-form";
import { useThongTinThuocCanHanHetHanContext } from "../_context/thong-tin-thuoc-can-han-het-han-context";
import { exportNearExpiryDateTable } from "../_utils/can-han-export-excel";
import { NotifyModelDTO } from "../_utils/definitions/bang-thong-tin.dto";
import { exportExpiredTable } from "../_utils/het-han-export-excel";
import { filterFormSchema, FilterFormValues } from "../_utils/schema";

export type InventoryFilterParams = {
  stockId: string;
  expireInDays: number;
};

interface ThongTinThuocCanHanHetHanFilterFormProps {
  inventoryList: { stockID: string; name: string }[];
  dataCanHan: NotifyModelDTO[];
  dataHetHan: NotifyModelDTO[];
}

const ThongTinThuocCanHanHetHanFilterForm = ({
  inventoryList,
  dataCanHan,
  dataHetHan,
}: ThongTinThuocCanHanHetHanFilterFormProps) => {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const { searchText, setSearchText } = useThongTinThuocCanHanHetHanContext();
  const form = useForm<FilterFormValues>({
    resolver: zodResolver(filterFormSchema),
    defaultValues: {
      stockID: searchParams.get("stockID") ?? "",
      soNgay: searchParams.get("soNgay") ?? "0",
    },
  });

  function setQueryRouter(values: FilterFormValues) {
    const filteredValues = Object.fromEntries(
      Object.entries({
        ...searchParams,
        stockID: values.stockID.toString(),
        soNgay: values.soNgay.toString(),
      }).filter(([_, value]) => value),
    );
    const query = new URLSearchParams(
      filteredValues as Record<string, string>,
    ).toString();
    router.push(pathname + "?" + query);
  }

  const onSubmit = (values: FilterFormValues) => {
    setQueryRouter(values);
  };
  const onExportExcel = async () => {
    await Promise.all([
      exportNearExpiryDateTable(dataCanHan),
      exportExpiredTable(dataHetHan),
    ]);
  };

  return (
    <Form {...form}>
      <form
        className="grid grid-cols-12 gap-2 items-center"
        onSubmit={form.handleSubmit(onSubmit)}
      >
        <div className="col-span-2 flex items-center space-x-2">
          <Label className="whitespace-nowrap">Kho:</Label>
          <FormField
            control={form.control}
            name="stockID"
            render={({ field }) => (
              <Select
                className="w-full"
                classNamePopover="w-full"
                classNameSelectList="max-h-96"
                placeholder="Chọn kho"
                value={field.value}
                onChange={(value) => {
                  field.onChange(value.toString());
                }}
                options={inventoryList.map((item) => ({
                  label: item.name,
                  value: item.stockID,
                }))}
              />
            )}
          />
        </div>

        <div className="col-span-3 flex items-center space-x-2">
          <Label className="whitespace-nowrap">
            In các loại thuốc có hạn dùng trong vòng:
          </Label>
          <FormField
            control={form.control}
            name="soNgay"
            render={({ field }) => (
              <Input
                type="number"
                className="w-20"
                value={field.value}
                onChange={field.onChange}
              />
            )}
          />
          <span>ngày</span>
        </div>

        <div className="flex items-right justify-end col-span-7 space-x-2">
          <Button variant="default" onClick={onExportExcel}>
            <span className="text-sm">Xuất Excel</span>
          </Button>
        </div>

        <div className="col-span-12 flex justify-start mt-2 space-x-2">
          <Button type="submit">Xem</Button>

          <div className="flex flex-1 items-center space-x-2">
            <Label className="w-20">Tìm kiếm</Label>
            <Input
              type="search"
              placeholder="Tìm kiếm"
              className="w-full"
              onChange={(e) => setSearchText(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  setSearchText(e.currentTarget.value);
                }
              }}
              value={searchText}
            />
          </div>
        </div>
      </form>
    </Form>
  );
};

export default ThongTinThuocCanHanHetHanFilterForm;
