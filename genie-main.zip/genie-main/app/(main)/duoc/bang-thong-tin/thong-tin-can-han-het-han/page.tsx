import { Suspense } from "react";
import { Loading } from "../../(base_components)/loading";
import { ws_UserStockPermissions_Get } from "../../shared/_utils/services/apis";
import ThongTinCanHanHetHanContainer from "./_components/thong-tin-thuoc-can-han-het-han-container";
import ThongTinThuocCanHanHetHanFilterForm from "./_components/thong-tin-thuoc-can-han-het-han-filter-form";
import { ThongTinThuocCanHanHetHanProvider } from "./_context/thong-tin-thuoc-can-han-het-han-context";
import { NotifyModelDTO } from "./_utils/definitions/bang-thong-tin.dto";
import { FilterFormValues } from "./_utils/schema";
import { fetchNotifyList } from "./_utils/services/thong-tin-thuoc-can-han-het-han.api";
import { notifyModelRespToDto } from "./_utils/services/thong-tin-thuoc-can-han-het-han.mapper";

interface PageProps {
  searchParams: Promise<FilterFormValues>;
}

export default async function ThongTinCanHanHetHanPage({
  searchParams,
}: PageProps) {
  const inventoryListResp = await ws_UserStockPermissions_Get({
    actionType: 2,
    stockId: "",
  });
  const inventoryList = inventoryListResp.map((item) => ({
    stockID: item.stockID.toString(),
    name: item.name,
  }));
  const { soNgay, stockID } = await searchParams;

  let dataCanHan: NotifyModelDTO[] = [];
  let dataHetHan: NotifyModelDTO[] = [];
  if (stockID && soNgay) {
    const result = await fetchNotifyList({
      SoNgay: Number(soNgay),
      StockID: stockID,
    });
    dataCanHan = result.table1.map((item) => notifyModelRespToDto(item));
    dataHetHan = result.table.map((item) => notifyModelRespToDto(item));
  }

  return (
    <ThongTinThuocCanHanHetHanProvider>
      <div className="flex flex-col space-y-2 h-full">
        <ThongTinThuocCanHanHetHanFilterForm
          inventoryList={inventoryList}
          dataCanHan={dataCanHan}
          dataHetHan={dataHetHan}
        />
        <div className="flex-1">
          <Suspense fallback={<Loading />} key={`${stockID}-${soNgay}`}>
            <ThongTinCanHanHetHanContainer
              dataCanHan={dataCanHan}
              dataHetHan={dataHetHan}
            />
          </Suspense>
        </div>
      </div>
    </ThongTinThuocCanHanHetHanProvider>
  );
}
