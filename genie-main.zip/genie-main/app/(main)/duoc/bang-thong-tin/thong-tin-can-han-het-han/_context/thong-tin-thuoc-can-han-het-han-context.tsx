"use client";

import React, { createContext, ReactNode, useContext, useState } from "react";

type ThongTinThuocCanHanHetHanContextType = {
  searchText: string;
  setSearchText: React.Dispatch<React.SetStateAction<string>>;
};

const ThongTinThuocCanHanHetHanContext = createContext<
  ThongTinThuocCanHanHetHanContextType | undefined
>(undefined);

export const ThongTinThuocCanHanHetHanProvider: React.FC<{
  children: ReactNode;
}> = ({ children }) => {
  const [searchText, setSearchText] = useState<string>("");

  return (
    <ThongTinThuocCanHanHetHanContext.Provider
      value={{
        searchText,
        setSearchText,
      }}
    >
      {children}
    </ThongTinThuocCanHanHetHanContext.Provider>
  );
};

export const useThongTinThuocCanHanHetHanContext = () => {
  const context = useContext(ThongTinThuocCanHanHetHanContext);
  if (!context) {
    throw new Error(
      "useThongTinThuocCanHanHetHanContext must be used within a ThongTinThuocCanHanHetHanProvider",
    );
  }
  return context;
};
