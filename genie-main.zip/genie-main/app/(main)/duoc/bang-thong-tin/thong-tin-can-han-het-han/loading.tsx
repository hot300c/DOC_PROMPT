import { Loading as BaseLoading } from "../../(base_components)/loading";

export default function Loading() {
  return <BaseLoading />;
}
