import { DATE_FORMAT } from "@/app/lib/enums";
import {
  exportToExcelWithTitle,
  TableConfig,
} from "@/app/lib/utils/export-to-excel-with-header";
import { format } from "date-fns";
import { NotifyModelDTO } from "./definitions/bang-thong-tin.dto";

export const exportNearExpiryDateTable = async (data: NotifyModelDTO[]) => {
  const tableConfig: TableConfig = {
    title: "BÁO CÁO THUỐC CẬN HẠN DÙNG",
    columns: {
      "Tên thuốc": { width: 50, alignment: "left" },
      "Hoạt chất": { width: 30, alignment: "left" },
      "Đơn vị tính": { width: 20, alignment: "left" },
      "Số lô": { width: 30, alignment: "left" },
      "Đơn giá": { width: 20, alignment: "right" },
      "Hạn dùng": { width: 30, alignment: "left" },
      "Số lượng": { width: 20, alignment: "right" },
    },
    data: [
      ...data.map((row) => [
        row.hospitalName,
        row.formula ?? "",
        row.unitName,
        row.batch,
        row.avgPrice,
        format(row.expDate, DATE_FORMAT.DD_MM_YYYY_VI),
        row.qty,
      ]),
    ],
    sheetName: "Báo cáo thuốc cận hạn",
    fileName: "bao-cao-thuoc-can-han.xlsx",
  };

  await exportToExcelWithTitle(tableConfig);
};
