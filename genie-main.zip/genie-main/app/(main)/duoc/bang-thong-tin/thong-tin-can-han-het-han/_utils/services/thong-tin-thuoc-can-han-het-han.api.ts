"use server";
import { getUserSession } from "@/actions/get-user-session";
import * as httpService from "@/app/lib/network/http";
import { NotifyModelRESP } from "../definitions/bang-thong-tin.response";

type NotifyListParams = {
  SoNgay: number;
  StockID: string;
};
export const fetchNotifyList = async (
  params: NotifyListParams,
): Promise<{ table: NotifyModelRESP[]; table1: NotifyModelRESP[] }> => {
  try {
    const { facId } = await getUserSession();
    const response = await httpService.post("/DataAccess", [
      {
        category: "QAHosGenericDB",
        command: "ws_frm_notify_List",
        parameters: {
          FacID: facId,
          SoNgay: params.SoNgay,
          StockID: params.StockID,
        },
      },
    ]);
    const { table, table1 } = response.data;
    return { table, table1 };
  } catch (error) {
    return {
      table: [],
      table1: [],
    };
  }
};
