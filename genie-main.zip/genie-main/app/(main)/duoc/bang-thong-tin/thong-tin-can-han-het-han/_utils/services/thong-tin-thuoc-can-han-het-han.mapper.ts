import { NotifyModelDTO } from "../definitions/bang-thong-tin.dto";
import { NotifyModelRESP } from "../definitions/bang-thong-tin.response";

export const notifyModelRespToDto = (res: NotifyModelRESP): NotifyModelDTO => {
  return {
    hospitalName: res.hospitalName,
    hospitalCode: res.hospitalCode,
    name: res.name,
    batch: res.batch,
    expDate: res.expDate,
    qty: res.qty,
    unitName: res.unitName,
    avgPrice: res.avgPrice,
    formula: res.formula,
  };
};
