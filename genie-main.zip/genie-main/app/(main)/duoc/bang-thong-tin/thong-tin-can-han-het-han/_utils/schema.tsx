import { z } from "zod";

export const filterFormSchema = z
  .object({
    stockID: z.string().min(1),
    soNgay: z.string(),
  })
  .strict();

export type FilterFormValues = z.infer<typeof filterFormSchema>;
