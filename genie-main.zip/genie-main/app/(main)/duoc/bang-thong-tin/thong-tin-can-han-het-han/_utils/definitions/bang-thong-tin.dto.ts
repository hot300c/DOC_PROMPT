export type NotifyModelDTO = {
  hospitalName: string;
  hospitalCode: string;
  name: string;
  batch: string;
  expDate: Date;
  qty: number;
  unitName: string;
  avgPrice: number;
  formula: string;
};
