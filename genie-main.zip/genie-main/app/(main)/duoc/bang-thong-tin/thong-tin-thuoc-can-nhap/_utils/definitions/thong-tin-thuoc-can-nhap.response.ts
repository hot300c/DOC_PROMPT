export interface ProductInvQtyRESP {
  productId: number;
  stockId: number;
  facId: number;
  minQty: number;
  maxQty: number;
  productId1: number;
  facId1: number;
  hospitalCode: string;
  hospitalName: string;
  formula: string;
  unitName: string;
  qty: number;
  name: string;
}
