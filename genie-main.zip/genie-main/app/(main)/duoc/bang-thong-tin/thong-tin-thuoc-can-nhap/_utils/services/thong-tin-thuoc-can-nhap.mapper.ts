import { ProductInvQtyDTO } from "../definitions/thong-tin-thuoc-can-nhap.dto";
import { ProductInvQtyRESP } from "../definitions/thong-tin-thuoc-can-nhap.response";

export const productInvQtyRespToDto = (
  res: ProductInvQtyRESP,
): ProductInvQtyDTO => {
  return {
    minQty: res.minQty,
    maxQty: res.maxQty,
    hospitalName: res.hospitalName,
    qty: res.qty,
    name: res.name,
  };
};
