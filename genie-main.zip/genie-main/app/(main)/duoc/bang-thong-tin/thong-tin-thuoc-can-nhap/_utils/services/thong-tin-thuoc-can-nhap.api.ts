"use server";
import { getUserSession } from "@/actions/get-user-session";
import * as httpService from "@/app/lib/network/http";
import { ProductInvQtyRESP } from "../definitions/thong-tin-thuoc-can-nhap.response";

export const ws_L_ProductInvQty_LayDSCanNhap = async (
  stockID: string,
): Promise<ProductInvQtyRESP[]> => {
  try {
    const { facId } = await getUserSession();
    const response = await httpService.post("/DataAccess", [
      {
        category: "QAHosGenericDB",
        command: "ws_L_ProductInvQty_LayDSCanNhap",
        parameters: {
          FacID: facId,
          StockID: stockID,
        },
      },
    ]);
    return response.data.table || [];
  } catch (error) {
    return [];
  }
};
