export interface ProductInvQtyDTO {
  minQty: number;
  maxQty: number;
  hospitalName: string;
  qty: number;
  name: string;
}
