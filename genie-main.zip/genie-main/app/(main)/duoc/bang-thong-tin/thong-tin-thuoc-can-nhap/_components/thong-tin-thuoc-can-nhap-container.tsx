import { ProductInvQtyDTO } from "../_utils/definitions/thong-tin-thuoc-can-nhap.dto";
import { ws_L_ProductInvQty_LayDSCanNhap } from "../_utils/services/thong-tin-thuoc-can-nhap.api";
import { productInvQtyRespToDto } from "../_utils/services/thong-tin-thuoc-can-nhap.mapper";
import ThongTinThuocCanNhapPresentation from "./thong-tin-thuoc-can-nhap-presentation";

interface ThongTinThuocCanNhapContainerProps {
  stockID: string;
}
const ThongTinThuocCanNhapContainer = async ({
  stockID,
}: ThongTinThuocCanNhapContainerProps) => {
  let data: ProductInvQtyDTO[] = [];
  if (stockID) {
    const res = await ws_L_ProductInvQty_LayDSCanNhap(stockID);
    data = res.map((item) => productInvQtyRespToDto(item));
  }
  return <ThongTinThuocCanNhapPresentation data={data} />;
};

export default ThongTinThuocCanNhapContainer;
