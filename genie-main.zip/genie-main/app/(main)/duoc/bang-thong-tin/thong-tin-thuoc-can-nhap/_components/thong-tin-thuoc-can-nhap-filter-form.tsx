"use client";
import { Select } from "@/components/select/select";
import { Label } from "@/components/ui/label";
import { usePathname, useRouter, useSearchParams } from "next/navigation";

interface ThongTinThuocCanNhapFilterFormProps {
  inventoryList: { stockID: string; name: string }[];
}

const ThongTinThuocCanNhapFilterForm = ({
  inventoryList,
}: ThongTinThuocCanNhapFilterFormProps) => {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();

  function setQueryRouter(stockID: String) {
    const filteredValues = Object.fromEntries(
      Object.entries({
        ...searchParams,
        stockID: stockID,
      }).filter(([_, value]) => value),
    );
    const query = new URLSearchParams(
      filteredValues as Record<string, string>,
    ).toString();
    router.push(pathname + "?" + query);
  }

  return (
    <div className="col-span-2 flex items-center space-x-2">
      <Label className="whitespace-nowrap">Kho:</Label>
      <Select
        className="w-70"
        classNamePopover="w-full"
        classNameSelectList="max-h-96"
        placeholder="Chọn kho"
        value={searchParams.get("stockID") ?? ""}
        onChange={(value) => {
          setQueryRouter(value);
        }}
        options={inventoryList.map((item) => ({
          label: item.name,
          value: item.stockID,
        }))}
      />
    </div>
  );
};

export default ThongTinThuocCanNhapFilterForm;
