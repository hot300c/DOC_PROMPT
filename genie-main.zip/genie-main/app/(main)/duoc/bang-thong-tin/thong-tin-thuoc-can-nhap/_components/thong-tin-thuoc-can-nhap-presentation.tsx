"use client";
import { exportToExcel, TableConfig } from "@/app/lib/utils/exportToExcel ";
import { Button } from "@/components/ui/button";
import { ProductInvQtyDTO } from "../_utils/definitions/thong-tin-thuoc-can-nhap.dto";
import ThongTinThuocCanNhapDataTable from "./thong-tin-thuoc-can-nhap-datatable";
type ThongTinThuocCanNhapPresentationProps = {
  data: ProductInvQtyDTO[];
};
const ThongTinThuocCanNhapPresentation = ({
  data,
}: ThongTinThuocCanNhapPresentationProps) => {
  const handleExportExcel = async () => {
    const tableConfig: TableConfig = {
      columns: {
        "Tên sản phẩm": { width: 50, alignment: "left" },
        Kho: { width: 50, alignment: "left" },
        "SL Tối Thiểu": { width: 30, alignment: "left" },
        "SL Tồn Kho": { width: 30, alignment: "left" },
      },
      data:
        data && data.length > 0
          ? data.map((row) => [row.hospitalName, row.name, row.minQty, row.qty])
          : [],

      sheetName: "DanhSachThongTinThuocCanNhap",
      fileName: "DanhSachThongTinThuocCanNhap.xlsx",
    };
    await exportToExcel(tableConfig);
  };
  return (
    <div className="flex flex-col h-full">
      <ThongTinThuocCanNhapDataTable data={data} />
      <Button
        variant="outline"
        className="w-20 px-2 py-1 rounded text-center"
        onClick={handleExportExcel}
      >
        Excel
      </Button>
    </div>
  );
};
export default ThongTinThuocCanNhapPresentation;
