"use client";
import {
  DataTable,
  DataTableColumnHeaderSort,
} from "@/components/ui/dataTable";
import { ColumnDef } from "@tanstack/react-table";

import { ProductInvQtyDTO } from "../_utils/definitions/thong-tin-thuoc-can-nhap.dto";

export interface ThongTinThuocCanNhapDataTableProps {
  data: ProductInvQtyDTO[];
}

const columns: ColumnDef<ProductInvQtyDTO>[] = [
  {
    id: "hospitalName",
    accessorKey: "hospitalName",
    header: ({ column }) => (
      <DataTableColumnHeaderSort
        column={column}
        title="Tên sản phẩm"
        className="justify-start"
      />
    ),
    enableSorting: true,
  },
  {
    id: "name",
    accessorKey: "name",
    header: ({ column }) => (
      <DataTableColumnHeaderSort
        column={column}
        title="Kho"
        className="justify-start"
      />
    ),
  },
  {
    id: "minQty",
    accessorKey: "minQty",
    header: ({ column }) => (
      <DataTableColumnHeaderSort
        column={column}
        title="SL Tối thiểu"
        className="justify-start"
      />
    ),
    enableSorting: true,
  },
  {
    id: "qty",
    accessorKey: "qty",
    header: ({ column }) => (
      <DataTableColumnHeaderSort
        column={column}
        title="SL tồn kho"
        className="justify-start"
      />
    ),
    enableSorting: true,
  },
];

const ThongTinThuocCanNhapDataTable: React.FC<
  ThongTinThuocCanNhapDataTableProps
> = ({ data }) => {
  return (
    <div className="flex-1 flex flex-col h-full">
      <DataTable
        className="w-full border overflow-y-auto"
        columns={columns}
        data={data}
        placeholderSearch="Nhập để tìm kiếm..."
        columnVisibilityInit={{ search: false }}
        enableColumnFilter={true}
        enableGlobalFilter={true}
        enablePaging={false}
        enableFooter={true}
      />
    </div>
  );
};

export default ThongTinThuocCanNhapDataTable;
