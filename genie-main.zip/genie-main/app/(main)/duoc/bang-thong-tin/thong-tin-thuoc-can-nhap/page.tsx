import { Suspense } from "react";
import { Loading } from "../../(base_components)/loading";
import { FilterFormValues } from "../thong-tin-can-han-het-han/_utils/schema";
import ThongTinThuocCanNhapContainer from "./_components/thong-tin-thuoc-can-nhap-container";
import ThongTinThuocCanNhapFilterForm from "./_components/thong-tin-thuoc-can-nhap-filter-form";
import { ws_UserStockPermissions_Get } from "../../shared/_utils/services/apis";

interface PageProps {
  searchParams: Promise<FilterFormValues>;
}

export default async function ThongTinThuocCanNhapPage({
  searchParams,
}: PageProps) {
  const inventoryListResp = await ws_UserStockPermissions_Get({
    actionType: 2,
    stockId: "",
  });
  const inventoryList = inventoryListResp.map((item) => ({
    stockID: item.stockID.toString(),
    name: item.name,
  }));
  const { stockID } = await searchParams;
  return (
    <div className="flex flex-col space-y-2 h-full">
      <ThongTinThuocCanNhapFilterForm inventoryList={inventoryList} />  
      <div className="flex-1">
        <Suspense fallback={<Loading />} key={`${stockID}`}>
          <ThongTinThuocCanNhapContainer stockID={stockID} />
        </Suspense>
      </div>
    </div>
  );
}
