import { redirect } from "next/navigation";

export default function Page() {
  redirect("/duoc/bang-thong-tin/thong-tin-can-han-het-han");
}
