import { z } from "zod";

export const FormFilterSchema = z.object({
  fromDate: z
    .string({
      required_error: "Vui lòng chọn ngày",
    })
    .min(1, { message: "Vui lòng chọn ngày" }),
  toDate: z
    .string({
      required_error: "Vui lòng chọn ngày",
    })
    .min(1, { message: "Vui lòng chọn ngày" }),
  stockId: z.string({
    required_error: "Vui lòng chọn kho",
  }),
  facId: z.string({
    required_error: "Vui lòng chọn cơ sở",
  }),
});

export type FormFilterParams = z.infer<typeof FormFilterSchema>;
