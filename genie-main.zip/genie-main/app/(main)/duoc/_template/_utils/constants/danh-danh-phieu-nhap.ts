export const ACTION_TYPE = 12;
