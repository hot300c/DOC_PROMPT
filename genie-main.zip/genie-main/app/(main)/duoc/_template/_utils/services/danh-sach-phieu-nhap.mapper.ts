import { formatCurrency } from "@/app/lib/utils";
import { format } from "date-fns";
import {
  ImportInfoDetailDTO,
  ImportInfoDTO,
  ReportModel,
} from "../definitions/danh-sach-phieu-nhap.dto";
import {
  ImportVoucherDetailRESP,
  ImportVoucherRESP,
} from "../definitions/danh-sach-phieu-nhap.response";

export const importVoucherRespToDto = (
  res: ImportVoucherRESP,
): ImportInfoDTO => {
  return {
    approvalDate: res.ngayDuyet ? format(res.ngayDuyet, "dd/MM/yyyy") : "",
    approver: res.nguoiDuyet,
    contractNumber: res.soHD,
    importer: res.nguoiNhap,
    importType: res.inTypeName,
    importWarehouse: res.khoNhap_Name,
    isInconstant: res.batThuong,
    isPaidDept: res.daTraCongNo,
    provider: res.vendorName,
    serial: res.serial,
    totalMoney: res.tongTien,
    totalRemainingMoney: res.tongTienChuaCK,
    voucherCode: res.approvedInNo,
    approvedInID: res.approvedInID,
  };
};

export const importVoucherDetailRespToDto = (
  res: ImportVoucherDetailRESP,
): ImportInfoDetailDTO => {
  return {
    amountAfterDiscount: res.total,
    amountBeforeDiscount: res.thanhTienTruocCK,
    conversionAmount: res.soSachQty,
    conversionSalePrice: formatCurrency(res.priceImportNotVat),
    discount: res.tienCK,
    expiredDate: res.expDate ? format(res.expDate, "dd/MM/yyyy") : "",
    lot: res.batch,
    productCode: res.hospitalCode,
    productName: res.hospitalName,
    registerNumber: res.soDangKi,
    salePrice: formatCurrency(res.price),
    sense: res.camQuan,
    temperature: res.nhietDoVaccine,
    totalVat: res.tongVAT,
    unit: res.unitName,
    vat: res.vat,
    vatSalePrice: formatCurrency(res.importPriceVAT),
    importedAmount: res.realQty,
  };
};

export const deserializeReportModel = (jsonString: string): ReportModel[] => {
  return JSON.parse(jsonString) as ReportModel[];
};
