import { TableConfig } from "@/app/lib/utils/exportToExcel ";
import { ImportInfoDTO } from "../definitions/danh-sach-phieu-nhap.dto";

export const getExcelTableConfig = (
  data: ImportInfoDTO[],
  fileName: string,
): TableConfig => {
  const tableConfig: TableConfig = {
    columns: {
      STT: { width: 10, alignment: "center" },
      "Loại nhập": { width: 50, alignment: "center" },
      "Mã phiếu": { width: 60, alignment: "center" },
      "Kho nhập": { width: 40, alignment: "left" },
      "Nhà cung cấp": { width: 40, alignment: "left" },
      "Số HĐ": { width: 30, alignment: "left" },
      Serial: { width: 30, alignment: "left" },
      "Người nhập": { width: 30, alignment: "left" },
      "Người duyệt": { width: 30, alignment: "left" },
      "Ngày duyệt": { width: 30, alignment: "left" },
      "Tổng tiền chưa CK": { width: 30, alignment: "left", format: "currency" },
      "Tổng tiền": { width: 30, alignment: "left", format: "currency" },
      "Đã trả công nợ": { width: 30, alignment: "left" },
      "Bất thường": { width: 30, alignment: "left" },
    },
    data:
      data && data.length > 0
        ? data.map((row, index) => [
            index + 1,
            row.importType,
            row.voucherCode,
            row.importWarehouse,
            row.provider,
            row.contractNumber,
            row.serial,
            row.importer,
            row.approver,
            row.approvalDate,
            row.totalRemainingMoney,
            row.totalMoney,
            row.isPaidDept ? "Chưa trả công nợ" : "Đã trả công nợ",
            row.isInconstant ? "Có" : "Không",
          ])
        : [],
    sheetName: fileName,
    fileName: fileName + ".xlsx",
  };
  return tableConfig;
};
