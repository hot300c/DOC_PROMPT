import * as httpService from "@/app/lib/network/http";
import {
  ImportListREQ,
  ImportVoucherDetailREQ,
  InOutTypeStockReportREQ,
  InventoryStockListREQ,
} from "../definitions/danh-sach-phieu-nhap.request";
import {
  ImportVoucherDetailRESP,
  ImportVoucherRESP,
  InOutTypeStockReportRESP,
  InventoryStockRESP,
} from "../definitions/danh-sach-phieu-nhap.response";
import { getUserSession } from "@/actions/get-user-session";
import { cachePost } from "@/app/lib/network/cache-http";

export const fetchInventoryStockList = async (
  req: InventoryStockListREQ,
): Promise<InventoryStockRESP[]> => {
  const data = await cachePost({
    url: "/DataAccess",
    payload: [
      {
        category: "QAHosGenericDB",
        command: "ws_L_InventoryStock_List",
        parameters: {
          FacID: req.facId,
          ActionType: req.actionType,
        },
      },
    ],
    cacheKey: `inventory-stock-list-${req.facId}-${req.actionType}`,
    ttl: 3600,
  });
  return data.table;
};

export const fetchImportListByRule = async (
  req: ImportListREQ,
): Promise<ImportVoucherRESP[]> => {
  const { facId } = await getUserSession();
  const response = await httpService.post("/DataAccess", [
    {
      category: "QAHosGenericDB",
      command: "ws_INV_ApprovedIn_LayDanhSachPhieuNhapTheoQuyen",
      parameters: {
        FacID: facId,
        FromDate: req.fromDate,
        ThruDate: req.toDate,
        StockID: req.stockId,
      },
    },
  ]);
  return response.data.table;
};

export const fetchImportVoucherDetail = async (
  req: ImportVoucherDetailREQ,
): Promise<ImportVoucherDetailRESP[]> => {
  const response = await httpService.post("/DataAccess", [
    {
      category: "QAHosGenericDB",
      command: "ws_INV_ApprovedInDetail_GetChiTietPhieu",
      parameters: {
        ApprovedInID: req.approvedInId,
        FacID: req.facId,
      },
    },
  ]);
  return response.data.table;
};

export const ws_L_INVInOutTypeStockLink_GetReportInID = async (
  req: InOutTypeStockReportREQ,
): Promise<InOutTypeStockReportRESP> => {
  const { facId,customerId } = await getUserSession();
  const response = await httpService.post("/DataAccess", [
    {
      category: "QAHosGenericDB",
      command: "ws_L_INVInOutTypeStockLink_GetReportInID",
      parameters: {
        ApprovedInID: req.approvedInId,
        FacID: facId,
        CustomerID: customerId,
      },
    },
  ]);
  return response.data.table[0];
};
