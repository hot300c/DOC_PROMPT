export type InventoryStockListREQ = {
  facId: string;
  actionType: number;
};

export type ImportListREQ = {
  facId: string;
  fromDate: string;
  toDate: string;
  stockId: string;
};

export type ImportVoucherDetailREQ = {
  approvedInId: string;
  facId: string;
};

export type InOutTypeStockReportREQ = {
  approvedInId: string;
  facId: string;
  customerId: string;
};
