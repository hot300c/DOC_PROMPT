export type ImportInfoDTO = {
  importType: string;
  voucherCode: string;
  importWarehouse: string;
  provider: string;
  contractNumber: string;
  serial: string;
  importer: string;
  approver: string;
  approvalDate: string;
  totalRemainingMoney: number;
  totalMoney: number;
  isPaidDept: boolean;
  isInconstant: boolean;
  approvedInID: string;
};

export type ImportInfoDetailDTO = {
  productCode: string;
  productName: string;
  unit: string;
  lot: string;
  expiredDate: string;
  salePrice: string;
  conversionAmount: number;
  conversionSalePrice: string;
  vat: number;
  vatSalePrice: string;
  totalVat: number;
  amountBeforeDiscount: number;
  discount: number;
  amountAfterDiscount: number;
  temperature: string;
  registerNumber: string;
  sense: boolean;
  importedAmount: number;
};

export type ReportModel = {
  ReportID: string;
  ReportCaption: string;
};
