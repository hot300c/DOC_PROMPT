import { FormFilterParams } from "./_utils/schemas/form-filter";
import Template from "./template";

export default async function Page(
  props: {
    searchParams?: Promise<FormFilterParams>;
  }
) {
  const searchParams = await props.searchParams;
  return <Template searchParams={searchParams} />;
}
