import { getUserSession } from "@/actions/get-user-session";
import { format } from "date-fns";
import DataContainer from "./_components/data-container";
import FormFilter from "./_components/form-filter";
import { ACTION_TYPE } from "./_utils/constants/danh-danh-phieu-nhap";
import { InventoryStockRESP } from "./_utils/definitions/danh-sach-phieu-nhap.response";
import { FormFilterParams } from "./_utils/schemas/form-filter";
import { fetchInventoryStockList } from "./_utils/services/danh-sach-phieu-nhap.api";

export type TemplateProps = {
  searchParams?: FormFilterParams;
};
const Template = async ({ searchParams }: TemplateProps) => {
  const currentUser = await getUserSession();
  let inventoryList: InventoryStockRESP[] = [];
  if (currentUser.facId) {
    inventoryList = await fetchInventoryStockList({
      actionType: ACTION_TYPE,
      facId: currentUser.facId,
    });
  }

  const defaultFilterValue: FormFilterParams = {
    fromDate: searchParams?.fromDate ?? format(new Date(), "yyyy-MM-dd"),
    toDate: searchParams?.toDate ?? format(new Date(), "yyyy-MM-dd"),
    stockId:
      searchParams?.stockId ?? inventoryList?.[0]?.stockID?.toString() ?? "",
    facId: searchParams?.facId ?? currentUser.facId ?? "",
  };

  return (
    <div className="flex flex-col overflow-y-hidden w-full h-[calc(100vh-40px)] space-y-2">
      <FormFilter filter={defaultFilterValue} list={inventoryList} />
      <DataContainer searchParams={searchParams} />
    </div>
  );
};

export default Template;
