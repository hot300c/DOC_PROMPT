import { Suspense } from "react";
import { ImportInfoDTO } from "../_utils/definitions/danh-sach-phieu-nhap.dto";
import { FormFilterParams } from "../_utils/schemas/form-filter";
import { fetchImportListByRule } from "../_utils/services/danh-sach-phieu-nhap.api";
import { importVoucherRespToDto } from "../_utils/services/danh-sach-phieu-nhap.mapper";
import Loading from "./loading";
import Presentation from "./presentation";

export type DataContainerProps = {
  searchParams?: FormFilterParams;
};
const DataContainer = async ({ searchParams }: DataContainerProps) => {
  let importList: ImportInfoDTO[] = [];
  if (
    searchParams?.facId &&
    searchParams?.fromDate &&
    searchParams?.stockId &&
    searchParams?.toDate
  ) {
    const response = await fetchImportListByRule({
      facId: searchParams.facId,
      fromDate: searchParams.fromDate,
      stockId: searchParams.stockId,
      toDate: searchParams.toDate,
    });
    importList = response
      ? response.map((item) => importVoucherRespToDto(item))
      : [];
  }
  return (
    <Suspense fallback={<Loading />}>
      <Presentation data={importList} />
    </Suspense>
  );
};

export default DataContainer;
