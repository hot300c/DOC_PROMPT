import { formatCurrency } from "@/app/lib/utils";
import { Label } from "@/components/ui/label";

export type FooterProps = {
  voucherCodeCount: number;
  totalRemainingMoney: number;
  totalMoney: number;
};
const Footer = ({
  voucherCodeCount,
  totalRemainingMoney,
  totalMoney,
}: FooterProps) => {
  return (
    <div className="flex items-center md:px-28 px-2  py-3 justify-between">
      <Label className="p-2 bg-muted">Tổng số phiếu: {voucherCodeCount}</Label>
      <div className="flex space-x-3 items-center">
        <Label className="p-2 bg-muted">
          Tổng tiền chưa CK: {formatCurrency(totalRemainingMoney)}
        </Label>
        <Label className="p-2 bg-muted">
          Tổng tiền: {formatCurrency(totalMoney)}
        </Label>
      </div>
    </div>
  );
};

export default Footer;
