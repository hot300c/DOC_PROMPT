"use client";
import { InputDatePicker } from "@/components/input-date-picker";
import { Select } from "@/components/select/select";
import { Button } from "@/components/ui/button";
import { Form, FormField } from "@/components/ui/form";
import { Label } from "@/components/ui/label";
import { format } from "date-fns";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { InventoryStockRESP } from "../_utils/definitions/danh-sach-phieu-nhap.response";
import {
  FormFilterParams,
  FormFilterSchema,
} from "../_utils/schemas/form-filter";
import { zodResolver } from "@hookform/resolvers/zod";
import { useEffect, useMemo } from "react";
import { SelectOption } from "@/components/select/select-list";

export type FormFilterProps = {
  filter: FormFilterParams;
  list: InventoryStockRESP[];
};

const FormFilter = ({ filter, list: inventoryList }: FormFilterProps) => {
  const router = useRouter();

  const stockOptions = useMemo(() => {
    return inventoryList.map(
      (item) =>
        ({
          label: item.aliasName,
          value: item.stockID.toString(),
        }) as SelectOption,
    );
  }, [inventoryList]);

  const form = useForm<FormFilterParams>({
    resolver: zodResolver(FormFilterSchema),
    defaultValues: filter,
  });

  const onSubmit = (values: FormFilterParams) => {
    const filteredValues: FormFilterParams = Object.assign({}, filter, {
      fromDate: format(new Date(values.fromDate), "yyyy-MM-dd"),
      toDate: format(new Date(values.toDate), "yyyy-MM-dd"),
      stockId: values.stockId,
      facId: values.facId,
    });
    const query = new URLSearchParams(filteredValues).toString();
    router.push("?" + query);
  };

  useEffect(() => {
    // We use window.location.search to check the search parameters because using useSearchParams from Next.js
    // causes unnecessary re-renders.
    if (window.location.search.length === 0) {
      const query = new URLSearchParams(filter).toString();
      router.replace("?" + query);
    }
  }, [filter, router]);

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="p-2">
        <div className="grid grid-cols-12 gap-2">
          <div className="col-span-12 grid grid-cols-12">
            <div className="col-span-2 flex items-center space-x-3">
              <div className="flex items-center flex-1">
                <Label className="whitespace-nowrap w-15">Từ ngày</Label>
                <FormField
                  control={form.control}
                  name="fromDate"
                  render={({ field }) => (
                    <InputDatePicker
                      value={new Date(field.value)}
                      onChange={(date) => {
                        if (date) {
                          field.onChange(format(date, "yyyy/MM/dd"));
                        }
                      }}
                    />
                  )}
                />
              </div>
              <div className="flex items-center flex-1">
                <Label className="whitespace-nowrap w-15">Đến ngày</Label>
                <FormField
                  control={form.control}
                  name="toDate"
                  render={({ field }) => (
                    <InputDatePicker
                      value={new Date(field.value)}
                      onChange={(date) => {
                        if (date) {
                          field.onChange(format(date, "yyyy/MM/dd"));
                        }
                      }}
                    />
                  )}
                />
              </div>
            </div>
          </div>
          <div className="col-span-3 flex items-center">
            <Label className="whitespace-nowrap w-19">Kho nhập</Label>
            <FormField
              control={form.control}
              name="stockId"
              render={({ field }) => (
                <Select
                  className="w-full"
                  value={field.value}
                  classNamePopover="w-90"
                  onChange={(value) => {
                    field.onChange(value);
                  }}
                  options={stockOptions}
                />
              )}
            />
          </div>
          <Button className="w-fit" variant="outline">
            Xem
          </Button>
        </div>
      </form>
    </Form>
  );
};

export default FormFilter;
