"use client";
import { getUserSession } from "@/actions/get-user-session";
import { PaperSize } from "@/app/lib/enums";
import { notifyWarning, runReport } from "@/app/lib/utils";
import { exportToExcel } from "@/app/lib/utils/exportToExcel ";
import { selectBaseSetting } from "@/redux/selectors";
import { useAppSelector } from "@/redux/store";
import { useState } from "react";
import { ImportInfoDTO } from "../_utils/definitions/danh-sach-phieu-nhap.dto";
import { ws_L_INVInOutTypeStockLink_GetReportInID } from "../_utils/services/danh-sach-phieu-nhap.api";
import { deserializeReportModel } from "../_utils/services/danh-sach-phieu-nhap.mapper";
import { getExcelTableConfig } from "../_utils/services/danh-sach-phieu-nhap.utils";
import Actions from "./actions";
import Table from "./table";

export type PresentationProps = {
  data: ImportInfoDTO[];
};

const Presentation = ({ data }: PresentationProps) => {
  const baseSettings = useAppSelector(selectBaseSetting);
  const onExportData = async () => {
    const tableConfig = getExcelTableConfig(data, "warehouse_list");
    await exportToExcel(tableConfig);
  };
  const [selectedRow, setSelectedRow] = useState<ImportInfoDTO | undefined>(
    undefined,
  );
  const onPrint = async () => {
    const currentUser = await getUserSession();
    if (currentUser.facId && selectedRow?.approvedInID) {
      const response = await ws_L_INVInOutTypeStockLink_GetReportInID({
        approvedInId: selectedRow?.approvedInID,
        customerId: currentUser.customerId,
        facId: currentUser.facId,
      });
      if (response) {
        const reportModels = deserializeReportModel(
          response.reportID_PhieuNhap,
        );
        if (reportModels && reportModels.length > 0) {
          reportModels.map((item) => {
            // TODO (https://rm.vnvc.info/issues/89928): Fix and remove eslint-disable-next-line comment
            // eslint-disable-next-line @typescript-eslint/no-floating-promises
            runReport(
              item.ReportID,
              currentUser.facId,
              {
                ApprovedInID: selectedRow.approvedInID,
                FacID: currentUser.facId,
              },
              baseSettings,
              true,
              PaperSize.A4,
              true,
            );
          });
        } else {
          notifyWarning(
            "Vui lòng cấu hình ReportID_Phiếu nhập của loại xuất này",
          );
        }
      }
    }
  };
  return (
    <div className="w-full flex flex-col overflow-hidden flex-1 overflow-y-hidden">
      <Table data={data} className="flex-1" onRowClick={setSelectedRow} />
      <Actions onExportExcel={onExportData} onPrint={onPrint} />
    </div>
  );
};

export default Presentation;
