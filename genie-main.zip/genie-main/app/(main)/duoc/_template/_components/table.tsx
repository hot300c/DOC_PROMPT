import { compareInclude, formatCurrency } from "@/app/lib/utils";
import { Checkbox } from "@/components/ui/checkbox";
import {
  DataTable,
  DataTableColumnHeaderSort,
} from "@/components/ui/dataTable";
import { ColumnDef, Row } from "@tanstack/react-table";
import { useMemo, useState } from "react";
import { ImportInfoDTO } from "../_utils/definitions/danh-sach-phieu-nhap.dto";
import Footer from "./footer";
import DetailModal from "./detail-modal";

const globalFilterFn = (
  row: Row<ImportInfoDTO>,
  columnId: string,
  filterValue: string,
) => {
  if (
    columnId === "importType" ||
    columnId === "voucherCode" ||
    columnId === "importWarehouse" ||
    columnId === "provider" ||
    columnId === "importer" ||
    columnId === "approver"
  ) {
    const originalValue = String(row.original[columnId as keyof ImportInfoDTO]);
    return compareInclude(filterValue, originalValue);
  }
  return false;
};

const columnDefs: ColumnDef<ImportInfoDTO>[] = [
  {
    id: "importType",
    accessorKey: "importType",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Loại nhập" />
    ),
  },
  {
    id: "voucherCode",
    accessorKey: "voucherCode",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Mã phiếu" />
    ),
  },
  {
    id: "importWarehouse",
    accessorKey: "importWarehouse",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Kho nhập" />
    ),
  },
  {
    id: "provider",
    accessorKey: "provider",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Nhà cung cấp" />
    ),
  },
  {
    id: "contractNumber",
    accessorKey: "contractNumber",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Số HĐ" />
    ),
  },
  {
    id: "serial",
    accessorKey: "serial",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Serial" />
    ),
  },
  {
    id: "importer",
    accessorKey: "importer",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Người nhập" />
    ),
  },
  {
    id: "approver",
    accessorKey: "approver",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Người duyệt" />
    ),
  },
  {
    id: "approvalDate",
    accessorKey: "approvalDate",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Ngày duyệt" />
    ),
    sortingFn: "datetime",
  },
  {
    id: "totalRemainingMoney",
    accessorKey: "totalRemainingMoney",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Tổng tiền chưa CK" />
    ),
    cell: ({ row }) => {
      return <p>{formatCurrency(row.original.totalRemainingMoney)}</p>;
    },
  },
  {
    id: "totalMoney",
    accessorKey: "totalMoney",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Tổng tiền" />
    ),
    cell: ({ row }) => {
      return <p>{formatCurrency(row.original.totalMoney)}</p>;
    },
  },
  {
    id: "isPaidDept",
    accessorKey: "isPaidDept",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Đã trả công nợ" />
    ),
    cell: ({ row }) => {
      return (
        <Checkbox
          defaultChecked={row.original.isPaidDept}
          disabled
          className="p-0"
        />
      );
    },
  },
  {
    id: "isInconstant",
    accessorKey: "isInconstant",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Bất thường" />
    ),
    cell: ({ row }) => {
      return (
        <Checkbox
          defaultChecked={row.original.isInconstant}
          disabled
          className="p-0"
        />
      );
    },
  },
];

export type DanhSachPhieuNhapTableProps = {
  className?: string;
  data: ImportInfoDTO[];
  onRowClick: (row: ImportInfoDTO) => void;
};
const Table = ({
  className,
  data,
  onRowClick,
}: DanhSachPhieuNhapTableProps) => {
  const summary = useMemo(() => {
    return data.reduce(
      (acc, item) => {
        acc.totalRemainingMoney += item.totalRemainingMoney;
        acc.totalMoney += item.totalMoney;
        acc.totalVoucherCode += 1;
        return acc;
      },
      {
        totalRemainingMoney: 0,
        totalMoney: 0,
        totalVoucherCode: 0,
      },
    );
  }, [data]);

  const [isOpen, setOpen] = useState(false);
  const [selectedRow, setSelectedRow] = useState<ImportInfoDTO | undefined>(
    undefined,
  );
  const onDetailModalClosed = () => {
    setOpen(false);
  };
  return (
    <div className="flex flex-col overflow-y-hidden flex-1">
      <DataTable
        className={`max-h-[95%] w-full overflow-y-auto border flex-1 ${className}`}
        tHeadClass="z-40"
        tRowClass="cursor-pointer"
        data={data}
        columns={columnDefs}
        enablePaging={false}
        enableColumnFilter={false}
        enableGlobalFilter={true}
        placeholderSearch="Nhập loại nhập/mã phiếu/kho nhập/nhà cung cấp/người nhập/người duyệt"
        globalFilterFn={globalFilterFn}
        onRowDoubleClick={(row) => {
          setOpen(true);
          setSelectedRow(row);
        }}
        onRowClick={onRowClick}
      />
      {isOpen && selectedRow && (
        <DetailModal
          isOpen={isOpen}
          onClosed={onDetailModalClosed}
          approvalInId={selectedRow.approvedInID}
        />
      )}
      <Footer
        voucherCodeCount={summary.totalVoucherCode}
        totalRemainingMoney={summary.totalRemainingMoney}
        totalMoney={summary.totalMoney}
      />
    </div>
  );
};

export default Table;
