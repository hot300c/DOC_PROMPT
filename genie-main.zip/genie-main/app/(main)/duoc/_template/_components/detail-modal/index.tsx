import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { selectFaculty } from "@/redux/selectors";
import { useAppSelector } from "@/redux/store";
import useSWR from "swr";
import { fetchImportVoucherDetail } from "../../_utils/services/danh-sach-phieu-nhap.api";
import { importVoucherDetailRespToDto } from "../../_utils/services/danh-sach-phieu-nhap.mapper";
import Presentation from "./presentation";

export type DetailModalProps = {
  isOpen: boolean;
  onClosed: () => void;
  approvalInId: string;
};
const DetailModal = ({ isOpen, onClosed, approvalInId }: DetailModalProps) => {
  const faculty = useAppSelector(selectFaculty);
  const { data: importVoucherDetail } = useSWR(
    faculty.facId && approvalInId
      ? {
          url: "PatientService.fetchPatientExaminationHistory",
          payload: {
            approvedInId: approvalInId,
            facId: faculty.facId,
          },
        }
      : null,
    async ({ payload }) => {
      const response = await fetchImportVoucherDetail(payload);
      return response?.map((item) => importVoucherDetailRespToDto(item)) ?? [];
    },
  );
  return (
    <Dialog open={isOpen} onOpenChange={onClosed}>
      <DialogContent
        className="bg-white min-w-[90%] flex flex-col justify-start items-start h-[98vh]"
        aria-describedby={undefined}
      >
        <DialogHeader className="w-full">
          <DialogTitle className="text-lg">Chi tiết phiếu nhập</DialogTitle>
        </DialogHeader>
        <Presentation
          approvalInId={approvalInId}
          data={importVoucherDetail ?? []}
        />
      </DialogContent>
    </Dialog>
  );
};

export default DetailModal;
