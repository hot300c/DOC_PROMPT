import { formatCurrency, formatCurrencyVND } from "@/app/lib/utils";
import { Checkbox } from "@/components/ui/checkbox";
import {
  DataTable,
  DataTableColumnHeaderSort,
} from "@/components/ui/dataTable";
import { ColumnDef } from "@tanstack/react-table";
import { ImportInfoDetailDTO } from "../../_utils/definitions/danh-sach-phieu-nhap.dto";

export type DetailTableProps = {
  className?: string;
  data: ImportInfoDetailDTO[];
};

const columnDefs: ColumnDef<ImportInfoDetailDTO>[] = [
  {
    id: "productCode",
    accessorKey: "productCode",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Mã SP" />
    ),
  },
  {
    id: "productName",
    accessorKey: "productName",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Tên sản phẩm" />
    ),
  },
  {
    id: "unit",
    accessorKey: "unit",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="ĐVT" />
    ),
  },
  {
    id: "lot",
    accessorKey: "lot",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Lô" />
    ),
  },
  {
    id: "expiredDate",
    accessorKey: "expiredDate",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Hạn dùng" />
    ),
  },
  {
    id: "salePrice",
    accessorKey: "salePrice",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Đơn giá" />
    ),
  },
  {
    id: "conversionAmount",
    accessorKey: "conversionAmount",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="SL quy đổi" />
    ),
  },
  {
    id: "conversionSalePrice",
    accessorKey: "conversionSalePrice",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Đơn giá quy đổi" />
    ),
  },
  {
    id: "importedAmount",
    accessorKey: "importedAmount",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Thực nhập" />
    ),
  },
  {
    id: "vat",
    accessorKey: "vat",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="VAT" />
    ),
  },
  {
    id: "vatSalePrice",
    accessorKey: "vatSalePrice",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Đơn giá VAT" />
    ),
  },
  {
    id: "totalVat",
    accessorKey: "totalVat",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Tổng VAT" />
    ),
    cell: ({ row }) => {
      return <p>{formatCurrency(row.original.totalVat)}</p>;
    },
  },

  {
    id: "amountBeforeDiscount",
    accessorKey: "amountBeforeDiscount",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="TT trước CK" />
    ),
    cell: ({ row }) => (
      <p>{formatCurrency(row.original.amountBeforeDiscount)}</p>
    ),
  },
  {
    id: "discount",
    accessorKey: "discount",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Chiết khấu" />
    ),
  },
  {
    id: "amountAfterDiscount",
    accessorKey: "amountAfterDiscount",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="TT sau CK" />
    ),
    cell: ({ row }) => (
      <p>{formatCurrencyVND(row.original.amountAfterDiscount)}</p>
    ),
  },
  {
    id: "temperature",
    accessorKey: "temperature",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Nhiệt độ" />
    ),
  },
  {
    id: "registerNumber",
    accessorKey: "registerNumber",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Sổ đăng ký" />
    ),
  },
  {
    id: "sense",
    accessorKey: "sense",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Cảm quan" />
    ),
    cell: ({ row }) => (
      <Checkbox className="ml-3" checked={row.original.sense} disabled={true} />
    ),
  },
];

const DetailTable = ({ className, data }: DetailTableProps) => {
  return (
    <div className="flex flex-col flex-1 overflow-y-hidden">
      <DataTable
        className={`w-full flex-1 overflow-y-auto border ${className}`}
        tHeadClass="z-40"
        tRowClass="cursor-pointer"
        data={data}
        columns={columnDefs}
        enablePaging={false}
        enableColumnFilter={false}
        enableGlobalFilter={false}
      />
    </div>
  );
};

export default DetailTable;
