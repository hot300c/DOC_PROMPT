import { Button } from "@/components/ui/button";

export type ActionProps = {
  className?: string;
  onExportExcel: () => void;
  onPrint: () => void;
};
const Actions = ({ className, onExportExcel, onPrint }: ActionProps) => {
  return (
    <div
      className={`${className} w-full  flex items-center space-x-3 justify-end p-2`}
    >
      <Button variant={"outline"} onClick={onPrint}>
        In
      </Button>
      <Button variant={"outline"} onClick={onExportExcel}>
        Excel
      </Button>
    </div>
  );
};

export default Actions;
