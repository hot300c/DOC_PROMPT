import { getUserSession } from "@/actions/get-user-session";
import { PaperSize } from "@/app/lib/enums";
import { notifyWarning, runReport } from "@/app/lib/utils";
import { exportToExcel, TableConfig } from "@/app/lib/utils/exportToExcel ";
import { selectBaseSetting } from "@/redux/selectors";
import { useAppSelector } from "@/redux/store";
import { useMemo } from "react";
import { ImportInfoDetailDTO } from "../../_utils/definitions/danh-sach-phieu-nhap.dto";
import { ws_L_INVInOutTypeStockLink_GetReportInID } from "../../_utils/services/danh-sach-phieu-nhap.api";
import { deserializeReportModel } from "../../_utils/services/danh-sach-phieu-nhap.mapper";
import Actions from "./actions";
import DetailTable from "./table";

export type PresentationProps = {
  data: ImportInfoDetailDTO[];
  approvalInId: string;
};

const Presentation = ({ data, approvalInId }: PresentationProps) => {
  const tableConfig = useMemo<TableConfig>(
    () => ({
      columns: {
        STT: { width: 10, alignment: "center" },
        "Mã SP": { width: 50, alignment: "center" },
        "Tên sản phẩm": { width: 60, alignment: "center" },
        ĐVT: { width: 40, alignment: "left" },
        Lô: { width: 40, alignment: "left" },
        "Hạn dùng": { width: 30, alignment: "left" },
        "Đơn giá": { width: 30, alignment: "left", format: "currency" },
        "SL quy đổi": { width: 30, alignment: "left" },
        "Đơn giá quy đổi": { width: 30, alignment: "left", format: "currency" },
        "Thực Nhập": { width: 30, alignment: "left" },
        VAT: { width: 30, alignment: "left" },
        "Đơn giá VAT": { width: 30, alignment: "left", format: "currency" },
        "Tổng VAT": { width: 30, alignment: "left" },
        "TT Trước CK": { width: 30, alignment: "left", format: "currency" },
        "Chiết khấu": { width: 30, alignment: "left" },
        "TT Sau CK": { width: 30, alignment: "left", format: "currency" },
        "Nhiệt độ": { width: 30, alignment: "left" },
        "Số đăng ký": { width: 30, alignment: "left" },
        "Cảm quản": { width: 30, alignment: "left" },
      },
      data:
        data && data.length > 0
          ? data.map((row, index) => [
              index + 1,
              row.productCode,
              row.productName,
              row.unit,
              row.lot,
              row.expiredDate,
              row.salePrice,
              row.conversionAmount,
              row.conversionSalePrice,
              row.importedAmount,
              row.vat,
              row.vatSalePrice,
              row.totalVat,
              row.amountBeforeDiscount,
              row.discount,
              row.amountAfterDiscount,
              row.temperature,
              row.registerNumber,
              row.sense ? "Có" : "Không",
            ])
          : [],
      sheetName: "warehouse_list_details",
      fileName: "warehouse_list_details.xlsx",
    }),
    [data],
  );
  const baseSettings = useAppSelector(selectBaseSetting);
  const onExportData = async () => {
    await exportToExcel(tableConfig);
  };
  const onPrint = async () => {
    const currentUser = await getUserSession();
    if (currentUser.facId) {
      const response = await ws_L_INVInOutTypeStockLink_GetReportInID({
        approvedInId: approvalInId,
        customerId: currentUser.customerId,
        facId: currentUser.facId,
      });
      if (response) {
        const reportModels = deserializeReportModel(
          response.reportID_PhieuNhap,
        );
        if (reportModels && reportModels.length > 0) {
          reportModels.map((item) => {
            // TODO (https://rm.vnvc.info/issues/89928): Fix and remove eslint-disable-next-line comment
            // eslint-disable-next-line @typescript-eslint/no-floating-promises
            runReport(
              item.ReportID,
              currentUser.facId!,
              {
                ApprovedInID: approvalInId,
                FacID: currentUser.facId,
              },
              baseSettings,
              true,
              PaperSize.A4,
              true,
            );
          });
        } else {
          notifyWarning(
            "Vui lòng cấu hình ReportID_Phiếu nhập của loại xuất này",
          );
        }
      }
    }
  };
  return (
    <div className="flex-col flex flex-1 w-full overflow-y-hidden">
      <DetailTable data={data} className="flex-1" />
      <Actions onExportExcel={onExportData} onPrint={onPrint} />
    </div>
  );
};

export default Presentation;
