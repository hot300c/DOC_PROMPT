import { Button } from "@/components/ui/button";

export type DanhSachPhieuNhapActionProps = {
  onExportExcel: () => void;
  onPrint: () => void;
};
const Actions = ({ onPrint, onExportExcel }: DanhSachPhieuNhapActionProps) => {
  return (
    <div className="space-x-4 py-2 px-8 bg-muted w-full flex items-center justify-end">
      <Button variant={"outline"} onClick={onExportExcel}>
        Excel
      </Button>
      <Button variant={"outline"} onClick={onPrint}>
        In
      </Button>
    </div>
  );
};

export default Actions;
