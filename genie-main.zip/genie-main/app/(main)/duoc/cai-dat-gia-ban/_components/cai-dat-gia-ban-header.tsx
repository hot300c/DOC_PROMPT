"use client";

import FacilityInfo from "@/components/facilityInfo";

export default function CaiDatGiaBanHeader() {
  return <FacilityInfo page={"DƯỢC | CÀI ĐẶT GIÁ BÁN"} />;
}
