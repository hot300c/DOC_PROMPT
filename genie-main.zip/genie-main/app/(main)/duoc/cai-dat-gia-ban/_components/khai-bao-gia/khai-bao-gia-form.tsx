"use client";

import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
} from "@/components/ui/form";

import { DATE_FORMAT } from "@/app/lib/enums";
import { InputDatePicker } from "@/components/input-date-picker";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { zodResolver } from "@hookform/resolvers/zod";
import { format } from "date-fns";
import { useEffect, useMemo } from "react";
import { useForm } from "react-hook-form";
import { NumericFormat } from "react-number-format";
import { useCaiDatGiaBanContext } from "../../_context/cai-dat-gia-ban-context";
import { KhaiBaoGiaSchema, KhaiBaoGiaSchemaForm } from "../../_utils/schema";

type KhaiBaoGiaFilterProps = {
  onApDungGia: (value: KhaiBaoGiaSchemaForm) => void;
};

export default function KhaiBaoGiaFilterForm({
  onApDungGia,
}: KhaiBaoGiaFilterProps) {
  const { selectedProductPrice, setSharedFormValues } =
    useCaiDatGiaBanContext();
  const defaultValues = useMemo(() => {
    return {
      giaDatTruoc: selectedProductPrice
        ? selectedProductPrice.giaDichVu?.toString()
        : "",
      giaBan: selectedProductPrice
        ? selectedProductPrice.hospitalPrice?.toString()
        : "",
      effFrom: selectedProductPrice?.effFrom
        ? format(selectedProductPrice.effFrom, DATE_FORMAT.YYYY_MM_DD)
        : "01/01/2999",
      effThru: selectedProductPrice?.effThru
        ? format(selectedProductPrice.effThru, DATE_FORMAT.YYYY_MM_DD)
        : "01/01/2999",
    } as KhaiBaoGiaSchemaForm;
  }, [selectedProductPrice]);

  const form = useForm<KhaiBaoGiaSchemaForm>({
    resolver: zodResolver(KhaiBaoGiaSchema),
    defaultValues: defaultValues,
  });

  useEffect(() => {
    form.reset(defaultValues);
    setSharedFormValues(form.getValues());
    // TODO(https://rm.vnvc.info/issues/92105): Fix and remove disable comment
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedProductPrice, defaultValues]);

  const onSubmit = async (value: KhaiBaoGiaSchemaForm) => {
    onApDungGia(value);
  };

  return (
    <Form {...form}>
      <form
        onSubmit={form.handleSubmit(onSubmit)}
        className="flex-none bg-gray-100 p-2 rounded-lg m-1 flex flex-col gap-2"
      >
        <div className="w-full flex justify-start">
          <Label className="text-sm font-semibold">Khai báo giá</Label>
        </div>
        <div className="w-2/3">
          <div className="flex gap-4 w-full justify-end">
            <FormField
              control={form.control}
              name="giaBan"
              render={({ field }) => (
                <FormItem className="flex items-center w-full sm:w-auto">
                  <FormControl className="flex-1">
                    <div className="flex">
                      <FormLabel className="text-sm font-medium w-35">
                        Giá bán
                      </FormLabel>
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <NumericFormat
                              value={field.value}
                              decimalScale={2}
                              thousandSeparator="."
                              decimalSeparator=","
                              fixedDecimalScale
                              customInput={Input}
                              onValueChange={(values) => {
                                field.onChange(values.value);
                                setSharedFormValues(form.getValues());
                              }}
                              onFocus={(e) => {
                                e.target.select();
                              }}
                            />
                          </TooltipTrigger>
                          <TooltipContent>VNĐ</TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    </div>
                  </FormControl>
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="giaDatTruoc"
              render={({ field }) => (
                <FormItem className="items-center w-full sm:w-auto">
                  <FormControl>
                    <div className="flex">
                      <FormLabel className="text-sm font-medium w-35 whitespace-nowrap pr-2">
                        Giá đặt trước
                      </FormLabel>
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <NumericFormat
                              value={field.value}
                              decimalScale={2}
                              thousandSeparator="."
                              decimalSeparator=","
                              fixedDecimalScale={true}
                              customInput={Input}
                              onValueChange={(values) => {
                                field.onChange(values.value);
                              }}
                              onFocus={(e) => {
                                e.target.select();
                              }}
                            />
                          </TooltipTrigger>
                          <TooltipContent>VNĐ</TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    </div>
                  </FormControl>
                </FormItem>
              )}
            />
          </div>
          <div className="flex  w-full justify-between">
            <div className="w-1/2 ">
              <FormField
                control={form.control}
                name="effFrom"
                render={({ field }) => (
                  <FormItem className="flex items-center w-full sm:w-auto ">
                    <FormLabel className="text-sm font-medium w-32 mt-2 pr-2">
                      Áp dụng từ
                    </FormLabel>
                    <FormControl>
                      <InputDatePicker
                        className="w-full"
                        value={new Date(field.value || "")}
                        onChange={(date) => {
                          if (date && selectedProductPrice) {
                            field.onChange(
                              format(date, DATE_FORMAT.YYYY_MM_DD),
                            );
                            setSharedFormValues(form.getValues());
                          }
                        }}
                      />
                    </FormControl>
                  </FormItem>
                )}
              />
            </div>
            <div className="w-1/2">
              <FormField
                control={form.control}
                name="effThru"
                render={({ field }) => (
                  <FormItem className="flex items-center w-full sm:w-auto ml-4">
                    <FormLabel className="text-sm font-medium w-24  mt-2">
                      Đến ngày
                    </FormLabel>
                    <FormControl>
                      <InputDatePicker
                        disabled={true}
                        className="w-full"
                        value={new Date(field.value || "")}
                      />
                    </FormControl>
                  </FormItem>
                )}
              />
            </div>
          </div>
          <div className="flex gap-4 w-full justify-end mt-2">
            <Button variant="outline" type="submit">
              Áp dụng giá
            </Button>
          </div>
        </div>
      </form>
    </Form>
  );
}
