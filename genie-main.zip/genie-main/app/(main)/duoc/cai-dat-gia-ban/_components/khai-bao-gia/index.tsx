"use client";

import { DATE_FORMAT } from "@/app/lib/enums";
import { useFeedbackDialog } from "@/app/lib/feedback-dialog-provider";
import { notifySuccess } from "@/app/lib/utils";
import { getErrorMessage } from "@/app/lib/utils/errorUtils";
import { format } from "date-fns";
import { useEffect } from "react";
import { useCaiDatGiaBanContext } from "../../_context/cai-dat-gia-ban-context";
import { KhaiBaoGiaSchemaForm } from "../../_utils/schema";
import { saveProductPriceForProduct } from "../../_utils/services/cai-dat-gia-ban.api";
import CoSoDataTable from "./co-so-table";
import KhaiBaoGiaDataTable from "./khai-bao-gia-datatable";
import KhaiBaoGiaFilterForm from "./khai-bao-gia-form";

export const KhaiBaoGia = () => {
  const {
    productVaccines,
    customerVaccines,
    loadProductPriceData,
    productPriceData,
  } = useCaiDatGiaBanContext();
  const { confirm, alert } = useFeedbackDialog();

  useEffect(() => {
    void loadProductPriceData();
  }, [loadProductPriceData]);

  const handleApDungGia = async (value: KhaiBaoGiaSchemaForm) => {
    const facIds = customerVaccines
      .filter((x) => x.isChon)
      .map((item) => item.facID)
      .join(",");
    if (!facIds) {
      await alert({
        title: "Cảnh báo",
        content: "Vui lòng chọn cơ sở để áp dụng",
      });
      return;
    }
    const productIDs = productVaccines
      .filter((x) => x.isChon)
      .map((item) => item.productID)
      .join(",");
    if (!productIDs) {
      await alert({
        title: "Cảnh báo",
        content: "Vui lòng chọn sản phẩm để áp dụng",
      });
      return;
    }
    const answer = await confirm({
      title: "Cảnh báo",
      content: "Bạn đang áp dụng giá cho sản phẩm, bạn đã chắc chắn chưa?",
    });
    if (!answer) return;

    const selectedAllFacility = customerVaccines.find(
      (fac) => fac.isChon && fac.customerFullName === "Tất cả",
    );

    if (selectedAllFacility) {
      const confirmSelectAll = await confirm({
        title: "Cảnh báo",
        content:
          "Bạn đang áp dụng giá cho tất cả các cơ sở, bạn đã chắc chắn chưa?",
      });
      if (!confirmSelectAll) return;
    }

    try {
      if (value) {
        await saveProductPriceForProduct({
          facIDs: facIds,
          productIDs,
          hospitalPrice: Number(value?.giaBan) || 0,
          giaDichVu: Number(value.giaDatTruoc) || 0,
          effFrom: format(value.effFrom ?? new Date(), DATE_FORMAT.YYYY_MM_DD),
          effThru: "01/01/2999",
        });
        notifySuccess(`Lưu thành công`);
        await loadProductPriceData();
      } else {
        await alert({
          title: "Cảnh báo",
          content: "Vui lòng chọn giá để khai báo",
        });
        return;
      }
    } catch (error) {
      const content = getErrorMessage(error);
      await alert({
        title: "Cảnh báo",
        content,
      });
      return;
    }
  };

  return (
    <div className="flex-1 flex flex-col h-full">
      <KhaiBaoGiaFilterForm onApDungGia={handleApDungGia} />
      <CoSoDataTable data={customerVaccines} />
      <div className="flex-1 overflow-auto mt-1">
        <KhaiBaoGiaDataTable data={productPriceData} />
      </div>
    </div>
  );
};
