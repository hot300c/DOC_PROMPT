"use client";
import { DATE_FORMAT } from "@/app/lib/enums";
import { formatCurrencyVND } from "@/app/lib/utils";
import { vietnameseSort } from "@/app/lib/vietnameseSort";
import {
  DataTable,
  DataTableColumnHeaderSort,
} from "@/components/ui/dataTable";
import { ColumnDef } from "@tanstack/react-table";
import { format } from "date-fns";
import { useMemo } from "react";
import { useCaiDatGiaBanContext } from "../../_context/cai-dat-gia-ban-context";
import { ProductPrice } from "../../_utils/definitions/product-price";

export interface KhaiBaoGiaDataTableProps {
  data: ProductPrice[];
}

const KhaiBaoGiaDataTable: React.FC<KhaiBaoGiaDataTableProps> = ({ data }) => {
  const { selectedProductPrice, setSelectedProductPrice } =
    useCaiDatGiaBanContext();

  const indexScrollTo = useMemo(() => {
    return selectedProductPrice
      ? data.findIndex((row) => row === selectedProductPrice)
      : 0;
  }, [selectedProductPrice, data]);

  const columns = useMemo(() => {
    const result: ColumnDef<ProductPrice>[] = [
      {
        id: "customerFullName",
        accessorKey: "customerFullName",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Cơ sở"
            className="justify-start"
          />
        ),
        enableSorting: true,
        sortingFn: vietnameseSort,
      },
      {
        id: "hospitalPrice",
        accessorKey: "hospitalPrice",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Giá bán"
            className="justify-start"
          />
        ),
        cell: ({ row }) => (
          <div className="text-right">
            {formatCurrencyVND(row.original.hospitalPrice, 2, false)}
          </div>
        ),
      },
      {
        id: "giaDichVu",
        accessorKey: "giaDichVu",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Giá đặt trước"
            className="justify-start"
          />
        ),
        enableSorting: true,
        cell: ({ row }) => (
          <div className="text-right">
            {formatCurrencyVND(row.original.giaDichVu, 2, false)}
          </div>
        ),
      },
      {
        id: "effFrom",
        accessorKey: "effFrom",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Từ ngày"
            className="justify-start"
          />
        ),
        cell: ({ row }) => (
          <div className="min-w-32">
            {format(row.original.effFrom, DATE_FORMAT.DD_MM_YYYY_VI)}
          </div>
        ),
        enableSorting: true,
      },
      {
        id: "effThru",
        accessorKey: "effThru",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Đến ngày"
            className="justify-start"
          />
        ),
        cell: ({ row }) => (
          <div className="min-w-10">
            {format(row.original.effThru, DATE_FORMAT.DD_MM_YYYY_VI)}
          </div>
        ),
        enableSorting: true,
      },
    ];
    return result;
  }, []);

  return (
    <div className="flex flex-col h-full w-full">
      <DataTable
        className="overflow-y-auto border"
        columns={columns}
        data={data}
        columnVisibilityInit={{ search: false }}
        enableColumnFilter={true}
        enablePaging={true}
        enableFooter={true}
        onRowClick={setSelectedProductPrice}
        indexScrollTo={indexScrollTo}
      />
    </div>
  );
};

export default KhaiBaoGiaDataTable;
