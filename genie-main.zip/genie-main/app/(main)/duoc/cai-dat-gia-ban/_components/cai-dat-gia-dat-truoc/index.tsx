"use client";

import { DATE_FORMAT } from "@/app/lib/enums";
import { useFeedbackDialog } from "@/app/lib/feedback-dialog-provider";
import { notifySuccess } from "@/app/lib/utils";
import { getErrorMessage } from "@/app/lib/utils/errorUtils";
import { format } from "date-fns";
import { useCaiDatGiaBanContext } from "../../_context/cai-dat-gia-ban-context";
import { CaiDatGiaBanSchemaForm } from "../../_utils/schema";
import { saveProductPriceForProduct } from "../../_utils/services/cai-dat-gia-ban.api";
import CaiDatGiaBanTruocFilterForm from "./cai-dat-gia-dat-truoc-form";
import GiaDatTruocDataTable from "./gia-dat-truoc-datatable";

export const CaiDatGiaDatTruoc = () => {
  const {
    productVaccines,
    customerVaccines,
    selectedProductPrice,
    sharedFormValues,
    loadProductPriceData,
  } = useCaiDatGiaBanContext();
  const { confirm, alert } = useFeedbackDialog();

  const handleTinhLaiGiaDatTruoc = async (value: CaiDatGiaBanSchemaForm) => {
    if (!value.facIds) {
      await alert({
        title: "Cảnh báo",
        content: "Vui lòng chọn cơ sở để tính lại giá đặt trước",
      });
      return;
    }
    const productIDs = productVaccines
      .filter((x) => x.isChon)
      .map((item) => item.productID)
      .join(",");

    if (!productIDs) {
      await alert({
        title: "Cảnh báo",
        content: "Vui lòng chọn sản phẩm tính lại giá đặt trước",
      });
      return;
    }

    const answer = await confirm({
      title: "Cảnh báo",
      content:
        "Bạn đang tính lại giá đặt trước cho sản phẩm, bạn đã chắc chắn chưa?",
    });
    if (!answer) return;
    const selectedFacility = customerVaccines.find(
      (fac) => fac.facID === value.facIds,
    );
    const customerFullName = selectedFacility
      ? selectedFacility.customerFullName
      : "";

    if (customerFullName === "Tất cả") {
      const confirmSelectAll = await confirm({
        title: "Cảnh báo",
        content:
          "Bạn đang tính lại giá đặt trước cho tất cả các cơ sở, bạn đã chắc chắn chưa?",
      });
      if (!confirmSelectAll) return;
    }
    let giaBan: number = selectedProductPrice?.hospitalPrice ?? 0;

    if (value.menhGia) {
      giaBan =
        parseFloat(value.menhGia) +
        parseFloat(giaBan?.toString().replace(",0000", ".") || "0");
    }
    if (value.giaBaoQuan) {
      giaBan =
        (parseFloat(value.giaBaoQuan.toString()) *
          parseFloat(giaBan.toString().replace(",0000", "."))) /
          100 +
        parseFloat(giaBan.toString().replace(",0000", "."));
    }

    try {
      if (selectedProductPrice) {
        await saveProductPriceForProduct({
          facIDs: value.facIds,
          productIDs,
          hospitalPrice: Number(sharedFormValues?.giaBan) || 0,
          giaDichVu: giaBan,
          effFrom: format(
            sharedFormValues?.effFrom || selectedProductPrice.effFrom,
            DATE_FORMAT.YYYY_MM_DD,
          ),
          effThru: "01/01/2999",
        });
        notifySuccess(`Lưu thành công`);
        await loadProductPriceData();
      } else {
        await alert({
          title: "Cảnh báo",
          content: "Vui lòng chọn giá để khai báo",
        });
        return;
      }
    } catch (error) {
      const content = getErrorMessage(error);
      await alert({
        title: "Cảnh báo",
        content,
      });
      return;
    }
  };

  return (
    <div className="flex-1 flex flex-col h-full">
      <CaiDatGiaBanTruocFilterForm
        customerVaccines={customerVaccines}
        onSubmitForm={handleTinhLaiGiaDatTruoc}
      />
      <div className="flex-1 overflow-x-auto">
        <GiaDatTruocDataTable data={productVaccines} />
      </div>
    </div>
  );
};
