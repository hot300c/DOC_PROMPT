import {
  ResizableHandle,
  ResizablePanel,
  ResizablePanelGroup,
} from "@/components/ui/resizable";
import CaiDatGiaBanVatTuHeader from "./_components/cai-dat-gia-ban-vat-tu-header";
import { CaiDatGiaDatTruoc } from "./_components/cai-dat-gia-vat-tu-dat-truoc";
import { KhaiBaoGia } from "./_components/khai-bao-gia";
import { CaiDatGiaBanProvider } from "./_context/cai-dat-gia-ban-vat-tu-context";

export default async function Page() {
  return (
    <CaiDatGiaBanProvider>
      <div className="flex flex-col h-full">
        <CaiDatGiaBanVatTuHeader />
        <ResizablePanelGroup direction="horizontal">
          <ResizablePanel>
            <CaiDatGiaDatTruoc />
          </ResizablePanel>
          <ResizableHandle />
          <ResizablePanel>
            <KhaiBaoGia />
          </ResizablePanel>
        </ResizablePanelGroup>
      </div>
    </CaiDatGiaBanProvider>
  );
}
