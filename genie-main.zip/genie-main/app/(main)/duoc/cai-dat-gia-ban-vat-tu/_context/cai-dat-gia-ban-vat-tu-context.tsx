"use client";

import { notifyError } from "@/app/lib/utils";
import { getErrorMessage } from "@/app/lib/utils/errorUtils";
import useLoading from "@/components/loading";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import React, {
  createContext,
  ReactNode,
  useCallback,
  useContext,
  useEffect,
  useState,
  useTransition,
} from "react";
import { Loading } from "../../(base_components)/loading";
import { CustomerVaccine } from "../_utils/definitions/customer-vaccine";
import { ProductPrice } from "../_utils/definitions/product-price";
import { ProductVaccine } from "../_utils/definitions/product-vaccine";
import { KhaiBaoGiaSchemaForm } from "../_utils/schema";
import {
  fetchCustomerVaccineList,
  fetchProductPriceListByProduct,
  fetchProductVaccineList,
} from "../_utils/services/cai-dat-gia-ban-vat-tu.api";

type CaiDatGiaBanContextType = {
  customerVaccines: CustomerVaccine[];
  productVaccines: ProductVaccine[];
  selectedProductPrice: ProductPrice | null;
  setCustomerVaccines: React.Dispatch<React.SetStateAction<CustomerVaccine[]>>;
  setProductVaccines: React.Dispatch<React.SetStateAction<ProductVaccine[]>>;
  setSelectedProductPrice: React.Dispatch<
    React.SetStateAction<ProductPrice | null>
  >;
  sharedFormValues: KhaiBaoGiaSchemaForm | null;
  setSharedFormValues: (values: KhaiBaoGiaSchemaForm) => void;
  isCheckAll: boolean;
  productPriceData: ProductPrice[];
  setProductPriceData: React.Dispatch<React.SetStateAction<ProductPrice[]>>;
  loadProductPriceData: () => Promise<void>;
};

const CaiDatGiaBanContext = createContext<CaiDatGiaBanContextType | undefined>(
  undefined,
);

export const CaiDatGiaBanProvider: React.FC<{ children: ReactNode }> = ({
  children,
}) => {
  const searchParams = useSearchParams();
  const router = useRouter();
  const pathname = usePathname();
  const { showLoading, hideLoading } = useLoading();
  const [customerVaccines, setCustomerVaccines] = useState<any[]>([]);
  const [productVaccines, setProductVaccines] = useState<ProductVaccine[]>([]);
  const [isCheckAll, setIsCheckAll] = useState<boolean>(false);
  const [selectedProductPrice, setSelectedProductPrice] =
    useState<ProductPrice | null>(null);
  const [isPending, startTransition] = useTransition();
  const [sharedFormValues, setSharedFormValues] =
    useState<KhaiBaoGiaSchemaForm | null>(null);
  const [productPriceData, setProductPriceData] = useState<ProductPrice[]>([]);

  const productID = searchParams.get("productID");
  const setQueryParams = useCallback(() => {
    const query = new URLSearchParams(searchParams.toString());
    if (productVaccines.length > 0 && !productID) {
      // @ts-ignore https://rm.vnvc.info/issues/93471
      query.set("productID", productVaccines[0].productID);
      router.push(pathname + "?" + query.toString());
    }
  }, [searchParams, productVaccines, productID, router, pathname]);

  useEffect(() => {
    if (window.location.search.length === 0) {
      setQueryParams();
    }
  }, [router, productID, setQueryParams]);

  const fetchVaccines = useCallback(async () => {
    try {
      const [customers, products] = await Promise.all([
        fetchCustomerVaccineList(),
        fetchProductVaccineList(),
      ]);
      setCustomerVaccines(customers);
      setProductVaccines(products);
    } catch (error) {
      console.error("Failed to fetch vaccine data", error);
    }
  }, []);

  useEffect(() => {
    setIsCheckAll(
      productVaccines.length > 0 &&
        productVaccines.every((item) => item.isChon),
    );
  }, [productVaccines]);

  useEffect(() => {
    startTransition(async () => {
      await fetchVaccines();
    });
  }, [fetchVaccines]);

  const loadProductPriceData = useCallback(async () => {
    const loadingId = showLoading("Đang tải dữ liệu");
    try {
      const facIDs = customerVaccines
        .filter((x) => x.isChon)
        .map((item) => item.facID)
        .join(",");
      if (productID && facIDs) {
        const resProducts = await fetchProductPriceListByProduct({
          facIDs: facIDs,
          productID: productID,
        });

        setProductPriceData(resProducts);
        if (resProducts.length > 0) {
          // @ts-ignore https://rm.vnvc.info/issues/93471
          setSelectedProductPrice(resProducts[0]);
        }
      } else {
        setProductPriceData([]);
      }
    } catch (error) {
      notifyError("Lỗi load giá bán" + getErrorMessage(error));
      return;
    } finally {
      hideLoading(loadingId);
    }
  }, [
    customerVaccines,
    hideLoading,
    productID,
    setSelectedProductPrice,
    showLoading,
  ]);

  return (
    <CaiDatGiaBanContext.Provider
      value={{
        customerVaccines,
        productVaccines,
        selectedProductPrice,
        setCustomerVaccines,
        setProductVaccines,
        setSelectedProductPrice,
        sharedFormValues,
        setSharedFormValues,
        isCheckAll,
        productPriceData,
        setProductPriceData,
        loadProductPriceData,
      }}
    >
      {isPending && <Loading />}
      {children}
    </CaiDatGiaBanContext.Provider>
  );
};

export const useCaiDatGiaBanContext = () => {
  const context = useContext(CaiDatGiaBanContext);
  if (!context) {
    throw new Error(
      "useCaiDatGiaBanContext must be used within a CaiDatGiaBanProvider",
    );
  }
  return context;
};
