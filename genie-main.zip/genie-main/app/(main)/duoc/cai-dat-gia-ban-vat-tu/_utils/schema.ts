import { z } from "zod";

export const CaiDatGiaBanSchema = z.object({
  giaBaoQuan: z.string().optional(),
  menhGia: z.string().optional(),
  facIds: z.string().optional(),
  isChonTatCa: z.boolean().default(false),
});

export type CaiDatGiaBanSchemaForm = z.infer<typeof CaiDatGiaBanSchema>;

export const KhaiBaoGiaSchema = z.object({
  giaDatTruoc: z.string().optional(),
  giaBan: z.string().optional(),
  effFrom: z.string().optional(),
  effThru: z.string().optional(),
});

export type KhaiBaoGiaSchemaForm = z.infer<typeof KhaiBaoGiaSchema>;

export const SearchParamsSchema = z.object({
  facIds: z.string({
    required_error: "Vui lòng chọn kho",
  }),
  productID: z.string().optional(),
});

export type SearchParams = z.infer<typeof SearchParamsSchema>;
