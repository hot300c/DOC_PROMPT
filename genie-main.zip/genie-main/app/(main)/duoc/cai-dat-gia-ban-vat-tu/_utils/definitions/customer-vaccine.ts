export type CustomerVaccine = {
  stt: number;
  customerID: string;
  facID: string;
  customerFullName: string;
  customerAddress: string;
  isChon: boolean;
};
