import { getUserSession } from "@/actions/get-user-session";
import * as httpService from "@/app/lib/network/http";
import { CustomerVaccine } from "../definitions/customer-vaccine";
import { ProductPrice } from "../definitions/product-price";
import { ProductVaccine } from "../definitions/product-vaccine";

export async function fetchCustomerVaccineList(): Promise<CustomerVaccine[]> {
  const currentUser = await getUserSession();
  const response = await httpService.post("/DataAccess", [
    {
      category: "QAHosGenericDB",
      command: "ws_CustomerVaccine_List",
      parameters: {
        FacID: currentUser.facId,
      },
    },
  ]);

  return response.data.table;
}

export async function fetchProductVaccineList(): Promise<ProductVaccine[]> {
  const currentUser = await getUserSession();
  const response = await httpService.post("/DataAccess", [
    {
      category: "QAHosGenericDB",
      command: "ws_LoadProductVaccine_List",
      parameters: {
        FacID: currentUser.facId,
        IsVatTu: 1, // Get from QAS
      },
    },
  ]);

  return response.data.table;
}

export type FetchProductPriceListByProductParams = {
  facIDs: string;
  productID: string;
};

export async function fetchProductPriceListByProduct(
  params: FetchProductPriceListByProductParams,
): Promise<ProductPrice[]> {
  try {
    const response = await httpService.post("/DataAccess", [
      {
        category: "QAHosGenericDB",
        command: "ws_L_ProductPrice_ListByProduct",
        parameters: {
          FacIDs: params.facIDs,
          ProductID: params.productID,
        },
      },
    ]);

    return response.data.table || [];
  } catch (error) {
    return [];
  }
}

export type SaveProductPriceForProductParams = {
  facIDs: string;
  productIDs: string;
  hospitalPrice: number;
  giaDichVu: number;
  effFrom: string;
  effThru: string;
};

export async function saveProductPriceForProduct(
  params: SaveProductPriceForProductParams,
) {
  await httpService.post("/DataAccess", [
    {
      category: "QAHosGenericDB",
      command: "ws_L_ProductPrice_SaveForProduct_V2",
      parameters: {
        FacIDs: params.facIDs,
        ProductIDs: params.productIDs,
        HospitalPrice: params.hospitalPrice.toString().replace(",", "."),
        GiaDichVu: params.giaDichVu.toString().replace(",", "."),
        EffFrom: params.effFrom,
        EffThru: params.effThru,
      },
    },
  ]);
}
