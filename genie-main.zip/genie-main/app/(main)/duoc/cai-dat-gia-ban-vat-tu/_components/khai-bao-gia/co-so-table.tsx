"use client";
import { vietnameseSort } from "@/app/lib/vietnameseSort";
import { Checkbox } from "@/components/ui/checkbox";
import {
  DataTable,
  DataTableColumnHeaderSort,
} from "@/components/ui/dataTable";
import { ColumnDef } from "@tanstack/react-table";
import { useMemo, useState, useTransition } from "react";
import { useCaiDatGiaBanContext } from "../../_context/cai-dat-gia-ban-vat-tu-context";
import { CustomerVaccine } from "../../_utils/definitions/customer-vaccine";

export interface CoSoDataTableProps {
  data: CustomerVaccine[];
}

const CoSoDataTable: React.FC<CoSoDataTableProps> = ({ data }) => {
  const { customerVaccines, setCustomerVaccines } = useCaiDatGiaBanContext();
  const [, startTransition] = useTransition();
  const [selectedFacId, setSelectedFacId] = useState<CustomerVaccine>(data[0]!);

  const indexScrollTo = useMemo(
    () =>
      selectedFacId
        ? data.findIndex((row) => row.facID == selectedFacId.facID)
        : 0,
    [selectedFacId, data],
  );
  const columns = useMemo(() => {
    const result: ColumnDef<CustomerVaccine>[] = [
      {
        id: "Chọn",
        accessorKey: "isChon",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Chọn"
            className="justify-start"
          />
        ),
        cell: ({ row }) => {
          const customerVaccine = customerVaccines[row.index];
          const isSelected = customerVaccine?.isChon;
          return (
            <Checkbox
              className="min-w-4 min-h-4"
              checked={isSelected}
              onCheckedChange={(value: boolean) => {
                startTransition(() => {
                  const updatedCustomerVaccines = [...customerVaccines];
                  updatedCustomerVaccines[row.index] = {
                    ...(updatedCustomerVaccines[row.index] as CustomerVaccine),
                    isChon: value,
                  };
                  setCustomerVaccines(updatedCustomerVaccines);
                });
              }}
            />
          );
        },
        enableSorting: false,
      },
      {
        id: "Tên cơ sở",
        accessorKey: "customerFullName",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Tên cơ sở"
            className="justify-start"
          />
        ),
        cell: ({ row }) => (
          <div className="min-w-32">{row.original.customerFullName}</div>
        ),
        enableSorting: true,
        sortingFn: vietnameseSort,
      },
      {
        id: "Địa chỉ",
        accessorKey: "customerAddress",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Địa chỉ"
            className="justify-start"
          />
        ),
        cell: ({ row }) => (
          <div className="min-w-52">{row.original.customerAddress}</div>
        ),
      },
      {
        id: "Trạng thái",
        accessorKey: "trangThai",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Trạng thái"
            className="justify-start"
          />
        ),
      },
    ];
    return result;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [customerVaccines]);

  return (
    <div className="flex flex-col h-60 w-full">
      <DataTable
        className="h-full overflow-auto border"
        columns={columns}
        data={data}
        columnVisibilityInit={{ search: false }}
        enableColumnFilter={true}
        enablePaging={true}
        enableFooter={true}
        onRowClick={setSelectedFacId}
        indexScrollTo={indexScrollTo}
      />
    </div>
  );
};

export default CoSoDataTable;
