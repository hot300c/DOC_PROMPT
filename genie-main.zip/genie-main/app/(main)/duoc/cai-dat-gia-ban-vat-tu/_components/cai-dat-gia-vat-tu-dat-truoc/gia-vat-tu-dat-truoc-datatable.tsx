"use client";
import { vietnameseSort } from "@/app/lib/vietnameseSort";
import { Checkbox } from "@/components/ui/checkbox";
import {
  DataTable,
  DataTableColumnHeaderSort,
} from "@/components/ui/dataTable";
import { ColumnDef } from "@tanstack/react-table";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { useCallback, useMemo, useTransition } from "react";
import { useCaiDatGiaBanContext } from "../../_context/cai-dat-gia-ban-vat-tu-context";
import { ProductVaccine } from "../../_utils/definitions/product-vaccine";

export interface GiaDatTruocDataTableProps {
  data: ProductVaccine[];
}

const GiaDatTruocDataTable: React.FC<GiaDatTruocDataTableProps> = ({
  data,
}) => {
  const { productVaccines, setProductVaccines } = useCaiDatGiaBanContext();
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const [, startTransition] = useTransition();
  const productID = searchParams.get("productID");
  const indexScrollTo = useMemo(
    () => (productID ? data.findIndex((row) => row.productID == productID) : 0),
    [productID, data],
  );
  const handleSelectedRow = useCallback(
    (records: ProductVaccine) => {
      const query = new URLSearchParams(window.location.search);
      query.set("productID", records.productID);
      router.push(pathname + "?" + query.toString());
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [],
  );
  const columns = useMemo(() => {
    const result: ColumnDef<ProductVaccine>[] = [
      {
        id: "Chọn",
        accessorKey: "isChon",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Chọn"
            className="justify-center"
          />
        ),
        cell: ({ row }) => {
          const productVaccine = productVaccines[row.index];
          const isSelected = productVaccine?.isChon;
          return (
            <Checkbox
              className="min-w-4 min-h-4"
              checked={isSelected}
              onCheckedChange={(value: boolean) => {
                startTransition(() => {
                  setProductVaccines((prev: ProductVaccine[]) => {
                    const updated = [...prev];
                    // @ts-ignore https://rm.vnvc.info/issues/93471
                    updated[row.index] = {
                      ...updated[row.index],
                      isChon: value,
                    };
                    return updated;
                  });
                });
              }}
            />
          );
        },
        enableSorting: false,
      },
      {
        id: "Mã chung",
        accessorKey: "maChung",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Mã chung"
            className="justify-start"
          />
        ),
        enableSorting: true,
        sortingFn: vietnameseSort,
      },
      {
        id: "Mã SP",
        accessorKey: "hospitalCode",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Mã SP"
            className="justify-start"
          />
        ),
      },
      {
        id: "Tên SP",
        accessorKey: "hospitalName",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Tên SP"
            className="justify-start"
          />
        ),
        enableSorting: true,
        sortingFn: vietnameseSort,
      },
      {
        id: "Hàm Lượng",
        accessorKey: "content",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Hàm lượng"
            className="justify-start"
          />
        ),
        enableSorting: true,
      },
      {
        id: "Nước sản xuất",
        accessorKey: "countryName",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Nước sản xuất"
            className="justify-start"
          />
        ),
        enableSorting: true,
        sortingFn: vietnameseSort,
      },
    ];
    return result;
  }, [productVaccines, setProductVaccines]);

  return (
    <div className="flex flex-col h-full w-full">
      <DataTable
        className="w-full overflow-y-auto border"
        columns={columns}
        data={data}
        columnVisibilityInit={{ search: false }}
        enableColumnFilter={true}
        enablePaging={true}
        enableFooter={true}
        indexScrollTo={indexScrollTo ?? 0}
        onRowClick={handleSelectedRow}
      />
    </div>
  );
};

export default GiaDatTruocDataTable;
