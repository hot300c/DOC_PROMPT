"use client";

import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
} from "@/components/ui/form";

import { Select } from "@/components/select/select";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMemo } from "react";
import { useForm } from "react-hook-form";
import { NumericFormat } from "react-number-format";
import { useCaiDatGiaBanContext } from "../../_context/cai-dat-gia-ban-vat-tu-context";
import { CustomerVaccine } from "../../_utils/definitions/customer-vaccine";
import {
  CaiDatGiaBanSchema,
  CaiDatGiaBanSchemaForm,
} from "../../_utils/schema";

type CaiDatGiaBanTruocFilterProps = {
  customerVaccines: CustomerVaccine[];

  onSubmitForm: (value: CaiDatGiaBanSchemaForm) => void;
};

export default function CaiDatGiaBanTruocFilterForm({
  customerVaccines,
  onSubmitForm,
}: CaiDatGiaBanTruocFilterProps) {
  const { isCheckAll, setProductVaccines } = useCaiDatGiaBanContext();
  const defaultValues = useMemo(() => {
    return {
      giaBaoQuan: "",
      menhGia: "",
      facIds: "",
    } as CaiDatGiaBanSchemaForm;
  }, []);
  const form = useForm<CaiDatGiaBanSchemaForm>({
    resolver: zodResolver(CaiDatGiaBanSchema),
    defaultValues: defaultValues,
  });

  const onSubmit = (value: CaiDatGiaBanSchemaForm) => {
    onSubmitForm(value);
  };

  return (
    <Form {...form}>
      <form
        onSubmit={form.handleSubmit(onSubmit)}
        className="bg-gray-100 p-2 rounded-lg m-1 flex flex-col gap-2 "
      >
        <div className="w-full flex justify-start">
          <Label className="text-sm font-semibold">Cài đặt giá đặt trước</Label>
        </div>
        <div className="w-2/3">
          <div className="flex justify-between gap-4 w-full ">
            <FormLabel className="text-sm font-medium w-30">
              Giá đặt trước
            </FormLabel>
            <div className="flex gap-4 w-full">
              <div className="w-1/2">
                <FormField
                  control={form.control}
                  name="giaBaoQuan"
                  render={({ field }) => (
                    <FormItem className="flex items-center w-full sm:w-auto">
                      <FormControl className="flex-1">
                        <div className="relative">
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <Input
                                  type="number"
                                  value={field.value}
                                  onChange={(value) => {
                                    field.onChange(value);
                                  }}
                                  onBlur={() => {
                                    form.setValue("menhGia", "");
                                  }}
                                />
                              </TooltipTrigger>
                              <TooltipContent>%</TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                        </div>
                      </FormControl>
                    </FormItem>
                  )}
                />
              </div>
              <div className="w-1/2">
                <FormField
                  control={form.control}
                  name="menhGia"
                  render={({ field }) => (
                    <FormItem className="items-center w-full sm:w-auto">
                      <FormControl className="flex-1">
                        <div className="relative">
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <NumericFormat
                                  value={field.value}
                                  decimalScale={2}
                                  thousandSeparator="."
                                  decimalSeparator=","
                                  fixedDecimalScale={true}
                                  customInput={Input}
                                  onValueChange={(values) => {
                                    field.onChange(values.value);
                                  }}
                                  onBlur={() => {
                                    form.setValue("giaBaoQuan", "");
                                  }}
                                />
                              </TooltipTrigger>
                              <TooltipContent>VNĐ</TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                        </div>
                      </FormControl>
                    </FormItem>
                  )}
                />
              </div>
            </div>
          </div>
          <div className="flex gap-4 w-full justify-between ">
            <FormField
              control={form.control}
              name="isChonTatCa"
              render={({ field }) => (
                <FormItem className="flex items-center w-full sm:w-auto">
                  <FormControl>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        checked={isCheckAll}
                        onCheckedChange={(checked) => {
                          field.onChange(checked);
                          setProductVaccines((prev) =>
                            prev.map((product) => ({
                              ...product,
                              isChon: Boolean(checked),
                            })),
                          );
                        }}
                      />
                      <Label>Chọn tất cả</Label>
                    </div>
                  </FormControl>
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="facIds"
              render={({ field }) => (
                <FormItem className="flex items-center w-full sm:w-auto">
                  <FormLabel className="text-sm font-medium w-12">
                    Cơ sở
                  </FormLabel>
                  <FormControl className="flex-1">
                    <Select
                      className="w-64"
                      classNamePopover="w-full"
                      classNameSelectList="max-h-96"
                      onChange={(value) => {
                        field.onChange(value);
                      }}
                      value={field.value?.toString()}
                      placeholder="Chọn cơ sở để tính giá đặt trước"
                      options={
                        customerVaccines?.map((item) => ({
                          label: item.customerFullName,
                          value: item.facID.toString(),
                        })) ?? []
                      }
                    ></Select>
                  </FormControl>
                </FormItem>
              )}
            />
          </div>
          <div className="flex gap-4 w-full justify-end mt-2">
            <Button variant="outline">Tính lại giá đặt trước</Button>
          </div>
        </div>
      </form>
    </Form>
  );
}
