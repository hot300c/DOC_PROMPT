"use client";

import { ETitleConfirm } from "@/app/lib/enums";
import { useFeedbackDialog } from "@/app/lib/feedback-dialog-provider";
import { formatCurrencyVND } from "@/app/lib/utils";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogOverlay,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { ChangeEvent, useEffect, useState } from "react";
import { CartItem } from "../_models/cart-model";

export default function DiscountModal({
  cartItem,
  onClose: onClose,
  handleChangeDiscount,
}: {
  cartItem: CartItem;
  onClose: () => void;
  handleChangeDiscount: (
    item: CartItem,
    percent: number,
    discount: number,
    reason: string,
  ) => void;
}) {
  const [percent, setPercent] = useState<string>("");
  const [discount, setDiscount] = useState<string>("");
  const [reason, setReason] = useState<string>("");
  const { alert } = useFeedbackDialog();

  useEffect(() => {
    const percentItiem = cartItem.discountPercent || 0;
    const discountItiem = cartItem.discount || 0;
    if (percentItiem > 0) setPercent(percentItiem.toString());
    else if (discountItiem > 0)
      setDiscount(formatCurrencyVND(discountItiem, 0, false)?.toString());
    else {
      setPercent("0");
      setDiscount("0");
    }
    setReason(cartItem.reason || "");
  }, [cartItem]);

  const handleOnClickSave = async () => {
    const value = Number(percent.replace(/\D/g, "") || "0");
    const discountPrice = Number(discount.replace(/\D/g, "") || "0");
    if (value > 100) {
      await alert({
        title: ETitleConfirm.THONG_BAO,
        content: "Không được nhập chiết khấu trên 100%",
      });
      return;
    }
    void handleChangeDiscount(cartItem, value, discountPrice, reason);
    onClose();
  };
  const validateValue = (value: number, valueMax: number) => {
    if (value < 0 || value > valueMax) return false;
    return true;
  };

  const handleSetPercent = (e: ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.replace(/\D/g, "");
    if (value === "") {
      setPercent("");
      return;
    }
    const number = Number(value);
    if (!validateValue(number, 100)) return;
    setPercent(e.target.value);
  };

  const handleSetDiscount = (e: ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.replace(/\D/g, "");
    if (value === "") {
      setDiscount("");
      return;
    }
    const number = Number(value);
    if (!validateValue(number, cartItem.thanhTienTruocCK)) return;
    setDiscount(value);
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogOverlay />
      <DialogContent
        className="sm:max-w-96 z-101 bg-white"
        aria-describedby={undefined}
      >
        <DialogHeader>
          <DialogTitle>Giảm tiền</DialogTitle>
        </DialogHeader>
        <>
          <div className="items-center gap-4">
            <div>
              <div className="flex mb-2">
                <Label className="w-20">Nội dung</Label>
                <div className="flex-1 border-b" title={cartItem?.name || ""}>
                  {cartItem?.name || ""}
                </div>
              </div>
              <div className="flex mb-2">
                <Label className="w-20">KH trả</Label>
                <div className="flex-1 border-b">
                  {formatCurrencyVND(cartItem?.thanhTienTruocCK, 2)}
                </div>
              </div>
              <div className="flex mb-2">
                <Label className="w-20">Tiền giảm</Label>
                <div className="flex flex-1">
                  <div className="relative w-1/3 mr-3">
                    <Input
                      disabled={
                        !!discount && Number(discount.replace(/\D/g, "")) > 0
                      }
                      className="w-full pr-5 pl-2 py-1 border rounded text-right"
                      value={percent}
                      onChange={handleSetPercent}
                    />
                    <span className="absolute right-2 top-1/2 -translate-y-1/2 pointer-events-none">
                      %
                    </span>
                  </div>
                  <div className="relative flex-1">
                    <Input
                      disabled={
                        !!percent && Number(percent.replace(/\D/g, "")) > 0
                      }
                      className="w-full pr-5 pl-2 py-1 border rounded text-right"
                      value={discount}
                      onChange={handleSetDiscount}
                      onBlur={(e) =>
                        setDiscount(
                          formatCurrencyVND(
                            Number(e.target.value.replace(/\D/g, "") || "0"),
                            0,
                            false,
                          ),
                        )
                      }
                    />
                    <span className="absolute right-2 top-1/2 -translate-y-1/2 pointer-events-none">
                      đ
                    </span>
                  </div>
                </div>
              </div>
            </div>
            <div className="flex mb-2">
              <Label className="w-20">Lý do</Label>
              <div className="flex-1">
                <Textarea
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  maxLength={300}
                ></Textarea>
              </div>
            </div>
            <div className="flex flex-1 justify-end">
              <Button
                className="items-center"
                variant="outline"
                onClick={handleOnClickSave}
              >
                Lưu
              </Button>
            </div>
          </div>
        </>
      </DialogContent>
    </Dialog>
  );
}
