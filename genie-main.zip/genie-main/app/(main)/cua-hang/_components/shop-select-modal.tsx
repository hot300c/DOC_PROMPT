"use client";

import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Shop } from "../_models/shop-model";
import { DataTable } from "@/components/ui/dataTable";
import { SHOP_COLUMNS } from "@/app/(main)/cua-hang/_utils/general-table-columns";
import { useState } from "react";

interface ShopSelectModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  shops: Shop[];
  onShopSelect: (shop: Shop) => void;
}

export default function ShopSelectModal({
  open,
  shops,
  onOpenChange,
  onShopSelect,
}: ShopSelectModalProps) {
  const [selectedShop, setSelectedShop] = useState<Shop | null>(null);
  const handleSelect = () => {
    if (selectedShop) {
      onShopSelect(selectedShop);
      onOpenChange(false);
    }
  };

  const handleRowClick = (shop: Shop) => {
    setSelectedShop(shop);
  };

  const handleRowDoubleClick = (shop: Shop) => {
    setSelectedShop(shop);
    handleSelect();
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg h-[32vh] flex flex-col">
        <DialogHeader className="flex-shrink-0">
          <DialogTitle>Chọn cửa hàng</DialogTitle>
        </DialogHeader>
        <div className="flex-grow overflow-auto min-h-0">
          <DataTable
            columns={SHOP_COLUMNS}
            data={shops}
            enablePaging={false}
            onRowClick={handleRowClick}
            onRowDoubleClick={handleRowDoubleClick}
            enableColumnFilter={false}
            enableGlobalFilter={false}
            placeholderSearch="Tìm cửa hàng..."
          />
        </div>
        <DialogFooter className="flex-shrink-0">
          <Button onClick={handleSelect} disabled={!selectedShop}>
            Chọn
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
