"use client";

import { useEffect, useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { useAppSelector } from "@/redux/store";
import { selectFaculty } from "@/redux/selectors";
import { DataTable } from "@/components/ui/dataTable";
import { getCountersByFacId } from "@/app/(main)/cua-hang/_action/get-counter";
import { Counter } from "@/app/(main)/cua-hang/_models/counter-model";
import { getWorkShiftByCounterIdAndFacId } from "@/app/(main)/cua-hang/_action/get-work-shift";
import { DATE_FORMAT, ETitleConfirm } from "@/app/lib/enums";
import { format } from "date-fns";
import { useFeedbackDialog } from "@/app/lib/feedback-dialog-provider";
import { notifyError } from "@/app/lib/utils";
import { WorkShift } from "@/app/(main)/cua-hang/_models/work-shift-model";
import { COUNTER_COLUMNS } from "@/app/(main)/cua-hang/_utils/general-table-columns";

interface CounterSelectModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onCounterSelect: (counter: Counter) => void;
  onStoreWorkShiftSelect: (workShift: WorkShift) => void;
}

export default function CounterSelectModal({
  open,
  onOpenChange,
  onCounterSelect,
  onStoreWorkShiftSelect,
}: CounterSelectModalProps) {
  const [counters, setCounters] = useState<Counter[]>([]);
  const [selectedCounter, setSelectedCounter] = useState<Counter | null>(null);
  const faculty = useAppSelector(selectFaculty);
  const { alert, confirm } = useFeedbackDialog();

  useEffect(() => {
    if (open) {
      const loadCounters = async () => {
        try {
          const shopsData = await getCountersByFacId(faculty.facId || "");
          setCounters(shopsData);
        } catch (error) {
          console.error("Failed to load shops:", error);
        }
      };

      void loadCounters();
    }
  }, [open, faculty.facId]);

  const handleSelect = async () => {
    // Note: QAs use service's info to save data between forms (saf) so some info have to be mapped back and forth
    // counterId_NT: counterID - default to 0 => no counter selected (don't ask) - we ignore these code
    if (selectedCounter) {
      try {
        // Fetch current work shift data for selected counter
        // This simulates the ws_L_ShiftDaily_LayCaHienTaiLamViec request from C#
        const workShift = await getWorkShiftByCounterIdAndFacId(
          faculty?.facId || "",
          selectedCounter.counterID,
        );

        if (!workShift) {
          await alert({
            title: ETitleConfirm.CANH_BAO,
            content: "Quầy bạn chọn chưa có ca làm việc.",
            buttonLabels: {
              Ok: "Xác nhận",
            },
          });

          return;
        }

        // Date validation - compare current date with work shift date
        const currentDate = format(new Date(), DATE_FORMAT.YYYYMMDD);

        const workShiftDate = format(
          workShift.ngayDoanhThu,
          DATE_FORMAT.YYYYMMDD,
        );

        if (workShiftDate !== currentDate) {
          // Show warning when dates don't match
          const confirmContinue = await confirm({
            title: ETitleConfirm.CANH_BAO,
            content:
              "Ca đang mở khác ngày hiện tại. Xác nhận tiếp tục ca hiện tại?",
          });

          if (!confirmContinue) {
            // User canceled, don't select counter
            return;
          }

          console.log("User continued with different date shift");
        }

        // Pass counter to parent component
        onCounterSelect(selectedCounter);

        // Pass work shift to parent component
        onStoreWorkShiftSelect(workShift);
        onOpenChange(false);
      } catch (error) {
        console.error("Failed to load work shift:", error);
        notifyError("Có lỗi xảy ra trong quá trình lấy thông tin ca làm việc.");
      } finally {
      }
    }
  };

  const handleRowClick = (counter: Counter) => {
    setSelectedCounter(counter);
  };

  const handleRowDoubleClick = (counter: Counter) => {
    setSelectedCounter(counter);
    void handleSelect();
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg h-[32vh] flex flex-col">
        <DialogHeader className="flex-shrink-0">
          <DialogTitle>Chọn quầy</DialogTitle>
        </DialogHeader>
        <div className="flex-grow overflow-auto min-h-0">
          <DataTable
            columns={COUNTER_COLUMNS}
            data={counters}
            enablePaging={false}
            onRowClick={handleRowClick}
            onRowDoubleClick={handleRowDoubleClick}
            enableColumnFilter={false}
            enableGlobalFilter={false}
            placeholderSearch="Tìm cửa hàng..."
          />
        </div>
        <DialogFooter className="flex-shrink-0">
          <Button onClick={handleSelect} disabled={!selectedCounter}>
            Chọn
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
