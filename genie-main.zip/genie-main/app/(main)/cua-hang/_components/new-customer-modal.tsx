"use client";

import React, { useEffect, useState } from "react";
import { Guid } from "js-guid";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Button } from "@/components/ui/button";
import { Select } from "@/components/select/select";
import { Input } from "@/components/ui/input";
import { NewCustomerData } from "../_models/customer-model";
import { Checkbox } from "@/components/ui/checkbox";
import { InputDatePicker } from "@/components/input-date-picker";
import {
  getDistrictsByProvinceId,
  getLocationData,
  getWardsByDistrictId,
} from "../_action/get-location-data";
import { LocationData } from "../_models/location-models";
import { useForm, useWatch } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useFeedbackDialog } from "@/app/lib/feedback-dialog-provider";
import { saveCustomer } from "../_action/save-new-customer";
import { notifySuccess } from "@/app/lib/utils";
import {
  customerFormSchema,
  CustomerFormValues,
} from "../_schema/customer-schema";

interface NewCustomerModalProps {
  open: boolean;
  onClose: () => void;
  onSave: (NewCustomerData: NewCustomerData) => void;
  facId: string; // Add facId prop
}

const NewCustomerModal: React.FC<NewCustomerModalProps> = ({
  open,
  onClose,
  onSave,
  facId,
}) => {
  // Location data state
  const [provinces, setProvinces] = useState<LocationData[]>([]);
  const [districts, setDistricts] = useState<LocationData[]>([]);
  const [wards, setWards] = useState<LocationData[]>([]);
  const { alert } = useFeedbackDialog();

  const form = useForm<CustomerFormValues>({
    resolver: zodResolver(customerFormSchema),
    defaultValues: {
      patientId: "",
      fullName: "",
      birthDate: new Date(),
      gender: 1,
      genderText: "Nam",
      streetNo: "",
      province: "",
      district: "",
      ward: "",
      phone: "",
      taxId: "",
      company: "",
      email: "",
      isWalkInCustomer: true,
    },
  });

  const province = useWatch({
    control: form.control,
    name: "province",
  });

  const district = useWatch({
    control: form.control,
    name: "district",
  });

  // Load provinces on component mount
  useEffect(() => {
    const fetchProvinces = async () => {
      try {
        const data = await getLocationData();

        // Sort to prioritize Hanoi and HCMC
        const sortedProvinces = [...data].sort((a, b) => {
          if (a.name === "Hà Nội" || a.name === "Hồ Chí Minh") return -1;
          if (b.name === "Hà Nội" || b.name === "Hồ Chí Minh") return 1;
          return a.name.localeCompare(b.name);
        });

        setProvinces(sortedProvinces);
      } catch (error) {
        console.error("Error loading provinces:", error);
      }
    };

    void fetchProvinces();
  }, []);

  // Load districts when province changes
  useEffect(() => {
    if (!province) {
      setDistricts([]);
      return;
    }

    const fetchDistricts = async () => {
      try {
        const data = await getDistrictsByProvinceId(province);
        setDistricts(data);
      } catch (error) {
        console.error("Error loading districts:", error);
      }
    };

    void fetchDistricts();
  }, [province]);

  useEffect(() => {
    if (!district) {
      setWards([]);
      return;
    }

    const fetchWards = async () => {
      try {
        const data = await getWardsByDistrictId(district);
        setWards(data);
      } catch (error) {
        console.error("Error loading wards:", error);
      }
    };

    void fetchWards();
  }, [district]);

  useEffect(() => {
    const province = form.watch("province");
    if (!province) {
      setDistricts([]);
      return;
    }

    const fetchDistricts = async () => {
      try {
        const data = await getDistrictsByProvinceId(province);
        setDistricts(data);
      } catch (error) {
        console.error("Error loading districts:", error);
      }
    };

    void fetchDistricts();
  }, [form]);

  useEffect(() => {
    const district = form.watch("district");
    if (!district) {
      setWards([]);
      return;
    }

    const fetchWards = async () => {
      try {
        const data = await getWardsByDistrictId(district);
        setWards(data);
      } catch (error) {
        console.error("Error loading wards:", error);
      }
    };

    void fetchWards();
  }, [form]);

  const onSubmit = async (values: CustomerFormValues) => {
    // Validate required fields
    if (!values.phone) {
      await alert({
        title: "Lỗi",
        content: "Vui lòng thêm thông tin số điện thoại",
      });
      return;
    }

    if (!values.fullName) {
      await alert({
        title: "Lỗi",
        content: "Vui lòng thêm thông tin tên khách hàng",
      });
      return;
    }
    values.fullName = values.fullName.trim();

    // Construct full address - matching the original C# code
    let fullAddress = "";
    if (values.streetNo?.trim()) {
      fullAddress += `${values.streetNo.trim()}, `;
    }

    // Find the actual names instead of IDs for the address
    const selectedWard = wards.find((w) => w.wardID === values.ward);
    if (selectedWard && selectedWard.name?.trim()) {
      fullAddress += `${selectedWard.name.trim()}, `;
    }

    const selectedDistrict = districts.find(
      (d) => d.districtID === values.district,
    );
    if (selectedDistrict && selectedDistrict.name?.trim()) {
      fullAddress += `${selectedDistrict.name.trim()}, `;
    }

    const selectedProvince = provinces.find((p) => p.id === values.province);
    if (selectedProvince && selectedProvince.name?.trim()) {
      fullAddress += `${selectedProvince.name.trim()}`;
    }

    // Remove trailing comma and space
    fullAddress = fullAddress.trim().replace(/,\s*$/, "");

    // Generate a new GUID for patientId if not provided
    const patientId = values.patientId || Guid.newGuid().toString();

    const updatedCustomer: NewCustomerData = {
      ...values,
      address: fullAddress,
      id: patientId,
      patientId: patientId,
      email: values.email.trim(),
      province: selectedProvince?.name || "",
      district: selectedDistrict?.name || "",
      ward: selectedWard?.name || "",
    };

    // If not a walk-in customer, save to the database
    if (!values.isWalkInCustomer) {
      try {
        const hospitalId = await saveCustomer(updatedCustomer, facId);

        if (hospitalId) {
          updatedCustomer.patientId = hospitalId;
          onSave(updatedCustomer);
          onClose();
          notifySuccess("Thông tin khách hàng đã được lưu thành công");
        } else {
          await alert({
            title: "Lỗi",
            content: "Không thể lưu thông tin khách hàng",
          });
        }
      } catch (error) {
        console.error("Error saving customer:", error);
        await alert({
          title: "Lỗi",
          content: "Không thể lưu thông tin khách hàng",
        });
      }
    } else {
      // For walk-in customers, just return the data
      updatedCustomer.patientId = "";
      onSave(updatedCustomer);
      onClose();
    }

    // Clear the form
    form.reset();
  };

  return (
    <Dialog
      open={open}
      onOpenChange={() => {
        onClose();
        form.reset(); // Reset the form when closing
      }}
    >
      <DialogContent className="bg-white max-w-[800px] flex flex-col max-h-[800px]">
        <DialogHeader className="w-full">
          <DialogTitle className="text-lg">Thông tin khách hàng</DialogTitle>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <div className="grid grid-cols-12 gap-4">
              <div className="col-span-12">
                <FormField
                  control={form.control}
                  name="fullName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel htmlFor="fullName">Họ và tên</FormLabel>
                      <FormControl>
                        <Input id="fullName" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="col-span-10">
                <FormField
                  control={form.control}
                  name="birthDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel htmlFor="birthDate">Năm sinh</FormLabel>
                      <FormControl>
                        <InputDatePicker
                          className="w-full"
                          value={field.value}
                          onChange={field.onChange}
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
              </div>

              <div className="col-span-2">
                <FormField
                  control={form.control}
                  name="gender"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Giới tính</FormLabel>
                      <div className="flex space-x-4 items-center mt-1">
                        <div className="flex items-center space-x-1">
                          <FormControl>
                            <input
                              type="radio"
                              id="genderMale"
                              value={1}
                              checked={field.value === 1}
                              onChange={() => {
                                field.onChange(1);
                                form.setValue("genderText", "Nam");
                              }}
                              className="h-4 w-4"
                            />
                          </FormControl>
                          <label htmlFor="genderMale">Nam</label>
                        </div>
                        <div className="flex items-center space-x-1">
                          <FormControl>
                            <input
                              type="radio"
                              id="genderFemale"
                              value={0}
                              checked={field.value === 0}
                              onChange={() => {
                                field.onChange(0);
                                form.setValue("genderText", "Nữ");
                              }}
                              className="h-4 w-4"
                            />
                          </FormControl>
                          <label htmlFor="genderFemale">Nữ</label>
                        </div>
                      </div>
                    </FormItem>
                  )}
                />
              </div>

              <div className="col-span-3 hidden">
                <FormField
                  control={form.control}
                  name="isWalkInCustomer"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel htmlFor="isWalkInCustomer">Khách lẻ</FormLabel>
                      <div className="flex items-center space-x-1 mt-1">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                      </div>
                    </FormItem>
                  )}
                />
              </div>

              <div className="col-span-12">
                <FormField
                  control={form.control}
                  name="streetNo"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel htmlFor="streetNo">Số nhà</FormLabel>
                      <FormControl>
                        <Input id="streetNo" {...field} />
                      </FormControl>
                    </FormItem>
                  )}
                />
              </div>

              <div className="col-span-4">
                <FormField
                  control={form.control}
                  name="province"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel htmlFor="province">Tỉnh/Thành</FormLabel>
                      <FormControl>
                        <Select
                          className="w-full"
                          value={field.value}
                          classNamePopover="w-90"
                          onChange={(value) => {
                            field.onChange(value);
                            form.setValue("district", "");
                            form.setValue("ward", "");
                          }}
                          options={provinces.map((province) => ({
                            label: province.name,
                            value: province.id,
                          }))}
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
              </div>

              <div className="col-span-4">
                <FormField
                  control={form.control}
                  name="district"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel htmlFor="district">Quận/Huyện</FormLabel>
                      <FormControl>
                        <Select
                          className="w-full"
                          value={field.value}
                          classNamePopover="w-90"
                          onChange={(value) => {
                            field.onChange(value);
                            form.setValue("ward", "");
                          }}
                          disabled={!form.watch("province")}
                          options={districts.map((district) => ({
                            label: district.name,
                            value: district.districtID,
                          }))}
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
              </div>

              <div className="col-span-4">
                <FormField
                  control={form.control}
                  name="ward"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel htmlFor="ward">Phường/Xã</FormLabel>
                      <FormControl>
                        <Select
                          className="w-full"
                          value={field.value}
                          classNamePopover="w-90"
                          onChange={field.onChange}
                          disabled={!form.watch("district")}
                          options={wards.map((ward) => ({
                            label: ward.name,
                            value: ward.wardID,
                          }))}
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
              </div>

              <div className="col-span-6">
                <FormField
                  control={form.control}
                  name="phone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel htmlFor="phone">SĐT</FormLabel>
                      <FormControl>
                        <Input
                          id="phone"
                          {...field}
                          maxLength={15}
                          pattern="[0-9]*"
                          type={"number"}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="col-span-6">
                <FormField
                  control={form.control}
                  name="taxId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel htmlFor="taxId">Mã số thuế</FormLabel>
                      <FormControl>
                        <Input id="taxId" {...field} />
                      </FormControl>
                    </FormItem>
                  )}
                />
              </div>

              <div className="col-span-6">
                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel htmlFor="email">Email</FormLabel>
                      <FormControl>
                        <Input id="email" {...field} />
                      </FormControl>
                    </FormItem>
                  )}
                />
              </div>

              <div className="col-span-6">
                <FormField
                  control={form.control}
                  name="company"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel htmlFor="company">Nơi công tác</FormLabel>
                      <FormControl>
                        <Input id="company" {...field} />
                      </FormControl>
                    </FormItem>
                  )}
                />
              </div>
            </div>
            <DialogFooter className="flex-shrink-0">
              <Button type="button" onClick={onClose}>
                Hủy
              </Button>
              <Button type="submit" color="primary">
                Lưu
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
};

export default NewCustomerModal;
