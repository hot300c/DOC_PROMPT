import { GiftProduct } from "@/app/(main)/cua-hang/_models/gift-product-model";
import { Button } from "@/components/ui/button";
import {
  DataTable,
  DataTableColumnHeaderSort,
} from "@/components/ui/dataTable";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { ColumnDef } from "@tanstack/react-table";
import _ from "lodash";
import React, { useEffect, useMemo, useRef, useState } from "react";

interface GiftSelectionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: (selectedGifts: GiftProduct[], note: string) => void;
  giftProducts: GiftProduct[];
  promotionName: string;
  billNote: string;
  noteGiftModal: string;
  missingProductNotes: string;
  setNoteGiftModal: (value: string) => void;
  onGiftSkipConfirm: (note: string) => Promise<void>;
}

export const GiftSelectionModal: React.FC<GiftSelectionModalProps> = ({
  isOpen,
  onClose,
  onConfirm,
  giftProducts,
  promotionName,
  billNote,
  noteGiftModal,
  setNoteGiftModal,
  onGiftSkipConfirm,
  missingProductNotes,
}) => {
  const [selectedItemId, setSelectedItemId] = useState<string | null>(null);
  const [note, setNote] = useState<string>("");

  useEffect(() => {
    setNote(noteGiftModal);
  }, [noteGiftModal]);

  const noteErrorMessageRef = useRef<HTMLSpanElement>(null);

  const columns = useMemo(() => {
    const result: ColumnDef<GiftProduct>[] = [
      {
        id: "select",
        cell: ({ row }) => (
          <div className="flex items-center justify-center">
            <Input
              type="radio"
              checked={row.original.giftProductId === selectedItemId}
              onChange={(value) => {
                if (value.target.checked) {
                  setSelectedItemId(row.original.giftProductId);
                }
              }}
            />
          </div>
        ),
        enableSorting: false,
        enableHiding: false,
      },
      {
        id: "giftProductCode",
        accessorKey: "giftProductCode",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Mã SP"
            className="justify-start"
          />
        ),
        cell: ({ row }) => (
          <div className="min-w-[100px]">{row.original.giftProductCode}</div>
        ),
      },
      {
        id: "giftProductName",
        accessorKey: "giftProductName",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Tên sản phẩm"
            className="justify-start"
          />
        ),
        cell: ({ row }) => (
          <div className="min-w-[200px]">{row.original.giftProductName}</div>
        ),
      },
      {
        id: "quantity",
        accessorKey: "quantity",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Số lượng"
            className="justify-start"
          />
        ),
        cell: ({ row }) => (
          <div className="min-w-[80px] text-center">
            {row.original.quantity}
          </div>
        ),
      },
    ];
    return result;
  }, [selectedItemId]);

  const handleConfirm = () => {
    if (selectedItemId) {
      const selectedGift = giftProducts.find(
        (gift) => gift.giftProductId === selectedItemId,
      );
      if (selectedGift) {
        onConfirm(
          [selectedGift],
          `${billNote ? billNote + ";" : ""}${missingProductNotes ? missingProductNotes + ";" : ""}${note ?? ""}`,
        );
      }
    }
  };

  const handleClose = () => {
    setSelectedItemId(null);
    onClose();
  };

  const handleOnSkipGift = () => {
    if (_.isEmpty((note ?? "").trim())) {
      noteErrorMessageRef.current!.innerText = "(Ghi chú không được để trống)";
      return;
    }
    noteErrorMessageRef.current!.innerText = "";
    setSelectedItemId(null);
    void onGiftSkipConfirm(
      `${billNote ? billNote + ";" : ""}${missingProductNotes ? missingProductNotes + ";" : ""}${note ?? ""}`,
    );
    onClose();
  };

  useEffect(() => {
    if (
      !_.isEmpty((note ?? "").trim()) &&
      noteErrorMessageRef?.current?.innerText
    ) {
      noteErrorMessageRef.current.innerText = "";
    }
  }, [note]);

  // Reset selected item when modal opens with new gifts
  React.useEffect(() => {
    if (isOpen) {
      setSelectedItemId(null);
    }
  }, [isOpen]);

  // Handle double click on a row
  const handleRowDoubleClick = (row: GiftProduct) => {
    setSelectedItemId(row.giftProductId);
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-4xl max-h-[80vh]">
        <DialogHeader>
          <DialogTitle className="mr-4">
            Chọn quà tặng - {promotionName}
          </DialogTitle>
        </DialogHeader>

        <div className="flex flex-col gap-4 overflow-hidden">
          <div className="text-sm text-gray-600">
            Vui lòng chọn một quà tặng bạn muốn nhận từ chương trình khuyến mãi
            này:
          </div>

          <div className="flex-1 overflow-hidden">
            <DataTable
              columns={columns}
              data={giftProducts}
              enablePaging={false}
              enableToggleColumn={false}
              enableColumnFilter={false}
              onRowDoubleClick={handleRowDoubleClick}
            />
          </div>

          <div>
            <Label>Ghi chú</Label>
            <span
              ref={noteErrorMessageRef}
              className="text-xs text-red-600 ml-2"
            ></span>
            <Textarea
              value={note}
              onChange={(e) => {
                setNote(e.target.value);
                setNoteGiftModal(e.target.value);
              }}
            />
          </div>

          <div className="flex justify-between items-center pt-4 border-t">
            <div className="text-sm text-gray-600">
              {selectedItemId ? "Đã chọn 1 sản phẩm" : "Chưa chọn sản phẩm"}
            </div>
            <div className="flex gap-2">
              <Button variant="outline" onClick={handleOnSkipGift}>
                Bỏ qua
              </Button>
              <Button onClick={handleConfirm} disabled={!selectedItemId}>
                Xác nhận
              </Button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
