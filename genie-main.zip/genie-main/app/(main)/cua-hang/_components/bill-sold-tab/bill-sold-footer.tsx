"use client";
import { useBaseSetting } from "@/app/hooks/useBaseSetting";
import { PaperSize } from "@/app/lib/enums";
import { useModal } from "@/app/lib/modal-print-provider";
import * as utils from "@/app/lib/utils";
import { notifyError } from "@/app/lib/utils";
import { Button } from "@/components/ui/button";
import { selectBaseSetting } from "@/redux/selectors";
import { useAppSelector } from "@/redux/store";
import { useState } from "react";
import { useBillSold } from "./bill-sold-provider";
import ReceiptReversal from "./receipt-reversal/receipt-reversal";
import ReceiptReversalExchangePoint from "./receipt-reversal/receipt-reversal-exchange-point";
import ScratchCardInfo from "./scratch-card-info";

const BillSoldFooter = () => {
  const [showScratchCardInfo, setShowScratchCardInfo] = useState(false);
  const [receiptReversal, setReceiptReversal] = useState(false);
  const context = useBillSold();
  const { getBaseSettingValue } = useBaseSetting();
  const baseSettings = useAppSelector(selectBaseSetting);

  const {
    isDisableReceive,
    facId,
    invoiceBusiness,
    isExchangePoint,
    setKeyReloadInvoiceData,
  } = context!;
  const { openModal } = useModal();

  const handlePrint = async () => {
    try {
      const reportId =
        getBaseSettingValue({
          name: "BienLaiThuTienBanLe",
          category: "Report_BanLe_1",
        }) || "";

      // Prepare parameters for the report
      const reportParams = {
        InvoiceBusinessID: invoiceBusiness?.invoiceBusinessID,
        FacID: facId,
        IsTemp: 0,
      };

      // Generate the report
      const base64Res = await utils.handleBase64(
        reportId,
        facId,
        reportParams,
        baseSettings,
        true,
        PaperSize.A5,
      );

      if (base64Res) {
        await openModal({
          reportID: reportId,
          base64Data: base64Res,
          paperSize: PaperSize.A5,
        });
      }
    } catch (error) {
      console.error("Error printing receipt:", error);
      notifyError("Lỗi khi in biên lai");
    }
  };

  return (
    <>
      <footer className="flex items-center bg-strong-blue justify-between py-1 px-4 border-t fs-unmask">
        <div className="flex items-center space-x-1">
          <Button
            disabled={!invoiceBusiness}
            className="flex items-center gap-1"
            onClick={handlePrint}
          >
            In lại
          </Button>
          <Button
            className="flex items-center gap-1"
            onClick={() => {
              setShowScratchCardInfo(true);
            }}
          >
            Thông tin thẻ cào
          </Button>
        </div>
        <div className="flex items-center space-x-1">
          <Button
            className="flex items-center gap-1"
            onClick={() => setReceiptReversal(true)}
            disabled={isDisableReceive}
          >
            Hoàn / hủy biên lai
          </Button>
          {!isExchangePoint && (
            <Button className="flex items-center gap-1" disabled>
              Hủy phương thức thanh toán
            </Button>
          )}
        </div>
      </footer>

      {showScratchCardInfo && (
        <ScratchCardInfo onClose={() => setShowScratchCardInfo(false)} />
      )}
      {receiptReversal &&
        (isExchangePoint ? (
          <ReceiptReversalExchangePoint
            onClose={() => {
              setReceiptReversal(false);
              setKeyReloadInvoiceData(utils.GUID_NewSequential());
            }}
          />
        ) : (
          <ReceiptReversal
            onClose={() => {
              setReceiptReversal(false);
              setKeyReloadInvoiceData(utils.GUID_NewSequential());
            }}
          />
        ))}
    </>
  );
};

export default BillSoldFooter;
