import BillSoldFilter from "./bill-sold-filter";
import BillSoldFooter from "./bill-sold-footer";
import { BillSoldProvider } from "./bill-sold-provider";
import InvoiceBusinessesDetailTable from "./invoice-business-detail-table";
import InvoiceBusinessTable from "./invoice-business-table.";

const BillSoldTab = ({
  isExchangePoint = false,
}: {
  isExchangePoint?: boolean;
}) => {
  return (
    <BillSoldProvider isExchangePoint={isExchangePoint}>
      <div className="flex flex-col h-full">
        <BillSoldFilter />
        <div className="flex flex-1 h-0 mx-2 mb-1 overflow-hidden">
          <div className="w-1/2 mr-2 bg-white border rounded-md flex flex-col">
            <h2 className="ml-4">Danh sách hóa đơn</h2>
            <div className="flex-1 overflow-hidden mx-1 pb-[40px]">
              <InvoiceBusinessTable />
            </div>
          </div>
          <div className="w-1/2 bg-white border rounded-md flex flex-col">
            <h2 className="ml-4">Chi tiết hóa đơn</h2>
            <div className="flex-1 overflow-hidden mx-1">
              <InvoiceBusinessesDetailTable />
            </div>
          </div>
        </div>
        <BillSoldFooter />
      </div>
    </BillSoldProvider>
  );
};

export default BillSoldTab;
