import { DATE_FORMAT } from "@/app/lib/enums";
import * as utils from "@/app/lib/utils";
import { VirtualSelect } from "@/components/select/virtual-select/virtual-select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { format } from "date-fns";
import { useMemo, useState } from "react";
import useSWR from "swr";
import {
  getRetailInvoiceInfo,
  getShiftDailyListNhaThuoc,
} from "../../../_action/get-bill-sold";
import {
  RetailInvoiceInfo,
  ShiftDailyModel,
} from "../../../_models/bill-sold-model";
import { useBillSold } from "../bill-sold-provider";

interface InvoiceInfoProps {
  retailInvoiceInfo: RetailInvoiceInfo | null;
  setRetailInvoiceInfo: (value: RetailInvoiceInfo | null) => void;
  shiftDailyId: string;
  setShiftDailyId: (value: string) => void;
}

const InvoiceInfo = ({
  retailInvoiceInfo,
  setRetailInvoiceInfo,
  shiftDailyId,
  setShiftDailyId,
}: InvoiceInfoProps) => {
  const context = useBillSold();
  const { facId, invoiceBusiness } = context!;
  const [shiftDailies, setShiftDailies] = useState<ShiftDailyModel[]>([]);

  useSWR(facId ? facId : null, async () => {
    const result = await getShiftDailyListNhaThuoc(facId || "");
    setShiftDailies(result || []);
  });

  useSWR(
    invoiceBusiness?.invoiceBusinessID
      ? `${invoiceBusiness?.invoiceBusinessID}`
      : null,
    async () => {
      const data = await getRetailInvoiceInfo(
        facId,
        invoiceBusiness?.invoiceBusinessID || "",
      );
      setRetailInvoiceInfo(data || null);
    },
  );

  const shiftOptions = useMemo(() => {
    return shiftDailies
      .filter((x) => {
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const ngayDoanhThu = new Date(x.ngayDoanhThu);
        ngayDoanhThu.setHours(0, 0, 0, 0);
        return ngayDoanhThu.getTime() === today.getTime();
      })
      .map((v) => ({
        value: String(v.shiftDailyID),
        label: v.shiftName,
      }));
  }, [shiftDailies]);

  const formatToVNTime = (dateStr: string): string => {
    const date = new Date(dateStr);
    const formattedDate = format(date, DATE_FORMAT.DD_MM_YYYY_HH_MM_SS);
    return `${formattedDate} ${date.getHours() >= 12 ? "CH" : "SA"}`;
  };

  return (
    <div className="space-y-0.5 h-lg:pl-6 h-lg:pr-3 h-lg:py-3 h-lg:space-y-1.5 mb-2">
      <div className="grid grid-cols-12">
        <div className="col-span-4 flex items-center">
          <Label className="w-25 flex-shrink-0">Ca hủy:</Label>
          <VirtualSelect
            className="w-xpt-70"
            value={shiftDailyId || ""}
            classNamePopover="w-65 h-md:w-95"
            placeholder="Chọn Ca/Quầy"
            onChange={(value) => {
              setShiftDailyId(value);
            }}
            options={shiftOptions}
          />
        </div>

        <div className="col-span-8 ml-4 flex items-center">
          <p className="text-red-90 text-sm">
            Ca hủy trùng với ca phát sẽ hủy biên lai , khác ca phát sẽ hoàn biên
            lai
          </p>
        </div>
      </div>
      <div className="grid grid-cols-12">
        <div className="col-span-4 flex items-center">
          <Label className="w-25 flex-shrink-0">Mã phiếu:</Label>
          <Input
            className="w-xpt-70"
            value={retailInvoiceInfo?.maPhieu || ""}
            readOnly
            disabled
          />
        </div>
        <div className="col-span-4 ml-4 flex items-center">
          <Label className="w-25 flex-shrink-0">Ngày Xuất:</Label>
          <Input
            className="w-xpt-70"
            value={
              retailInvoiceInfo?.ngayXuat
                ? formatToVNTime(retailInvoiceInfo?.ngayXuat)
                : ""
            }
            readOnly
            disabled
          />
        </div>
        <div className="col-span-4 ml-4 flex items-center">
          <Label className="w-15 flex-shrink-0">Ca Xuất:</Label>
          <Input
            className="w-xpt-70"
            value={retailInvoiceInfo?.caXuat || ""}
            readOnly
            disabled
          />
        </div>
      </div>
      <div className="grid grid-cols-12">
        <div className="col-span-4 flex items-center">
          <Label className="w-25 flex-shrink-0">Khách hàng:</Label>
          <Input
            className="w-xpt-70"
            value={retailInvoiceInfo?.tenKhachHang || ""}
            readOnly
            disabled
          />
        </div>
        <div className="col-span-4 ml-4 flex items-center">
          <Label className="w-25 flex-shrink-0">Số điện thoại:</Label>
          <Input
            className="w-xpt-70"
            value={retailInvoiceInfo?.phone || ""}
            readOnly
            disabled
          />
        </div>
        <div className="col-span-4 ml-4 flex items-center">
          <Label className="w-15 flex-shrink-0">Địa chỉ:</Label>
          <Input
            title={retailInvoiceInfo?.diaChi || ""}
            className="w-xpt-70"
            value={retailInvoiceInfo?.diaChi || ""}
            readOnly
            disabled
          />
        </div>
      </div>
      <div className="grid grid-cols-12">
        <div className="col-span-4 flex items-center">
          <Label className="w-25 flex-shrink-0">Người xuất:</Label>
          <Input
            className="w-xpt-70"
            value={retailInvoiceInfo?.nguoiXuat || ""}
            readOnly
            disabled
          />
        </div>
        <div className="col-span-4 ml-4 flex items-center">
          <Label className="w-25 flex-shrink-0">Thành tiền :</Label>
          <Input
            className="w-xpt-70"
            value={utils.formatCurrencyVND(
              retailInvoiceInfo?.thanhTien || 0,
              4,
              false,
            )}
            readOnly
            disabled
          />
        </div>
      </div>
    </div>
  );
};
export default InvoiceInfo;
