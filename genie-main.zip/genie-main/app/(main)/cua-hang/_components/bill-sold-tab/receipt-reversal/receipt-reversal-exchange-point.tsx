import { useBaseSetting } from "@/app/hooks/useBaseSetting";
import { SequenceRequest } from "@/app/lib/definitions/setting";
import { ELoadingMessages, ETitleConfirm, PaperSize } from "@/app/lib/enums";
import { useFeedbackDialog } from "@/app/lib/feedback-dialog-provider";
import { useModal } from "@/app/lib/modal-print-provider";
import { executeTransaction } from "@/app/lib/services/system";
import * as utils from "@/app/lib/utils";
import useLoading from "@/components/loading";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogOverlay,
  DialogTitle,
} from "@/components/ui/dialog";
import { selectBaseSetting } from "@/redux/selectors";
import { useAppSelector } from "@/redux/store";
import { useState } from "react";
import { callTemService } from "../../../_action/tem-services";
import {
  ApprovedOutDetail,
  RetailInvoiceInfo,
} from "../../../_models/bill-sold-model";
import { useBillSold } from "../bill-sold-provider";
import InvoiceInfo from "./invoice-info";
import ReceiptReversalExchangePointTable from "./receipt-reversal-exchange-point-table";

const ReceiptReversalExchangePoint = ({ onClose }: { onClose: () => void }) => {
  const [retailInvoiceInfo, setRetailInvoiceInfo] =
    useState<RetailInvoiceInfo | null>(null);
  const [approvedOutDetails, setApprovedOutDetails] = useState<
    ApprovedOutDetail[]
  >([]);
  const context = useBillSold();
  const { facId, invoiceBusiness } = context!;
  const [shiftDailyId, setShiftDailyId] = useState<string>("");
  const [isDisableBtn, setIsDisableBtn] = useState<boolean>(false);
  const { alert, confirm } = useFeedbackDialog();
  const { getBaseSettingValue } = useBaseSetting();
  const baseSettings = useAppSelector(selectBaseSetting);
  const { openModal } = useModal();
  const { showLoading, hideLoading } = useLoading();

  const checkStatus = async (
    approvedOutDetails: ApprovedOutDetail[],
  ): Promise<{ result: boolean; errorMessage: string }> => {
    let result = true;
    let errorMessage = "";
    const linkUrl = "http://vnvc.vinachg.vn/tem-services/check";

    for (const item of approvedOutDetails) {
      if (!item.serial) continue;
      try {
        const payload = { serial: item.serial };
        const data = await callTemService({
          url: linkUrl,
          payload,
          headers: { "x-key-check": "e57D)8J^EHJtu=r" },
        });
        if (data?.status === 1) {
          result = false;
        }
        if (data?.status === -1) {
          result = false;
        }
        if (data?.status === 0) {
          result = false;
          errorMessage = "không tồn tại serial này";
        }
        if (data?.status === 2) {
          result = true;
        }
        if (data?.status === 3) {
          result = false;
          errorMessage = "đã bị kích hoạt và sử dụng nên không thể hủy";
        }
      } catch (error) {
        result = false;
        errorMessage = "Không thể kích hoạt";
      }
    }

    return { result: result, errorMessage: errorMessage };
  };

  const handleDeactivate = async (
    selectedScratchcards: ApprovedOutDetail[],
  ) => {
    const linkUrl = "http://vnvc.vinachg.vn/tem-services/restore";

    for (const item of selectedScratchcards) {
      if (!item.serial) continue;
      try {
        const payload = { serial: item.serial, phone: item.phone };
        const response = await callTemService({
          url: linkUrl,
          payload,
          headers: { "x-key-restore": "^]dvB(!b@9MT7Jx(" },
        });
        if (response) {
          const dataString = JSON.stringify(response);
          if (response?.status === 1) {
            const requests = [] as SequenceRequest[];
            requests.push({
              category: "QAHosGenericDB",
              command: "ws_CN_ScratchcardRefundSaled_Log_Save",
              parameters: {
                Mathe: item?.serial || "",
                Phone: item?.phone || "",
                ProductID: item?.productID?.toString() || "",
                TrangThai: response.status,
                TinNhan: "Thành công",
                responseString: dataString,
              },
            });
            requests.push({
              category: "QAHosGenericDB",
              command: "ws_CN_ScratchcardRefundSaled_Save",
              parameters: {
                Mathe: item?.serial || "",
                Phone: item?.phone || "",
                ProductID: item?.productID?.toString() || "",
                InvoiceID: invoiceBusiness?.invoiceBusinessID || "",
                TrangThai: response.status,
              },
            });

            try {
              const result = await executeTransaction({ request: requests });
              if (result === null) return;
            } catch (error) {
              if (error instanceof Error) {
                utils.notifyError(`Lưu không thành công: ${error?.message}`);
              }
            }
          } else {
            const requests = [] as SequenceRequest[];
            requests.push({
              category: "QAHosGenericDB",
              command: "ws_CN_ScratchcardRefundSaled_Log_Save",
              parameters: {
                Mathe: item?.serial || "",
                Phone: item?.phone || "",
                ProductID: item?.productID?.toString() || "",
                TrangThai: response.status,
                TinNhan: response?.message || "",
                responseString: dataString,
              },
            });

            try {
              const result = await executeTransaction({ request: requests });
              if (result === null) return;
              void alert({
                title: ETitleConfirm.THONG_BAO,
                content: response?.message || "",
              });
            } catch (error) {
              if (error instanceof Error) {
                utils.notifyError(`Lưu không thành công: ${error?.message}`);
              }
            }
          }
        }
      } catch (error: any) {
        if (error?.response) {
          const response = error?.response;
          const requests = [] as SequenceRequest[];
          requests.push({
            category: "QAHosGenericDB",
            command: "ws_CN_ScratchcardRefundSaled_Log_Save",
            parameters: {
              Mathe: item?.serial || "",
              Phone: item?.phone || "",
              ProductID: item?.productID?.toString() || "",
              TrangThai: response?.status || 0,
              TinNhan: response?.message || "",
              responseString: JSON.stringify(response) || "",
            },
          });

          try {
            const result = await executeTransaction({ request: requests });
            if (result === null) return;
            void alert({
              title: ETitleConfirm.THONG_BAO,
              content: response?.message || "",
            });
          } catch (error) {
            if (error instanceof Error) {
              utils.notifyError(`Lưu không thành công: ${error?.message}`);
            }
          }
        }
      }
    }
  };

  const validatePreReturnProduct = async (
    approvedOutDetails: ApprovedOutDetail[],
  ): Promise<boolean> => {
    if (!approvedOutDetails?.length) return false;
    const source = approvedOutDetails.filter((x) => x.refundQty > 0);
    if (!source?.length) {
      await alert({
        title: ETitleConfirm.THONG_BAO,
        content: "Không có thuốc nào có số lượng trả",
      });
      return false;
    }
    const checkStatusResult = await checkStatus(source);
    if (!checkStatusResult.result) {
      await alert({
        title: ETitleConfirm.THONG_BAO,
        content: checkStatusResult.errorMessage,
      });
      return false;
    }
    return true;
  };

  const handleReturnProduct = async () => {
    if (!shiftDailyId) {
      await alert({ title: "Thông báo", content: "Vui lòng chọn ca hoàn hủy" });
      return;
    }
    const answer = await confirm({
      title: ETitleConfirm.CANH_BAO,
      content: `Bạn có chắc chắn muốn ${shiftDailyId === retailInvoiceInfo?.shiftDailyIDXuat ? "hủy" : "hoàn trả"} biên lai này không?`,
    });
    if (!answer) return;

    const loadingId = showLoading(ELoadingMessages.WAITING, "z-100");

    try {
      const invoiceBusinessId_New = utils.GUID_NewSequential();
      const approvedInId = utils.GUID_NewSequential();

      if (invoiceBusiness?.trangThaiHoan === 0) {
        if (shiftDailyId === retailInvoiceInfo?.shiftDailyIDXuat) {
          const answer = await confirm({
            title: ETitleConfirm.THONG_BAO,
            content:
              "Biên lai bị hủy sẽ không khôi phục được, bạn có muốn hủy không?",
          });
          if (!answer) return;
          if (!(await validatePreReturnProduct(approvedOutDetails))) return;
          const requests = [] as SequenceRequest[];
          requests.push({
            category: "QAHosGenericDB",
            command: "ws_BIL_InvoiceBusiness_HuyBienLaiBanLe",
            parameters: {
              ApprovedInID: approvedInId,
              PhieuXuatCuID: retailInvoiceInfo?.phieuXuatID || "",
              FacID: facId || "",
              ShiftDailyID: shiftDailyId,
              Notes: "Nhà thuốc: nhập hoàn trả",
              InvoiceBusinessID: invoiceBusiness.invoiceBusinessID,
            },
          });

          try {
            const result = await executeTransaction({ request: requests });
            if (result === null) return;
          } catch (error) {
            if (error instanceof Error) {
              utils.notifyError(`Lưu không thành công: ${error?.message}`);
            }
            return;
          }
          await handleDeactivate(
            approvedOutDetails.filter((x) => x.approvedQty > 0),
          );
          setIsDisableBtn(true);

          await handleRunPrint("b7fd38a1-bf21-48db-81a3-8d088b722b93", {
            ApprovedInID: approvedInId,
            FacID: facId,
            InvoiceBusinessID_New: invoiceBusinessId_New,
          });

          await handleRunPrint("643EDA4F-0F8A-48C5-814B-E49B3F19E5A7", {
            InvoiceID: invoiceBusiness.invoiceBusinessID,
            FacID: facId,
          });
          return;
        }
        if (!(await validatePreReturnProduct(approvedOutDetails))) return;

        try {
          const result = await executeTransaction({
            request: [
              {
                category: "QAHosGenericDB",
                command: "ws_BIL_InvoiceBusiness_HoanBienLaiBanLe",
                parameters: {
                  ApprovedInID: approvedInId,
                  PhieuXuatCuID: retailInvoiceInfo?.phieuXuatID || "",
                  SluongTra: approvedOutDetails
                    .map((x) => x.refundQty)
                    .join("|")
                    .replace(",", "."),
                  FacID: facId || "",
                  ShiftDailyID: shiftDailyId,
                  Notes: "Nhà thuốc: nhập hoàn trả",
                  ApprovedOutDetailIDs: approvedOutDetails
                    .map((x) => x.approvedOutDetailID)
                    .join("|"),
                  InvoiceBusinessIDNew: invoiceBusinessId_New,
                  InvoiceBusinessID: invoiceBusiness.invoiceBusinessID,
                  ProductIDTras: approvedOutDetails
                    .map((x) => x.productID)
                    .join("|"),
                },
              },
            ],
          });
          if (result === null) return;
        } catch (error) {
          if (error instanceof Error) {
            utils.notifyError(`Lưu không thành công: ${error?.message}`);
          }
          return;
        }
        await handleDeactivate(
          approvedOutDetails.filter((x) => x.approvedQty > 0),
        );
        setIsDisableBtn(true);
        try {
          const result = await executeTransaction({
            request: [
              {
                category: "QAHosGenericDB",
                command: "ws_BIL_InvoiceBusiness_KiemTraBienLai",
                parameters: {
                  invoiceBusinessId_New,
                },
              },
            ],
          });
          if (result === null) return;
          if (result?.table?.length > 0) {
            const reportId =
              getBaseSettingValue({
                name: "BienLaiThuTienBanLe",
                category: "Report_BanLe_1",
              }) || "";

            const reportParams = {
              InvoiceBusinessID: invoiceBusinessId_New,
              FacID: facId,
              IsTemp: 0,
            };
            await handleRunPrint(reportId, reportParams);
          }
        } catch (error) {
          if (error instanceof Error) {
            utils.notifyError(`Lưu không thành công: ${error?.message}`);
          }
          return;
        }
        await handleRunPrint("643EDA4F-0F8A-48C5-814B-E49B3F19E5A7", {
          InvoiceID: invoiceBusiness.invoiceBusinessID,
          FacID: facId,
        });
        await handleRunPrint(
          "b7fd38a1-bf21-48db-81a3-8d088b722b93",
          {
            ApprovedInID: approvedInId,
            InvoiceBusinessID_New: invoiceBusinessId_New,
            FacID: facId,
          },
          PaperSize.A5,
        );
        return;
      }
      if (!(await validatePreReturnProduct(approvedOutDetails))) return;

      try {
        const result = await executeTransaction({
          request: [
            {
              category: "QAHosGenericDB",
              command: "ws_BIL_InvoiceBusiness_HoanBienLaiBanLeLan2",
              parameters: {
                ApprovedInID: approvedInId,
                PhieuXuatCuID: retailInvoiceInfo?.phieuXuatID || "",
                SluongTra: approvedOutDetails
                  .map((x) => x.refundQty)
                  .join("|")
                  .replace(",", "."),
                FacID: facId || "",
                ShiftDailyID: shiftDailyId,
                Notes: "Nhà thuốc: nhập hoàn trả",
                ApprovedOutDetailIDs: approvedOutDetails
                  .map((x) => x.approvedOutDetailID)
                  .join("|"),
                InvoiceBusinessIDNew: invoiceBusinessId_New,
                InvoiceBusinessID: invoiceBusiness?.invoiceBusinessID || "",
                ProductIDTras: approvedOutDetails
                  .map((x) => x.productID)
                  .join("|"),
                Batchs: approvedOutDetails.map((x) => x.batch).join("|"),
                ExpDates: approvedOutDetails.map((x) => x.expdate).join("|"),
                RefundType:
                  shiftDailyId === retailInvoiceInfo?.shiftDailyIDXuat ? 1 : 2,
                TrangThaiHoan: invoiceBusiness?.trangThaiHoan,
              },
            },
          ],
        });

        if (result === null) return;
      } catch (error) {
        if (error instanceof Error) {
          utils.notifyError(`Lưu không thành công: ${error?.message}`);
        }
        return;
      }
      await handleDeactivate(
        approvedOutDetails.filter((x) => x.approvedQty > 0),
      );
      setIsDisableBtn(true);
      try {
        const result = await executeTransaction({
          request: [
            {
              category: "QAHosGenericDB",
              command: "ws_BIL_InvoiceBusiness_KiemTraBienLai",
              parameters: {
                invoiceBusinessId_New,
              },
            },
          ],
        });
        if (result === null) return;
        if (result?.table?.length > 0) {
          const reportId =
            getBaseSettingValue({
              name: "BienLaiThuTienBanLe",
              category: "Report_BanLe_1",
            }) || "";
          await handleRunPrint(reportId, {
            InvoiceBusinessID: invoiceBusinessId_New,
            FacID: facId,
            IsTemp: 0,
          });
        }
      } catch (error) {
        if (error instanceof Error) {
          utils.notifyError(`Lưu không thành công: ${error?.message}`);
        }
        return;
      }
      await handleRunPrint("643EDA4F-0F8A-48C5-814B-E49B3F19E5A7", {
        InvoiceID: invoiceBusiness?.invoiceBusinessID,
        FacID: facId,
      });
      await handleRunPrint(
        "b7fd38a1-bf21-48db-81a3-8d088b722b93",
        {
          ApprovedInID: approvedInId,
          InvoiceBusinessID_New: invoiceBusinessId_New,
          FacID: facId,
        },
        PaperSize.A5,
      );
    } finally {
      hideLoading(loadingId);
    }
  };

  const handlePrint = async () => {
    try {
      const reportId =
        getBaseSettingValue({
          name: "BienLaiThuTienBanLe",
          category: "Report_BanLe_1",
        }) || "";

      // Prepare parameters for the report
      const reportParams = {
        InvoiceBusinessID: invoiceBusiness?.invoiceBusinessID,
        FacID: facId,
        IsTemp: 0,
      };

      // Generate the report
      await handleRunPrint(reportId, reportParams);
    } catch (error) {
      console.error("Error printing receipt:", error);
      utils.notifyError("Lỗi khi in biên lai");
    }
  };

  const handleRunPrint = async (
    reportId: string,
    reportParams: any,
    paperSize = PaperSize.A5,
  ) => {
    try {
      // Generate the report
      const base64Res = await utils.handleBase64(
        reportId,
        facId,
        reportParams,
        baseSettings,
        true,
        paperSize,
      );

      if (base64Res) {
        await openModal({
          reportID: reportId,
          base64Data: base64Res,
          paperSize: paperSize,
          width: "min-w-165 max-w-fit",
        });
      }
    } catch (error) {
      console.error("Error printing receipt:", error);
      utils.notifyError("Lỗi khi in biên lai");
    }
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogOverlay />
      <DialogContent className="sm:max-w-[90vw] h-[80vh] bg-white z-100">
        <DialogHeader>
          <DialogTitle>Hoàn / hủy biên lai</DialogTitle>
        </DialogHeader>

        <div className="p-4 min-h-[73vh] h-sm:min-h-[74vh] h-md:min-h-[76vh]  flex flex-col flex-1 overflow-hidden h-full">
          <InvoiceInfo
            retailInvoiceInfo={retailInvoiceInfo}
            setRetailInvoiceInfo={setRetailInvoiceInfo}
            shiftDailyId={shiftDailyId}
            setShiftDailyId={setShiftDailyId}
          />

          <ReceiptReversalExchangePointTable
            shiftDailyId={shiftDailyId}
            retailInvoiceInfo={retailInvoiceInfo}
            approvedOutDetails={approvedOutDetails}
            setApprovedOutDetails={setApprovedOutDetails}
          />

          <div className="flex justify-between mt-1">
            <Button onClick={handlePrint}>In biên lai</Button>

            <Button disabled={isDisableBtn} onClick={handleReturnProduct}>
              {shiftDailyId
                ? retailInvoiceInfo?.shiftDailyIDXuat === shiftDailyId
                  ? "Hủy biên lai"
                  : "Hoàn trả biên lai"
                : "Trả sản phẩm"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
export default ReceiptReversalExchangePoint;
