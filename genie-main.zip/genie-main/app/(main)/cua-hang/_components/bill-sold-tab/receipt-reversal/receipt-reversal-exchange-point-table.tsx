import {
  DataTable,
  DataTableColumnHeaderSort,
} from "@/components/ui/dataTable";
import { ColumnDef } from "@tanstack/react-table";
import {
  ApprovedOutDetail,
  RetailInvoiceInfo,
} from "../../../_models/bill-sold-model";

import { DATE_FORMAT } from "@/app/lib/enums";
import * as utils from "@/app/lib/utils";
import { Input } from "@/components/ui/input";
import { format } from "date-fns";
import { useMemo, useRef, useState } from "react";
import useSWR from "swr";
import { getApprovedOutDetails } from "../../../_action/get-bill-sold";
import { useBillSold } from "../bill-sold-provider";

const ReceiptReversalExchangePointTable = ({
  shiftDailyId,
  retailInvoiceInfo,
  approvedOutDetails,
  setApprovedOutDetails,
}: {
  shiftDailyId: string;
  retailInvoiceInfo: RetailInvoiceInfo | null;
  approvedOutDetails: ApprovedOutDetail[];
  setApprovedOutDetails: (data: ApprovedOutDetail[]) => void;
}) => {
  const context = useBillSold();
  const { facId, invoiceBusiness, isExchangePoint } = context!;
  const refundQtyMapRef = useRef<Record<string, number>>({});

  useSWR(
    retailInvoiceInfo?.phieuXuatID ? `${retailInvoiceInfo?.phieuXuatID}` : null,
    async () => {
      const data = await getApprovedOutDetails(
        facId,
        invoiceBusiness?.invoiceBusinessID || "",
        retailInvoiceInfo?.phieuXuatID || "",
        isExchangePoint,
      );
      setApprovedOutDetails(data || []);
      refundQtyMapRef.current = Object.fromEntries(
        data?.map((x) => [x.invoiceBusinessDetailID, x.refundQty]),
      );
    },
  );

  const RefundQtyInput = ({ row }: { row: ApprovedOutDetail }) => {
    const [value, setValue] = useState(row.refundQty?.toString() ?? "0");

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      const refundQtyRoot =
        refundQtyMapRef.current[row.invoiceBusinessDetailID];
      const newValue = Number(e.target.value || "0");
      if (newValue < 0 || newValue > (refundQtyRoot || 0)) return;

      setValue(e.target.value);
    };

    const handleBlur = () => {
      const refundQty = Number(value || 0);
      const data = approvedOutDetails.map((item) => {
        if (item.invoiceBusinessDetailID === row.invoiceBusinessDetailID) {
          item.refundQty = refundQty;
          item.thanhTienHoan = (item.price || 0) * refundQty;
        }
        return item;
      });
      setApprovedOutDetails(data);
    };

    return (
      <Input
        type="number"
        min={0}
        max={refundQtyMapRef.current[row.invoiceBusinessDetailID] || 0}
        step={1}
        onKeyDown={(e) => e.stopPropagation()}
        className="text-right"
        value={value}
        onChange={handleChange}
        onBlur={handleBlur}
      />
    );
  };

  const COLUMNS: ColumnDef<ApprovedOutDetail>[] = useMemo(() => {
    return [
      {
        id: "maSP",
        accessorKey: "maSP",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Mã SP" />
        ),
      },
      {
        id: "tenSP",
        accessorKey: "tenSP",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Tên SP" />
        ),
        cell: ({ row }) => (
          <div title={row.original.tenSP || ""}>{row.original.tenSP || ""}</div>
        ),
      },
      {
        id: "unitName",
        accessorKey: "unitName",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="ĐVT" />
        ),
      },
      {
        id: "approvedQty",
        accessorKey: "approvedQty",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="SL Xuất" />
        ),
        cell: ({ row }) => (
          <>
            {utils.formatCurrencyVND(row.original.approvedQty || 0, 3, false)}
          </>
        ),
      },
      {
        id: "refundQty",
        accessorKey: "refundQty",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="SL Trả" />
        ),
        cell: ({ row }) => <RefundQtyInput row={row.original} />,
      },
      {
        id: "batch",
        accessorKey: "batch",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Số lô" />
        ),
        cell: ({ row }) => <div>{row.original?.batch || ""}</div>,
      },

      {
        id: "expdate",
        accessorKey: "expdate",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Hạn dùng" />
        ),
        cell: ({ row }) => (
          <div>
            {row.original.expdate
              ? format(row.original.expdate, DATE_FORMAT.DD_MM_YYYY_VI)
              : ""}
          </div>
        ),
      },
      {
        id: "price",
        accessorKey: "price",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Đơn giá" />
        ),
        cell: ({ row }) => (
          <>{utils.formatCurrencyVND(row.original.price || 0, 2)}</>
        ),
      },
      {
        id: "thanhTienHoan",
        accessorKey: "thanhTienHoan",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Tổng điểm hoàn" />
        ),
        cell: ({ row }) => (
          <>{utils.formatCurrencyVND(row.original.thanhTienHoan || 0, 2)}</>
        ),
      },
      {
        id: "serial",
        accessorKey: "serial",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Serial" />
        ),
        cell: ({ row }) => <div>{row.original?.serial || ""}</div>,
      },
    ];
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [approvedOutDetails]);

  return (
    <div className="flex-1 overflow-hidden">
      <DataTable
        className="h-full overflow-auto border rounded-md"
        columns={COLUMNS.filter(
          (col) =>
            !shiftDailyId ||
            shiftDailyId !== retailInvoiceInfo?.shiftDailyIDXuat ||
            !["refundQty"].includes(col.id!),
        )}
        data={approvedOutDetails}
        enablePaging={false}
        enableColumnFilter={false}
        enableGlobalFilter={false}
      />
    </div>
  );
};

export default ReceiptReversalExchangePointTable;
