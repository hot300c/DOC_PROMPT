"use client";
import { selectFaculty } from "@/redux/selectors";
import { useAppSelector } from "@/redux/store";
import { createContext, useContext, useState } from "react";
import { InvoiceBusiness } from "../../_models/bill-sold-model";

type BillSoldContextType = {
  facId: string;
  isExchangePoint: boolean;
  shiftDailyId: string;
  setShiftDailyId: (value: string) => void;
  isDisableReceive: boolean;
  setIsDisableReceive: (value: boolean) => void;

  invoiceBusiness: InvoiceBusiness | null;
  setInvoiceBusiness: (value: InvoiceBusiness | null) => void;
  keyReloadInvoiceData?: string;
  setKeyReloadInvoiceData: (id: string) => void;
};

const BillSoldContext = createContext<BillSoldContextType | undefined>(
  undefined,
);

export const useBillSold = () => {
  const context = useContext(BillSoldContext);
  return context;
};

interface BillSoldProviderProps {
  children: React.ReactNode;

  isExchangePoint?: boolean;
}

export const BillSoldProvider: React.FC<BillSoldProviderProps> = ({
  isExchangePoint = false,
  children,
}) => {
  const [isDisableReceive, setIsDisableReceive] = useState<boolean>(true);
  const [shiftDailyId, setShiftDailyId] = useState<string>("");
  const { facId } = useAppSelector(selectFaculty);
  const [keyReloadInvoiceData, setKeyReloadInvoiceData] = useState<string>();

  const [invoiceBusiness, setInvoiceBusiness] =
    useState<InvoiceBusiness | null>(null);

  return (
    <BillSoldContext.Provider
      value={{
        facId: facId || "",
        isExchangePoint,
        shiftDailyId,
        setShiftDailyId,
        invoiceBusiness: invoiceBusiness,
        setInvoiceBusiness: setInvoiceBusiness,
        isDisableReceive,
        setIsDisableReceive,
        keyReloadInvoiceData,
        setKeyReloadInvoiceData,
      }}
    >
      {children}
    </BillSoldContext.Provider>
  );
};
