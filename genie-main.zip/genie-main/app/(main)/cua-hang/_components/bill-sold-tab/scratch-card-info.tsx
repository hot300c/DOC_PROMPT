import { SequenceRequest } from "@/app/lib/definitions/setting";
import { DATE_FORMAT, ELoadingMessages, ETitleConfirm } from "@/app/lib/enums";
import { useFeedbackDialog } from "@/app/lib/feedback-dialog-provider";
import { executeTransaction } from "@/app/lib/services/system";
import { notifyError } from "@/app/lib/utils";
import { InputDatePicker } from "@/components/input-date-picker";
import useLoading from "@/components/loading";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import {
  DataTable,
  DataTableColumnHeaderSort,
} from "@/components/ui/dataTable";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogOverlay,
  DialogTitle,
} from "@/components/ui/dialog";
import { ColumnDef } from "@tanstack/react-table";
import { format, formatDate } from "date-fns";
import { useEffect, useMemo, useState } from "react";
import { getSoldScratchcards } from "../../_action/get-bill-sold";
import { callTemService } from "../../_action/tem-services";
import { ScratchcardSold } from "../../_models/bill-sold-model";
import { useBillSold } from "./bill-sold-provider";

const ScratchCardInfo = ({ onClose }: { onClose: () => void }) => {
  const [fromDate, setFromDate] = useState<Date>(new Date());
  const [toDate, setToDate] = useState<Date>(new Date());
  const [soldScratchcards, setSoldScratchcards] = useState<ScratchcardSold[]>(
    [],
  );
  const context = useBillSold();
  const { facId } = context!;
  const { showLoading, hideLoading } = useLoading();
  const [checkAll, setCheckAll] = useState(false);
  const { alert } = useFeedbackDialog();

  const handleLoadData = async () => {
    const loadingID = showLoading(ELoadingMessages.LOADING_DATA);
    try {
      const data = await getSoldScratchcards(
        facId,
        formatDate(fromDate, "yyyy-MM-dd"),
        formatDate(toDate, "yyyy-MM-dd"),
        false,
        false,
      );
      setSoldScratchcards(data || []);
    } finally {
      setCheckAll(false);
      hideLoading(loadingID);
    }
  };

  useEffect(() => {
    void handleLoadData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [facId]);

  const handleCheckStatus = async (
    selectedScratchcards: ScratchcardSold[],
  ): Promise<{ result: boolean; errorMessage: string }> => {
    let result = false;
    let errorMessage = "";
    let serialError = "";
    const linkUrl = "http://vnvc.vinachg.vn/tem-services/check";

    for (const item of selectedScratchcards) {
      try {
        const payload = { serial: item.serial };
        const data = await callTemService({
          url: linkUrl,
          payload,
          headers: { "x-key-check": "e57D)8J^EHJtu=r" },
        });
        if (data?.status === 1) {
          result = false;
          serialError = item.serial;
          errorMessage = serialError + "có tồn tại và chưa kích hoạt";
        }
        if (data?.status === -1) {
          result = false;
          serialError = item.serial;
          errorMessage = "Lỗi dữ liệu, phương thức gửi qua";
        }
        if (data?.status === 0) {
          result = false;
          serialError = item.serial;
          errorMessage = "không tồn tại serial này";
        }
        if (data?.status === 2) {
          result = true;
        }
        if (data?.status === 3) {
          result = false;
          serialError = item.serial;
          errorMessage = "đã bị kích hoạt và sử dụng nên không thể hủy";
        }
      } catch (error) {
        result = false;
        serialError = item.serial;
        errorMessage = "Không thể kích hoạt";
      }
    }

    return { result: result, errorMessage: errorMessage };
  };

  const handleDeactivate = async (selectedScratchcards: ScratchcardSold[]) => {
    const linkUrl = "http://vnvc.vinachg.vn/tem-services/restore";
    for (const item of selectedScratchcards) {
      try {
        const payload = { serial: item.serial };
        const data = await callTemService({
          url: linkUrl,
          payload,
          headers: { "x-key-restore": "^]dvB(!b@9MT7Jx(" },
        });
        if (data) {
          const dataString = JSON.stringify(data);
          if (data?.status === 1) {
            const requests = [] as SequenceRequest[];
            requests.push({
              category: "QAHosGenericDB",
              command: "ws_CN_ScratchcardRefundSaled_Log_Save",
              parameters: {
                Mathe: item?.serial || "",
                Phone: item?.phone || "",
                ProductID: item?.productID?.toString() || "",
                TrangThai: data.status,
                TinNhan: "Thành công",
                responseString: dataString,
              },
            });
            requests.push({
              category: "QAHosGenericDB",
              command: "ws_CN_ScratchcardRefundSaled_Save",
              parameters: {
                Mathe: item?.serial || "",
                Phone: item?.phone || "",
                ProductID: item?.productID?.toString() || "",
                InvoiceID: item?.invoiceID || "",
                TrangThai: data.status,
              },
            });

            try {
              await executeTransaction({ request: requests });
            } catch (error) {
              if (error instanceof Error) {
                notifyError(`Lưu không thành công: ${error?.message}`);
              }
            }
          } else {
            const requests = [] as SequenceRequest[];
            requests.push({
              category: "QAHosGenericDB",
              command: "ws_CN_ScratchcardRefundSaled_Log_Save",
              parameters: {
                Mathe: item?.serial || "",
                Phone: item?.phone || "",
                ProductID: item?.productID?.toString() || "",
                TrangThai: data.status,
                TinNhan: data?.message || "",
                responseString: dataString,
              },
            });

            try {
              await executeTransaction({ request: requests });
              void alert({
                title: ETitleConfirm.THONG_BAO,
                content: data?.message || "",
              });
            } catch (error) {
              if (error instanceof Error) {
                notifyError(`Lưu không thành công: ${error?.message}`);
              }
            }
          }
        }
      } catch (error: any) {
        if (error?.response) {
          const response = error?.response;
          const requests = [] as SequenceRequest[];
          requests.push({
            category: "QAHosGenericDB",
            command: "ws_CN_ScratchcardRefundSaled_Log_Save",
            parameters: {
              Mathe: item?.serial || "",
              Phone: item?.phone || "",
              ProductID: item?.productID?.toString() || "",
              TrangThai: response?.status || 0,
              TinNhan: response?.message || "",
              responseString: JSON.stringify(response) || "",
            },
          });

          try {
            await executeTransaction({ request: requests });
            await alert({
              title: ETitleConfirm.THONG_BAO,
              content: response?.message || "",
            });
          } catch (error) {
            if (error instanceof Error) {
              notifyError(`Lưu không thành công: ${error?.message}`);
            }
          }
        }
      }
    }
  };

  const handleOnclickDeactivate = async () => {
    if (soldScratchcards.length === 0) return;
    const selectedScratchcards = soldScratchcards.filter(
      (item) => item.isCheck,
    );
    if (selectedScratchcards.length === 0) {
      await alert({
        title: ETitleConfirm.THONG_BAO,
        content: "Vui lòng chọn thông tin thẻ cần hủy kích hoạt",
      });
      return;
    }
    const checkStatus = await handleCheckStatus(selectedScratchcards);
    if (!checkStatus.result) {
      await alert({
        title: ETitleConfirm.THONG_BAO,
        content: checkStatus.errorMessage,
      });
      return;
    }
    await handleDeactivate(selectedScratchcards);
  };

  const columns = useMemo(() => {
    const COLUMNS: ColumnDef<ScratchcardSold>[] = [
      {
        id: "isCheck",
        accessorKey: "isCheck",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="" />
        ),
        enableSorting: false,
        cell: ({ row }) => (
          <Checkbox
            checked={row.original.isCheck || false}
            onClick={() => {
              const rowCurrent = row.original;

              setSoldScratchcards((prev) =>
                prev.map((item) =>
                  item === rowCurrent
                    ? { ...item, isCheck: !item.isCheck }
                    : item,
                ),
              );
            }}
          />
        ),
      },
      {
        id: "serial",
        accessorKey: "serial",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Số Serial" />
        ),
      },
      {
        id: "tenSanPham",
        accessorKey: "tenSanPham",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Tên sản phẩm" />
        ),
      },
      {
        id: "phone",
        accessorKey: "phone",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Số điện thoại" />
        ),
      },
      {
        id: "maBienLai",
        accessorKey: "maBienLai",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Mã biên lai thu tiền"
          />
        ),
        cell: ({ row }) => (
          <div title={row.original?.maBienLai || ""}>
            {row.original?.maBienLai || ""}
          </div>
        ),
      },
      {
        id: "ngayKichHoat",
        accessorKey: "ngayKichHoat",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Ngày kích hoạt" />
        ),
        cell: ({ row }) => (
          <div>
            {row.original.ngayKichHoat
              ? format(row.original.ngayKichHoat, DATE_FORMAT.DD_MM_YYYY_VI)
              : ""}
          </div>
        ),
      },
      {
        id: "invoiceNoThanhToan",
        accessorKey: "invoiceNoThanhToan",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Ngày hủy kích hoạt"
          />
        ),
        cell: ({ row }) => (
          <div>
            {row.original.ngayHuy
              ? format(row.original.ngayHuy, DATE_FORMAT.DD_MM_YYYY_VI)
              : ""}
          </div>
        ),
      },
      {
        id: "trangThai",
        accessorKey: "trangThai",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Trạng thái" />
        ),
        cell: ({ row }) => (
          <div title={row.original?.trangThai || ""}>
            {row.original?.trangThai || ""}
          </div>
        ),
      },
    ];
    return COLUMNS;
  }, []);

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogOverlay />
      <DialogContent
        className="sm:max-w-[90vw] h-[80vh] z-100"
        aria-describedby={undefined}
      >
        <DialogHeader>
          <DialogTitle>Thông tin thẻ cào</DialogTitle>
        </DialogHeader>

        <div className="p-4 min-h-[73vh] h-sm:min-h-[74vh] h-md:min-h-[76vh] flex flex-col flex-1 overflow-hidden h-full">
          <div className="flex flex-col md:flex-row gap-4 mb-1 items-end">
            <label htmlFor="fromDate" className="text-sm">
              Từ ngày:
            </label>
            <InputDatePicker
              value={fromDate}
              onChange={(date) => {
                if (date) setFromDate(date);
              }}
            />
            <label htmlFor="toDate" className="text-sm">
              Đến ngày:
            </label>
            <InputDatePicker
              value={toDate}
              onChange={(date) => {
                if (date) setToDate(date);
              }}
            />

            <Button onClick={handleLoadData}>Lọc</Button>
          </div>

          <div className="flex-1 overflow-hidden pb-[65px]">
            <DataTable
              className="h-full overflow-auto border rounded-md"
              columns={columns}
              data={soldScratchcards}
              enablePaging={true}
              enableColumnFilter={false}
              enableGlobalFilter={true}
              placeholderSearch="Tìm kiếm theo số Serial, Số điện thoại, Mã biên lai"
            />
          </div>

          <div className="flex justify-between mt-2">
            <div>
              <Checkbox
                checked={checkAll}
                onClick={() => {
                  const soldScratchcardss = soldScratchcards.map((item) => ({
                    ...item,
                    isCheck: !checkAll,
                  }));
                  setSoldScratchcards(soldScratchcardss);
                  setCheckAll(!checkAll);
                }}
              />
              <label className="ml-2 text-sm">Tất cả</label>
            </div>

            <Button onClick={handleOnclickDeactivate}>Hủy kích hoạt</Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
export default ScratchCardInfo;
