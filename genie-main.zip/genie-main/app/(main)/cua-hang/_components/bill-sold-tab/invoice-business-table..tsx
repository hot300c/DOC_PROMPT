"use client";
import { DATE_FORMAT, ELoadingMessages } from "@/app/lib/enums";
import * as utils from "@/app/lib/utils";
import useLoading from "@/components/loading";
import {
  DataTable,
  DataTableColumnHeaderSort,
} from "@/components/ui/dataTable";
import { ColumnDef } from "@tanstack/react-table";
import { format } from "date-fns";
import { useEffect, useState } from "react";
import { getInvoiceBusinessByShiftDailyId } from "../../_action/get-bill-sold";
import { InvoiceBusiness } from "../../_models/bill-sold-model";
import { useBillSold } from "./bill-sold-provider";

const COLUMNS: ColumnDef<InvoiceBusiness>[] = [
  {
    id: "stt",
    accessorKey: "stt",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="STT" />
    ),
  },
  {
    id: "stockName",
    accessorKey: "stockName",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Tên kho" />
    ),
    cell: ({ row }) => (
      <div
        className="w-[250px] min-w-[250px] max-w-[250px] truncate"
        title={row.original.stockName || ""}
      >
        {row.original.stockName}
      </div>
    ),
  },
  {
    id: "invoiceNo",
    accessorKey: "invoiceNo",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Mã biên lai" />
    ),
    cell: ({ row }) => (
      <div className="w-40" title={row.original.invoiceNo}>
        {row.original.invoiceNo}
      </div>
    ),
  },
  {
    id: "tenKhachHang",
    accessorKey: "tenKhachHang",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Tên KH" />
    ),
    cell: ({ row }) => (
      <div className="w-[150px]" title={row.original.tenKhachHang || ""}>
        {row.original.tenKhachHang}
      </div>
    ),
  },
  {
    id: "ngayThu",
    accessorKey: "ngayThu",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Ngày thu" />
    ),
    cell: ({ row }) => (
      <div>
        {row.original.ngayThu
          ? format(row.original.ngayThu, DATE_FORMAT.DD_MM_YYYY_VI)
          : ""}
      </div>
    ),
  },

  {
    id: "phone",
    accessorKey: "phone",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Phone" />
    ),
  },
  {
    id: "nguoiThu",
    accessorKey: "nguoiThu",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Người thu" />
    ),
    cell: ({ row }) => (
      <div title={row.original?.nguoiThu || ""}>
        {row.original?.nguoiThu || ""}
      </div>
    ),
  },
  {
    id: "total",
    accessorKey: "total",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Số tiền" />
    ),
    cell: ({ row }) => (
      <div className="text-right">
        {utils.formatCurrencyVND(row.original.total || 0, 0, false)}
      </div>
    ),
  },

  {
    id: "invoiceNoThanhToan",
    accessorKey: "invoiceNoThanhToan",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Số BL tham chiếu" />
    ),
    cell: ({ row }) => (
      <div title={row.original?.invoiceNoThanhToan || ""}>
        {row.original?.invoiceNoThanhToan || ""}
      </div>
    ),
  },
  {
    id: "invoiceDateThanhToan",
    accessorKey: "invoiceDateThanhToan",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Ngày BL tham chiếu" />
    ),
    cell: ({ row }) => (
      <div>
        {row.original.invoiceDateThanhToan
          ? format(row.original.invoiceDateThanhToan, DATE_FORMAT.DD_MM_YYYY)
          : ""}
      </div>
    ),
  },
  {
    id: "soHopDongThanhToan",
    accessorKey: "soHopDongThanhToan",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Số hợp đồng" />
    ),
    cell: ({ row }) => (
      <div title={row.original?.soHopDongThanhToan || ""}>
        {row.original?.soHopDongThanhToan || ""}
      </div>
    ),
  },
];

const InvoiceBusinessTable = () => {
  const context = useBillSold();
  const { showLoading, hideLoading } = useLoading();

  const [invoiceBusinesses, setInvoiceBusinesses] = useState<InvoiceBusiness[]>(
    [],
  );
  const {
    invoiceBusiness,
    setInvoiceBusiness: setInvoiceBusinessId,
    setInvoiceBusiness,
    isExchangePoint,
    shiftDailyId,
    facId,
    keyReloadInvoiceData,
  } = context!;

  const getInvoiceBusiness = async (id: string) => {
    if (!id) return;
    const loadingId = showLoading(ELoadingMessages.LOADING_DATA);
    try {
      const result = await getInvoiceBusinessByShiftDailyId(
        facId,
        id,
        isExchangePoint,
      );
      setInvoiceBusinesses(result || []);
      if (result?.length) {
        setInvoiceBusiness(result[0] || null);
      } else setInvoiceBusiness(null);
    } finally {
      hideLoading(loadingId);
    }
  };
  useEffect(() => {
    if (keyReloadInvoiceData) void getInvoiceBusiness(shiftDailyId);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [keyReloadInvoiceData]);

  useEffect(() => {
    if (shiftDailyId) {
      void getInvoiceBusiness(shiftDailyId);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [shiftDailyId]);
  return (
    <DataTable
      className="h-full flex-1 overflow-auto border-t rounded-md"
      tHeadClass="z-40"
      tRowClass="cursor-pointer"
      data={invoiceBusinesses}
      columns={COLUMNS}
      enablePaging={true}
      enableColumnFilter={true}
      enableFooter={false}
      onRowClick={(row) => {
        if (row !== invoiceBusiness) setInvoiceBusinessId(row);
      }}
      indexScrollTo={0}
    />
  );
};
export default InvoiceBusinessTable;
