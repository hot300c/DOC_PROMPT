"use client";
import { GUID_NewSequential } from "@/app/lib/utils";
import { VirtualSelect } from "@/components/select/virtual-select/virtual-select";
import { Button } from "@/components/ui/button";
import { useEffect, useState } from "react";
import { getShiftDailyListNhaThuoc } from "../../_action/get-bill-sold";
import { ShiftDailyModel } from "../../_models/bill-sold-model";
import { useBillSold } from "./bill-sold-provider";

const BillSoldFilter = () => {
  const [shiftDailies, setShiftDailies] = useState<ShiftDailyModel[]>([]);
  const context = useBillSold();
  const { shiftDailyId, setShiftDailyId, setKeyReloadInvoiceData, facId } =
    context!;

  useEffect(() => {
    void getShiftDailyListNhaThuoc(facId || "").then((data) =>
      setShiftDailies(data || []),
    );
  }, [facId]);

  return (
    <div className="flex items-center m-2">
      <label>Ca thanh toán:</label>
      <VirtualSelect
        className="mx-2 w-[400px]"
        value={shiftDailyId || ""}
        classNamePopover="w-[400px]"
        placeholder="Chọn Ca/Quầy"
        onChange={(value) => {
          setShiftDailyId(value);
        }}
        options={shiftDailies.map((v) => ({
          value: String(v.shiftDailyID),
          label: v.shiftName,
        }))}
      />
      <Button onClick={() => setKeyReloadInvoiceData(GUID_NewSequential())}>
        Lọc
      </Button>
    </div>
  );
};
export default BillSoldFilter;
