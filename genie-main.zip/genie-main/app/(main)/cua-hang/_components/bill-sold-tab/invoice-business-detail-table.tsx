"use client";
import { SequenceRequest } from "@/app/lib/definitions/setting";
import {
  DATE_FORMAT,
  ELoadingMessages,
  ETitleConfirm,
  PermissionEnum,
} from "@/app/lib/enums";
import { useFeedbackDialog } from "@/app/lib/feedback-dialog-provider";
import { executeTransaction } from "@/app/lib/services/system";
import * as utils from "@/app/lib/utils";
import { notifyError } from "@/app/lib/utils";
import { useAppPermissions } from "@/components/app-permissions/app-permissions";
import useLoading from "@/components/loading";
import { Button } from "@/components/ui/button";
import {
  DataTable,
  DataTableColumnHeaderSort,
} from "@/components/ui/dataTable";
import { ColumnDef } from "@tanstack/react-table";
import { useEffect, useMemo, useState } from "react";
import { getInvoiceBusinessDetailById } from "../../_action/get-bill-sold";
import { callTemService } from "../../_action/tem-services";
import { InvoiceBusinessDetail } from "../../_models/bill-sold-model";
import { useBillSold } from "./bill-sold-provider";
import { format } from "date-fns";

const InvoiceBusinessesDetailTable = () => {
  const { showLoading, hideLoading } = useLoading();
  const context = useBillSold();
  const {
    facId,
    invoiceBusiness,
    isDisableReceive,
    setIsDisableReceive,
    isExchangePoint,
  } = context!;
  const { alert } = useFeedbackDialog();
  const [invoiceBusinessesDetails, setInvoiceBusinessesDetails] = useState<
    InvoiceBusinessDetail[]
  >([]);
  const hasPermission = useAppPermissions();
  const isHasStoreActiveVoucher = hasPermission.hasPermission(
    PermissionEnum.STORE_ACTIVATE_VOUCHER,
  );

  const getInvoiceBusinessDetails = async (id: string, isHoanHuy: boolean) => {
    const loadingId = showLoading(ELoadingMessages.LOADING_DATA);
    try {
      if (isHoanHuy !== isDisableReceive) setIsDisableReceive(isHoanHuy);

      const result = await getInvoiceBusinessDetailById(facId, id);
      setInvoiceBusinessesDetails(result || []);
    } finally {
      hideLoading(loadingId);
    }
  };

  useEffect(() => {
    if (invoiceBusiness) {
      void getInvoiceBusinessDetails(
        invoiceBusiness.invoiceBusinessID,
        invoiceBusiness.isHoanhuy || false,
      );
    } else if (invoiceBusinessesDetails?.length)
      setInvoiceBusinessesDetails([]);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [invoiceBusiness]);

  const handleOnclickStatus = async (
    invoiceBusinessDetail: InvoiceBusinessDetail,
  ) => {
    if (!invoiceBusinessDetail) return;

    const requestUriString = "http://vnvc.vinachg.vn/tem-services/selled";
    if (invoiceBusinessDetail.invoiceID && isHasStoreActiveVoucher) {
      try {
        const payload = {
          Phone: invoiceBusiness?.phone,
          Serial: invoiceBusinessDetail?.serial,
        };

        const data = await callTemService({
          url: requestUriString,
          payload: payload,
          headers: {
            "x-key-sell": "HvAUwrs;7bfWX#h",
          },
        });
        const dataString = JSON.stringify(data) || "";

        if (data?.status === 1) {
          const requests = [] as SequenceRequest[];
          requests.push({
            category: "QAHosGenericDB",
            command: "ws_CN_ScratchcardSaled_Log_Save",
            parameters: {
              Mathe: invoiceBusinessDetail?.serial || "",
              Phone: invoiceBusiness?.phone || "",
              ProductID: invoiceBusinessDetail?.productID?.toString() || "",
              TinNhan: "Thành công",
              responseString: dataString,
            },
          });
          requests.push({
            category: "QAHosGenericDB",
            command: "ws_CN_ScratchcardSaled_Save",
            parameters: {
              Mathe: invoiceBusinessDetail?.serial || "",
              Phone: invoiceBusiness?.phone || "",
              ProductID: invoiceBusinessDetail?.productID?.toString() || "",
              InvoiceID: invoiceBusinessDetail?.invoiceID || "",
              TrangThai: 1,
            },
          });
          requests.push({
            category: "QAHosGenericDB",
            command: "ws_BIL_InvoiceBusinessDetail_UpdateSerial",
            parameters: {
              InvoiceBusinessID: invoiceBusinessDetail?.invoiceID || "",
              InvoiceBusinessDetailID:
                invoiceBusinessDetail?.invoiceDetailID || "",
              Mathe: invoiceBusinessDetail?.serial || "",
            },
          });

          try {
            await executeTransaction({ request: requests });
          } catch (error) {
            if (error instanceof Error) {
              notifyError(`Lưu không thành công: ${error?.message}`);
            }
          }
        } else if (data?.status === 0) {
          const requests = [] as SequenceRequest[];
          requests.push({
            category: "QAHosGenericDB",
            command: "ws_CN_ScratchcardSaled_Log_Save",
            parameters: {
              Mathe: invoiceBusinessDetail?.serial || "",
              Phone: invoiceBusiness?.phone || "",
              ProductID: invoiceBusinessDetail?.productID?.toString() || "",
              TrangThai: data?.status || 0,
              TinNhan: data?.message || "",
              responseString: dataString,
            },
          });

          try {
            await executeTransaction({ request: requests });
            await alert({
              title: ETitleConfirm.THONG_BAO,
              content:
                "Đã có lỗi xảy ra trong quá trình kích hoạt: " +
                  data?.message || "",
            });
          } catch (error) {
            if (error instanceof Error) {
              notifyError(`Lưu không thành công: ${error?.message}`);
            }
          }
        }
      } catch (error: any) {
        if (error?.response) {
          const response = error?.response;
          const requests = [] as SequenceRequest[];
          requests.push({
            category: "QAHosGenericDB",
            command: "ws_CN_ScratchcardSaled_Log_Save",
            parameters: {
              Mathe: invoiceBusinessDetail?.serial || "",
              Phone: invoiceBusiness?.phone || "",
              ProductID: invoiceBusinessDetail?.productID?.toString() || "",
              TrangThai: response?.status || 0,
              TinNhan: response?.message || "",
              responseString: JSON.stringify(response) || "",
            },
          });

          try {
            await executeTransaction({ request: requests });
            await alert({
              title: ETitleConfirm.THONG_BAO,
              content: response?.message || "",
            });
          } catch (error) {
            if (error instanceof Error) {
              notifyError(`Lưu không thành công: ${error?.message}`);
            }
          }
        }
      }
    }

    await getInvoiceBusinessDetails(
      invoiceBusiness?.invoiceBusinessID || "",
      invoiceBusiness?.isHoanhuy || false,
    );
  };
  const columns = useMemo(() => {
    const columns: ColumnDef<InvoiceBusinessDetail>[] = [
      {
        id: "stt",
        accessorKey: "stt",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="STT" />
        ),
      },
      {
        id: "productCode",
        accessorKey: "productCode",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Mã SP" />
        ),
        cell: ({ row }) => (
          <div className="whitespace-nowrap overflow-hidden text-ellipsis">
            {row.original.productCode}
          </div>
        ),
      },
      {
        id: "productName",
        accessorKey: "productName",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Tên SP" />
        ),
        cell: ({ row }) => (
          <div className="whitespace-nowrap overflow-hidden text-ellipsis">
            {row.original.productName}
          </div>
        ),
      },
      {
        id: "unitName",
        accessorKey: "unitName",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="ĐVT" />
        ),
      },
      {
        id: "qty",
        accessorKey: "qty",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="SL" />
        ),
        cell: ({ row }) => <>{utils.formatNumber(row.original.qty)}</>,
      },
      {
        id: "batch",
        accessorKey: "batch",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Số lô" />
        ),
      },
      {
        id: "expDate",
        accessorKey: "expDate",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="HSD" />
        ),
        cell: ({ row }) => (
          <div className="whitespace-nowrap overflow-hidden text-ellipsis">
            {row.original.expDate
              ? format(
                  new Date(row.original.expDate),
                  DATE_FORMAT.DD_MM_YYYY_VI,
                )
              : ""}
          </div>
        ),
      },
      {
        id: "price",
        accessorKey: "price",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Đơn giá" />
        ),
        cell: ({ row }) => (
          <div className="text-right">
            {utils.formatCurrencyVND(row.original.price || 0, 0, false)}
          </div>
        ),
      },
      {
        id: "chietKhau",
        accessorKey: "chietKhau",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="CK" />
        ),
        cell: ({ row }) => (
          <>{utils.formatCurrencyVND(row.original.chietKhau || 0, 0, false)}</>
        ),
      },

      {
        id: "thanhTien",
        accessorKey: "thanhTien",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title={isExchangePoint ? "Tổng điểm" : "Thành tiền"}
          />
        ),
        cell: ({ row }) => (
          <div className="text-right">
            {utils.formatCurrencyVND(row.original.thanhTien || 0, 0, false)}
          </div>
        ),
      },
      {
        id: "tenChinhSach",
        accessorKey: "tenChinhSach",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Chính sách" />
        ),
        cell: ({ row }) => <div>{row.original.tenChinhSach || ""}</div>,
      },
      {
        id: "tt",
        accessorKey: "tt",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="tt" />
        ),
        cell: ({ row }) => (
          <Button
            variant="ghost"
            className="hover:underline"
            title={row.original?.tt || ""}
            onClick={() => handleOnclickStatus(row.original)}
          >
            {row.original?.tt || ""}
          </Button>
        ),
      },
    ];

    return columns.filter(
      (col) => !isExchangePoint || !["ck", "tt"].includes(col.id!),
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [invoiceBusinessesDetails]);

  return (
    <DataTable
      className="h-full flex-1 overflow-auto border-t rounded-md"
      tRowClass="cursor-pointer"
      data={invoiceBusinessesDetails}
      columns={columns}
      enablePaging={false}
      enableColumnFilter={false}
      enableFooter={true}
    />
  );
};
export default InvoiceBusinessesDetailTable;
