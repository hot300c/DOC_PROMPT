import { CartItem } from "@/app/(main)/cua-hang/_models/cart-model";
import { Counter } from "@/app/(main)/cua-hang/_models/counter-model";
import { Product } from "@/app/(main)/cua-hang/_models/product-model";
import { WorkShift } from "@/app/(main)/cua-hang/_models/work-shift-model";
import { getCartColumns } from "@/app/(main)/cua-hang/_utils/sale-tab-table-columns";
import { LoadingUI } from "@/components/loading";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import {
  DataTable,
  DataTableColumnHeaderSort,
} from "@/components/ui/dataTable";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { selectUser } from "@/redux/selectors";
import { useAppSelector } from "@/redux/store";
import { ColumnDef } from "@tanstack/react-table";
import { Plus, Search } from "lucide-react";
import { useEffect, useMemo, useState } from "react";

export default function PointRedeemingTab({
  selectedShopTypeId,
  selectedCounter,
  setIsCounterModalOpen,
  selectedStoreWorkShift,
}: {
  selectedShopTypeId: string;
  selectedCounter: Counter | null;
  setIsCounterModalOpen: (open: boolean) => void;
  selectedStoreWorkShift: WorkShift | null;
}) {
  // State management
  const [searchProduct] = useState("");
  const [productQuantity, setProductQuantity] = useState("1");
  const [products] = useState<any[]>([]);
  const [cartItems] = useState<CartItem[]>([]);
  const [customerId, setCustomerId] = useState("");
  const [customerPhone, setCustomerPhone] = useState("");
  const [customerInfo] = useState({
    name: "...",
    gender: "...",
    birthYear: "...",
    address: "...",
    id: "",
  });
  const [totalPoint] = useState(0);
  const [isLoading] = useState(false);
  const [selectedIndex] = useState<number>();
  const user = useAppSelector(selectUser);
  const [counter, setCounter] = useState<Counter | null>(selectedCounter);
  const [isPaid] = useState(false);

  useEffect(() => {
    if (selectedCounter) {
      setCounter(selectedCounter);
    } else {
      setCounter(null);
    }
  }, [selectedCounter]);

  const PRODUCT_COLUMNS = useMemo<ColumnDef<Product>[]>(
    () => [
      {
        id: "hospitalCode",
        accessorKey: "hospitalCode",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Mã"
            className="w-[100px] min-w-[100px]"
          />
        ),
      },
      {
        id: "productName",
        accessorKey: "productName",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Tên"
            className="w-[250px] min-w-[200px]"
          />
        ),
      },
      {
        id: "price",
        accessorKey: "price",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Giá bán"
            className="w-[120px] min-w-[120px] text-right"
          />
        ),
        cell: ({ row }) => (
          <div className="text-right">{row.getValue("price")}</div>
        ),
      },
      {
        id: "moTaSanPham",
        accessorKey: "moTaSanPham",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Mô tả"
            className="w-[180px] min-w-[150px] max-w-[250px] truncate"
          />
        ),
      },
      {
        id: "stockName",
        accessorKey: "stockName",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Kho"
            className="w-[150px] min-w-[120px]"
          />
        ),
      },
      {
        id: "qty_Text",
        accessorKey: "qty_Text",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="SL tồn"
            className="w-[80px] min-w-[80px] text-right"
          />
        ),
        cell: ({ row }) => (
          <div className="text-right">{row.getValue("qty_Text")}</div>
        ),
      },
      {
        id: "actions",
        header: "",
        cell: ({ row }) => (
          <Button
            size="icon"
            variant="ghost"
            onClick={() => console.log("Add to cart", row.original)} // TODO: Implement this
            disabled={isPaid}
          >
            <Plus className="h-4 w-4 text-green-500" />
          </Button>
        ),
      },
    ],
    [isPaid],
  );

  const handleRemoveFromCart = (idx: number) => {
    // TODO: Implement this if used
  };

  return (
    <div className="flex h-full overflow-hidden">
      {isLoading && <LoadingUI />}
      {/* Left Panel - Product List */}
      <div className="w-3/5 p-1 border-r overflow-y-auto">
        <Card className="h-full flex flex-col max-h-[calc(100vh-2rem)]">
          <CardHeader className="py-2 px-3 space-y-1">
            <div className="grid grid-cols-12 gap-1 items-center">
              <div className="col-span-5">
                <Label>
                  Quầy:{" "}
                  <a
                    className="text-blue-500 hover:underline cursor-pointer"
                    onClick={() => setIsCounterModalOpen(true)}
                  >
                    {counter?.counterName || "Chưa chọn quầy"}
                  </a>
                </Label>
              </div>
              <div className="col-span-5">
                <Label>
                  Ca làm việc:{" "}
                  <b className="text-red-500">
                    {selectedStoreWorkShift?.shiftName || "Chưa có ca làm việc"}
                  </b>
                </Label>
              </div>
              <div className="col-span-2">
                <Button
                  variant="outline"
                  className="w-full"
                  onClick={() => {
                    // TODO: Implement this
                  }}
                >
                  Tạo giỏ hàng mới
                </Button>
              </div>
            </div>
            <div className="grid grid-cols-12 gap-1 mt-1 items-center">
              <div className="col-span-10">
                <Input
                  placeholder="Tìm kiếm sản phẩm"
                  value={searchProduct}
                  onChange={(e) => {
                    // TODO: Implement this
                  }}
                  className="w-full"
                />
              </div>
              <div className="col-span-1">
                <Input
                  placeholder="SL"
                  type="number"
                  min={1}
                  value={productQuantity}
                  onChange={(e) => {
                    const value = parseInt(e.target.value);
                    if (isNaN(value) || value < 1) {
                      setProductQuantity("1");
                    } else {
                      setProductQuantity(e.target.value);
                    }
                  }}
                  className="w-full"
                />
              </div>
              <div className="col-span-1">
                <Button
                  size="sm"
                  className="w-full"
                  onClick={async () => {
                    // TODO: Implement this
                  }}
                  disabled={isPaid}
                >
                  Thêm
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent className="flex-1 overflow-auto p-0">
            <DataTable
              columns={PRODUCT_COLUMNS}
              data={products}
              className="w-full"
              enableColumnFilter={false}
              enablePaging={false}
              enableToggleColumn={true}
              enableGrouping={false}
              enableGlobalFilter={false}
              indexScrollTo={selectedIndex}
              onRowClick={(row) => console.log(row)}
              onRowDoubleClick={(row) => console.log(row)} // TODO: Implement this
            />
          </CardContent>
        </Card>
      </div>

      {/* Right Panel - Customer Info, Cart, Payment */}
      <div className="w-2/5 p-1 flex flex-col h-full overflow-hidden">
        {/* Customer Information */}
        <Card className="mb-1">
          <CardContent className="p-2 space-y-1">
            <div className="flex flex-row items-center space-x-1">
              <Label
                htmlFor="customerId"
                className="w-24 text-right whitespace-nowrap"
              >
                Mã thẻ:
              </Label>
              <div className="flex-1 flex space-x-1">
                <Input
                  id="customerId"
                  value={customerId}
                  onChange={(e) => setCustomerId(e.target.value)}
                  className="flex-1"
                  disabled={isPaid}
                  onKeyDown={async (e) => {
                    if (e.key === "Enter") {
                      // TODO: Implement this
                    }
                  }}
                />
                <Button size="sm" className="px-2">
                  <Search className="h-4 w-4" />
                </Button>
              </div>
            </div>

            <div className="flex flex-row items-center">
              <Label className="w-24 text-right whitespace-nowrap">
                Tên khách hàng:
              </Label>
              <div className="m-1 flex-1 truncate">{customerInfo.name}</div>
            </div>

            <div className="flex flex-row">
              <div className="w-1/2 flex flex-row items-center">
                <Label className="w-24 text-right whitespace-nowrap">
                  Giới tính:
                </Label>
                <div className="m-1">{customerInfo.gender}</div>
              </div>
              <div className="w-1/2 flex flex-row items-center">
                <Label className="w-24 text-right whitespace-nowrap">
                  Năm sinh:
                </Label>
                <div className="m-1">{customerInfo.birthYear}</div>
              </div>
            </div>

            <div className="flex flex-row items-center space-x-1">
              <Label
                htmlFor="customerPhone"
                className="w-24 text-right whitespace-nowrap"
              >
                Số điện thoại:
              </Label>
              <div className="flex-1 flex space-x-1">
                <Input
                  id="customerPhone"
                  value={customerPhone}
                  onChange={(e) => setCustomerPhone(e.target.value)}
                  className="flex-1"
                  disabled={isPaid}
                  onKeyDown={async (e) => {
                    if (e.key === "Enter") {
                    }
                  }}
                />
                <Button size="sm" className="px-2">
                  <Search className="h-4 w-4" />
                </Button>
              </div>
            </div>

            <div className="flex flex-row">
              <div className="w-full flex flex-row items-center">
                <Label className="w-24 text-right whitespace-nowrap">
                  Điểm đang có:
                </Label>
                <div className="m-1">{customerInfo.address}</div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Shopping Cart */}
        <Card className="flex-1 mb-1 overflow-hidden">
          <CardContent className="h-full flex flex-col p-0">
            <div className="flex-1 overflow-auto">
              <DataTable
                columns={getCartColumns(handleRemoveFromCart, isPaid)}
                data={cartItems}
                className="w-full"
                enableColumnFilter={false}
                enablePaging={false}
                enableToggleColumn={true}
                enableGrouping={false}
                enableGlobalFilter={false}
              />
            </div>
          </CardContent>
        </Card>

        {/* Payment Information */}
        <Card>
          <CardContent className="p-2 space-y-1">
            <div className="grid grid-cols-12 items-center gap-2">
              <div className="col-span-4">
                <Label className="text-left whitespace-break-spaces">
                  Tổng điểm:
                </Label>
                <span className="font-medium ml-1">
                  {totalPoint ? totalPoint : "..."}
                </span>
              </div>
              <div className="col-span-4">
                <Label className="text-left whitespace-break-spaces">
                  Nhân viên thu ngân:
                </Label>
                <span className="font-medium ml-1">
                  <b>{user.name.toUpperCase()}</b>
                </span>
              </div>
              <div className="col-span-4">
                <Button className="whitespace-nowrap w-full" disabled={isPaid}>
                  Xem biên lai
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
