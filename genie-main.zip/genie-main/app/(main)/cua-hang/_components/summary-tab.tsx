"use client";

import { getBillData } from "@/app/(main)/cua-hang/_action/get-receipts";
import { Receipt } from "@/app/(main)/cua-hang/_models/recept-model";
import {
  getCanceledConfig,
  getDetailConfig,
  getReceiptsConfig,
  getRefundedConfig,
} from "@/app/(main)/cua-hang/_utils/summary-tab-excel-table-config";
import {
  CANCELLED_COLUMNS,
  DETAIL_COLUMNS,
  RECEIPT_COLUMNS,
  REFUNDED_COLUMNS,
} from "@/app/(main)/cua-hang/_utils/summary-tab-table-columns";
import { PaperSize, RevenueTabType } from "@/app/lib/enums";
import { useModal } from "@/app/lib/modal-print-provider";
import * as utils from "@/app/lib/utils";
import { cn, notifyError } from "@/app/lib/utils";
import { exportToExcel, TableConfig } from "@/app/lib/utils/exportToExcel ";
import { InputDatePicker } from "@/components/input-date-picker";
import { LoadingUI } from "@/components/loading";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { DataTable } from "@/components/ui/dataTable";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { selectBaseSetting, selectFaculty } from "@/redux/selectors";
import { useAppSelector } from "@/redux/store";
import { Row } from "@tanstack/react-table";
import { useRef, useState } from "react";
import useSWR from "swr";

export default function RevenueDetails() {
  const [isLoading, setIsLoading] = useState(false);
  const [activeTab, setActiveTab] = useState<RevenueTabType>(
    RevenueTabType.RECEIPTS,
  );
  const [fromDate, setFromDate] = useState(new Date());
  const [toDate, setToDate] = useState(new Date());
  const [receipts, setReceipts] = useState<Receipt[]>([]);
  const [refundedReceipts, setRefundedReceipts] = useState<Receipt[]>([]);
  const [canceledReceipts, setCanceledReceipts] = useState<Receipt[]>([]);
  const [detailReceipts, setDetailReceipts] = useState<Receipt[]>([]);
  const [selectedRow, setSelectedRow] = useState<Receipt | null>(null);
  const filteredTableData = useRef<Receipt[]>([]);

  const faculty = useAppSelector(selectFaculty);
  const facId = faculty.facId || "";
  const baseSettings = useAppSelector(selectBaseSetting);
  const { openModal } = useModal();

  const { mutate: mutateReceipts } = useSWR(
    activeTab === RevenueTabType.RECEIPTS && facId
      ? {
          url: "RevenueService.getReceipts",
          payload: { facId, fromDate, toDate },
        }
      : null,
    async ({
      payload,
    }: {
      payload: { facId: string; fromDate: Date; toDate: Date };
    }) => {
      setIsLoading(true);
      try {
        return await getBillData(
          payload.facId,
          payload.fromDate,
          payload.toDate,
          RevenueTabType.RECEIPTS,
        );
      } catch (error) {
        console.error("Error fetching receipts:", error);
        notifyError("Lỗi khi tải danh sách biên lai");
        return [];
      } finally {
        setIsLoading(false);
      }
    },
    {
      onSuccess: (data) => {
        setReceipts(data || []);
      },
    },
  );

  const { mutate: mutateRefunded } = useSWR(
    activeTab === RevenueTabType.REFUNDED && facId
      ? {
          url: "RevenueService.getRefundedReceipts",
          payload: { facId, fromDate, toDate },
        }
      : null,
    async ({
      payload,
    }: {
      payload: { facId: string; fromDate: Date; toDate: Date };
    }) => {
      setIsLoading(true);
      try {
        return await getBillData(
          payload.facId,
          payload.fromDate,
          payload.toDate,
          RevenueTabType.REFUNDED,
        );
      } catch (error) {
        console.error("Error fetching refunded receipts:", error);
        notifyError("Lỗi khi tải danh sách biên lai hoàn");
        return [];
      } finally {
        setIsLoading(false);
      }
    },
    {
      onSuccess: (data) => {
        setRefundedReceipts(data || []);
      },
    },
  );

  const { mutate: mutateCanceled } = useSWR(
    activeTab === RevenueTabType.CANCELED && facId
      ? {
          url: "RevenueService.getCanceledReceipts",
          payload: { facId, fromDate, toDate },
        }
      : null,
    async ({
      payload,
    }: {
      payload: { facId: string; fromDate: Date; toDate: Date };
    }) => {
      setIsLoading(true);
      try {
        return await getBillData(
          payload.facId,
          payload.fromDate,
          payload.toDate,
          RevenueTabType.CANCELED,
        );
      } catch (error) {
        console.error("Error fetching canceled receipts:", error);
        notifyError("Lỗi khi tải danh sách biên lai hủy");
        return [];
      } finally {
        setIsLoading(false);
      }
    },
    {
      onSuccess: (data) => {
        setCanceledReceipts(data || []);
      },
    },
  );

  const { mutate: mutateDetail } = useSWR(
    activeTab === RevenueTabType.DETAIL && facId
      ? {
          url: "RevenueService.getDetailReceipts",
          payload: { facId, fromDate, toDate },
        }
      : null,
    async ({
      payload,
    }: {
      payload: { facId: string; fromDate: Date; toDate: Date };
    }) => {
      setIsLoading(true);
      try {
        return await getBillData(
          payload.facId,
          payload.fromDate,
          payload.toDate,
          RevenueTabType.DETAIL,
        );
      } catch (error) {
        console.error("Error fetching detail receipts:", error);
        notifyError("Lỗi khi tải danh sách biên lai chi tiết");
        return [];
      } finally {
        setIsLoading(false);
      }
    },
    {
      onSuccess: (data) => {
        setDetailReceipts(data || []);
      },
    },
  );

  const handleFilter = async () => {
    setIsLoading(true);
    try {
      switch (activeTab) {
        case RevenueTabType.RECEIPTS:
          await mutateReceipts();
          filteredTableData.current = receipts;
          break;
        case RevenueTabType.REFUNDED:
          await mutateRefunded();
          filteredTableData.current = refundedReceipts;
          break;
        case RevenueTabType.CANCELED:
          await mutateCanceled();
          filteredTableData.current = canceledReceipts;
          break;
        case RevenueTabType.DETAIL:
          await mutateDetail();
          filteredTableData.current = detailReceipts;
          break;
      }
    } catch (error) {
      console.error("Error filtering data:", error);
      notifyError("Lỗi khi lọc dữ liệu");
    } finally {
      setIsLoading(false);
    }
  };

  const handleExportExcel = async () => {
    try {
      let config: TableConfig;

      switch (activeTab) {
        case RevenueTabType.RECEIPTS:
          config = getReceiptsConfig(
            filteredTableData.current,
            fromDate,
            toDate,
          );
          break;
        case RevenueTabType.REFUNDED:
          config = getRefundedConfig(
            filteredTableData.current,
            fromDate,
            toDate,
          );
          break;
        case RevenueTabType.CANCELED:
          config = getCanceledConfig(
            filteredTableData.current,
            fromDate,
            toDate,
          );
          break;
        case RevenueTabType.DETAIL:
          config = getDetailConfig(filteredTableData.current, fromDate, toDate);
          break;
        default:
          notifyError("Tab không hợp lệ");
          return;
      }

      await exportToExcel(config);
    } catch (error) {
      console.error("Error exporting to Excel:", error);
      notifyError("Có lỗi khi xuất Excel");
    }
  };

  const handlePrint = async () => {
    try {
      if (!selectedRow) {
        notifyError("Vui lòng chọn một dòng để in");
        return;
      }

      let reportId;

      switch (activeTab) {
        case RevenueTabType.RECEIPTS:
          reportId =
            baseSettings.find(
              (item) =>
                item.category === "Report_BanLe_1" &&
                item.name === "BienLaiThuTienBanLe",
            )?.value || "";
          break;

        case RevenueTabType.REFUNDED:
          reportId = "643EDA4F-0F8A-48C5-814B-E49B3F19E5A7"; // TODO: Check what this is???
          break;

        case RevenueTabType.CANCELED:
          reportId = "643EDA4F-0F8A-48C5-814B-E49B3F19E5A7"; // TODO: Check what this is???
          break;

        case RevenueTabType.DETAIL:
          reportId =
            baseSettings.find(
              (item) =>
                item.category === "Report_BanLe_1" &&
                item.name === "BienLaiThuTienBanLe",
            )?.value || "";
          break;

        default:
          notifyError("Vui lòng chọn một tab hợp lệ");
          return;
      }

      if (!reportId) {
        notifyError("Không tìm thấy mẫu báo cáo");
        return;
      }

      // Prepare parameters for the report
      const reportParams =
        activeTab === RevenueTabType.REFUNDED ||
        activeTab === RevenueTabType.CANCELED
          ? {
              InvoiceID: selectedRow.invoiceID,
              FacID: facId,
            }
          : {
              InvoiceBusinessID: selectedRow.invoiceID,
              Invoice_HinhThucThanhToan_ID: selectedRow.invoice_PTTT_ID,
              FacID: facId,
            };

      // Generate the report
      const base64Res = await utils.handleBase64(
        reportId,
        facId,
        reportParams,
        baseSettings,
        true,
        PaperSize.A5,
      );

      if (base64Res) {
        await openModal({
          reportID: reportId,
          base64Data: base64Res,
          paperSize: PaperSize.A5,
        });
      }
    } catch (error) {
      console.error("Error printing receipt:", error);
      notifyError("Lỗi khi in biên lai");
    }
  };

  return (
    <div className="flex h-full overflow-auto">
      {isLoading && <LoadingUI />}
      <div className="w-full p-1 border-r overflow-y-auto">
        <Card className="h-full flex flex-col max-h-[calc(100vh-2rem)]">
          <CardHeader className="py-2 px-3 space-y-1">
            <div className="grid grid-cols-12 gap-2 items-center">
              <div className="col-span-8 flex items-center">
                <div className="grid grid-cols-12 gap-2 items-center">
                  <div className="col-span-5 flex items-center">
                    <Label className="whitespace-nowrap mr-2">Từ ngày:</Label>
                    <InputDatePicker
                      value={fromDate}
                      onChange={(date) => setFromDate(date || new Date())}
                    />
                  </div>
                  <div className="col-span-5 flex items-center">
                    <Label className="whitespace-nowrap mr-2">Đến ngày:</Label>
                    <InputDatePicker
                      value={toDate}
                      onChange={(date) => setToDate(date || new Date())}
                    />
                  </div>
                  <Button
                    size="sm"
                    className="w-full col-span-2"
                    onClick={handleFilter}
                  >
                    Lọc
                  </Button>
                </div>
              </div>

              <div className="col-span-4">
                <div className="grid grid-cols-12 gap-2 items-center">
                  <div className="col-span-6">
                    <Button size="sm" className="w-full" onClick={handlePrint}>
                      In phiếu
                    </Button>
                  </div>
                  <div className="col-span-6">
                    <Button
                      size="sm"
                      className="w-full"
                      onClick={handleExportExcel}
                    >
                      Xuất Excel
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </CardHeader>
          <CardContent className="flex-1 flex overflow-hidden p-0">
            <Tabs
              className="flex flex-col flex-1 w-full overflow-hidden"
              value={activeTab}
              onValueChange={(value) => {
                setSelectedRow(null);
                setActiveTab(value as RevenueTabType);
              }}
            >
              <TabsList className="justify-start bg-white">
                <TabsTrigger value={RevenueTabType.RECEIPTS}>
                  Biên lai
                </TabsTrigger>
                <TabsTrigger value={RevenueTabType.REFUNDED}>
                  Biên lai hoàn
                </TabsTrigger>
                <TabsTrigger value={RevenueTabType.CANCELED}>
                  Biên lai hủy
                </TabsTrigger>
                <TabsTrigger value={RevenueTabType.DETAIL}>
                  Biên lai chi tiết
                </TabsTrigger>
              </TabsList>

              <TabsContent
                value={RevenueTabType.RECEIPTS}
                className={cn(
                  "flex-1 flex flex-col overflow-hidden w-full",
                  activeTab !== RevenueTabType.RECEIPTS && "hidden",
                )}
              >
                <DataTable
                  columns={RECEIPT_COLUMNS}
                  data={receipts}
                  className="w-full flex-1 overflow-auto"
                  enableColumnFilter={true}
                  enablePaging={true}
                  enableToggleColumn={true}
                  enableFooter={true}
                  enableGrouping={false}
                  onFilteredRowCountChange={(filteredData: Row<Receipt>[]) => {
                    filteredTableData.current = filteredData.map(
                      (item: { original: Receipt }) => item.original,
                    );
                  }}
                  onRowClick={setSelectedRow as any}
                />
              </TabsContent>

              <TabsContent
                value={RevenueTabType.REFUNDED}
                className={cn(
                  "flex-1 flex flex-col overflow-hidden w-full",
                  activeTab !== RevenueTabType.REFUNDED && "hidden",
                )}
              >
                <DataTable
                  columns={REFUNDED_COLUMNS}
                  data={refundedReceipts}
                  className="w-full flex-1 overflow-auto"
                  enableColumnFilter={true}
                  enablePaging={true}
                  enableFooter={true}
                  enableToggleColumn={true}
                  enableGrouping={false}
                  onFilteredRowCountChange={(filteredData: Row<Receipt>[]) => {
                    filteredTableData.current = filteredData.map(
                      (item: { original: Receipt }) => item.original,
                    );
                  }}
                  onRowClick={setSelectedRow as any}
                />
              </TabsContent>

              <TabsContent
                value={RevenueTabType.CANCELED}
                className={cn(
                  "flex-1 flex flex-col overflow-hidden w-full",
                  activeTab !== RevenueTabType.CANCELED && "hidden",
                )}
              >
                <DataTable
                  columns={CANCELLED_COLUMNS}
                  data={canceledReceipts}
                  className="w-full flex-1 overflow-auto"
                  enableColumnFilter={true}
                  enablePaging={true}
                  enableToggleColumn={true}
                  enableGrouping={false}
                  enableFooter={true}
                  onFilteredRowCountChange={(filteredData: Row<Receipt>[]) => {
                    filteredTableData.current = filteredData.map(
                      (item: { original: Receipt }) => item.original,
                    );
                  }}
                  onRowClick={setSelectedRow as any}
                />
              </TabsContent>

              <TabsContent
                value={RevenueTabType.DETAIL}
                className={cn(
                  "flex-1 flex flex-col overflow-hidden w-full",
                  activeTab !== RevenueTabType.DETAIL && "hidden",
                )}
              >
                <DataTable
                  columns={DETAIL_COLUMNS}
                  data={detailReceipts}
                  className="w-full flex-1 overflow-auto"
                  enableColumnFilter={true}
                  enablePaging={true}
                  enableToggleColumn={true}
                  enableFooter={true}
                  enableGrouping={false}
                  onFilteredRowCountChange={(filteredData: Row<Receipt>[]) => {
                    filteredTableData.current = filteredData.map(
                      (item: { original: Receipt }) => item.original,
                    );
                  }}
                  onRowClick={setSelectedRow as any}
                />
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
