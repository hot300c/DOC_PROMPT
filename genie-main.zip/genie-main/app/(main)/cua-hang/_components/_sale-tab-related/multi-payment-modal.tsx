"use client";

import { getPaymentMethods } from "@/app/(main)/cua-hang/_action/get-payment-methods";
import { InvoiceInfoTable } from "@/app/(main)/cua-hang/_components/_sale-tab-related/invoice-info-table";
import { PaymentForm } from "@/app/(main)/cua-hang/_components/_sale-tab-related/payment-form";
import { PaymentRecordsList } from "@/app/(main)/cua-hang/_components/_sale-tab-related/payment-records-list";
import { InvoiceItem } from "@/app/(main)/cua-hang/_models/bill-model";
import { CartItem } from "@/app/(main)/cua-hang/_models/cart-model";
import { Counter } from "@/app/(main)/cua-hang/_models/counter-model";
import { WorkShift } from "@/app/(main)/cua-hang/_models/work-shift-model";
import {
  createPaymentProcessingRequests,
  createTempInvoiceCleanupQuery,
  findPaymentMethodId,
  generateReportParams,
  generateSummaryReportParams,
  processPaymentReport,
} from "@/app/(main)/cua-hang/_utils/multi-payment-modal-actions";
import { getPaymentColumns } from "@/app/(main)/cua-hang/_utils/multi-payment-modal-columns";
import { saveOrderQAPay } from "@/app/(main)/thanh-toan/_actions/qa-pay/save-order-qa-pay";
import { useTechcombank } from "@/app/(main)/thanh-toan/_hooks/techcombank/use-techcombank";
import { transactionQueueOrder } from "@/app/(main)/thanh-toan/_utils/qa-pay-api/ntransaction-queue-order";
import { PaymentType } from "@/app/lib/definitions/setting";
import { PaperDimensions, PaperSize, QA_PAY_OTP } from "@/app/lib/enums";
import { useFeedbackDialog } from "@/app/lib/feedback-dialog-provider";
import { useModal } from "@/app/lib/modal-print-provider";
import * as SystemService from "@/app/lib/services/system";
import { notifyError, notifySuccess } from "@/app/lib/utils";
import { usePrinterService } from "@/components/app-printer-configs/app-printer-services";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  selectBaseSetting,
  selectFaculty,
  selectUser,
} from "@/redux/selectors";
import { useAppSelector } from "@/redux/store";
import { Guid } from "js-guid";
import { useCallback, useEffect, useRef, useState } from "react";

interface PaymentRecord {
  id: string;
  paymentMethodId: string;
  paymentMethodName: string;
  amount: number;
  cardNumber?: string;
  voucherCode?: string;
  totalAmount: number;
  invoiceId?: string;
  invoiceHinhThucThanhToanId?: string;
  isPrinted: boolean;
}

interface MultiPaymentModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  cartItems: CartItem[];
  initialInvoiceData?: CartItem[];
  totalAmount?: number;
  selectedCounter: Counter | null;
  selectedStoreWorkShift: WorkShift | null;
  invoiceParams: {
    customerId: string;
    customerName: string;
    customerAddress: string;
    customerPhone: string;
    customerGender: string;
    customerBirthYear: string;
    facId: string;
    counterId: string;
    shiftDailyId: string;
    shiftName: string;
    paymentMethodName: string | undefined;
    note: string;
    stockId?: number;
    stockName?: string;
    email: string;
  };
  isPrintOpening: boolean;
  setIsPrintOpening: (isPrintOpening: boolean) => void;
  loadPurchasedItems: (invoiceId: string) => Promise<void>;
}

export function MultiPaymentModal({
  open,
  onOpenChange,
  cartItems,
  invoiceParams,
  isPrintOpening,
  setIsPrintOpening,
  loadPurchasedItems,
}: MultiPaymentModalProps) {
  // State for invoice/receipt items
  const [invoiceItems, setInvoiceItems] = useState<InvoiceItem[]>([]);
  const [selectedInvoiceIndex, setSelectedInvoiceIndex] = useState<number>(0);
  const newInvoiceId = useRef(Guid.newGuid().toString());
  // State for payment methods and records
  const [paymentMethods, setPaymentMethods] = useState<PaymentType[]>([]);
  const [paymentRecords, setPaymentRecords] = useState<PaymentRecord[]>([]);

  const { openModal } = useModal();
  const { alert, confirm } = useFeedbackDialog();
  const baseSettings = useAppSelector(selectBaseSetting);

  const { validateTCBForVNVCStoreMultiPaymentBeforePrint } = useTechcombank();
  const { getSavedPrinterName, getConnectedPrinters } = usePrinterService();

  const faculty = useAppSelector(selectFaculty);
  const facId = faculty.facId || "";
  const user = useAppSelector(selectUser);

  useEffect(() => {
    newInvoiceId.current = Guid.newGuid().toString();
  }, [open]);

  // Add new payment record
  const handleAddPayment = async (paymentData: {
    paymentMethod: string;
    amount: string;
    cardNumber: string;
    voucherCode: string;
  }) => {
    if (selectedInvoiceIndex === undefined) {
      return;
    }

    const selectedInvoice = invoiceItems[selectedInvoiceIndex];
    if (!selectedInvoice) {
      return;
    }

    const paymentAmountValue = parseFloat(paymentData.amount);

    if (isNaN(paymentAmountValue) || paymentAmountValue <= 0) {
      await alert({
        title: "Thông báo",
        content: "Số tiền không hợp lệ. Vui lòng nhập lại.",
      });
      return;
    }

    if (
      baseSettings?.find((setting) => setting.name === "CoKetNoiMayPOS")
        ?.value === "N" &&
      !paymentData.cardNumber.trim() &&
      (paymentData.paymentMethod.toUpperCase() === "THẺ" ||
        paymentData.paymentMethod.toUpperCase() === "CHUYỂN KHOẢN" ||
        paymentData.paymentMethod.toUpperCase() === "QA PAY")
    ) {
      await alert({
        title: "Thông báo",
        content: "Chưa nhập số thẻ/tài khoản. Vui lòng thử lại.",
      });
      return;
    }

    if (selectedInvoice.patientPay <= paymentAmountValue) {
      await alert({
        title: "Thông báo",
        content:
          "Giá thanh toán phải thấp hơn giá của biên lai! Vui lòng nhập lại giá.",
      });
      return;
    }

    const existingPaymentsTotal = paymentRecords.reduce(
      (sum, record) => sum + record.amount,
      0,
    );

    const remainingAmount = selectedInvoice.patientPay - existingPaymentsTotal;
    if (remainingAmount < paymentAmountValue) {
      await alert({
        title: "Thông báo",
        content:
          "Thanh toán vượt quá số tiền còn lại của hóa đơn! Vui lòng nhập lại.",
      });
      return;
    }

    const paymentMethod = paymentMethods.find(
      (m) => m.ten === paymentData.paymentMethod,
    );

    const newPayment: PaymentRecord = {
      id: Guid.newGuid().toString(),
      paymentMethodId: paymentMethod?.id.toString() || "",
      paymentMethodName: paymentData.paymentMethod,
      amount: paymentAmountValue,
      cardNumber: paymentData.cardNumber.trim() || undefined,
      voucherCode: paymentData.voucherCode.trim() || undefined,
      totalAmount: selectedInvoice.thanhTien,
      invoiceId: selectedInvoice.invoiceId || undefined,
      isPrinted: false,
    };

    setPaymentRecords([...paymentRecords, newPayment]);
  };

  // Delete payment record
  const handleDeletePayment = useCallback(
    async (payment: PaymentRecord) => {
      if (payment.invoiceHinhThucThanhToanId || payment.isPrinted) {
        await alert({
          title: "Thông báo",
          content: "Phương thức thanh toán này đã được lưu! Không thể xóa.",
        });
        return;
      }

      setPaymentRecords(paymentRecords.filter((p) => p.id !== payment.id));
    },
    [paymentRecords, alert],
  );

  // Print/process payment record
  const handleProcessPayment = useCallback(
    async (payment: PaymentRecord) => {
      try {
        if (isPrintOpening) {
          return;
        }
        if (payment.isPrinted) {
          notifyError("Thanh toán này đã được xử lý!");
          return;
        }
        setIsPrintOpening(true);

        // Initialize invoice ID
        if (!payment.invoiceId) {
          payment.invoiceId = newInvoiceId.current;
        }

        // Get selected invoice
        const selectedInvoice = invoiceItems[selectedInvoiceIndex];

        // Check if this is a full payment
        const isFullPayment = selectedInvoice?.moneyOwe === payment.amount;

        // Find payment method ID
        const paymentMethodId = findPaymentMethodId(
          paymentMethods,
          payment.paymentMethodName?.replace("QA PAY", "VNVC Point"),
        );

        // Create payment processing requests
        let { query, requests, paymentId } = createPaymentProcessingRequests(
          payment,
          newInvoiceId.current,
          selectedInvoice,
          paymentMethodId,
          facId,
          invoiceParams,
          cartItems,
          isFullPayment,
        );

        // Execute temp transaction
        try {
          await SystemService.executeTransaction({ request: requests });
        } catch (e: any) {
          await alert({
            content: e.message || "Đã xảy ra lỗi trong quá trình thanh toán",
            title: "Đã xảy ra lỗi!",
          });
          setIsPrintOpening(false);
          return;
        }

        //Handle Payable VNVC Point
        const transactionPayload = {
          transactionSessionId: "",
          transactionPointId: "",
          transactionMoneyId: "",
          otp: QA_PAY_OTP,
        };

        if (paymentMethodId === "6") {
          const order = await transactionQueueOrder(
            payment.cardNumber || "",
            payment.amount,
            0,
            user.userId,
            `Mua hàng`,
          );
          if (!order || !order.transactionSessionID) {
            await alert({
              title: "Cảnh báo",
              content:
                order?.messageError ||
                "Có lỗi khi thanh toán bằng VNVC Point. Vui lòng thanh toán lại.",
            });
            setIsPrintOpening(false);
            await SystemService.executeTransaction({
              request: [createTempInvoiceCleanupQuery(payment.invoiceId)],
            });
            return;
          }
          transactionPayload.transactionSessionId = order.transactionSessionID;
          transactionPayload.transactionPointId = order.transactionPointID;
          transactionPayload.transactionMoneyId = order.transactionMoneyID;
        }

        notifySuccess("Đã lưu");

        // Generate and display report
        const reportId =
          baseSettings.find(
            (item) =>
              item.category === "Report_BanLe_1" &&
              item.name === "BienLaiThuTienBanLe",
          )?.value || "";

        if (reportId) {
          const reportParams = generateReportParams(
            newInvoiceId.current,
            facId,
            paymentId,
          );
          const base64Res = await processPaymentReport(
            reportId,
            reportParams,
            baseSettings,
          );

          let isPrinted = false;
          if (base64Res) {
            await openModal({
              reportID: reportId,
              base64Data: base64Res,
              onHandlePrint: async () => {
                // Execute the transaction to save the payment permanently
                try {
                  if (query.length) {
                    //Handle Payable VNVC Point
                    if (paymentMethodId === "6") {
                      if (!transactionPayload.transactionSessionId) {
                        setIsPrintOpening(false);
                        return false;
                      }

                      const result = await saveOrderQAPay(
                        transactionPayload.transactionSessionId,
                        transactionPayload.otp,
                      );
                      if (!result) {
                        setIsPrintOpening(false);
                        return false;
                      }

                      query.push({
                        category: "QAHosGenericDB",
                        command: "ws_Billing_InvoiceBusiness_QAPAY_Update",
                        parameters: {
                          InvoiceID: newInvoiceId.current,
                          TransactionMoneyID:
                            transactionPayload.transactionMoneyId,
                          TransactionPointID:
                            transactionPayload.transactionPointId,
                          TransactionSessionID:
                            transactionPayload.transactionSessionId,
                        },
                      });
                    }

                    if (paymentMethodId === "15") {
                      const tcbPaymentCheckResult =
                        await validateTCBForVNVCStoreMultiPaymentBeforePrint({
                          facId: faculty.facId || "",
                          patientId: "00000000-0000-0000-0000-000000000000",
                          patientHospitalId: invoiceParams.customerId,
                          invoiceBusinessID: newInvoiceId.current,
                          reason: "Thanh toán hóa đơn cửa hàng",
                          printers: getConnectedPrinters(),
                          selectedPrinter: getSavedPrinterName(
                            PaperDimensions[PaperSize.A5].printerType,
                          ),
                        });
                      if (!tcbPaymentCheckResult.isSuccess) {
                        await alert({
                          title: "Cảnh báo",
                          content:
                            "Thanh toán Techcombank không thành công. Vui lòng thử lại.",
                        });
                        setIsPrintOpening(false);
                        return false;
                      }

                      // Filter and update the query for TCB payment and update the SoTK to tcbPaymentCheckResult.techcombankInvoiceId
                      query = query.map((req) => {
                        // Check if this is a Techcombank payment request
                        if (
                          (req.command ===
                            "ws_BIL_InvoiceBusiness_Temp_Credit_Save_Genie" ||
                            req.command ===
                              "ws_BIL_InvoiceBusiness_Credit_Save_Genie") &&
                          req.parameters?.HinhThucThanhToan === "Techcombank"
                        ) {
                          // Update the SoTK field with the techcombankInvoiceId
                          return {
                            ...req,
                            parameters: {
                              ...req.parameters,
                              SoTK:
                                tcbPaymentCheckResult.techcombankInvoiceId ||
                                "",
                            },
                          };
                        }
                        return req;
                      });
                    }

                    await SystemService.executeTransaction({ request: query });

                    // Mark this payment as printed
                    setPaymentRecords((prev) =>
                      prev.map((p) =>
                        p.id === payment.id ? { ...p, isPrinted: true } : p,
                      ),
                    );

                    // Update the invoice item to reflect new payment amounts
                    setInvoiceItems((prev) => {
                      if (selectedInvoiceIndex !== undefined) {
                        const updatedItems = [...prev];
                        const originalItem = updatedItems[selectedInvoiceIndex];

                        if (!originalItem) {
                          notifyError("Không tìm thấy hóa đơn để cập nhật");
                          return prev;
                        }

                        updatedItems[selectedInvoiceIndex] = {
                          invoiceId: originalItem.invoiceId || "",
                          invoiceNo: originalItem.invoiceNo || "",
                          patientPay: originalItem.patientPay,
                          moneyPaid:
                            (originalItem.moneyPaid || 0) + payment.amount,
                          moneyOwe:
                            (originalItem.moneyOwe || 0) - payment.amount,
                          thanhTien: originalItem.thanhTien,
                        };
                        return updatedItems;
                      }
                      return prev;
                    });

                    notifySuccess("Đã lưu thanh toán thành công");
                    isPrinted = true;

                    // Load purchased items after saving
                    if (isFullPayment && isPrinted)
                      await loadPurchasedItems(newInvoiceId.current);

                    return true;
                  } else {
                    notifyError("Không có dữ liệu để lưu");
                    return false;
                  }
                } catch (e: any) {
                  await alert({
                    content: e.message || "Đã xảy ra lỗi khi lưu thanh toán",
                    title: "Lỗi!",
                  });
                  return false;
                } finally {
                  setIsPrintOpening(false);
                }
              },
            });

            if (isFullPayment && isPrinted) {
              // Print the summary report
              const summaryReportParams = generateSummaryReportParams(
                newInvoiceId.current,
                facId,
              );
              const base64SummaryRes = await processPaymentReport(
                reportId,
                summaryReportParams,
                baseSettings,
              );

              if (base64SummaryRes) {
                await openModal({
                  reportID: reportId,
                  base64Data: base64SummaryRes,
                  paperSize: PaperSize.A5,
                });
              }
            }
            await SystemService.executeTransaction({
              request: [createTempInvoiceCleanupQuery(newInvoiceId.current)],
            });
          }
          setIsPrintOpening(false);
        } else {
          notifyError("Không tìm thấy báo cáo để in hóa đơn.");
          setIsPrintOpening(false);
        }
      } catch (error) {
        console.error("Failed to process payment:", error);
        notifyError("Xử lý thanh toán thất bại. Vui lòng thử lại.");
        setIsPrintOpening(false);
      }
    },
    [
      isPrintOpening,
      setIsPrintOpening,
      invoiceItems,
      selectedInvoiceIndex,
      paymentMethods,
      facId,
      invoiceParams,
      cartItems,
      baseSettings,
      alert,
      user.userId,
      openModal,
      validateTCBForVNVCStoreMultiPaymentBeforePrint,
      faculty.facId,
      getConnectedPrinters,
      getSavedPrinterName,
      loadPurchasedItems,
    ],
  );

  // Load payment methods on mount
  useEffect(() => {
    const loadPaymentMethods = async () => {
      try {
        const availableMethods = await getPaymentMethods(facId);
        if (availableMethods.length > 0) {
          // Replace QA Pay with VNVC Point
          const vnvcPointIndex = availableMethods.findIndex(
            (m) => m.ten.toUpperCase() === "QA PAY",
          );
          if (vnvcPointIndex !== -1 && availableMethods[vnvcPointIndex]) {
            availableMethods[vnvcPointIndex].ten = "VNVC Point";
          }
          availableMethods.sort((a, b) => a.orderIndex - b.orderIndex);
          setPaymentMethods(availableMethods);
        }
      } catch (error) {
        console.error("Failed to load payment methods:", error);
      }
    };

    void loadPaymentMethods();
  }, [facId]);

  useEffect(() => {
    const itemData = cartItems?.filter((x) => !x.invoiceId) || [];

    setInvoiceItems([
      {
        invoiceId: itemData[0]?.invoiceId || "",
        invoiceNo: "",
        patientPay: itemData.reduce(
          (sum, item) => sum + item.thanhTienSauCK,
          0,
        ),
        moneyPaid: 0,
        moneyOwe: itemData.reduce((sum, item) => sum + item.thanhTienSauCK, 0),
        thanhTien: itemData.reduce((sum, item) => sum + item.thanhTienSauCK, 0),
      },
    ]);
  }, [cartItems]);

  // On modal close
  const handleClose = async () => {
    const currentInvoice = invoiceItems[selectedInvoiceIndex];
    if (!currentInvoice) {
      return;
    }

    if (currentInvoice?.moneyOwe > 0 && currentInvoice?.moneyPaid > 0) {
      await alert({
        title: "Thông báo",
        content: "Vui lòng thanh toán đủ số tiền trên biên lai gốc",
      });
      return;
    }

    // Check for unprocessed payments
    const unprocessedPayments = paymentRecords.filter((p) => !p.isPrinted);

    if (unprocessedPayments.length > 0) {
      try {
        const confirmed = await confirm({
          title: "Xác nhận đóng",
          content:
            "Có thanh toán chưa được xử lý. Dữ liệu sẽ không được lưu. Bạn có chắc muốn đóng không?",
        });

        if (!confirmed) {
          return;
        }
      } catch (error) {
        console.error("Error showing confirmation dialog:", error);
        return;
      }
    }

    // Clean up resources and state
    setPaymentRecords([]);
    const totalAmount = cartItems.reduce(
      (sum, item) => sum + item.thanhTienSauCK,
      0,
    );
    setInvoiceItems([
      {
        invoiceId: "",
        invoiceNo: "",
        patientPay: totalAmount,
        moneyPaid: 0,
        moneyOwe: totalAmount,
        thanhTien: totalAmount,
      },
    ]);
    setSelectedInvoiceIndex(0);

    // Close the modal
    onOpenChange(paymentRecords.filter((p) => p.isPrinted).length > 0);
  };

  return (
    <div>
      <Dialog open={open} onOpenChange={handleClose}>
        <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto p-6">
          <DialogHeader>
            <DialogTitle className="text-xl font-semibold">
              Thanh toán nhiều phương thức
            </DialogTitle>
          </DialogHeader>

          <div className="flex flex-col gap-4 pt-2">
            <div className="grid grid-cols-6 gap-4">
              <div className="col-span-4">
                <InvoiceInfoTable
                  invoiceItems={invoiceItems}
                  onRowClick={(rowIndex) => setSelectedInvoiceIndex(rowIndex)}
                />
              </div>

              <div className="col-span-2">
                <PaymentForm
                  paymentMethods={paymentMethods}
                  initialPaymentMethod={paymentMethods[0]?.ten || ""}
                  onAddPayment={handleAddPayment}
                />
              </div>
            </div>

            <PaymentRecordsList
              paymentRecords={paymentRecords}
              columns={getPaymentColumns(
                handleDeletePayment,
                handleProcessPayment,
                isPrintOpening,
              )}
            />
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
