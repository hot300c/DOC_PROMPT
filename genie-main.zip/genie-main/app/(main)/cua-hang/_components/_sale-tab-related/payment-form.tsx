"use client";
import { QaPayInfoDialog } from "@/app/(main)/cua-hang/_components/_sale-tab-related/qa-pay-info-modal";
import { Loading } from "@/app/(main)/duoc/(base_components)/loading";
import { QAPayCardInfo } from "@/app/lib/definitions/qa-pay";
import { PaymentType } from "@/app/lib/definitions/setting";
import { CANH_BAO, TypicalPaymentMethod } from "@/app/lib/enums";
import { useFeedbackDialog } from "@/app/lib/feedback-dialog-provider";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

import * as QAPayService from "@/app/lib/services/qa-pay-services";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { zodResolver } from "@hookform/resolvers/zod";
import { CreditCard } from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { NumericFormat } from "react-number-format";
import { z } from "zod";

interface PaymentFormProps {
  paymentMethods: PaymentType[];
  onAddPayment: (paymentData: {
    paymentMethod: string;
    amount: string;
    cardNumber: string;
    voucherCode: string;
  }) => void;
  initialPaymentMethod?: string;
}

const cardNumberRequiredMethods = [
  "Chuyển khoản",
  "Thẻ ATM",
  "Thẻ tín dụng",
  "VNVC Point",
];

const PaymentFormSchema = z
  .object({
    paymentMethod: z.string().min(1, "Vui lòng chọn phương thức thanh toán"),
    paymentAmount: z
      .string()
      .refine((value) => !isNaN(Number(value)) && Number(value) > 0, {
        message: "Số tiền phải lớn hơn 0",
      }),
    cardNumber: z.string(),
    voucherCode: z.string().optional(),
  })
  .superRefine((data, ctx) => {
    if (
      cardNumberRequiredMethods.includes(data.paymentMethod) &&
      !data.cardNumber.trim()
    ) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: "Vui lòng nhập mã thẻ/số tài khoản",
        path: ["cardNumber"],
      });
    }
  });

type FormValues = z.infer<typeof PaymentFormSchema>;

export function PaymentForm({
  paymentMethods,
  onAddPayment,
  initialPaymentMethod,
}: PaymentFormProps) {
  const [isCardNumberInputEnabled, setIsCardNumberInputEnabled] =
    useState(false);
  const [isVoucherCodeInputEnabled, setIsVoucherCodeInputEnabled] =
    useState(false);
  const [needsQaPayValidation, setNeedsQaPayValidation] = useState(false);
  const [qaPayDialogOpen, setQaPayDialogOpen] = useState(false);
  const cardOwner = useRef<QAPayCardInfo | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const { alert } = useFeedbackDialog();

  const defaultPaymentMethod =
    initialPaymentMethod || paymentMethods[0]?.ten || "";

  const form = useForm<FormValues>({
    resolver: zodResolver(PaymentFormSchema),
    defaultValues: {
      paymentMethod: defaultPaymentMethod,
      paymentAmount: "0",
      cardNumber: "",
      voucherCode: "",
    },
  });

  const watchedCardNumber = form.watch("cardNumber");
  const watchedPaymentMethod = form.watch("paymentMethod");

  useEffect(() => {
    const paymentMethod = watchedPaymentMethod;

    if (
      paymentMethod.toUpperCase() === TypicalPaymentMethod.ATM_CARD ||
      paymentMethod.toUpperCase() === TypicalPaymentMethod.BANK_TRANSFER ||
      paymentMethod.toUpperCase() === TypicalPaymentMethod.CREDIT_CARD
    ) {
      setIsCardNumberInputEnabled(true);
      setIsVoucherCodeInputEnabled(false);
      setNeedsQaPayValidation(false);
    } else if (paymentMethod.toUpperCase() === TypicalPaymentMethod.VOUCHER) {
      setIsVoucherCodeInputEnabled(true);
      setIsCardNumberInputEnabled(false);
      setNeedsQaPayValidation(false);
    } else if (
      paymentMethod.replace("VNVC Point", "QA PAY").toUpperCase() ===
      TypicalPaymentMethod.QA_PAY
    ) {
      setIsCardNumberInputEnabled(true);
      setIsVoucherCodeInputEnabled(false);
      setNeedsQaPayValidation(true);
    } else {
      setIsCardNumberInputEnabled(false);
      setIsVoucherCodeInputEnabled(false);
      setNeedsQaPayValidation(false);
    }
  }, [watchedPaymentMethod]);

  const handleValidateQaPay = async () => {
    try {
      if (!watchedCardNumber?.trim()) {
        await alert({
          title: "Thông báo",
          content: "Vui lòng nhập mã thẻ VNVC Point.",
        });
        return;
      }

      setIsLoading(true);

      const result = await QAPayService.fetchAccountOwner({
        cardNumber: watchedCardNumber.trim(),
      });
      if (!result) {
        await alert({
          title: CANH_BAO,
          content: "Thông tin thẻ trống",
        });
        return;
      }

      const cardInfos = await QAPayService.fetchCardInfo({
        accountId: result.accountID,
      });
      const cardFiltered = cardInfos.filter((x) => !x.isLock && x.isActive);

      if (!cardFiltered.length) {
        await alert({
          title: "Thông báo",
          content: "Không thể kiểm tra thông tin thẻ VNVC Point.",
        });
        return;
      }
      cardOwner.current = cardFiltered[0] || null;
      // Open the QA PAY info dialog
      setQaPayDialogOpen(true);
    } catch (error) {
      console.error("Failed to validate QAPAY card:", error);
      await alert({
        title: "Lỗi",
        content: "Không thể kiểm tra thông tin thẻ VNVC Point.",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const onSubmit = (data: FormValues) => {
    onAddPayment({
      paymentMethod: data.paymentMethod,
      amount: data.paymentAmount,
      cardNumber: data.cardNumber || "",
      voucherCode: data.voucherCode || "",
    });

    // Reset form after submission
    form.setValue("paymentAmount", "0");
    form.setValue("cardNumber", "");
    form.setValue("voucherCode", "");
  };

  const filteredPaymentMethods = useMemo(() => {
    const unsupportedMethods = ["7", "10", "11", "13"];
    return paymentMethods
      .filter((method) => !unsupportedMethods.includes(method.id.toString()))
      .map((method) => (
        <SelectItem key={method.id} value={method.ten}>
          {method.ten}
        </SelectItem>
      ));
  }, [paymentMethods]);

  return (
    <div>
      {isLoading && <Loading />}
      <Card className="shadow-sm h-full">
        <CardContent className="p-4">
          <div className="font-semibold text-lg mb-4">Thêm thanh toán</div>

          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              {/* Payment Method */}
              <FormField
                control={form.control}
                name="paymentMethod"
                render={({ field }) => (
                  <FormItem className="space-y-2">
                    <FormLabel>Phương thức thanh toán</FormLabel>
                    <Select value={field.value} onValueChange={field.onChange}>
                      <FormControl>
                        <SelectTrigger className="w-full">
                          <SelectValue placeholder="Chọn phương thức" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>{filteredPaymentMethods}</SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Payment Amount */}
              <FormField
                control={form.control}
                name="paymentAmount"
                render={({ field }) => (
                  <FormItem className="space-y-2">
                    <FormLabel>Số tiền thanh toán</FormLabel>
                    <FormControl>
                      <NumericFormat
                        id="paymentAmount"
                        value={field.value}
                        thousandSeparator="."
                        decimalSeparator=","
                        decimalScale={0}
                        fixedDecimalScale
                        suffix={" đ"}
                        customInput={Input}
                        onValueChange={(values) => {
                          field.onChange(values.value);
                        }}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Card/Account Number */}
              <FormField
                control={form.control}
                name="cardNumber"
                render={({ field }) => (
                  <FormItem className="space-y-2">
                    <FormLabel>
                      {needsQaPayValidation
                        ? "Mã thẻ VNVC Point"
                        : "Mã thẻ/ số TK"}
                    </FormLabel>
                    <div className="flex space-x-2">
                      <FormControl>
                        <Input
                          id="cardNumber"
                          {...field}
                          disabled={!isCardNumberInputEnabled}
                        />
                      </FormControl>

                      {needsQaPayValidation && (
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={handleValidateQaPay}
                          disabled={!watchedCardNumber}
                          className="whitespace-nowrap"
                        >
                          <CreditCard className="h-4 w-4 mr-1" /> Xác thực
                        </Button>
                      )}
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Voucher Code */}
              <FormField
                control={form.control}
                name="voucherCode"
                render={({ field }) => (
                  <FormItem className="space-y-2">
                    <FormLabel>Mã khuyến mãi</FormLabel>
                    <FormControl>
                      <Input
                        id="voucherCode"
                        {...field}
                        disabled={!isVoucherCodeInputEnabled}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <Button className="w-full mt-2" type="submit">
                Thêm thanh toán
              </Button>
            </form>
          </Form>
        </CardContent>
      </Card>
      {qaPayDialogOpen && cardOwner.current && (
        <QaPayInfoDialog
          open={qaPayDialogOpen}
          onOpenChange={setQaPayDialogOpen}
          initialCardNumber={watchedCardNumber}
          onConfirm={(confirmedCardNumber) => {
            form.setValue("cardNumber", confirmedCardNumber);
            setQaPayDialogOpen(false);
          }}
          cardOwner={cardOwner?.current}
        />
      )}
    </div>
  );
}
