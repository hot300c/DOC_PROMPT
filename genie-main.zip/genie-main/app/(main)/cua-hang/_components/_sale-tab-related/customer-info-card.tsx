import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Search } from "lucide-react";
import { Select } from "@/components/select/select";
import React from "react";
import useSWRImmutable from "swr/immutable";
import { fetchDoiTuongTinhTienDataAltListData } from "@/app/(main)/cua-hang/_action/get-patient-type";

interface CustomerInfoCardProps {
  customerHospitalId: string;
  setCustomerHospitalId: (id: string) => void;
  customerPhone: string;
  setCustomerPhone: (phone: string) => void;
  customerEmail: string;
  setCustomerEmail: (email: string) => void;
  customerInfo: {
    name: string;
    gender: string;
    birthYear: string;
    address: string;
    customerTypeId: number | undefined;
    employeeId: string | undefined;
    id: string;
  };
  isPaid: boolean;
  isCustomerDataSet: boolean;
  handleAddCustomer: () => void;
  handleSearchById: () => Promise<void>;
  handleSearchByPhone: () => Promise<void>;
  onEmployeeIdChange?: (employeeId: string) => void;
  onCustomerTypeChange?: (
    customerTypeId: number,
    customerTypeName: string,
  ) => void;
}

export function CustomerInfoCard({
  customerHospitalId,
  setCustomerHospitalId,
  customerPhone,
  setCustomerPhone,
  customerEmail,
  setCustomerEmail,
  customerInfo,
  isPaid,
  isCustomerDataSet,
  handleAddCustomer,
  handleSearchById,
  handleSearchByPhone,
  onEmployeeIdChange,
  onCustomerTypeChange,
}: CustomerInfoCardProps) {
  // đối tượng tính tiền
  const { data: lstDoiTuongTinhTienAlt } = useSWRImmutable(
    "ServiceAdmissionPara.fetchDoiTuongTinhTienDataAltListData",
    () => fetchDoiTuongTinhTienDataAltListData(),
  );

  return (
    <Card className="mb-1">
      <CardContent className="p-2 space-y-1">
        <div className="flex flex-row items-center space-x-1">
          <Label
            htmlFor="customerId"
            className="w-24 text-right whitespace-nowrap"
          >
            Mã khách hàng:
          </Label>
          <div className="flex-1 flex space-x-1">
            <Input
              id="customerId"
              value={customerHospitalId}
              onChange={(e) => setCustomerHospitalId(e.target.value)}
              className="flex-1"
              disabled={isPaid || isCustomerDataSet}
              onKeyDown={async (e) => {
                if (e.key === "Enter") {
                  await handleSearchById();
                }
              }}
            />
            <Button
              size="sm"
              onClick={handleSearchById}
              disabled={isCustomerDataSet}
              className="px-2"
            >
              <Search className="h-4 w-4" />
            </Button>
            <Button
              size="sm"
              className="px-2"
              disabled={isPaid || isCustomerDataSet}
              onClick={handleAddCustomer}
            >
              Thêm
            </Button>
          </div>
        </div>

        <div className="flex flex-row items-center">
          <Label className="w-24 text-right whitespace-nowrap">
            Tên khách hàng:
          </Label>
          <div className="m-1 flex-1 truncate">{customerInfo.name}</div>
        </div>

        <div className="flex flex-row">
          <div className="w-1/2 flex flex-row items-center">
            <Label className="w-24 text-right whitespace-nowrap">
              Giới tính:
            </Label>
            <div className="m-1">{customerInfo.gender}</div>
          </div>
          <div className="w-1/2 flex flex-row items-center">
            <Label className="w-24 text-right whitespace-nowrap">
              Năm sinh:
            </Label>
            <div className="m-1">{customerInfo.birthYear}</div>
          </div>
        </div>

        <div className="flex flex-row">
          <div className="w-1/2 flex flex-row items-center">
            <Label
              htmlFor="customerEmail"
              className="w-24 text-right whitespace-nowrap"
            >
              Địa chỉ email:
            </Label>
            <div className="flex-1 flex space-x-1 m-1">
              <Input
                id="customerEmail"
                value={customerEmail}
                onChange={(e) => {
                  setCustomerEmail(e.target.value);
                }}
                className="flex-1"
                disabled={isPaid}
              />
            </div>
          </div>
          <div className="w-1/2 flex flex-row items-center">
            <Label
              htmlFor="customerPhone"
              className="w-24 text-right whitespace-nowrap"
            >
              Số điện thoại:
            </Label>
            <div className="flex-1 flex space-x-1 ml-1">
              <Input
                id="customerPhone"
                value={customerPhone}
                onChange={(e) => setCustomerPhone(e.target.value)}
                className="flex-1"
                inputMode="tel"
                disabled={isPaid || isCustomerDataSet}
                onKeyDown={async (e) => {
                  if (e.key === "Enter") {
                    await handleSearchByPhone();
                  }
                }}
              />
              <Button
                size="sm"
                disabled={isCustomerDataSet}
                onClick={handleSearchByPhone}
                className="px-2"
              >
                <Search className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>

        <div className="flex flex-row">
          <div className="w-full flex flex-row items-center">
            <Label className="w-24 text-right whitespace-nowrap">
              Địa chỉ TT:
            </Label>
            <div className="m-1">{customerInfo.address}</div>
          </div>
        </div>

        <div className="flex flex-row">
          <div className="w-1/2 flex flex-row items-center">
            <Label
              htmlFor="customerType"
              className="w-24 text-right whitespace-nowrap"
            >
              Đối tượng TT:
            </Label>
            <div className="flex-1 flex space-x-1 m-1">
              <Select
                tabIndex={-1}
                className="flex-1"
                classNamePopover="w-full"
                data-cy={`cy-patientInfo-doiTuongTinhTien`}
                onChange={(value) => {
                  if (onCustomerTypeChange && value) {
                    const selectedCustomerType = lstDoiTuongTinhTienAlt?.find(
                      (item) => item.doiTuongId.toString() === value,
                    );
                    if (selectedCustomerType) {
                      onCustomerTypeChange(
                        selectedCustomerType.doiTuongId,
                        selectedCustomerType.doiTuongName,
                      );
                    }
                  }
                }}
                value={customerInfo.customerTypeId?.toString()}
                placeholder="Chọn đối tượng"
                options={
                  lstDoiTuongTinhTienAlt?.map((item) => ({
                    label: item.doiTuongName,
                    value: item.doiTuongId.toString(),
                  })) ?? []
                }
                disabled={isPaid}
                showSearch={true}
                id="customerType"
              />
            </div>
          </div>
          <div className="w-1/2 flex flex-row items-center">
            <Label
              htmlFor="customerEmployeeId"
              className="w-24 text-right whitespace-nowrap"
            >
              Mã NV:
            </Label>
            <div className="flex-1 flex space-x-1 ml-1">
              <Input
                id="customerEmployeeId"
                value={customerInfo.employeeId?.toString() || ""}
                onChange={(e) => {
                  if (onEmployeeIdChange) {
                    onEmployeeIdChange(e.target.value);
                  }
                }}
                className="flex-1"
                disabled={isPaid}
              />
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
