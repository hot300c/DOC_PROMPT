import { getCartColumns } from "@/app/(main)/cua-hang/_utils/sale-tab-table-columns";
import { SHIPPING_SERVICE_NAME } from "@/app/lib/enums";
import { useFeedbackDialog } from "@/app/lib/feedback-dialog-provider";
import { formatCurrencyVND, GUID_NewSequential } from "@/app/lib/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { DataTable } from "@/components/ui/dataTable";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import _ from "lodash";
import {
  ChangeEvent,
  FocusEvent,
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import { NumericFormat } from "react-number-format";
import { CartItem } from "../../_models/cart-model";
import DiscountModal from "../discount-modal";

interface CartItemsTableProps {
  cartItems: CartItem[];
  discount: string;
  setDiscount: (discount: string) => void;
  onRemoveFromCart: (idx: number) => void;
  isPaid: boolean;
  handleApplyDiscount: (chietKhau: string, discountPrice: string) => void;
  handleChangeQuantity: (item: CartItem, quantity: number) => void;
  handleChangeDiscount: (
    item: CartItem,
    percent: number,
    discount: number,
    reason: string,
  ) => void;
  onAddToCart: (newItem: CartItem) => Promise<void>;
}

export function CartItemsTable({
  cartItems,
  discount,
  setDiscount,
  onRemoveFromCart,
  isPaid,
  handleApplyDiscount,
  handleChangeQuantity,
  handleChangeDiscount,
  onAddToCart,
}: CartItemsTableProps) {
  const { alert } = useFeedbackDialog();
  const [discountPrice, setDiscountPrice] = useState("");
  const discountPriceRef = useRef("");
  const discountRef = useRef("");
  const useDiscountAll = useRef<boolean | null>(null);
  const priceTotal = useRef(0);
  const [deliveryFee, setDeliveryFee] = useState<number>(10000);
  const [cartItem, setCartItem] = useState<CartItem | null>(null);

  const handleSetCartItem = (item: CartItem | null) => {
    if (
      item?.name !== SHIPPING_SERVICE_NAME &&
      (Number(discount || "0") > 0 ||
        Number(discountPriceRef.current || "0") > 0)
    )
      return;
    setCartItem(item);
  };

  useEffect(() => {
    discountPriceRef.current = discountPrice?.replace(/\D/g, "") || "0";
  }, [discountPrice]);

  useEffect(() => {
    discountRef.current = discount || "0";
  }, [discount]);

  useEffect(() => {
    handleSetUseDiscount();
    priceTotal.current = _.sumBy(cartItems, (x) => x.thanhTienTruocCK) || 0;
    if (
      !cartItems?.some(
        (x) => x.discount > 0 && x.name !== SHIPPING_SERVICE_NAME,
      )
    ) {
      setDiscount("");
      setDiscountPrice("");
      useDiscountAll.current = null;
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [cartItems]);

  const handleSetUseDiscount = () => {
    if (
      Number(discountRef.current || 0) > 0 ||
      Number(discountPriceRef.current || 0) > 0
    )
      useDiscountAll.current = true;
    else if (
      cartItems.some((x) => x.discount > 0 && x.name !== SHIPPING_SERVICE_NAME)
    )
      useDiscountAll.current = false;
    else useDiscountAll.current = null;
  };

  const handleApDungLenDon = useCallback(async () => {
    if (useDiscountAll.current === false) return;
    let chietKhau = parseFloat(discountRef.current);
    let price = parseFloat(discountPriceRef.current);
    if (isNaN(chietKhau) && isNaN(price)) {
      setDiscount("");
      setDiscountPrice("");
      return;
    }
    if (chietKhau < 0) {
      chietKhau = Math.abs(chietKhau);
      setDiscount(String(chietKhau));
    } else if (chietKhau > 100) {
      await alert({
        title: "",
        content: "Không được nhập chiết khấu trên 100%",
      });
      chietKhau = 100;
      setDiscount(String(chietKhau));
    }
    handleApplyDiscount(String(chietKhau), discountPriceRef.current);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [discount, setDiscount, handleApplyDiscount, alert]);

  const handleSubmitChietKhau = useCallback(
    async (e: React.KeyboardEvent<HTMLInputElement>) => {
      if (e.key === "Enter") {
        await handleApDungLenDon();
      }
    },
    [handleApDungLenDon],
  );

  const handleChangeDiscountOnRow = async (
    item: CartItem,
    percent: number,
    discount: number,
    reason: string,
  ) => {
    if (percent > 0 || discount > 0) useDiscountAll.current = false;
    else useDiscountAll.current = null;
    await handleChangeDiscount(item, percent, discount, reason);
  };

  const validateValue = (value: number, valueMax: number) => {
    if (value < 0 || value > valueMax) return false;
    return true;
  };

  const handleSetDiscountPrice = (e: ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.replace(/\D/g, "");
    if (value === "") {
      setDiscountPrice("");
      return;
    }
    const number = Number(value);
    if (!validateValue(number, priceTotal.current)) return;
    setDiscountPrice(value);
  };

  const handleOnBlurDiscountPrice = async (
    e: FocusEvent<HTMLInputElement, Element>,
  ) => {
    await handleApDungLenDon();
    setDiscountPrice(
      formatCurrencyVND(
        Number(e.target.value.replace(/\D/g, "") || "0"),
        0,
        false,
      ),
    );
  };

  const isDisableDiscount = useMemo(() => {
    const percent = Number(discount || "0");
    const price = Number(discountPrice.replace(/\D/g, "") || "0");
    return (
      isPaid ||
      price > 0 ||
      (percent <= 0 &&
        useDiscountAll.current === false &&
        cartItems.some(
          (x) => x.discount > 0 && x.name !== SHIPPING_SERVICE_NAME,
        ))
    );
  }, [discount, discountPrice, isPaid, cartItems]);

  const isDisableDiscountPrice = useMemo(() => {
    const percent = Number(discount || "0");
    const price = Number(discountPrice.replace(/\D/g, "") || "0");
    return (
      isPaid ||
      percent > 0 ||
      (price <= 0 &&
        useDiscountAll.current === false &&
        cartItems.some(
          (x) => x.discount > 0 && x.name !== SHIPPING_SERVICE_NAME,
        ))
    );
  }, [discount, discountPrice, isPaid, cartItems]);
  const addNewCartItem = async () => {
    if (deliveryFee <= 0) return;
    const newItem: CartItem = {
      id: GUID_NewSequential(),
      productId: null,
      code: "",
      name: SHIPPING_SERVICE_NAME,
      price: deliveryFee,
      quantity: 1,
      stockId: 0,
      stockName: "",
      hangSanXuat: null,
      loaiXuat: "",
      discount: 0,
      discountPercent: 0,
      tt: "",
      thanhTienTruocCK: deliveryFee,
      thanhTienSauCK: deliveryFee,
      invoiceDetailId: null,
      invoiceId: null,
      tenChinhSach: "",
      batch: "",
      expDate: null,
    };
    setDeliveryFee(10000);
    await onAddToCart(newItem);
  };
  return (
    <>
      <Card className="flex-1 mb-1 overflow-hidden min-h-[300px]">
        <CardContent className="h-full flex flex-col p-0">
          <div className="flex-1 overflow-auto">
            <DataTable
              columns={getCartColumns(
                onRemoveFromCart,
                isPaid,
                handleChangeQuantity,
                handleSetCartItem,
              )}
              data={cartItems}
              className="w-full"
              enableColumnFilter={false}
              enablePaging={false}
              enableToggleColumn
              enableGrouping={false}
              enableGlobalFilter={false}
            />
          </div>
          <div className="p-2 flex flex-row items-center space-x-1 pt-1 border-t mt-0">
            <Label htmlFor="discount" className="whitespace-nowrap">
              CK:
            </Label>
            <div className="relative w-1/5 mr-3">
              <Input
                id="discount"
                type="number"
                disabled={isDisableDiscount}
                className="w-full pr-5 pl-2 py-1 border rounded text-right"
                value={discount}
                onChange={(e) => setDiscount(e.target.value)}
                onBlur={handleApDungLenDon}
                onKeyDown={handleSubmitChietKhau}
              />
              <span className="absolute right-2 top-1/2 -translate-y-1/2 pointer-events-none">
                %
              </span>
            </div>

            <div className="relative w-2/5 mr-3">
              <Input
                disabled={isDisableDiscountPrice}
                className="w-full pr-5 pl-2 py-1 border rounded text-right"
                value={discountPrice}
                onChange={handleSetDiscountPrice}
                onBlur={handleOnBlurDiscountPrice}
                onKeyDown={handleSubmitChietKhau}
              />
              <span className="absolute right-2 top-1/2 -translate-y-1/2 pointer-events-none">
                đ
              </span>
            </div>

            <Button
              className="whitespace-nowrap px-2"
              onClick={handleApDungLenDon}
              disabled={isPaid}
            >
              Áp dụng
            </Button>

            <Label className="whitespace-nowrap">Phí VC</Label>
            <div className="relative w-2/5">
              <NumericFormat
                placeholder="Nhập phí vận chuyển"
                value={deliveryFee}
                thousandSeparator="."
                decimalSeparator=","
                decimalScale={0}
                fixedDecimalScale
                suffix={" đ"}
                customInput={Input}
                onValueChange={(values) => {
                  setDeliveryFee(Number(values.value));
                }}
              />
            </div>

            <Button className="whitespace-nowrap px-2" onClick={addNewCartItem}>
              Thêm
            </Button>
          </div>
        </CardContent>
      </Card>
      {cartItem && (
        <DiscountModal
          cartItem={cartItem}
          onClose={() => setCartItem(null)}
          handleChangeDiscount={handleChangeDiscountOnRow}
        />
      )}
    </>
  );
}
