"use client";

import { checkBillGiftInfo } from "@/app/(main)/cua-hang/_action/check-bill-info";
import { getProductCustomColumns } from "@/app/(main)/cua-hang/_action/get-product-custom";
import { getPurchasedItems } from "@/app/(main)/cua-hang/_action/get-purchased-items";
import { getAllStoreProducts } from "@/app/(main)/cua-hang/_action/get-store-products";
import { MultiPaymentModal } from "@/app/(main)/cua-hang/_components/_sale-tab-related/multi-payment-modal";
import { GiftSelectionModal } from "@/app/(main)/cua-hang/_components/gift-selection-modal";
import { Counter } from "@/app/(main)/cua-hang/_models/counter-model";
import { WorkShift } from "@/app/(main)/cua-hang/_models/work-shift-model";
import { createTempInvoiceCleanupQuery } from "@/app/(main)/cua-hang/_utils/multi-payment-modal-actions";
import {
  createGiftCartItem,
  processPromotions,
} from "@/app/(main)/cua-hang/_utils/promotion-utils";
import {
  buildInventoryOutputRequest,
  buildInvoiceDetailRequests,
  buildInvoiceHeaderRequest,
  buildInvoiceTempRequests,
  savePaymentMethodRequests,
  savePaymentMethodTempRequests,
} from "@/app/(main)/cua-hang/_utils/sale-tab-actions";
import { saveOrderQAPay } from "@/app/(main)/thanh-toan/_actions/qa-pay/save-order-qa-pay";
import QAPayCheckCardNumber from "@/app/(main)/thanh-toan/_components/qa-pay/check-card/qa-pay-check-card-number";
import { useTechcombank } from "@/app/(main)/thanh-toan/_hooks/techcombank/use-techcombank";
import { CardOwner } from "@/app/(main)/thanh-toan/_utils/definitions/api";
import { transactionQueueOrder } from "@/app/(main)/thanh-toan/_utils/qa-pay-api/ntransaction-queue-order";
import { PaymentType } from "@/app/lib/definitions/setting";
import {
  CANH_BAO,
  PaperDimensions,
  PaperSize,
  PermissionEnum,
  QA_PAY_OTP,
  SHIPPING_SERVICE_NAME,
} from "@/app/lib/enums";
import { useFeedbackDialog } from "@/app/lib/feedback-dialog-provider";
import { useModal } from "@/app/lib/modal-print-provider";
import * as SystemService from "@/app/lib/services/system";
import * as utils from "@/app/lib/utils";
import { getSetting, notifySuccess } from "@/app/lib/utils";
import { useAppPermissions } from "@/components/app-permissions/app-permissions";
import { usePrinterService } from "@/components/app-printer-configs/app-printer-services";
import { LoadingUI } from "@/components/loading";
import {
  ResizableHandle,
  ResizablePanel,
  ResizablePanelGroup,
} from "@/components/ui/resizable";
import {
  selectBaseSetting,
  selectFaculty,
  selectUser,
} from "@/redux/selectors";
import { useAppSelector } from "@/redux/store";
import _ from "lodash";
import { useCallback, useEffect, useRef, useState } from "react";
import { getPaymentMethods } from "../../_action/get-payment-methods";
import { CartItem } from "../../_models/cart-model";
import { CustomerCartPanel } from "./customer-cart-panel";
import { ProductSearchPanel } from "./product-search-panel";

export default function SaleTab({
  selectedShopTypeId,
  selectedCounter,
  setIsCounterModalOpen,
  selectedStoreWorkShift,
}: {
  selectedShopTypeId: string;
  selectedCounter: Counter | null;
  setIsCounterModalOpen: (open: boolean) => void;
  selectedStoreWorkShift: WorkShift | null;
}) {
  // State management
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [multiplePaymentCartItems, setMultiplePaymentCartItems] = useState<
    CartItem[]
  >([]);
  const [customerId, setCustomerId] = useState("");
  const [customerHospitalId, setCustomerHospitalId] = useState("");
  const [customerPhone, setCustomerPhone] = useState("");
  const [customerEmail, setCustomerEmail] = useState("");
  const [customerInfo, setCustomerInfo] = useState({
    tier: 3,
    name: "...",
    gender: "...",
    birthYear: "...",
    address: "...",
    id: "",
    employeeId: "",
    customerTypeId: undefined as number | undefined,
  });
  const [discount, setDiscount] = useState("");
  const [paymentMethod, setPaymentMethod] = useState("");
  const [totalBeforeDiscount, setTotalBeforeDiscount] = useState(0);
  const [totalAfterDiscount, setTotalAfterDiscount] = useState(0);
  const [
    multiplePaymentTotalAfterDiscount,
    setMultiplePaymentTotalAfterDiscount,
  ] = useState(0);
  const [isLoading, setIsLoading] = useState(false);
  const [isQAPayCheckCardNumberOpen, setIsQAPayCheckCardNumberOpen] =
    useState(false);
  const [paymentMethods, setPaymentMethods] = useState<PaymentType[]>([]);
  const cardCodeRef = useRef("");
  const billNoteRef = useRef("");
  const [isPaid, setIsPaid] = useState(false);
  const [isCustomerDataSet, setIsCustomerDataSet] = useState(false);
  const resetBillStatesFnRef = useRef<(() => void) | null>(null);
  const [receiptNumber, setReceiptNumber] = useState("");
  const [isPrintOpening, setIsPrintOpening] = useState(false);
  const [isGiftSelectionOpen, setIsGiftSelectionOpen] = useState(false);
  const [availableGifts, setAvailableGifts] = useState<any[]>([]);
  const [promotionData, setPromotionData] = useState<any>(null);
  const [pendingGiftChoices, setPendingGiftChoices] = useState<any[]>([]);
  const [pendingPromotionResult, setPendingPromotionResult] =
    useState<any>(null);
  const [, setIsWaitingForGiftSelection] = useState(false);
  const [selectedChoiceGifts, setSelectedChoiceGifts] = useState<CartItem[]>(
    [],
  );
  const [pendingPaymentMode, setPendingPaymentMode] = useState<
    "single" | "multiple" | null
  >(null);

  const user = useAppSelector(selectUser);
  const faculty = useAppSelector(selectFaculty);
  const facId = faculty.facId || "";
  const facName = faculty.name || "";
  const baseSettings = useAppSelector(selectBaseSetting);
  const [counter, setCounter] = useState<Counter | null>(selectedCounter);
  const [isMultiplePaymentsOpen, setIsMultiplePaymentsOpen] = useState(false);

  const { alert, confirm } = useFeedbackDialog();
  const { openModal } = useModal();
  const { hasPermission } = useAppPermissions();
  const { validateTCBForVNVCStoreBeforePrint } = useTechcombank();
  const { getSavedPrinterName, getConnectedPrinters } = usePrinterService();
  const qaPayCardNumberRef = useRef<string>("");
  const noteGiftModal = useRef<string>("");
  const missingProductNotes = useRef<string>("");

  const ignoreMissingGiftProducts = useRef(
    getSetting(baseSettings, "BoQuaQuaBiThieu")?.value || "",
  );

  // Update local counter when prop changes
  useEffect(() => {
    setCounter(selectedCounter ?? null);
  }, [selectedCounter]);

  // Load available payment methods
  const getAvailablePaymentMethods = useCallback(async () => {
    try {
      const availableMethods = await getPaymentMethods(facId);
      if (availableMethods.length > 0) {
        // Replace QA Pay with VNVC Point
        const vnvcPointIndex = availableMethods.findIndex(
          (m) => m.ten.toUpperCase() === "QA PAY",
        );
        if (vnvcPointIndex !== -1 && availableMethods[vnvcPointIndex]) {
          availableMethods[vnvcPointIndex].ten = "VNVC Point";
        }

        availableMethods.sort((a, b) => a.orderIndex - b.orderIndex);
        setPaymentMethods(availableMethods);
        setPaymentMethod(availableMethods[0]!.id.toString());
      }
    } catch (error) {
      console.error("Error fetching payment methods:", error);
    }
  }, [facId]);

  // Add this function to validate gift policies
  const validateGiftPolicies = async (): Promise<{
    isValid: boolean;
    invoiceId?: string;
    contractId?: string;
    isBLTangKem?: boolean;
  }> => {
    if (cartItems.length <= 0) {
      await alert({
        title: CANH_BAO,
        content:
          "Không có chi tiết thông tin thanh toán, vui lòng kiểm tra lại!",
      });
      return { isValid: false };
    }

    // Check for gift policy items
    let hasGiftPolicy = false;
    let policyNames = "";
    let hospitalCodes = "";
    let productIds = "";

    for (const item of cartItems) {
      const policyName = item.tenChinhSach?.trim() || "";
      const productId = item.productId || 0;
      const hospitalCode = item.code?.trim() || "";

      if (policyName) {
        // TODO: Check if the receipt number is valid when needed
        // Ignore checking for receipt policy - Requested and confirmed by AnTran and Dan Calif
        hasGiftPolicy = false;
        if (policyNames) {
          policyNames += "|" + policyName;
          hospitalCodes += "|" + hospitalCode;
          productIds += "|" + productId.toString();
        } else {
          policyNames = policyName;
          hospitalCodes = hospitalCode;
          productIds = productId.toString();
        }
      }
    }

    // Receipt number validation
    if (hasGiftPolicy && !receiptNumber.trim()) {
      await alert({
        title: "Thông báo",
        content:
          "Có dữ liệu chính sách quà tặng kèm chi tiết, vui lòng nhập số biên lai thanh toán!",
      });
      return { isValid: false };
    }

    if (receiptNumber.trim() && !hasGiftPolicy) {
      await alert({
        title: "Thông báo",
        content:
          "Có số biên lai thanh toán, vui lòng nhập chính sách quà tặng kèm!",
      });
      return { isValid: false };
    }

    // If we have both gift policies and receipt number, validate with backend
    if (hasGiftPolicy) {
      try {
        const response = await checkBillGiftInfo(
          facId,
          receiptNumber,
          customerId,
          policyNames,
          hospitalCodes,
          productIds,
        );

        if (response.resultCode !== 200) {
          if (response.resultMessage) {
            await alert({
              title: "Thông báo",
              content: response.resultMessage,
            });
          }
          return { isValid: false };
        }

        return {
          isValid: true,
          invoiceId: response.invoiceId || "",
          contractId: response.hopDongId || "",
          isBLTangKem: !!response.invoiceId,
        };
      } catch (error) {
        console.error("Error validating gift policies:", error);
        await alert({
          title: "Thông báo",
          content: "Đã xảy ra lỗi khi kiểm tra chính sách quà tặng kèm!",
        });
        return { isValid: false };
      }
    }

    return { isValid: true };
  };

  useEffect(() => {
    void getAvailablePaymentMethods();
  }, [getAvailablePaymentMethods]);

  //Handle calc total order discount
  const calcTotalOrderDiscount = (
    cartItems: CartItem[],
    discountVal: string,
    discountPriceVal: string,
    forceApply: boolean = false,
  ) => {
    const percent = discountVal ? parseFloat(discountVal) : 0;
    const price = Number(discountPriceVal || 0);
    if (percent > 0) return handleDiscountPercent(cartItems, percent);
    else if (price > 0 || forceApply) {
      return handelDiscountPrice(cartItems, price);
    } else return cartItems;
  };
  //handle calc discount percent
  const handleDiscountPercent = (cartItems: CartItem[], percent: number) => {
    return cartItems.map((item) => {
      if (item.name === SHIPPING_SERVICE_NAME) return item;
      const beforeDisc = item.thanhTienTruocCK || item.price * item.quantity;

      const afterDisc = beforeDisc * (1 - percent / 100);

      return {
        ...item,
        discountPercent: percent,
        discount: beforeDisc - afterDisc,
        thanhTienSauCK: afterDisc,
      };
    });
  };
  //handle calc discount price
  const handelDiscountPrice = (cartItems: CartItem[], price: number) => {
    const totalAmount = _.sumBy(
      cartItems.filter((x) => x.name != SHIPPING_SERVICE_NAME),
      (x) => Number(x.thanhTienTruocCK || 0),
    );
    let processedAmount = 0;
    let remainingDiscount = price;

    return cartItems.map((item) => {
      if (item.name === SHIPPING_SERVICE_NAME) return item;
      const beforeDisc = item.thanhTienTruocCK || item.price * item.quantity;
      if (beforeDisc === 0) return item;

      let afterDisc = beforeDisc;

      processedAmount += beforeDisc;

      const discountPriceCurren =
        processedAmount === totalAmount
          ? remainingDiscount
          : _.round(price * (beforeDisc / totalAmount), 0);
      afterDisc = afterDisc - discountPriceCurren;
      remainingDiscount -= discountPriceCurren;

      return {
        ...item,
        discountPercent: 0,
        discount: beforeDisc - afterDisc,
        thanhTienSauCK: afterDisc,
      };
    });
  };

  const handleRemoveFromCart = (idx: number) => {
    const serviceName = cartItems[idx]?.name || "";
    const updatedCartItems = cartItems.filter((_, i) => i !== idx);
    if (!updatedCartItems?.length) {
      setCartItems([]);
      return;
    }
    resetDiscounts(updatedCartItems, serviceName);
  };

  const calculateTotals = useCallback(() => {
    const beforeDiscount = cartItems.reduce(
      (acc, item) =>
        acc + (item.thanhTienTruocCK || item.price * item.quantity),
      0,
    );
    setTotalBeforeDiscount(beforeDiscount);

    const afterDiscount = cartItems.reduce(
      (acc, item) => acc + (item.thanhTienSauCK ?? item.price * item.quantity),
      0,
    );
    setTotalAfterDiscount(afterDiscount);
  }, [cartItems]);

  useEffect(() => {
    calculateTotals();
  }, [cartItems, discount, calculateTotals]);

  // Clean up and re-initialize form/cart
  const handleCreateNewCart = async () => {
    setCartItems([]);
    setCustomerHospitalId("");
    setCustomerPhone("");
    setCustomerEmail("");
    setCustomerInfo({
      tier: 3, // Default tier
      name: "...",
      gender: "...",
      birthYear: "...",
      address: "...",
      id: "",
      employeeId: "",
      customerTypeId: undefined,
    });
    setDiscount("");
    cardCodeRef.current = "";
    billNoteRef.current = "";
    if (paymentMethods.length > 0) {
      setPaymentMethod(paymentMethods[0]!.id.toString());
    }
    setTotalBeforeDiscount(0);
    setTotalAfterDiscount(0);
    setIsPaid(false);
    setCustomerId("");
    setIsCustomerDataSet(false);

    // Reset promotion and gift selection states
    setPendingPromotionResult(null);
    setPendingGiftChoices([]);
    setSelectedChoiceGifts([]);
    setIsWaitingForGiftSelection(false);

    // Reset bill states in CustomerCartPanel
    if (resetBillStatesFnRef.current) {
      resetBillStatesFnRef.current();
    }
  };

  // Payment & Receipt
  const handleViewReceipt = async (qaPayCardNumber: string = "") => {
    qaPayCardNumberRef.current = qaPayCardNumber || "";
    // Basic validations
    const hadProducts = cartItems.find((item) => item.productId);
    if (cartItems.length === 0 || !hadProducts) {
      await alert({
        title: CANH_BAO,
        content: "Giỏ hàng trống. Vui lòng thêm sản phẩm trước.",
      });
      return;
    }
    if (!validateSerialNumbers()) {
      await alert({
        title: CANH_BAO,
        content: "Có lỗi khi kiểm tra serial, vui lòng kiểm tra lại.",
      });
      return;
    }
    if (!selectedStoreWorkShift?.shiftId) {
      await alert({
        title: CANH_BAO,
        content:
          "Bạn chưa thuộc ca làm việc nào, vui lòng tạo ca làm việc trước.",
      });
      return;
    }
    if (!selectedCounter) {
      await alert({
        title: CANH_BAO,
        content: "Bạn chưa chọn quầy, vui lòng chọn quầy làm việc.",
      });
      return;
    }

    if (!isCustomerDataSet) {
      await alert({
        title: CANH_BAO,
        content:
          "Thông tin khách hàng chưa được thiết lập, vui lòng kiểm tra lại.",
      });
      return;
    }
    setIsLoading(true);
    missingProductNotes.current = "";
    // Gift policy validation
    const giftPolicyResult = await validateGiftPolicies();
    if (!giftPolicyResult.isValid) {
      return;
    }

    // Check promotions before processing payment
    try {
      const promotionResult = await processPromotions(
        cartItems,
        facId,
        facName,
        {
          ...customerInfo,
          employeeId: customerInfo.employeeId,
          customerTypeId: customerInfo.customerTypeId,
        },
        customerPhone,
        customerHospitalId,
      );

      setIsLoading(false);
      if (promotionResult) {
        const currentAvailableProducts = await getAllStoreProducts(
          facId,
          selectedShopTypeId,
        );

        // Check if promotionResult has any missing products
        const missingProducts = promotionResult.autoGiftItems.filter((item) => {
          // Calculate total available quantity across all batches for this product
          const totalAvailableQty = currentAvailableProducts
            .filter((product) => product.productID === item.productId)
            .reduce((sum, product) => sum + product.qty, 0);

          // Check if product exists and has sufficient total quantity
          const productExists = currentAvailableProducts.some(
            (product) => product.productID === item.productId,
          );

          return !productExists || totalAvailableQty < item.quantity;
        });

        const missingChoiceGifts = promotionResult.choiceGiftItems.map(
          (group) => ({
            ...group,
            giftProducts: group.giftProducts.filter((product) => {
              const productId = parseInt(product.giftProductId, 10);
              // Calculate total available quantity across all batches for this gift product
              const totalAvailableQty = currentAvailableProducts
                .filter((p) => p.productID === productId)
                .reduce((sum, p) => sum + p.qty, 0);

              const productExists = currentAvailableProducts.some(
                (p) => p.productID === productId,
              );

              return productExists && totalAvailableQty >= product.quantity;
            }),
          }),
        );

        // If there are missing products, show an alert and stop processing
        if (missingProducts.length > 0) {
          const missingProductNames = [
            ...missingProducts.map((item) => `${item.name}`),
          ].join(", ");

          if (!(ignoreMissingGiftProducts.current === "Y")) {
            const answer = await confirm({
              title: CANH_BAO,
              content: `Một số sản phẩm trong khuyến mãi không có sẵn: ${missingProductNames} \n Vui lòng nhấn CÓ để tiếp tục thanh toán.`,
            });
            if (!answer) return;
            missingProductNotes.current = `Không đủ tồn sản phẩm khuyến mãi: ${missingProductNames} khi thanh toán`;
          }

          // Remove missing products from promotionResult
          promotionResult.autoGiftItems = promotionResult.autoGiftItems.filter(
            (item) =>
              !missingProducts.some(
                (missing) => missing.productId === item.productId,
              ),
          );
        }

        if (missingChoiceGifts.length > 0) {
          promotionResult.choiceGiftItems = promotionResult.choiceGiftItems.map(
            (group) => ({
              ...group,
              giftProducts: group.giftProducts.filter((product) =>
                currentAvailableProducts.some(
                  (p) => p.productID === parseInt(product.giftProductId, 10),
                ),
              ),
            }),
          );
        }

        // Process auto gift items to set proper batch and expDate
        const processedAutoGiftItems: CartItem[] = [];
        if (promotionResult.autoGiftItems.length > 0) {
          // Filter products to remove duplicates by productID, keeping the one with earliest expDate
          const uniqueProductsByExpDate = currentAvailableProducts.reduce(
            (acc, product) => {
              const existingProduct = acc.find(
                (p) => p.productID === product.productID,
              );
              if (!existingProduct) {
                acc.push(product);
              } else {
                // Keep the product with earliest expDate
                if (
                  new Date(product.expDate) < new Date(existingProduct.expDate)
                ) {
                  const index = acc.findIndex(
                    (p) => p.productID === product.productID,
                  );
                  acc[index] = product;
                }
              }
              return acc;
            },
            [] as typeof currentAvailableProducts,
          );

          for (const autoGift of promotionResult.autoGiftItems) {
            // Find the product with earliest expDate
            let selectedProduct = uniqueProductsByExpDate.find(
              (product) => autoGift.productId === product.productID,
            );

            if (selectedProduct) {
              let remainingQuantity = autoGift.quantity;

              // Check if the required quantity exceeds available quantity
              if (remainingQuantity > selectedProduct.qty) {
                // Add what we can from the first product
                if (selectedProduct.qty > 0) {
                  processedAutoGiftItems.push({
                    ...autoGift,
                    quantity: selectedProduct.qty,
                    stockId: selectedProduct.stockID,
                    stockName: selectedProduct.stockName,
                    batch: selectedProduct.batch,
                    expDate: selectedProduct.expDate
                      ? new Date(selectedProduct.expDate)
                      : null,
                  });
                  remainingQuantity -= selectedProduct.qty;
                }

                // Find additional products with same productID but different batch
                const additionalProducts = currentAvailableProducts
                  .filter(
                    (product) =>
                      product.productID === autoGift.productId &&
                      product.batch !== selectedProduct.batch &&
                      product.qty > 0,
                  )
                  .sort(
                    (a, b) =>
                      new Date(a.expDate).getTime() -
                      new Date(b.expDate).getTime(),
                  ); // Sort by expDate

                // Use additional products to fulfill remaining quantity
                for (const additionalProduct of additionalProducts) {
                  if (remainingQuantity <= 0) break;

                  const quantityToUse = Math.min(
                    remainingQuantity,
                    additionalProduct.qty,
                  );
                  processedAutoGiftItems.push({
                    ...autoGift,
                    id: `gift-${autoGift.productId}-${Date.now()}-${Math.random()}`, // Generate new ID for additional batch
                    quantity: quantityToUse,
                    stockId: additionalProduct.stockID,
                    stockName: additionalProduct.stockName,
                    batch: additionalProduct.batch,
                    expDate: additionalProduct.expDate
                      ? new Date(additionalProduct.expDate)
                      : null,
                  });
                  remainingQuantity -= quantityToUse;
                }
              } else {
                // Normal case: required quantity is available in the selected product
                processedAutoGiftItems.push({
                  ...autoGift,
                  stockId: selectedProduct.stockID,
                  stockName: selectedProduct.stockName,
                  batch: selectedProduct.batch,
                  expDate: selectedProduct.expDate
                    ? new Date(selectedProduct.expDate)
                    : null,
                });
              }
            } else {
              // Product not found in store, keep original auto gift (should not happen after missing product filtering)
              processedAutoGiftItems.push(autoGift);
            }
          }
        }

        // If there are choice gifts, show the selection modal and wait for user selection
        if (
          promotionResult.hasChoiceGifts &&
          promotionResult.choiceGiftItems.length > 0
        ) {
          // Store the promotion result for later use, but with processed auto gifts
          const updatedPromotionResult = {
            ...promotionResult,
            autoGiftItems: processedAutoGiftItems,
          };
          setPendingPromotionResult(updatedPromotionResult);
          setPendingGiftChoices(promotionResult.choiceGiftItems);
          setIsWaitingForGiftSelection(true);
          setPendingPaymentMode("single"); // Set payment mode for single payment

          // Show the first gift selection modal
          const firstChoice = promotionResult.choiceGiftItems[0];
          if (firstChoice) {
            setAvailableGifts(firstChoice.giftProducts);
            setPromotionData({
              name: firstChoice.promotionName,
              id: firstChoice.promotionId,
            });
            setIsGiftSelectionOpen(true);
          }
          return; // Stop here and wait for user selection
        } else {
          noteGiftModal.current = "";
        }

        // If no choice gifts, proceed with auto gifts and discounts
        const paymentCartItems = [
          ...promotionResult.discountAppliedItems,
          ...processedAutoGiftItems,
        ];

        // Show promotion applied message
        if (promotionResult.totalDiscountAmount > 0) {
          notifySuccess(
            `Đã áp dụng khuyến mãi với tổng giảm giá: ${utils.formatCurrencyVND(promotionResult.totalDiscountAmount, 0)}`,
          );
        }
        // Continue with payment processing
        await processPaymentView(
          qaPayCardNumber,
          giftPolicyResult.invoiceId,
          giftPolicyResult.contractId,
          giftPolicyResult.isBLTangKem,
          paymentCartItems,
          handleNotes(),
        );
      } else {
        // No promotions, proceed with original cart
        await processPaymentView(
          qaPayCardNumber,
          giftPolicyResult.invoiceId,
          giftPolicyResult.contractId,
          giftPolicyResult.isBLTangKem,
          cartItems,
          handleNotes(),
        );
      }
    } catch (error) {
      setIsLoading(false);
      console.error("Error checking promotions:", error);
      // Continue with original cart if promotion check fails
      await alert({
        title: "Thông báo",
        content: "Không thể kiểm tra khuyến mãi. Tiếp tục với đơn hàng gốc.",
      });
      await processPaymentView(
        qaPayCardNumber,
        giftPolicyResult.invoiceId,
        giftPolicyResult.contractId,
        giftPolicyResult.isBLTangKem,
        cartItems,
        handleNotes(),
      );
    }
  };

  const validateSerialNumbers = () => {
    // Place serial validation logic here if needed
    return true;
  };

  const processPaymentView = async (
    qaPayCardNumber: string = "",
    giftPolicyInvoiceId?: string,
    giftPolicyContractId?: string,
    isBLTangKem?: boolean,
    paymentCartItems?: CartItem[],
    note?: string,
  ) => {
    if (isPrintOpening) return;
    setIsPrintOpening(true);
    try {
      const invoiceId = utils.GUID_NewSequential();
      const invoicePaymentId = utils.GUID_NewSequential();

      // Use paymentCartItems if provided, otherwise use original cartItems
      const itemsForPayment = paymentCartItems || cartItems;

      const {
        invoiceDetailRequests,
        tempDataRequest,
        totalBeforeTax,
        totalDiscount,
      } = buildInvoiceDetailRequests(
        itemsForPayment,
        invoiceId,
        facId,
        customerInfo.id,
        customerPhone,
      );

      const invoiceParams = {
        invoiceId,
        customerId: customerInfo.id,
        customerName: customerInfo.name,
        customerAddress: customerInfo.address,
        customerPhone: customerPhone,
        customerEmail: customerEmail,
        customerGender: customerInfo.gender,
        customerBirthYear: customerInfo.birthYear,
        facId,
        counterId: selectedCounter?.counterID.toString() || "",
        shiftDailyId: selectedStoreWorkShift?.shiftDailyId || "",
        paymentMethodName: paymentMethods.find(
          (x) => x.id.toString() === paymentMethod,
        )?.ten,
        invoiceIDThanhToan: giftPolicyInvoiceId || null,
        hopDongIDThanhToan: giftPolicyContractId || null,
        isBLTangKem: isBLTangKem,
        note: note ?? "",
        stockId: itemsForPayment[0]?.stockId,
        stockName: itemsForPayment[0]?.stockName,
      };

      // Invoice header
      const invoiceHeaderRequest = buildInvoiceHeaderRequest(
        invoiceParams,
        totalBeforeTax,
        totalDiscount,
      );

      // Add temp invoice requests
      const tempInvoiceRequests = buildInvoiceTempRequests(
        invoiceParams,
        totalBeforeTax,
        totalDiscount,
      );
      tempDataRequest.push(...tempInvoiceRequests);

      // Inventory output
      const inventoryOutputRequest = buildInventoryOutputRequest(
        invoiceParams,
        itemsForPayment,
      );

      // Payment method requests
      const paymentTempRequest = savePaymentMethodTempRequests(
        paymentMethod,
        invoiceId,
        totalBeforeTax,
        totalDiscount,
        customerInfo.id,
        cardCodeRef.current,
        facId,
        selectedCounter?.counterID?.toString() || "",
        selectedStoreWorkShift?.shiftDailyId?.toString() || "",
        qaPayCardNumber,
        invoicePaymentId,
      );

      // Combine all requests
      const allRequests = [
        ...invoiceDetailRequests,
        invoiceHeaderRequest,
        inventoryOutputRequest,
      ];

      // Cases where payment method is not supported
      if (paymentTempRequest) {
        tempDataRequest.push(paymentTempRequest);
      }

      //Handle Payable QA Pay
      const transactionPayload = {
        transactionSessionId: "",
        transactionPointId: "",
        transactionMoneyId: "",
        otp: QA_PAY_OTP,
      };

      // Calculate total from the items being processed for payment
      const paymentTotal = itemsForPayment.reduce(
        (acc, item) =>
          acc + (item.thanhTienSauCK ?? item.price * item.quantity),
        0,
      );

      if (paymentMethod === "6") {
        const order = await transactionQueueOrder(
          qaPayCardNumber,
          paymentTotal, // Use calculated total from promotion-adjusted items
          0,
          user.userId,
          `Mua hàng`,
        );
        if (!order || !order.transactionSessionID) {
          await alert({
            title: "Cảnh báo",
            content:
              order?.messageError ||
              "Có lỗi khi thanh toán bằng VNVC Point. Vui lòng thanh toán lại.",
          });
          setIsPrintOpening(false);
          return;
        }
        transactionPayload.transactionSessionId = order.transactionSessionID;
        transactionPayload.transactionPointId = order.transactionPointID;
        transactionPayload.transactionMoneyId = order.transactionMoneyID;
      }

      // 1) Execute the "temp" requests first
      try {
        await SystemService.executeTransaction({ request: tempDataRequest });
      } catch (e: any) {
        await alert({
          content: e.message || "Đã xảy ra lỗi trong quá trình thanh toán",
          title: "Đã xảy ra lỗi!",
        });
        setIsPrintOpening(false);
        return;
      }

      // 2) Show the print preview
      const reportId =
        baseSettings.find(
          (item) =>
            item.category === "Report_BanLe_1" &&
            item.name === "BienLaiThuTienBanLe",
        )?.value || "";

      if (reportId) {
        const reportParams = {
          InvoiceBusinessID: invoiceId,
          FacID: facId,
          IsTemp: 1,
        };
        const base64Res = await utils.handleBase64(
          reportId,
          facId,
          reportParams,
          baseSettings,
          true,
          PaperSize.A5,
        );
        if (base64Res) {
          await openModal({
            reportID: reportId,
            base64Data: base64Res,
            onHandlePrint: async () => {
              let result = false;
              if (paymentMethod === "15") {
                const tcbPaymentCheck =
                  await validateTCBForVNVCStoreBeforePrint({
                    facId: faculty.facId || "",
                    patientId: "00000000-0000-0000-0000-000000000000",
                    patientHospitalId: customerHospitalId,
                    invoiceBusinessID: invoiceId,
                    reason: "Thanh toán hóa đơn cửa hàng",
                    printers: getConnectedPrinters(),
                    selectedPrinter: getSavedPrinterName(
                      PaperDimensions[PaperSize.A5].printerType,
                    ),
                  });
                if (!tcbPaymentCheck.isSuccess) {
                  await alert({
                    title: "Cảnh báo",
                    content:
                      "Thanh toán Techcombank không thành công. Vui lòng thử lại.",
                  });
                  setIsPrintOpening(false);
                  return false;
                }
                cardCodeRef.current =
                  tcbPaymentCheck.techcombankInvoiceId || "";
              }

              const paymentRequest = savePaymentMethodRequests(
                paymentMethod,
                invoiceId,
                totalBeforeTax,
                totalDiscount,
                customerInfo.id,
                cardCodeRef.current,
                facId,
                selectedCounter?.counterID?.toString() || "",
                selectedStoreWorkShift?.shiftDailyId?.toString() || "",
                qaPayCardNumber,
                invoicePaymentId,
              );
              if (paymentRequest) {
                allRequests.push(paymentRequest);
              }
              try {
                result = await processDataForPrint(
                  invoiceId,
                  allRequests,
                  transactionPayload,
                );
              } catch (error: any) {
                console.error("Error processing payment:", error);
                void alert({
                  title: "Đã xảy ra lỗi!",
                  content: error.message,
                });
              } finally {
                setIsPrintOpening(false);
              }
              return result;
            },
            getReportAgain: async () => {
              reportParams.IsTemp = 0;
              const againBase64 = await utils.handleBase64(
                reportId,
                facId,
                reportParams,
                baseSettings,
                true,
                PaperSize.A5,
              );
              if (againBase64) {
                setIsPaid(true);
                return againBase64;
              }
              return undefined;
            },
          });

          await SystemService.executeTransaction({
            request: [
              createTempInvoiceCleanupQuery(reportParams.InvoiceBusinessID),
            ],
          });

          setIsPrintOpening(false);
        }
      } else {
        await alert({
          title: CANH_BAO,
          content: "Không tìm thấy báo cáo để in hóa đơn.",
        });
        setIsPrintOpening(false);
      }
    } catch (error: any) {
      console.error("Error processing payment:", error);
      void alert({
        title: "Đã xảy ra lỗi!",
        content: error.toString() || "Đã xảy ra lỗi trong quá trình thanh toán",
      });
      setIsPrintOpening(false);
    }
  };

  // 3) Actually commit allRequests to finalize saving
  const processDataForPrint = async (
    invoiceId: string,
    query: any[],
    transactionPayload: any,
  ) => {
    if (query.length) {
      try {
        if (paymentMethod === "6") {
          if (!transactionPayload.transactionSessionId) return false;

          const result = await saveOrderQAPay(
            transactionPayload.transactionSessionId,
            transactionPayload.otp,
          );
          if (!result) return false;

          query.push({
            category: "QAHosGenericDB",
            command: "ws_Billing_InvoiceBusiness_QAPAY_Update",
            parameters: {
              InvoiceID: invoiceId,
              TransactionMoneyID: transactionPayload.transactionMoneyId,
              TransactionPointID: transactionPayload.transactionPointId,
              TransactionSessionID: transactionPayload.transactionSessionId,
            },
          });
        }

        await SystemService.executeTransaction({ request: query });

        // Load purchased items after saving
        await loadPurchasedItems(invoiceId);
      } catch (e: any) {
        await alert({
          content: e.message || "Đã xảy ra lỗi trong quá trình thanh toán",
          title: "Đã xảy ra lỗi!",
        });
        return false;
      }

      utils.notifySuccess("Đã lưu");
      return true;
    } else {
      utils.notifySuccess("Thanh toán không thành công");
      return false;
    }
  };

  const loadPurchasedItems = async (invoiceId: string) => {
    try {
      setIsLoading(true);
      // Load data for purchased items
      const purchasedItems = await getPurchasedItems(facId, invoiceId);
      if (purchasedItems.length > 0) {
        // Set the data for cart items with purchased items
        const updatedCartItems: CartItem[] = purchasedItems.map((item) => ({
          id: item.invoiceDetailID,
          productId: item.productID,
          code: item.productCode || "",
          name: item.productName || "",
          price: item.price || 0,
          quantity: item.qty || 0,
          hangSanXuat: null,
          stockId: 0,
          stockName: "",
          loaiXuat: "",
          discount: item.tienGiam || 0,
          discountPercent: item.chietKhau || 0,
          tt: item.tt || "",
          thanhTienTruocCK: item.thanhTienTruocCK || 0,
          thanhTienSauCK: item.thanhTienSauCK || 0,
          invoiceId: item.invoiceID || "",
          invoiceDetailId: item.invoiceDetailID || "",
          tenChinhSach: item.tenChinhSach || "",
          batch: item?.batch || "",
          expDate: item?.expDate ? new Date(item.expDate) : null,
        }));

        // Update cart items with purchased data
        setCartItems(updatedCartItems);
        // Mark transaction as paid
        setIsPaid(true);
      }
    } catch (error) {
      console.error("Error loading purchased items:", error);
      await alert({
        title: CANH_BAO,
        content: "Lỗi khi tải dữ liệu sản phẩm đã mua, vui lòng thử lại.",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleAddToCart = async (newItem: CartItem) => {
    const deliveryFeeExisted = cartItems.find(
      (item) => item.name === SHIPPING_SERVICE_NAME,
    );
    if (newItem.name === SHIPPING_SERVICE_NAME && cartItems.length < 1) {
      utils.notifyWarning("Vui lòng nhập sản phẩm");
      return;
    }
    if (deliveryFeeExisted && newItem.name === SHIPPING_SERVICE_NAME) {
      utils.notifyWarning("Phí vận chuyển đã được chọn");
      return;
    }
    if (newItem.name === SHIPPING_SERVICE_NAME && cartItems.length > 0) {
      newItem.stockId = cartItems[0]?.stockId!;
      newItem.stockName = cartItems[0]?.stockName!;
    }
    if (deliveryFeeExisted?.stockId == 0) {
      deliveryFeeExisted.stockId = newItem.stockId;
      deliveryFeeExisted.stockName = newItem.stockName;
    }
    try {
      setIsLoading(true);
      // Get dynamic columns if any
      if (newItem.productId) {
        const customColumns = await getProductCustomColumns(
          facId,
          newItem.productId,
        );

        // Apply custom column logic
        if (customColumns && customColumns.length > 0) {
          const productTypeId = customColumns[0]?.productTypeID.toString();

          // Special status for product type 23
          if (productTypeId === "23") {
            newItem.tt = "Chưa kích hoạt";
          }

          const existingIdx = cartItems.findIndex(
            (item) =>
              item.productId === newItem.productId &&
              item.batch === newItem.batch &&
              item.expDate === newItem.expDate,
          );

          if (existingIdx !== -1) {
            const updated = [...cartItems];
            const existingItem = updated[existingIdx];
            if (existingItem) {
              const newQty = existingItem.quantity + newItem.quantity;
              updated[existingIdx] = {
                ...existingItem,
                quantity: newQty,
                thanhTienTruocCK: newQty * existingItem.price,
                thanhTienSauCK: newQty * existingItem.price,
              };
              resetDiscounts(updated, newItem.name);

              calculateTotals();
              return;
            }
          }
        }
      }
      // Add as new item if no merging occurred

      const cartItemData = [...cartItems, newItem];
      resetDiscounts(cartItemData, newItem.name);

      calculateTotals();
    } catch (error) {
      console.error("Error adding product to cart:", error);
      await alert({
        title: CANH_BAO,
        content: "Lỗi khi thêm sản phẩm vào giỏ hàng, vui lòng thử lại.",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleMultiplePayments = async () => {
    // First check preconditions before opening the modal
    if (!customerInfo.id) {
      await alert({
        title: CANH_BAO,
        content:
          "Chưa có thông tin khách hàng, vui lòng chọn khách hàng trước.",
      });
      return;
    }
    if (!validateSerialNumbers()) {
      await alert({
        title: CANH_BAO,
        content: "Có lỗi khi kiểm tra serial, vui lòng kiểm tra lại.",
      });
      return;
    }
    if (!selectedStoreWorkShift?.shiftId) {
      await alert({
        title: CANH_BAO,
        content:
          "Bạn chưa thuộc ca làm việc nào, vui lòng tạo ca làm việc trước.",
      });
      return;
    }
    if (!(await validateCartItems())) {
      return;
    }
    if (!selectedCounter) {
      await alert({
        title: CANH_BAO,
        content: "Bạn chưa chọn quầy, vui lòng chọn quầy làm việc.",
      });
      return;
    }

    // Check promotions before processing payment
    try {
      setIsLoading(true);
      const promotionResult = await processPromotions(
        cartItems,
        facId,
        facName,
        {
          ...customerInfo,
          employeeId: customerInfo.employeeId,
          customerTypeId: customerInfo.customerTypeId,
        },
        customerPhone,
        customerHospitalId,
      );
      setIsLoading(false);
      missingProductNotes.current = "";
      if (promotionResult) {
        const currentAvailableProducts = await getAllStoreProducts(
          facId,
          selectedShopTypeId,
        );

        // Check if promotionResult has any missing products
        const missingProducts = promotionResult.autoGiftItems.filter((item) => {
          // Calculate total available quantity across all batches for this product
          const totalAvailableQty = currentAvailableProducts
            .filter((product) => product.productID === item.productId)
            .reduce((sum, product) => sum + product.qty, 0);

          // Check if product exists and has sufficient total quantity
          const productExists = currentAvailableProducts.some(
            (product) => product.productID === item.productId,
          );

          return !productExists || totalAvailableQty < item.quantity;
        });

        const missingChoiceGifts = promotionResult.choiceGiftItems.map(
          (group) => ({
            ...group,
            giftProducts: group.giftProducts.filter((product) => {
              const productId = parseInt(product.giftProductId, 10);
              // Calculate total available quantity across all batches for this gift product
              const totalAvailableQty = currentAvailableProducts
                .filter((p) => p.productID === productId)
                .reduce((sum, p) => sum + p.qty, 0);

              const productExists = currentAvailableProducts.some(
                (p) => p.productID === productId,
              );

              return productExists && totalAvailableQty >= product.quantity;
            }),
          }),
        );

        // If there are missing products, show an alert and stop processing
        if (missingProducts.length > 0) {
          const missingProductNames = [
            ...missingProducts.map((item) => `${item.name}`),
          ].join(", ");

          if (!(ignoreMissingGiftProducts.current === "Y")) {
            const answer = await confirm({
              title: CANH_BAO,
              content: `Một số sản phẩm trong khuyến mãi không có sẵn: ${missingProductNames} \n Vui lòng nhấn CÓ để tiếp tục thanh toán.`,
            });

            if (!answer) return;
            missingProductNotes.current = `Không đủ tồn sản phẩm khuyến mãi: ${missingProductNames} khi thanh toán`;
          }

          // Remove missing products from promotionResult
          promotionResult.autoGiftItems = promotionResult.autoGiftItems.filter(
            (item) =>
              !missingProducts.some(
                (missing) => missing.productId === item.productId,
              ),
          );
        }

        if (missingChoiceGifts.length > 0) {
          promotionResult.choiceGiftItems = promotionResult.choiceGiftItems.map(
            (group) => ({
              ...group,
              giftProducts: group.giftProducts.filter((product) =>
                currentAvailableProducts.some(
                  (p) => p.productID === parseInt(product.giftProductId, 10),
                ),
              ),
            }),
          );
        }

        // Process auto gift items to set proper batch and expDate
        const processedAutoGiftItems: CartItem[] = [];
        if (promotionResult.autoGiftItems.length > 0) {
          // Filter products to remove duplicates by productID, keeping the one with earliest expDate
          const uniqueProductsByExpDate = currentAvailableProducts.reduce(
            (acc, product) => {
              const existingProduct = acc.find(
                (p) => p.productID === product.productID,
              );
              if (!existingProduct) {
                acc.push(product);
              } else {
                // Keep the product with earliest expDate
                if (
                  new Date(product.expDate) < new Date(existingProduct.expDate)
                ) {
                  const index = acc.findIndex(
                    (p) => p.productID === product.productID,
                  );
                  acc[index] = product;
                }
              }
              return acc;
            },
            [] as typeof currentAvailableProducts,
          );

          for (const autoGift of promotionResult.autoGiftItems) {
            // Find the product with earliest expDate
            let selectedProduct = uniqueProductsByExpDate.find(
              (product) => autoGift.productId === product.productID,
            );

            if (selectedProduct) {
              let remainingQuantity = autoGift.quantity;

              // Check if the required quantity exceeds available quantity
              if (remainingQuantity > selectedProduct.qty) {
                // Add what we can from the first product
                if (selectedProduct.qty > 0) {
                  processedAutoGiftItems.push({
                    ...autoGift,
                    quantity: selectedProduct.qty,
                    stockId: selectedProduct.stockID,
                    stockName: selectedProduct.stockName,
                    batch: selectedProduct.batch,
                    expDate: selectedProduct.expDate
                      ? new Date(selectedProduct.expDate)
                      : null,
                  });
                  remainingQuantity -= selectedProduct.qty;
                }

                // Find additional products with same productID but different batch
                const additionalProducts = currentAvailableProducts
                  .filter(
                    (product) =>
                      product.productID === autoGift.productId &&
                      product.batch !== selectedProduct.batch &&
                      product.qty > 0,
                  )
                  .sort(
                    (a, b) =>
                      new Date(a.expDate).getTime() -
                      new Date(b.expDate).getTime(),
                  ); // Sort by expDate

                // Use additional products to fulfill remaining quantity
                for (const additionalProduct of additionalProducts) {
                  if (remainingQuantity <= 0) break;

                  const quantityToUse = Math.min(
                    remainingQuantity,
                    additionalProduct.qty,
                  );
                  processedAutoGiftItems.push({
                    ...autoGift,
                    id: `gift-${autoGift.productId}-${Date.now()}-${Math.random()}`, // Generate new ID for additional batch
                    quantity: quantityToUse,
                    stockId: additionalProduct.stockID,
                    stockName: additionalProduct.stockName,
                    batch: additionalProduct.batch,
                    expDate: additionalProduct.expDate
                      ? new Date(additionalProduct.expDate)
                      : null,
                  });
                  remainingQuantity -= quantityToUse;
                }
              } else {
                // Normal case: required quantity is available in the selected product
                processedAutoGiftItems.push({
                  ...autoGift,
                  stockId: selectedProduct.stockID,
                  stockName: selectedProduct.stockName,
                  batch: selectedProduct.batch,
                  expDate: selectedProduct.expDate
                    ? new Date(selectedProduct.expDate)
                    : null,
                });
              }
            } else {
              // Product not found in store, keep original auto gift (should not happen after missing product filtering)
              processedAutoGiftItems.push(autoGift);
            }
          }
        }

        // If there are choice gifts, show the selection modal and wait for user selection
        if (
          promotionResult.hasChoiceGifts &&
          promotionResult.choiceGiftItems.length > 0
        ) {
          // Store the promotion result for later use, but with processed auto gifts
          const updatedPromotionResult = {
            ...promotionResult,
            autoGiftItems: processedAutoGiftItems,
          };
          setPendingPromotionResult(updatedPromotionResult);
          setPendingGiftChoices(promotionResult.choiceGiftItems);
          setIsWaitingForGiftSelection(true);
          setPendingPaymentMode("multiple"); // Set payment mode for multiple payment

          // Show the first gift selection modal
          const firstChoice = promotionResult.choiceGiftItems[0];
          if (firstChoice) {
            setAvailableGifts(firstChoice.giftProducts);
            setPromotionData({
              name: firstChoice.promotionName,
              id: firstChoice.promotionId,
            });
            setIsGiftSelectionOpen(true);
          }
          return; // Stop here and wait for user selection
        } else {
          noteGiftModal.current = "";
        }

        // If no choice gifts, proceed with auto gifts and discounts
        const paymentCartItems = [
          ...promotionResult.discountAppliedItems,
          ...processedAutoGiftItems,
        ];

        // Set the cart items and total for the multiple payment modal
        setMultiplePaymentCartItems(paymentCartItems);

        // Calculate the total after discount for the payment modal
        const totalAfterPromotion = paymentCartItems.reduce(
          (acc, item) =>
            acc + (item.thanhTienSauCK ?? item.price * item.quantity),
          0,
        );
        setMultiplePaymentTotalAfterDiscount(totalAfterPromotion);
      } else {
        // No promotions, use the original cart items
        setMultiplePaymentCartItems([...cartItems]);
        setMultiplePaymentTotalAfterDiscount(totalAfterDiscount);
      }
    } catch (error) {
      setIsLoading(false);
      console.error("Error checking promotions:", error);
      // Continue with original cart if promotion check fails
      await alert({
        title: "Thông báo",
        content: "Không thể kiểm tra khuyến mãi. Tiếp tục với đơn hàng gốc.",
      });

      // Use original cart items if promotion check fails
      setMultiplePaymentCartItems([...cartItems]);
      setMultiplePaymentTotalAfterDiscount(totalAfterDiscount);
    }

    if (hasPermission(PermissionEnum.STORE_ACTIVATE_VOUCHER)) {
      // TODO: Check for voucher validation
    }
    // Open the multi-payment modal with all needed data
    setIsMultiplePaymentsOpen(true);
  };
  const validateCartItems = async () => {
    // Validate that there are items in the cart
    if (!cartItems.length) {
      await alert({
        title: CANH_BAO,
        content: "Giỏ hàng trống. Vui lòng thêm sản phẩm trước.",
      });
      return false;
    }

    // Validate quantities are > 0
    const hasInvalidQuantity = cartItems.some(
      (item) => !item.quantity || item.quantity <= 0,
    );
    if (hasInvalidQuantity) {
      await alert({
        title: CANH_BAO,
        content: "Số lượng sản phẩm phải lớn hơn 0, vui lòng kiểm tra lại!",
      });
      return false;
    }

    // Validate serials if needed (would need additional logic)
    return true;
  };

  const handleChangeQuantity = (item: CartItem, quantity: number) => {
    const thanhTienTruocCK = item.price * quantity;
    const thanhTienSauCK = item.price * quantity;

    setCartItems((prev) => {
      if (!prev.some((x) => x.id === item.id)) return prev;
      return prev.map((x) =>
        x.id === item.id
          ? {
              ...x,
              quantity,
              thanhTienTruocCK,
              discountPercent: 0,
              discount: 0,
              thanhTienSauCK,
              reason: "",
            }
          : resetDiscount(x),
      );
    });
  };

  const handleChangeDiscount = (
    item: CartItem,
    percent: number,
    discountPrice: number,
    reason: string,
  ) => {
    const discountPercent = Number(percent || "0.0");
    const discountUpdate =
      discountPercent > 0
        ? (item.price * item.quantity * Number(discountPercent)) / 100
        : discountPrice || 0;
    const thanhTienSauCK = item.price * item.quantity - discountUpdate;

    setCartItems((prev) => {
      if (!prev.some((x) => x.id === item.id)) return prev;
      return prev.map((x) =>
        x.id === item.id
          ? {
              ...x,
              discountPercent: discountPercent || 0,
              discount: discountUpdate,
              thanhTienSauCK,
              reason: discountUpdate ? reason : "",
            }
          : x,
      );
    });
  };

  const handleApplyDiscount = (discountVal: string, discountPrice: string) => {
    setDiscount(discountVal);
    const updated = calcTotalOrderDiscount(
      cartItems,
      discountVal,
      discountPrice,
      true,
    );
    setCartItems(updated);
    calculateTotals();
  };

  const resetDiscount = (item: CartItem) => {
    if (item.name === SHIPPING_SERVICE_NAME) return item;
    return {
      ...item,
      discountPercent: 0,
      discount: 0,
      thanhTienSauCK: item.price * item.quantity,
      reason: "",
    };
  };

  const resetDiscounts = (carts: CartItem[], serviceName: string) => {
    if (serviceName === SHIPPING_SERVICE_NAME) {
      setCartItems(carts);
      return;
    }
    setDiscount("");
    const updated = carts.map((item) => resetDiscount(item));
    setCartItems(updated);
  };

  const handleConfirmGifts = async (selectedGifts: any[], note: string) => {
    if (!promotionData || !pendingPromotionResult) return;

    // Get the products available in the store
    const currentAvailableProducts = await getAllStoreProducts(
      facId,
      selectedShopTypeId,
    );

    // Filter products to remove duplicates by productID, keeping the one with earliest expDate
    const uniqueProductsByExpDate = currentAvailableProducts.reduce(
      (acc, product) => {
        const existingProduct = acc.find(
          (p) => p.productID === product.productID,
        );
        if (!existingProduct) {
          acc.push(product);
        } else {
          // Keep the product with earliest expDate
          if (new Date(product.expDate) < new Date(existingProduct.expDate)) {
            const index = acc.findIndex(
              (p) => p.productID === product.productID,
            );
            acc[index] = product;
          }
        }
        return acc;
      },
      [] as typeof currentAvailableProducts,
    );

    // Create gift cart items but don't add to visible cart
    const giftCartItems: CartItem[] = [];

    for (const gift of selectedGifts) {
      // First try to find the product with earliest expDate
      let selectedProduct = uniqueProductsByExpDate.find(
        (product) => gift.giftProductId === product.productID.toString(),
      );

      if (selectedProduct) {
        let remainingQuantity = gift.quantity;

        // Check if the required quantity exceeds available quantity
        if (remainingQuantity > selectedProduct.qty) {
          // Add what we can from the first product
          if (selectedProduct.qty > 0) {
            giftCartItems.push(
              createGiftCartItem(
                {
                  giftProductId: selectedProduct.productID.toString(),
                  giftProductName: selectedProduct.productName,
                  quantity: selectedProduct.qty,
                  giftProductCode: selectedProduct.hospitalCode,
                },
                promotionData.name,
                selectedProduct.stockID,
                selectedProduct.stockName,
                selectedProduct.batch,
                selectedProduct.expDate,
              ),
            );
            remainingQuantity -= selectedProduct.qty;
          }

          // Find additional products with same productID but different batch
          const additionalProducts = currentAvailableProducts
            .filter(
              (product) =>
                product.productID.toString() === gift.giftProductId &&
                product.batch !== selectedProduct.batch &&
                product.qty > 0,
            )
            .sort(
              (a, b) =>
                new Date(a.expDate).getTime() - new Date(b.expDate).getTime(),
            ); // Sort by expDate

          // Use additional products to fulfill remaining quantity
          for (const additionalProduct of additionalProducts) {
            if (remainingQuantity <= 0) break;

            const quantityToUse = Math.min(
              remainingQuantity,
              additionalProduct.qty,
            );
            giftCartItems.push(
              createGiftCartItem(
                {
                  giftProductId: additionalProduct.productID.toString(),
                  giftProductName: additionalProduct.productName,
                  quantity: quantityToUse,
                  giftProductCode: additionalProduct.hospitalCode,
                },
                promotionData.name,
                additionalProduct.stockID,
                additionalProduct.stockName,
                additionalProduct.batch,
                additionalProduct.expDate,
              ),
            );
            remainingQuantity -= quantityToUse;
          }
        } else {
          // Normal case: required quantity is available in the selected product
          giftCartItems.push(
            createGiftCartItem(
              {
                giftProductId: selectedProduct.productID.toString(),
                giftProductName: selectedProduct.productName,
                quantity: gift.quantity,
                giftProductCode: selectedProduct.hospitalCode,
              },
              promotionData.name,
              selectedProduct.stockID,
              selectedProduct.stockName,
              selectedProduct.batch,
              selectedProduct.expDate,
            ),
          );
        }
      }
    }

    // Store selected gifts separately instead of adding to visible cart
    setSelectedChoiceGifts((prev) => [...prev, ...giftCartItems]);

    // Remove this choice from pending list
    const remainingChoices = pendingGiftChoices.slice(1);
    setPendingGiftChoices(remainingChoices);

    // Show next choice if any
    if (remainingChoices.length > 0) {
      const nextChoice = remainingChoices[0];
      if (nextChoice) {
        setAvailableGifts(nextChoice.giftProducts);
        setPromotionData({
          name: nextChoice.promotionName,
          id: nextChoice.promotionId,
        });
        // Keep modal open for next choice
        return;
      }
    }

    // All gift selections are complete - close modal and continue with payment
    setIsGiftSelectionOpen(false);
    setPromotionData(null);
    setIsWaitingForGiftSelection(false);

    utils.notifySuccess(
      `Đã chọn ${selectedGifts.length} quà tặng cho thanh toán`,
    );

    // Now proceed with payment based on the pending payment mode
    try {
      // Combine all items for payment: discounted items + auto gifts + selected choice gifts
      const paymentCartItems = [
        ...pendingPromotionResult.discountAppliedItems,
        ...pendingPromotionResult.autoGiftItems,
        ...selectedChoiceGifts,
        ...giftCartItems, // Add current selection
      ];

      // Show promotion applied message if there's a discount
      if (pendingPromotionResult.totalDiscountAmount > 0) {
        notifySuccess(
          `Đã áp dụng khuyến mãi với tổng giảm giá: ${utils.formatCurrencyVND(pendingPromotionResult.totalDiscountAmount, 0)}`,
        );
      }

      // Check payment mode and proceed accordingly
      if (pendingPaymentMode === "multiple") {
        // Set the cart items and total for the multiple payment modal
        setMultiplePaymentCartItems(paymentCartItems);

        // Calculate the total after discount for the payment modal
        const totalAfterPromotion = paymentCartItems.reduce(
          (acc, item) =>
            acc + (item.thanhTienSauCK ?? item.price * item.quantity),
          0,
        );
        setMultiplePaymentTotalAfterDiscount(totalAfterPromotion);

        // Open the multi-payment modal
        setIsMultiplePaymentsOpen(true);
      } else {
        // Single payment mode - proceed with single payment flow
        const giftPolicyResult = await validateGiftPolicies();
        if (!giftPolicyResult.isValid) {
          return;
        }

        // Continue with single payment processing
        await processPaymentView(
          qaPayCardNumberRef.current || "", // qaPayCardNumber - empty for now, could be passed if needed
          giftPolicyResult.invoiceId,
          giftPolicyResult.contractId,
          giftPolicyResult.isBLTangKem,
          paymentCartItems,
          note,
        );
      }

      // Clear pending promotion data after successful processing
      setPendingPromotionResult(null);
      setPendingGiftChoices([]);
      setSelectedChoiceGifts([]);
      setPendingPaymentMode(null);
    } catch (error) {
      console.error("Error continuing payment after gift selection:", error);
      await alert({
        title: "Lỗi",
        content: "Có lỗi xảy ra khi tiếp tục thanh toán. Vui lòng thử lại.",
      });

      // Reset states on error
      setPendingPromotionResult(null);
      setPendingGiftChoices([]);
      setSelectedChoiceGifts([]);
      setIsWaitingForGiftSelection(false);
      setPendingPaymentMode(null);
    }
  };

  const handleGiftSkipConfirm = async (note: string) => {
    const paymentCartItems = [
      ...pendingPromotionResult.discountAppliedItems,
      ...pendingPromotionResult.autoGiftItems,
      ...selectedChoiceGifts,
    ];

    if (pendingPaymentMode === "multiple") {
      // Set the cart items and total for the multiple payment modal
      setMultiplePaymentCartItems(paymentCartItems);

      // Calculate the total after discount for the payment modal
      const totalAfterPromotion = paymentCartItems.reduce(
        (acc, item) =>
          acc + (item.thanhTienSauCK ?? item.price * item.quantity),
        0,
      );
      setMultiplePaymentTotalAfterDiscount(totalAfterPromotion);

      // Open the multi-payment modal
      setIsMultiplePaymentsOpen(true);
    } else {
      const giftPolicyResult = await validateGiftPolicies();
      if (!giftPolicyResult.isValid) {
        return;
      }
      // Continue with single payment processing
      await processPaymentView(
        qaPayCardNumberRef.current || "",
        giftPolicyResult.invoiceId,
        giftPolicyResult.contractId,
        giftPolicyResult.isBLTangKem,
        paymentCartItems,
        note,
      );
    }
  };

  const handleNotes = () => {
    return (
      (!!billNoteRef.current ? billNoteRef.current + ";" : "") +
      (!!missingProductNotes.current ? missingProductNotes.current + ";" : "") +
      noteGiftModal.current
    );
  };

  return (
    <div className="flex h-full overflow-hidden">
      {isLoading && <LoadingUI />}
      {/* Left Panel */}
      <ResizablePanelGroup direction="horizontal">
        <ResizablePanel defaultSize={60}>
          <ProductSearchPanel
            counter={counter}
            setIsCounterModalOpen={setIsCounterModalOpen}
            selectedStoreWorkShift={selectedStoreWorkShift}
            handleCreateNewCart={handleCreateNewCart}
            isPaid={isPaid}
            facId={facId}
            selectedShopTypeId={selectedShopTypeId}
            onAddToCart={handleAddToCart}
            setIsLoading={setIsLoading}
            clearNote={(note: string) => {
              billNoteRef.current = note;
              noteGiftModal.current = note;
              missingProductNotes.current = note;
            }}
          />
        </ResizablePanel>
        <ResizableHandle withHandle />
        <ResizablePanel defaultSize={40}>
          {/* Right Panel - Customer Info, Cart, Payment */}
          <CustomerCartPanel
            cartItems={cartItems}
            handleChangeQuantity={handleChangeQuantity}
            handleChangeDiscount={handleChangeDiscount}
            onRemoveFromCart={handleRemoveFromCart}
            totalBeforeDiscount={totalBeforeDiscount}
            totalAfterDiscount={totalAfterDiscount}
            isPaid={isPaid}
            paymentMethods={paymentMethods}
            user={user}
            facId={facId}
            billNoteValue={billNoteRef.current}
            isCustomerDataSet={isCustomerDataSet}
            setIsCustomerDataSet={setIsCustomerDataSet}
            onHandleViewReceipt={handleViewReceipt}
            onApplyDiscount={handleApplyDiscount}
            setIsLoading={setIsLoading}
            customerId={customerId}
            setCustomerId={setCustomerId}
            customerHospitalId={customerHospitalId}
            setCustomerHospitalId={setCustomerHospitalId}
            setCustomerData={setCustomerInfo}
            paymentMethod={paymentMethod}
            setPaymentMethod={setPaymentMethod}
            onHandleMultiplePayments={handleMultiplePayments}
            onResetBillStates={(fn) => (resetBillStatesFnRef.current = fn)}
            billNumber={receiptNumber}
            setBillNumber={setReceiptNumber}
            customerPhone={customerPhone}
            setCustomerPhone={setCustomerPhone}
            customerEmail={customerEmail}
            setCustomerEmail={setCustomerEmail}
            setCardCodeValue={(cardCodeValue: string) => {
              cardCodeRef.current = cardCodeValue;
            }}
            setBillNoteValue={(billNoteValue: string) => {
              billNoteRef.current = billNoteValue;
            }}
            isPrintOpening={isPrintOpening}
            setIsPrintOpening={setIsPrintOpening}
            onAddToCart={handleAddToCart}
          />

          <QAPayCheckCardNumber
            isOpen={isQAPayCheckCardNumberOpen}
            onConfirm={async (cardInfo: CardOwner | null) => {
              if (cardInfo) {
                await handleViewReceipt(cardInfo.mathe || "");
              }
              setIsQAPayCheckCardNumberOpen(false);
            }}
          />

          <MultiPaymentModal
            open={isMultiplePaymentsOpen}
            onOpenChange={(isPaid: boolean) => {
              setIsMultiplePaymentsOpen(false);
              setIsPaid(isPaid);
            }}
            cartItems={multiplePaymentCartItems}
            initialInvoiceData={
              multiplePaymentCartItems.length > 0 ? cartItems : undefined
            }
            totalAmount={multiplePaymentTotalAfterDiscount}
            selectedCounter={selectedCounter}
            selectedStoreWorkShift={selectedStoreWorkShift}
            invoiceParams={{
              customerId: customerInfo.id,
              customerName: customerInfo.name,
              customerAddress: customerInfo.address,
              customerPhone: customerPhone,
              customerGender: customerInfo.gender,
              customerBirthYear: customerInfo.birthYear,
              facId,
              counterId: selectedCounter?.counterID.toString() || "",
              shiftDailyId: selectedStoreWorkShift?.shiftDailyId || "",
              shiftName: selectedStoreWorkShift?.shiftName || "",
              paymentMethodName: paymentMethods.find(
                (x) => x.id.toString() === paymentMethod,
              )?.ten,
              note: handleNotes(),
              stockId: multiplePaymentCartItems[0]?.stockId,
              stockName: multiplePaymentCartItems[0]?.stockName || "",
              email: customerEmail,
            }}
            isPrintOpening={isPrintOpening}
            setIsPrintOpening={setIsPrintOpening}
            loadPurchasedItems={loadPurchasedItems}
          />

          <GiftSelectionModal
            isOpen={isGiftSelectionOpen}
            onClose={() => setIsGiftSelectionOpen(false)}
            onConfirm={handleConfirmGifts}
            giftProducts={availableGifts}
            promotionName={promotionData?.name || ""}
            billNote={billNoteRef.current || ""}
            missingProductNotes={missingProductNotes.current || ""}
            onGiftSkipConfirm={handleGiftSkipConfirm}
            noteGiftModal={noteGiftModal.current ?? ""}
            setNoteGiftModal={(note: string) => {
              noteGiftModal.current = note;
            }}
          />
        </ResizablePanel>
      </ResizablePanelGroup>
    </div>
  );
}
