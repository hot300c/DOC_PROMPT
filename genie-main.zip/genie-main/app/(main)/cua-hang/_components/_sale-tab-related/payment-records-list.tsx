"use client";
import { Card, CardContent } from "@/components/ui/card";
import { DataTable } from "@/components/ui/dataTable";
import { ColumnDef } from "@tanstack/react-table";

interface PaymentRecord {
  id: string;
  paymentMethodId: string;
  paymentMethodName: string;
  amount: number;
  cardNumber?: string;
  voucherCode?: string;
  totalAmount: number;
  invoiceId?: string;
  invoiceHinhThucThanhToanId?: string;
  isPrinted: boolean;
}

interface PaymentRecordsListProps {
  paymentRecords: PaymentRecord[];
  columns: ColumnDef<PaymentRecord>[];
}

export function PaymentRecordsList({
  paymentRecords,
  columns,
}: PaymentRecordsListProps) {
  return (
    <Card className="shadow-sm">
      <CardContent className="p-0">
        <div className="font-semibold text-lg p-4 pb-2 grid grid-cols-2 items-center">
          <div>Danh sách thanh toán</div>
        </div>
        {paymentRecords.length > 0 ? (
          <div>
            <DataTable
              columns={columns}
              data={paymentRecords}
              className="w-full border"
              enableColumnFilter={false}
              enablePaging={false}
              enableToggleColumn={false}
              enableGrouping={false}
              enableGlobalFilter={false}
            />
          </div>
        ) : (
          <div className="text-center py-4 text-muted-foreground">
            Chưa có thanh toán nào được thêm
          </div>
        )}
      </CardContent>
    </Card>
  );
}
