import { checkBillInvoice } from "@/app/(main)/cua-hang/_action/check-bill-invoice";
import CustomerTableModal from "@/app/(main)/cua-hang/_components/_sale-tab-related/customer-table-modal";
import NewCustomerModal from "@/app/(main)/cua-hang/_components/new-customer-modal";
import { CustomerModel } from "@/app/(main)/cua-hang/_models/customer-model";
import { ConfigPosModal } from "@/app/(main)/thanh-toan/_components/config-pos/config-pos-modal";
import QAPayCheckCardNumber from "@/app/(main)/thanh-toan/_components/qa-pay/check-card/qa-pay-check-card-number";
import { CardOwner } from "@/app/(main)/thanh-toan/_utils/definitions/api";
import { PaymentType } from "@/app/lib/definitions/setting";
import {
  CANH_BAO,
  DATE_FORMAT,
  LocalStoragePersistKeys,
  RecordingSessionType,
} from "@/app/lib/enums";
import { useFeedbackDialog } from "@/app/lib/feedback-dialog-provider";
import { fetchEmployeeByUserId } from "@/app/lib/services/admissionParameterServices";
import { notifyError, startRecording } from "@/app/lib/utils";
import { format } from "date-fns";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  getCustomerInfoById,
  getCustomerInfoByPhoneNumber,
} from "../../_action/get-customer-info";
import { CartItem } from "../../_models/cart-model";
import { CartItemsTable } from "./cart-item-table";
import { CustomerInfoCard } from "./customer-info-card";
import { PaymentInfoCard } from "./payment-info-cart";

interface CustomerCartPanelProps {
  cartItems: CartItem[];
  onRemoveFromCart: (idx: number) => void;
  totalBeforeDiscount: number;
  totalAfterDiscount: number;
  isPaid: boolean;
  paymentMethods: PaymentType[];
  user: { name: string; userId: string };
  facId: string;
  billNoteValue: string;
  onHandleViewReceipt: (cardNumber: string) => void;
  onApplyDiscount: (discountValue: string, discountPrice: string) => void;
  setIsLoading: (loading: boolean) => void;
  isCustomerDataSet: boolean;
  setIsCustomerDataSet: (isCustomerDataSet: boolean) => void;
  customerId: string;
  setCustomerId: (customerId: string) => void;
  customerHospitalId: string;
  setCustomerHospitalId: (customerHospitalId: string) => void;
  setCustomerData: (customerData: {
    name: string;
    gender: string;
    birthYear: string;
    tier: number;
    address: string;
    employeeId: string;
    customerTypeId: number | undefined;
    id: string;
  }) => void;
  paymentMethod: string;
  setPaymentMethod: (paymentMethod: string) => void;
  onHandleMultiplePayments: () => void;
  onResetBillStates: (resetBillStates: () => void) => void;
  customerPhone: string;
  setCustomerPhone: (phone: string) => void;
  customerEmail: string;
  setCustomerEmail: (email: string) => void;
  billNumber: string;
  setBillNumber: (billNumber: string) => void;
  setCardCodeValue: (cardCode: string) => void;
  setBillNoteValue: (billNote: string) => void;
  handleChangeQuantity: (item: CartItem, quantity: number) => void;
  handleChangeDiscount: (
    item: CartItem,
    percent: number,
    discount: number,
    reason: string,
  ) => void;
  isPrintOpening: boolean;
  setIsPrintOpening: (isPrintOpening: boolean) => void;
  onAddToCart: (newItem: CartItem) => Promise<void>;
}

export function CustomerCartPanel({
  cartItems,
  onRemoveFromCart,
  totalBeforeDiscount,
  totalAfterDiscount,
  isPaid,
  paymentMethods,
  user,
  facId,
  billNoteValue,
  onHandleViewReceipt,
  onHandleMultiplePayments,
  onApplyDiscount,
  setIsLoading,
  isCustomerDataSet,
  setIsCustomerDataSet,
  customerId,
  setCustomerId,
  customerHospitalId,
  setCustomerHospitalId,
  setCustomerData,
  paymentMethod,
  setPaymentMethod,
  onResetBillStates,
  billNumber,
  setBillNumber,
  setBillNoteValue,
  setCardCodeValue,
  handleChangeQuantity,
  handleChangeDiscount,
  customerPhone,
  setCustomerPhone,
  customerEmail,
  setCustomerEmail,
  isPrintOpening,
  setIsPrintOpening,
  onAddToCart,
}: CustomerCartPanelProps) {
  // State management
  const [customerInfo, setCustomerInfo] = useState({
    name: "...",
    gender: "...",
    birthYear: "...",
    address: "...",
    customerTypeId: undefined as number | undefined,
    employeeId: "",
    id: "",
    tier: 3, // Add missing tier property
  });
  const [discount, setDiscount] = useState("");
  const [cardCode, setCardCode] = useState("");
  const [billNote, setBillNote] = useState(billNoteValue);
  const [isQAPayCheckCardNumberOpen, setIsQAPayCheckCardNumberOpen] =
    useState(false);
  const [isNewCustomerModalOpenned, setIsNewCustomerModalOpened] =
    useState<boolean>(false);
  const [billDate, setBillDate] = useState<string>("");
  const [contractNumber, setContractNumber] = useState<string>("");
  const [isPosConfigModalOpened, setIsPosConfigModalOpened] = useState(false);
  const [isValidCardNumber, setIsValidCardNumber] = useState(true);
  const { alert } = useFeedbackDialog();
  const employeeRef = useRef(user?.userId || "");

  useEffect(() => {
    const fetchEmployeeDetails = async () => {
      try {
        const employeeDetails = await fetchEmployeeByUserId(user?.userId || "");
        if (employeeDetails) {
          employeeRef.current = employeeDetails.employeeCode || "";
        }
      } catch (error) {
        console.error("Error fetching employee details:", error);
      }
    };

    void fetchEmployeeDetails();
  }, [user?.userId]);

  const startRecordingSession = useCallback(
    async (hospitalId: string, fullName: string) => {
      try {
        // Request args for TIEP_NHAN includes: patientHospitalID, fullName, employeeCode, userName, recordingSessionType
        const requestArgs = `"${hospitalId}" "${fullName}" "${employeeRef.current ?? ""}" "${user.name}" "${RecordingSessionType.TIEP_NHAN}"`;

        // Start recording session
        const result = await startRecording(requestArgs);
        if (result) {
          // Save the recording session to local storage
          localStorage.setItem(
            LocalStoragePersistKeys.RecordingSession,
            requestArgs,
          );
        }
      } catch (error) {
        console.error("Error starting recording session:", error);
        notifyError("Không thể bắt đầu phiên ghi âm.");
      }
    },
    [user.name],
  );

  const resetBillStates = useCallback(() => {
    setBillNumber("");
    setBillNote("");
    setBillDate("");
    setContractNumber("");
    setCardCode("");
  }, [setBillNumber]);

  useEffect(() => {
    if (!customerId) {
      setCustomerPhone("");
      setCustomerEmail("");
      setCustomerInfo({
        name: "...",
        gender: "...",
        birthYear: "...",
        address: "...",
        customerTypeId: undefined,
        employeeId: "",
        id: "",
        tier: 3, // Add missing tier property
      });
      setCustomerData({
        tier: 3, // Default tier for new customers
        name: "...",
        gender: "...",
        birthYear: "...",
        address: "...",
        customerTypeId: undefined,
        employeeId: "",
        id: "",
      });
      setDiscount("");
      setCardCode("");
      if (paymentMethods.length > 0) {
        setPaymentMethod(paymentMethods[0]!.id.toString());
      }
    }
  }, [
    paymentMethods,
    setCustomerData,
    setPaymentMethod,
    customerId,
    setCustomerPhone,
    setCustomerEmail,
  ]);

  // Add these to the CustomerCartPanel component
  const [customerResults, setCustomerResults] = useState<CustomerModel[]>([]);
  const [isCustomerTableModalOpen, setIsCustomerTableModalOpen] =
    useState(false);

  const handleSelectCustomer = useCallback(
    async (customer: CustomerModel) => {
      setCustomerId(customer.patientID);
      setCustomerInfo({
        name: customer.fullName,
        gender: customer.gioiTinh,
        birthYear: customer.ngaySinh,
        address: customer.diaChi,
        id: customer.patientID,
        customerTypeId: undefined,
        employeeId: customer.maNhanVien,
        tier: customer.tier, // Add missing tier property
      });
      setCustomerData({
        tier: customer.tier,
        name: customer.fullName,
        gender: customer.gioiTinh,
        birthYear: customer.ngaySinh,
        address: customer.diaChi,
        customerTypeId: undefined,
        employeeId: customer.maNhanVien,
        id: customer.patientID,
      });
      setCustomerHospitalId(customer.patientHospitalID);
      setCustomerEmail(customer.email);
      setIsCustomerDataSet(true);
      setIsCustomerTableModalOpen(false);

      void startRecordingSession(customer.patientHospitalID, customer.fullName);
    },
    [
      setCustomerId,
      setCustomerData,
      setCustomerHospitalId,
      setCustomerEmail,
      setIsCustomerDataSet,
      startRecordingSession,
    ],
  );

  useEffect(() => {
    if (onResetBillStates) {
      onResetBillStates(resetBillStates);
    }
  }, [onResetBillStates, resetBillStates]);

  useEffect(() => {
    const cardNumberRequiredMethods = ["1", "3", "5", "12"];
    if (cardNumberRequiredMethods.includes(paymentMethod)) {
      setIsValidCardNumber(cardCode.length > 0);
    } else {
      setIsValidCardNumber(true);
    }
  }, [cardCode, paymentMethod]);

  // Customer Search
  const searchCustomerById = useCallback(
    async (cusId: string) => {
      setIsLoading(true);
      try {
        const customer = await getCustomerInfoById(cusId);
        if (customer) {
          setCustomerId(customer.patientID);
          setIsCustomerDataSet(true);
          return {
            customerId: customer.patientHospitalID,
            name: customer.fullName,
            gender: customer.genderText,
            birthYear: format(
              new Date(customer.doB),
              DATE_FORMAT.DD_MM_YYYY_VI,
            ),
            address: customer.diaChi,
            tier: customer.tier,
            phone: customer.usePhoneNumber,
            patientId: customer.patientID,
            email: customer.email,
            employeeId: customer.maNhanVien,
          };
        }
        return null;
      } catch (error) {
        console.error("Error searching by ID:", error);
        return null;
      } finally {
        setIsLoading(false);
      }
    },
    [setCustomerId, setIsCustomerDataSet, setIsLoading],
  );

  const searchCustomerByPhone = useCallback(
    async (phone: string) => {
      setIsLoading(true);
      try {
        return await getCustomerInfoByPhoneNumber(phone, facId);
      } catch (error) {
        console.error("Error searching by phone:", error);
        return null;
      } finally {
        setIsLoading(false);
      }
    },
    [facId, setIsLoading],
  );

  const btnSearchSDT_ButtonClick = useCallback(async () => {
    if (!customerPhone.trim()) {
      notifyError("Vui lòng nhập số điện thoại");
      return;
    }
    const customers = await searchCustomerByPhone(customerPhone);
    if (customers && customers.length === 1) {
      const cusResult = customers[0]!;
      setCustomerId(cusResult.patientID);
      setIsCustomerDataSet(true);
      setCustomerInfo({
        name: cusResult.fullName,
        gender: cusResult.gioiTinh,
        birthYear: cusResult.ngaySinh,
        address: cusResult.diaChi,
        id: cusResult.patientID,
        customerTypeId: undefined,
        employeeId: cusResult.maNhanVien,
        tier: cusResult.tier, // Add missing tier property
      });
      setCustomerData({
        name: cusResult.fullName,
        gender: cusResult.gioiTinh,
        birthYear: cusResult.ngaySinh,
        tier: cusResult.tier,
        address: cusResult.diaChi,
        customerTypeId: undefined,
        employeeId: cusResult.maNhanVien,
        id: cusResult.patientID,
      });
      setCustomerHospitalId(cusResult.patientHospitalID);

      void startRecordingSession(
        cusResult.patientHospitalID,
        cusResult.fullName,
      );
    } else if (customers && customers.length > 1) {
      setCustomerResults(customers);
      setIsCustomerTableModalOpen(true);
    } else {
      setCustomerInfo({
        name: "...",
        gender: "...",
        birthYear: "...",
        address: "...",
        id: "",
        customerTypeId: undefined,
        employeeId: "",
        tier: 3, // Add missing tier property
      });
      setCustomerData({
        name: "...",
        gender: "...",
        tier: 3,
        birthYear: "...",
        customerTypeId: undefined,
        employeeId: "",
        address: "...",
        id: "",
      });
      setCustomerHospitalId("");
      await alert({
        title: CANH_BAO,
        content: `Không tìm thấy khách hàng với số điện thoại ${customerPhone}`,
      });
    }
  }, [
    alert,
    customerPhone,
    searchCustomerByPhone,
    setCustomerData,
    setCustomerHospitalId,
    setCustomerId,
    setIsCustomerDataSet,
    startRecordingSession,
  ]);

  const btnSearchMaKH_ButtonClick = useCallback(async () => {
    if (!customerHospitalId.trim()) {
      notifyError("Vui lòng nhập mã khách hàng");
      return;
    }
    const customer = await searchCustomerById(customerHospitalId);
    if (customer) {
      setCustomerInfo({
        name: customer.name,
        gender: customer.gender,
        birthYear: customer.birthYear,
        address: customer.address,
        id: customer.patientId,
        customerTypeId: undefined,
        employeeId: customer.employeeId,
        tier: customer.tier, // Add missing tier property
      });
      setCustomerData({
        name: customer.name,
        tier: customer.tier,
        gender: customer.gender,
        birthYear: customer.birthYear,
        address: customer.address,
        customerTypeId: undefined,
        employeeId: customer.employeeId,
        id: customer.patientId,
      });
      setCustomerPhone(customer.phone);
      setCustomerEmail(customer.email);
      void startRecordingSession(customer.customerId, customer.name);
    } else {
      notifyError(`Không tìm thấy khách hàng với mã ${customerHospitalId}`);
      setCustomerInfo({
        name: "...",
        gender: "...",
        birthYear: "...",
        address: "...",
        id: "",
        customerTypeId: undefined,
        employeeId: "",
        tier: 3, // Add missing tier property
      });
      setCustomerData({
        name: "...",
        gender: "...",
        tier: 3,
        birthYear: "...",
        customerTypeId: undefined,
        employeeId: "",
        address: "...",
        id: "",
      });
    }
  }, [
    customerHospitalId,
    searchCustomerById,
    setCustomerData,
    setCustomerEmail,
    setCustomerPhone,
    startRecordingSession,
  ]);

  const handleAddCustomer = async () => {
    setIsNewCustomerModalOpened(true);
  };

  const handleConfigPos = async () => {
    setIsPosConfigModalOpened(true);
  };

  const handleBillNumberBlur = async () => {
    if (billNumber.length > 0) {
      const billData = await checkBillInvoice(facId, billNumber);
      if (billData) {
        setBillDate(
          format(billData.paymentDate || new Date(), DATE_FORMAT.DD_MM_YYYY_VI),
        );
        setContractNumber(billData.contractNumber || "");
      } else {
        setBillDate("");
        setContractNumber("");
      }
    } else {
      setBillDate("");
      setContractNumber("");
    }
  };

  const handleViewReceipt = (cardValue: string) => {
    if (paymentMethod === "6") {
      setIsQAPayCheckCardNumberOpen(true);
    } else {
      onHandleViewReceipt(cardValue || cardCode);
    }
  };

  const handleSaveNewCustomer = async (newCustomer: any) => {
    try {
      setIsLoading(true);

      setCustomerInfo({
        name: newCustomer.fullName,
        gender: newCustomer.genderText,
        birthYear: format(newCustomer.birthDate, DATE_FORMAT.DD_MM_YYYY_VI),
        address: newCustomer.address,
        id: newCustomer.id,
        customerTypeId: undefined,
        employeeId: "",
        tier: 3, // Add missing tier property
      });

      setCustomerData({
        tier: 3, // Default tier for new customers
        name: newCustomer.fullName,
        gender: newCustomer.genderText,
        birthYear: format(newCustomer.birthDate, DATE_FORMAT.DD_MM_YYYY_VI),
        address: newCustomer.address,
        customerTypeId: undefined,
        employeeId: "",
        id: newCustomer.id,
      });

      setCustomerHospitalId(newCustomer.patientId);
      setCustomerPhone(newCustomer.phone);
      setCustomerEmail(newCustomer.email);
      setCustomerId(newCustomer.id);
      setIsNewCustomerModalOpened(false);
      setIsCustomerDataSet(true);

      if (newCustomer.patientId) {
        void startRecordingSession(newCustomer.patientId, newCustomer.name);
      } else {
        void startRecordingSession("", "Khách lẻ");
      }
    } catch (error) {
      console.error("Error saving customer:", error);
      notifyError("Không thể lưu thông tin khách hàng.");
    } finally {
      setIsLoading(false);
    }
  };

  const filteredPaymentMethods = useMemo(() => {
    const unsupportedMethods = ["7", "10", "11", "13"];
    return paymentMethods.filter(
      (method) => !unsupportedMethods.includes(method.id.toString()),
    );
  }, [paymentMethods]);

  const handleEmployeeIdChange = useCallback(
    (employeeId: string) => {
      setCustomerInfo((prev) => ({
        ...prev,
        employeeId: employeeId,
      }));

      // Also update the parent component's customer data
      setCustomerData({
        name: customerInfo.name,
        gender: customerInfo.gender,
        birthYear: customerInfo.birthYear,
        tier: customerInfo.tier || 3,
        address: customerInfo.address,
        employeeId: employeeId,
        customerTypeId: customerInfo.customerTypeId,
        id: customerInfo.id,
      });
    },
    [setCustomerData, customerInfo],
  );

  const handleCustomerTypeChange = useCallback(
    (customerTypeId: number, _customerTypeName: string) => {
      setCustomerInfo((prev) => ({
        ...prev,
        customerTypeId: customerTypeId,
      }));

      // Also update the parent component's customer data
      setCustomerData({
        name: customerInfo.name,
        gender: customerInfo.gender,
        birthYear: customerInfo.birthYear,
        tier: customerInfo.tier || 3,
        address: customerInfo.address,
        employeeId: customerInfo.employeeId,
        customerTypeId: customerTypeId,
        id: customerInfo.id,
      });
    },
    [setCustomerData, customerInfo],
  );

  return (
    <div className="w-full p-1 flex flex-col h-full overflow-auto">
      {/* Customer Information */}
      <CustomerInfoCard
        customerHospitalId={customerHospitalId}
        setCustomerHospitalId={setCustomerHospitalId}
        customerPhone={customerPhone}
        setCustomerPhone={setCustomerPhone}
        customerEmail={customerEmail}
        setCustomerEmail={setCustomerEmail}
        customerInfo={customerInfo}
        isPaid={isPaid}
        isCustomerDataSet={isCustomerDataSet}
        handleAddCustomer={handleAddCustomer}
        handleSearchById={btnSearchMaKH_ButtonClick}
        handleSearchByPhone={btnSearchSDT_ButtonClick}
        onEmployeeIdChange={handleEmployeeIdChange}
        onCustomerTypeChange={handleCustomerTypeChange}
      />

      {/* Shopping Cart */}
      <CartItemsTable
        cartItems={cartItems}
        discount={discount}
        setDiscount={setDiscount}
        onRemoveFromCart={onRemoveFromCart}
        isPaid={isPaid}
        handleApplyDiscount={onApplyDiscount}
        handleChangeQuantity={handleChangeQuantity}
        handleChangeDiscount={handleChangeDiscount}
        onAddToCart={onAddToCart}
      />

      {/* Payment Information */}
      <PaymentInfoCard
        totalBeforeDiscount={totalBeforeDiscount}
        totalAfterDiscount={totalAfterDiscount}
        billNumber={billNumber}
        setBillNumber={setBillNumber}
        billNote={billNote}
        setBillNote={setBillNote}
        setBillNoteValue={setBillNoteValue}
        contractNumber={contractNumber}
        billDate={billDate}
        paymentMethod={paymentMethod}
        setPaymentMethod={setPaymentMethod}
        paymentMethods={filteredPaymentMethods}
        cardCode={cardCode}
        setCardCode={setCardCode}
        setCardCodeValue={setCardCodeValue}
        isPaid={isPaid}
        isValidCardNumber={isValidCardNumber}
        handleConfigPos={handleConfigPos}
        handleMultiplePayments={onHandleMultiplePayments}
        handleViewReceipt={handleViewReceipt}
        user={user}
        handleBillNumberBlur={handleBillNumberBlur}
        isPrintOpening={isPrintOpening}
        setIsPrintOpening={setIsPrintOpening}
        facId={facId}
      />

      {/* Modals */}
      <QAPayCheckCardNumber
        isOpen={isQAPayCheckCardNumberOpen}
        onConfirm={(cardInfo: CardOwner | null) => {
          if (cardInfo) {
            onHandleViewReceipt(cardInfo.mathe || "");
          }
          setIsQAPayCheckCardNumberOpen(false);
        }}
      />

      <NewCustomerModal
        open={isNewCustomerModalOpenned}
        onClose={() => setIsNewCustomerModalOpened(false)}
        facId={facId}
        onSave={handleSaveNewCustomer}
      />

      {isPosConfigModalOpened && (
        <ConfigPosModal
          isOpen={isPosConfigModalOpened}
          onClose={() => setIsPosConfigModalOpened(false)}
        />
      )}

      <CustomerTableModal
        isOpen={isCustomerTableModalOpen}
        onClose={() => setIsCustomerTableModalOpen(false)}
        customers={customerResults}
        onSelectCustomer={handleSelectCustomer}
      />
    </div>
  );
}
