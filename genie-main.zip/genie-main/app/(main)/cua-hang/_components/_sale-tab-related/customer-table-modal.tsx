"use client";

import React from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { DataTable } from "@/components/ui/dataTable";
import { CustomerModel } from "../../_models/customer-model";
import { getCustomerColumns } from "../../_utils/sale-tab-table-columns";

interface CustomerTableModalProps {
  isOpen: boolean;
  onClose: () => void;
  customers: CustomerModel[];
  onSelectCustomer: (customer: CustomerModel) => void;
}

export default function CustomerTableModal({
  isOpen,
  onClose,
  customers,
  onSelectCustomer,
}: CustomerTableModalProps) {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-[80vw] max-h-[80vh] flex flex-col">
        <DialogHeader>
          <DialogTitle>Chọn khách hàng</DialogTitle>
        </DialogHeader>
        <div className="flex-1 overflow-y-auto">
          <DataTable
            columns={getCustomerColumns(onSelectCustomer)}
            data={customers}
            className="w-full"
            onRowDoubleClick={onSelectCustomer}
            enableColumnFilter={false}
            enablePaging={false}
            enableToggleColumn
            enableGrouping={false}
            enableGlobalFilter={true}
          />
        </div>
      </DialogContent>
    </Dialog>
  );
}
