import { getAllStoreProducts } from "@/app/(main)/cua-hang/_action/get-store-products";
import { Counter } from "@/app/(main)/cua-hang/_models/counter-model";
import { Product } from "@/app/(main)/cua-hang/_models/product-model";
import { WorkShift } from "@/app/(main)/cua-hang/_models/work-shift-model";
import { getProductColumns } from "@/app/(main)/cua-hang/_utils/sale-tab-table-columns";
import { useFeedbackDialog } from "@/app/lib/feedback-dialog-provider";
import * as utils from "@/app/lib/utils";
import { notifyError } from "@/app/lib/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { DataTable } from "@/components/ui/dataTable";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useKeyboardShortcut } from "@/hooks/use-keyboard-shortcut";
import { debounce, parseInt } from "lodash";
import { useCallback, useEffect, useMemo, useState } from "react";
import useSWR from "swr";
import { CartItem } from "../../_models/cart-model";

interface ProductSearchPanelProps {
  counter: Counter | null;
  setIsCounterModalOpen: (open: boolean) => void;
  selectedStoreWorkShift: WorkShift | null;
  handleCreateNewCart: () => Promise<void>;
  isPaid: boolean;
  facId: string;
  selectedShopTypeId: string;
  onAddToCart: (item: CartItem) => void;
  setIsLoading: (loading: boolean) => void;
  clearNote: (billNote: string) => void;
}

export function ProductSearchPanel({
  counter,
  setIsCounterModalOpen,
  selectedStoreWorkShift,
  handleCreateNewCart,
  isPaid,
  facId,
  selectedShopTypeId,
  onAddToCart,
  setIsLoading,
  clearNote,
}: ProductSearchPanelProps) {
  // State management
  const [searchProduct, setSearchProduct] = useState("");
  const [searchProductByScan, setSearchProductByScan] = useState("");
  const [products, setProducts] = useState<any[]>([]);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [selectedIndex, setSelectedIndex] = useState<number | undefined>();
  const [productQuantity, setProductQuantity] = useState("1");
  const { alert } = useFeedbackDialog();
  // Fetch products
  const { data: listProducts, mutate: mutateProducts } = useSWR(
    facId && selectedShopTypeId
      ? {
          url: "StoreService.getAllStoreProducts",
          payload: {
            facId,
            selectedShopTypeId,
          },
        }
      : [],
    async ({
      payload,
    }: {
      payload: { facId: string; selectedShopTypeId: string };
    }) => {
      setIsLoading(true);
      try {
        return await getAllStoreProducts(
          payload.facId,
          payload.selectedShopTypeId,
        );
      } catch (error) {
        console.error("Error fetching products:", error);
        notifyError("Lỗi khi tải danh sách sản phẩm");
        return [];
      } finally {
        setIsLoading(false);
      }
    },
    {
      onSuccess: (data) => {
        setProducts(data);
        // Set default selected row
        if (data.length > 0) {
          setSelectedProduct(data[0]!);
          setSelectedIndex(0);
        }
      },
    },
  );

  // Search products functionality
  const searchProductByName = useCallback(
    (val: string) => {
      const filtered =
        listProducts?.filter(
          (it) =>
            it.productName.toLowerCase().includes(val.toLowerCase()) ||
            it.hospitalCode.toLowerCase().includes(val.toLowerCase()),
        ) || [];
      setSearchProduct(val);
      setProducts(filtered);
      if (filtered.length > 0) {
        setSelectedProduct(filtered[0]!);
        setSelectedIndex(0);
      }
    },
    [listProducts],
  );

  // Reset on create new cart
  useEffect(() => {
    // Reset on unmount
    return () => {
      setSearchProduct("");
      setProductQuantity("1");
    };
  }, []);

  // Ensure selectedProduct is reset after payment
  useEffect(() => {
    if (isPaid) {
      setProductQuantity("1");
    }
  }, [isPaid]);

  // Function to handle adding to cart
  const handleAddToCart = useCallback(
    async (product: Product) => {
      if (!product || !product.productID) return;
      if (new Date(product.expDate) <= new Date()) {
        await alert({
          title: "Cảnh báo",
          content: "Sản phẩm: " + product.productName + " đã hết HSD",
        });
        return;
      }

      try {
        const newItem: CartItem = {
          id: utils.GUID_NewSequential(),
          productId: product.productID,
          code: product.hospitalCode,
          name: product.productName,
          hangSanXuat: product.hangSanXuat || null,
          price: product.price,
          quantity: parseInt(productQuantity) || 1,
          stockId: product.stockID,
          stockName: product.stockName,
          loaiXuat: product.phuongPhapXuat,
          discount: 0,
          discountPercent: 0,
          tt: "",
          thanhTienTruocCK: (parseInt(productQuantity) || 1) * product.price,
          thanhTienSauCK: (parseInt(productQuantity) || 1) * product.price,
          invoiceDetailId: null,
          invoiceId: null,
          tenChinhSach: "",
          batch: product.batch,
          expDate: product.expDate,
        };

        onAddToCart(newItem);
        setProductQuantity("1");
      } catch (error) {
        console.error("Error adding product to cart:", error);
        notifyError("Lỗi khi thêm sản phẩm vào giỏ hàng");
      }
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [onAddToCart, productQuantity],
  );

  const onCreateNewCart = async () => {
    await handleCreateNewCart();
    setSearchProductByScan("");
    setSearchProduct("");
    clearNote("");
    if (listProducts && listProducts.length > 0) {
      setSelectedProduct(listProducts[0]!);
      setSelectedIndex(0);
    } else {
      setSelectedProduct(null);
      setSelectedIndex(undefined);
    }
    setProductQuantity("1");

    await mutateProducts();
  };

  const handleScanBarcode = useMemo(
    () =>
      debounce(async (value: string) => {
        const filtered =
          listProducts?.filter(
            (it) =>
              `${it.hospitalCode.toLowerCase()}|${it.batch.toLowerCase()}` ===
              value?.toLowerCase(),
          ) || [];
        if (filtered?.length > 0) {
          setProducts(filtered);
          if (filtered?.length > 1) {
            utils.setFocusAndSelectInput("#scan-barcode-input");
            return;
          }
          const product = filtered[0];
          if (!product) return;
          setSelectedProduct(product);
          setSelectedIndex(0);
          await handleAddToCart(product);
          utils.notifySuccess(
            `Sản phẩm ${product.productName} đã được thêm vào giỏ hàng`,
          );
          utils.setFocusAndSelectInput("#scan-barcode-input");
        } else {
          utils.notifyError(`không tìm thấy sản phẩm có mã ${value}`);
          setProducts([]);
          utils.setFocusAndSelectInput("#scan-barcode-input");
        }
      }, 50),
    [handleAddToCart, listProducts],
  );

  useKeyboardShortcut("F2", () =>
    utils.setFocusAndSelectInput("#scan-barcode-input"),
  );

  return (
    <div className="w-full h-full p-1 border-r overflow-y-auto">
      <Card className="h-full flex flex-col max-h-[calc(100vh-2rem)]">
        <CardHeader className="py-2 px-3 space-y-1">
          <div className="grid grid-cols-12 gap-1 items-center">
            <div className="col-span-5">
              <Label>
                Quầy:{" "}
                <a
                  className="text-blue-500 hover:underline cursor-pointer"
                  onClick={() => setIsCounterModalOpen(true)}
                >
                  {counter?.counterName || "Chưa chọn quầy"}
                </a>
              </Label>
            </div>
            <div className="col-span-5">
              <Label>
                Ca làm việc:{" "}
                <b className="text-red-500">
                  {selectedStoreWorkShift?.shiftName || "Chưa có ca làm việc"}
                </b>
              </Label>
            </div>
            <div className="col-span-2">
              <Button
                variant="outline"
                className="w-full"
                onClick={onCreateNewCart}
              >
                Tạo giỏ hàng mới
              </Button>
            </div>
          </div>
          <div className="grid grid-cols-12 gap-1 mt-1 items-center">
            <div className="col-span-5">
              <Input
                placeholder="Tìm kiếm sản phẩm"
                value={searchProduct}
                onChange={(e) => searchProductByName(e.target.value)}
                className="w-full"
              />
            </div>
            <div className="col-span-5">
              <Input
                id="scan-barcode-input"
                placeholder="Quét mã sản phẩm"
                value={searchProductByScan}
                onChange={(e) => {
                  const { value } = e.target;
                  if (!value) {
                    setSearchProductByScan("");
                    if (products !== listProducts)
                      setProducts(listProducts || []);
                    return;
                  }
                  setSearchProductByScan(value);
                  void handleScanBarcode(value);
                }}
                onFocus={() =>
                  utils.setFocusAndSelectInput("#scan-barcode-input")
                }
                className="w-full"
              />
            </div>
            <div className="col-span-1">
              <Input
                placeholder="SL"
                type="number"
                min={1}
                value={productQuantity}
                onChange={(e) => {
                  const inputValue = e.target.value;
                  if (inputValue === "") {
                    setProductQuantity("");
                  } else {
                    const val = parseInt(inputValue);
                    setProductQuantity(
                      isNaN(val) || val < 1 ? "1" : inputValue,
                    );
                  }
                }}
                onBlur={(e) => {
                  const val = parseInt(e.target.value);
                  if (isNaN(val) || val < 1) {
                    setProductQuantity("1");
                  }
                }}
                className="w-full"
              />
            </div>
            <div className="col-span-1">
              <Button
                size="sm"
                className="w-full"
                onClick={() =>
                  selectedProduct && handleAddToCart(selectedProduct)
                }
                disabled={isPaid}
              >
                Thêm
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="flex-1 overflow-auto p-0">
          <DataTable
            columns={getProductColumns(
              (product) => handleAddToCart(product),
              isPaid,
            )}
            data={products}
            className="w-full"
            enableColumnFilter={false}
            enablePaging={false}
            enableToggleColumn={true}
            enableGrouping={false}
            enableGlobalFilter={false}
            indexScrollTo={selectedIndex}
            onRowClick={(row) => setSelectedProduct(row)}
            onRowDoubleClick={handleAddToCart}
          />
        </CardContent>
      </Card>
    </div>
  );
}
