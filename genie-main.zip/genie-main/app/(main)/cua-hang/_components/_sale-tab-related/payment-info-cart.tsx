import { PaymentType } from "@/app/lib/definitions/setting";
import { formatCurrencyVND } from "@/app/lib/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Eye } from "lucide-react";

interface PaymentInfoCardProps {
  totalBeforeDiscount: number;
  totalAfterDiscount: number;
  billNumber: string;
  setBillNumber: (billNumber: string) => void;
  billNote: string;
  setBillNote: (billNote: string) => void;
  setBillNoteValue: (billNote: string) => void;
  contractNumber: string;
  billDate: string;
  paymentMethod: string;
  setPaymentMethod: (paymentMethod: string) => void;
  paymentMethods: PaymentType[];
  cardCode: string;
  setCardCode: (cardCode: string) => void;
  setCardCodeValue: (cardCode: string) => void;
  isPaid: boolean;
  isValidCardNumber: boolean;
  handleConfigPos: () => void;
  handleMultiplePayments: () => void;
  handleViewReceipt: (cardValue: string) => void;
  user: { name: string };
  handleBillNumberBlur: () => Promise<void>;
  facId: string;
  isPrintOpening: boolean;
  setIsPrintOpening: (isPrintOpening: boolean) => void;
}

export function PaymentInfoCard({
  totalBeforeDiscount,
  totalAfterDiscount,
  billNumber,
  setBillNumber,
  billNote,
  setBillNote,
  setBillNoteValue,
  contractNumber,
  billDate,
  paymentMethod,
  setPaymentMethod,
  paymentMethods,
  cardCode,
  setCardCode,
  setCardCodeValue,
  isPaid,
  isValidCardNumber,
  handleConfigPos,
  handleMultiplePayments,
  handleViewReceipt,
  user,
  handleBillNumberBlur,
  isPrintOpening,
}: PaymentInfoCardProps) {
  return (
    <Card>
      <CardContent className="p-2 space-y-1">
        <div className="grid grid-cols-12 items-center gap-2">
          <Label className="col-span-3 text-left whitespace-break-spaces">
            Số biên lai thanh toán
          </Label>
          <Input
            className="col-span-3 font-medium"
            value={billNumber}
            disabled={true}
            onKeyDown={async (e) => {
              if (billNumber.length > 0 && e.key === "Enter") {
                e.currentTarget.blur();
              }
            }}
            onChange={(e) => {
              setBillNumber(e.target.value);
            }}
            onBlur={handleBillNumberBlur}
          />
          <Label className="col-span-2 text-right whitespace-break-spaces">
            Ghi chú:
          </Label>
          <Input
            className="col-span-4 font-medium"
            value={billNote}
            onChange={(e) => {
              setBillNote(e.target.value);
              setBillNoteValue(e.target.value);
            }}
          />
        </div>

        <div className="grid grid-cols-12 items-center gap-2">
          <Label className="col-span-3 text-left whitespace-break-spaces">
            Tổng tiền trước CK
          </Label>
          <span className="col-span-3 font-medium">
            {formatCurrencyVND(totalBeforeDiscount, 0)}
          </span>
          <Label className="col-span-2 text-right whitespace-break-spaces">
            Số HĐ:
          </Label>
          <span className="col-span-4 font-medium">
            {contractNumber || "..."}
          </span>
        </div>

        <div className="grid grid-cols-12 items-center gap-2">
          <Label className="col-span-3 text-left whitespace-break-spaces">
            Tổng tiền sau CK
          </Label>
          <span className="col-span-3 font-medium">
            {formatCurrencyVND(totalAfterDiscount, 0)}
          </span>
          <Label className="col-span-2 text-right whitespace-break-spaces">
            Ngày TT:
          </Label>
          <span className="col-span-4 font-medium">{billDate || "..."}</span>
        </div>

        <div className="grid grid-cols-12 items-center gap-2">
          <Label
            htmlFor="paymentMethod"
            className="col-span-3 whitespace-break-spaces text-left"
          >
            Phương thức TT
          </Label>
          <div className="col-span-5">
            <Select
              value={paymentMethod}
              onValueChange={setPaymentMethod}
              disabled={isPaid}
            >
              <SelectTrigger>
                <SelectValue placeholder="Chọn phương thức" />
              </SelectTrigger>
              <SelectContent>
                {paymentMethods.map((method) => (
                  <SelectItem key={method.id} value={method.id.toString()}>
                    {method.ten}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <Button
            className="col-span-4 whitespace-nowrap px-2"
            onClick={handleMultiplePayments}
            disabled={isPaid || !isValidCardNumber || isPrintOpening}
          >
            Thanh toán nhiều PT
          </Button>
        </div>

        <div className="grid grid-cols-12 items-center gap-2">
          <Label
            htmlFor="cardCode"
            className="col-span-3 text-left whitespace-break-spaces"
          >
            Mã thẻ/ số TK / Mã KM
          </Label>
          <Input
            id="cardCode"
            value={cardCode}
            onChange={(e) => {
              setCardCode(e.target.value);
              setCardCodeValue(e.target.value);
            }}
            className="col-span-9"
            disabled={isPaid}
            required={!isValidCardNumber}
            error={!isValidCardNumber}
          />
        </div>
        {!isValidCardNumber && (
          <div className="grid grid-cols-12 items-center gap-2">
            <div className="col-span-3"></div>
            <span className="col-span-9 text-red-500">
              Vui lòng nhập mã thẻ/ số TK / Mã KM
            </span>
          </div>
        )}

        <div className="grid grid-cols-12 items-center gap-2 pt-1">
          <div className="col-span-3 text-blue-500 hover:underline whitespace-nowrap">
            <span onClick={handleConfigPos} className="cursor-pointer">
              Máy POS
            </span>
          </div>
          <div className="col-span-5 whitespace-nowrap">
            <Label>Nhân viên thu ngân:</Label>
            <span className="ml-1">
              <b>{user.name.toUpperCase()}</b>
            </span>
          </div>
          <Button
            className="col-span-4 px-2 whitespace-nowrap"
            onClick={() => handleViewReceipt(cardCode)}
            disabled={isPaid || !isValidCardNumber || isPrintOpening}
          >
            <Eye className="h-4 w-4 mr-1" />
            Xem biên lai
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
