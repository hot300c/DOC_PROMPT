"use client";

import { CardOwner } from "@/app/(main)/thanh-toan/_utils/definitions/api";
import { fetchCardOwnerByCardNumber } from "@/app/(main)/thanh-toan/_utils/qa-pay-api/fetch-card-owner-by-card-number";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { useEffect, useState } from "react";

import { QAPayCardInfo } from "@/app/lib/definitions/qa-pay";
import { CANH_BAO } from "@/app/lib/enums";
import * as QAPayService from "@/app/lib/services/qa-pay-services";
import { notifyError } from "@/app/lib/utils";

interface QaPayInfoDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  initialCardNumber?: string;
  onConfirm: (cardNumber: string) => void;
  cardOwner: QAPayCardInfo;
}

export function QaPayInfoDialog({
  open,
  onOpenChange,
  initialCardNumber = "",
  onConfirm,
  cardOwner,
}: QaPayInfoDialogProps) {
  const [cardNumber, setCardNumber] = useState(initialCardNumber);
  const [cardInfo, setCardInfo] = useState<CardOwner | null>(null);

  useEffect(() => {
    void handleSelectCard(cardOwner);
  }, [cardOwner]);

  const handleCheckCardInfo = async () => {
    if (!cardNumber) {
      return;
    }

    try {
      const cardOwner = await QAPayService.fetchAccountOwner({
        cardNumber,
      });
      if (!cardOwner) {
        await alert({
          title: CANH_BAO,
          content: "Thông tin thẻ trống",
        });
        return;
      }

      const cardInfos = await QAPayService.fetchCardInfo({
        accountId: cardOwner.accountID,
      });
      const cardFiltered = cardInfos.filter((x) => !x.isLock && x.isActive);
      if (!cardFiltered?.length) {
        await alert({
          title: CANH_BAO,
          content: "Không tìm thấy dữ liệu",
        });
        return;
      } else {
        await handleSelectCard(cardFiltered[0] || null);
      }
    } catch (error) {
      notifyError("Error checkingCardNumber");
      return;
    }
  };

  const handleSelectCard = async (card: QAPayCardInfo | null) => {
    if (!card) return;
    const owner = await fetchCardOwnerByCardNumber(card.cardIDName);
    if (!owner) {
      await alert({
        title: "Cảnh báo",
        content: "Không thể kiểm tra thông tin thẻ.",
      });
      return;
    }
    setCardInfo(owner);
  };

  const handleConfirm = () => {
    if (cardInfo) {
      // Original: txtNumberCard.Text = frmThongTinQAPAY.Mathe;
      onConfirm(cardInfo?.mathe || "");
      onOpenChange(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>VNVC Point:</DialogTitle>
        </DialogHeader>

        <div className="space-y-4 py-4">
          {/* Card Information Display */}
          <div className="grid grid-cols-2 gap-2 text-sm">
            <div className="font-medium">Thông tin chủ thẻ:</div>
            <div>{cardInfo?.fullName || ""}</div>

            <div className="font-medium">Số tài khoản:</div>
            <div>{cardInfo?.mataikhoan || ""}</div>

            <div className="font-medium">Số thẻ:</div>
            <div>{cardInfo?.mathe || ""}</div>
          </div>

          {/* Card number input for re-entry */}
          <div className="flex items-center space-x-2 pt-4">
            <Input
              value={cardNumber}
              onChange={(e) => setCardNumber(e.target.value)}
              placeholder="Nhập mã thẻ VNVC Point"
            />
            <Button onClick={handleCheckCardInfo} variant="outline">
              Nhập lại
            </Button>
          </div>
        </div>

        <DialogFooter>
          <Button onClick={handleConfirm} disabled={!cardInfo}>
            Xác nhận
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
