"use client";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { DataTable } from "@/components/ui/dataTable";
import { InvoiceItem } from "@/app/(main)/cua-hang/_models/bill-model";
import { INVOICE_COLUMNS } from "@/app/(main)/cua-hang/_utils/multi-payment-modal-columns";

interface InvoiceInfoTableProps {
  invoiceItems: InvoiceItem[];
  onRowClick: (rowIndex: number) => void;
}

export function InvoiceInfoTable({
  invoiceItems,
  onRowClick,
}: InvoiceInfoTableProps) {
  return (
    <Card className="shadow-sm h-full">
      <CardHeader className="p-4">
        <div className="font-semibold text-lg mb-3">Thông tin hóa đơn</div>
      </CardHeader>
      <CardContent className="p-0">
        <DataTable
          columns={INVOICE_COLUMNS}
          data={invoiceItems}
          className="w-full p-0"
          enableColumnFilter={false}
          enablePaging={false}
          enableToggleColumn={false}
          enableGrouping={false}
          enableGlobalFilter={false}
          onRowClick={(_, rowIndex) => onRowClick(rowIndex)}
        />
      </CardContent>
    </Card>
  );
}
