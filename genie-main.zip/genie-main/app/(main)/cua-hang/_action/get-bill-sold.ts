import { QAHOSGENERICDB } from "@/app/lib/enums";
import { logger } from "@/app/lib/logger";
import { post } from "@/app/lib/network/http";
import {
  ApprovedOutDetail,
  InvoiceBusiness,
  InvoiceBusinessDetail,
  RetailInvoiceInfo,
  ScratchcardSold,
  ShiftDailyModel,
} from "../_models/bill-sold-model";

export const getShiftDailyListNhaThuoc = async (
  facId: string,
): Promise<ShiftDailyModel[]> => {
  try {
    const response = await post("/DataAccess", [
      {
        category: QAHOSGENERICDB,
        command: "ws_L_ShiftDaily_ListNhaThuoc",
        parameters: {
          Type: "NHA THUOC",
          FacID: facId,
          IsSapXepGanNhat: 1,
        },
      },
    ]);
    return response.data.table || [];
  } catch (error) {
    logger.error("ws_L_ShiftDaily_ListNhaThuoc", error);
    return [];
  }
};
export const getInvoiceBusinessByShiftDailyId = async (
  facId: string,
  shiftDailyId: string,
  isDoiDiem?: boolean | false,
): Promise<InvoiceBusiness[]> => {
  try {
    const response = await post("/DataAccess", [
      {
        category: QAHOSGENERICDB,
        command: "ws_BIL_InvoiceBusiness_GetByShiftDailyID_Genie",
        parameters: {
          FacID: facId,
          ShiftDailyID: shiftDailyId,
          IsDoiDiem: isDoiDiem,
        },
      },
    ]);
    return response.data.table || [];
  } catch (error) {
    logger.error("ws_BIL_InvoiceBusiness_GetByShiftDailyID_Genie", error);
    return [];
  }
};
export const getInvoiceBusinessDetailById = async (
  facId: string,
  invoiceBusinessId: string,
): Promise<InvoiceBusinessDetail[]> => {
  try {
    const response = await post("/DataAccess", [
      {
        category: QAHOSGENERICDB,
        command: "ws_BIL_InvoiceBusinessDetail_GetBienLaiBanLe_Genie",
        parameters: {
          FacID: facId,
          InvoiceBusinessID: invoiceBusinessId,
        },
      },
    ]);
    return response.data.table || [];
  } catch (error) {
    logger.error("ws_BIL_InvoiceBusinessDetail_GetBienLaiBanLe_Genie", error);
    return [];
  }
};
export const getSoldScratchcards = async (
  facId: string,
  fromDate: string,
  toDate: string,
  isCheck: boolean,
  isDoiDiem: boolean,
): Promise<ScratchcardSold[]> => {
  try {
    const response = await post("/DataAccess", [
      {
        category: QAHOSGENERICDB,
        command: "ws_CN_ScratchcardSaled_List",
        parameters: {
          FacID: facId,
          TuNgay: fromDate,
          DenNgay: toDate,
          IsCheck: isCheck,
          IsDoiDiem: isDoiDiem,
        },
      },
    ]);
    return response.data.table || [];
  } catch (error) {
    logger.error("ws_CN_ScratchcardSaled_List", error);
    return [];
  }
};
export const getRetailInvoiceInfo = async (
  facId: string,
  invoiceBusinessId: string,
): Promise<RetailInvoiceInfo | null> => {
  try {
    const response = await post("/DataAccess", [
      {
        category: QAHOSGENERICDB,
        command: "ws_BIL_InvoiceBusiness_GetThongTinBienLaiBanLe",
        parameters: {
          FacID: facId,
          InvoiceBusinessID: invoiceBusinessId,
        },
      },
    ]);
    return response.data.table[0] || null;
  } catch (error) {
    logger.error("ws_BIL_InvoiceBusiness_GetThongTinBienLaiBanLe", error);
    return null;
  }
};
export const getApprovedOutDetails = async (
  facId: string,
  invoiceBusinessId: string,
  phieuXuatId: string,
  isExchangePoint = false,
): Promise<ApprovedOutDetail[]> => {
  try {
    const response = await post("/DataAccess", [
      {
        category: QAHOSGENERICDB,
        command: "ws_INV_ApprovedOutDetail_ListByBienLaiBanLe",
        parameters: {
          FacID: facId,
          InvoiceBusinessID: invoiceBusinessId,
          phieuXuatID: phieuXuatId,
          IsDoiDiem: isExchangePoint,
        },
      },
    ]);
    return response.data.table || [];
  } catch (error) {
    logger.error("ws_INV_ApprovedOutDetail_ListByBienLaiBanLe", error);
    return [];
  }
};
