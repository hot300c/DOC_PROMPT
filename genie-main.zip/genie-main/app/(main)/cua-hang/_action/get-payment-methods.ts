import { post } from "@/app/lib/network/http";
import { QAHOSGENERICDB } from "@/app/lib/enums";
import { logger } from "@/app/lib/logger";
import { PaymentType } from "@/app/lib/definitions/setting";

export const getPaymentMethods = async (
  facId: string,
): Promise<PaymentType[]> => {
  try {
    const response = await post("/DataAccess", [
      {
        category: QAHOSGENERICDB,
        command: "ws_L_HinhThucThanhToan_List",
        parameters: {
          FacID: facId,
        },
      },
    ]);
    return response.data.table;
  } catch (error) {
    logger.error("ws_MDM_Patient_GetByMaKHOnSiteShop", error);
    return [];
  }
};
