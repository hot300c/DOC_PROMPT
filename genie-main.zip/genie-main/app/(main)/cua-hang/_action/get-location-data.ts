"use server";
import { QAHOSGENERICDB } from "@/app/lib/enums";
import { logger } from "@/app/lib/logger";
import { cachePost } from "@/app/lib/network/cache-http";
import { generateCacheKey } from "@/app/lib/network/utils";
import { LocationData } from "../_models/location-models";

export const getLocationData = async (): Promise<LocationData[]> => {
  try {
    const response = await cachePost({
      url: "/DataAccess",
      payload: [
        {
          category: QAHOSGENERICDB,
          command: "ws_MDM_Province_Get",
          parameters: {},
        },
      ],
      cacheKey: generateCacheKey("ws_MDM_Province_Get"),
      ttl: 86400, // 24 hours
    });
    return response.table;
  } catch (error) {
    logger.error("ws_MDM_Province_Get", error);
    return [];
  }
};

export const getDistrictsByProvinceId = async (
  provinceId: string,
): Promise<LocationData[]> => {
  try {
    const response = await cachePost({
      url: "/DataAccess",
      payload: [
        {
          category: QAHOSGENERICDB,
          command: "ws_MDM_District_List",
          parameters: {
            ProvinceID: provinceId,
          },
        },
      ],
      cacheKey: generateCacheKey("ws_MDM_District_List", {
        provinceId,
      }),
      ttl: 86400, // 24 hours
    });
    return response.table;
  } catch (error) {
    logger.error("ws_MDM_District_List", error);
    return [];
  }
};

export const getWardsByDistrictId = async (
  districtId: string,
): Promise<LocationData[]> => {
  try {
    const response = await cachePost({
      url: "/DataAccess",
      payload: [
        {
          category: QAHOSGENERICDB,
          command: "ws_MDM_Ward_List",
          parameters: {
            DistrictID: districtId,
          },
        },
      ],
      cacheKey: generateCacheKey("ws_MDM_Ward_List", { districtId }),
      ttl: 86400, // 24 hours
    });
    return response.table;
  } catch (error) {
    logger.error("ws_MDM_Ward_List", error);
    return [];
  }
};
