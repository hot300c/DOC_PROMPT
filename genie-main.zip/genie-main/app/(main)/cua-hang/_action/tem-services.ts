"use server";
import axios, { AxiosInstance } from "axios";
import { ResponseTemService } from "../_models/bill-sold-model";

export const callTemService = async ({
  url,
  payload,
  headers,
}: {
  url: string;
  payload: any;
  headers: {};
}): Promise<ResponseTemService> => {
  const urlObj = new URL(url);
  const axiosInstance: AxiosInstance = axios.create({
    baseURL: urlObj.origin,
    timeout: 60000,
  });

  const response = await axiosInstance.post(urlObj.pathname, payload, {
    headers: {
      ...headers,
      "Content-Type": "application/json",
    },
  });
  return response.data as ResponseTemService;
};
