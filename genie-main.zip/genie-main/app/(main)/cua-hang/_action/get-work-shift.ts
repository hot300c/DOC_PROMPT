"use client";

import { QAHOSGENERICDB } from "@/app/lib/enums";
import { logger } from "@/app/lib/logger";
import { post } from "@/app/lib/network/http";
import { WorkShift } from "@/app/(main)/cua-hang/_models/work-shift-model";

export const getWorkShiftByCounterIdAndFacId = async (
  facId: string,
  counterId: number,
): Promise<WorkShift | undefined> => {
  try {
    const response = await post("/DataAccess", [
      {
        category: QAHOSGENERICDB,
        command: "ws_L_ShiftDaily_LayCaHienTaiLamViec",
        parameters: {
          Type: "NHA THUOC",
          FacID: facId,
          CounterID: counterId,
        },
      },
    ]);
    return response.data.table[0];
  } catch (error) {
    logger.error("ws_MDM_Patient_GetByMaKHOnSiteShop", error);
  }
};
