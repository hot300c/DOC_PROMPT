"use server";

import { CardHolderInfo, QaPayResponse } from "../_models/qa-pay-models";
import { post } from "@/app/lib/network/http";
import { INTERGRATION_DB } from "@/app/lib/enums";
import { logger } from "@/app/lib/logger";

export async function validateQaPayCard(
  cardNumber: string,
): Promise<CardHolderInfo | null> {
  try {
    const apiUrl = (await getQaPayConfigForCardInfo()) || "";

    // Make the API request
    const response = await fetch(apiUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Accept-Language": "vi",
        API_KEY: process.env.QAPAY_API_KEY || "",
      },
      body: JSON.stringify({ CardNumber: cardNumber.trim() }),
    });

    if (!response.ok) {
      console.log(`API error: ${response.status}`);
      return null;
    }

    const data: QaPayResponse = await response.json();

    if (data && data.ThongTinChuThe && data.ThongTinChuThe.length > 0) {
      // Original: thongTinChuThe = JsonConvert.DeserializeObject<RootThongTinChuThe>(value2).ThongTinChuThe[0];
      const cardHolderInfo = data.ThongTinChuThe[0]!;
      cardHolderInfo.Link = apiUrl;
      return cardHolderInfo;
    }

    return null;
  } catch (error) {
    console.log("Failed to validate QA PAY card:", error);
    return null;
  }
}

const getQaPayConfigForCardInfo = async (): Promise<string | undefined> => {
  try {
    const response = await post("/DataAccess", [
      {
        category: INTERGRATION_DB,
        command: "ws_QAPAY_Config",
        parameters: {
          Type: "ThongTinChuThe",
        },
      },
    ]);
    return response.data.table[0];
  } catch (error) {
    logger.error("ws_QAPAY_Config", error);
  }
};
