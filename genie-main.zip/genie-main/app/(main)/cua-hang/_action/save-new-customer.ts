"use client";

import { QAHOSGENERICDB } from "@/app/lib/enums";
import { logger } from "@/app/lib/logger";
import { post } from "@/app/lib/network/http";
import { NewCustomerData } from "../_models/customer-model";

export const saveCustomer = async (
  customer: NewCustomerData,
  facId: string,
): Promise<string | undefined> => {
  try {
    const response = await post("/DataAccess", [
      {
        category: QAHOSGENERICDB,
        command: "ws_MDM_Patient_SaveV2",
        parameters: {
          FacID: facId,
          PatientID: customer.patientId,
          PatientHospitalID: "",
          MOHID: "",
          FullName: customer.fullName,
          Gender: customer.gender,
          DoB: customer.birthDate.toLocaleDateString("en-US", {
            month: "2-digit",
            day: "2-digit",
            year: "numeric",
          }),
          DobAccuracyCode: 3,
          DoB_DD: customer.birthDate.getDate(),
          DoB_MM: customer.birthDate.getMonth() + 1,
          DoB_YYYY: customer.birthDate.getFullYear(),
          ArmyLevel: "",
          ArmyPlace: "",
          ArmyStatus: "",
          NameRelation: "",
          TelRelation: "",
          Ethnicity: "",
          MaritalStatus: "",
          Occupation: "",
          NationalIDNo: "",
          Address: customer.address,
          DiaChi: customer.address,
          Street: customer.streetNo,
          Country: "",
          Province: customer.province,
          District: customer.district,
          Ward: customer.ward,
          Address2: "",
          Street2: "",
          Country2: "",
          Province2: "",
          District2: "",
          Ward2: "",
          HomePhone: customer.phone,
          Email: customer.email,
          Mobile: customer.phone,
          WorkPhone: customer.phone,
          Company: customer.company,
          Note: "",
          MaSoThue: customer.taxId,
          SoTaiKhoan: "",
        },
      },
    ]);

    return response?.data.table[0].patientHospitalID;
  } catch (error) {
    logger.error("ws_MDM_Patient_SaveV2", error);
    return undefined;
  }
};
