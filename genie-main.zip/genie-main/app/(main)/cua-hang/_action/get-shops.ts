"use client";

import { QAHOSGENERICDB } from "@/app/lib/enums";
import { logger } from "@/app/lib/logger";
import { post } from "@/app/lib/network/http";
import { Shop } from "@/app/(main)/cua-hang/_models/shop-model";

export const getShopsByFacId = async (facId: string): Promise<Shop[]> => {
  try {
    const response = await post("/DataAccess", [
      {
        category: QAHOSGENERICDB,
        command: "ws_L_OnSiteShopType_GetByFacID",
        parameters: {
          FacID: facId,
        },
      },
    ]);
    return response.data.table;
  } catch (error) {
    logger.error("ws_MDM_Patient_GetByMaKHOnSiteShop", error);
    return [];
  }
};
