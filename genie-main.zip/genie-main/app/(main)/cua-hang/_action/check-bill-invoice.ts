"use client";
import { QAHOSGENERICDB } from "@/app/lib/enums";
import { logger } from "@/app/lib/logger";
import { post } from "@/app/lib/network/http";
import { notifyError } from "@/app/lib/utils";

export interface BillInvoiceCheckResult {
  invoiceId?: string;
  contractNumber?: string;
  paymentDate?: Date;
}

export const checkBillInvoice = async (
  facId: string,
  invoiceNo: string,
): Promise<BillInvoiceCheckResult | undefined> => {
  try {
    const response = await post("/DataAccess", [
      {
        category: QAHOSGENERICDB,
        command: "ws_BIL_Invoice_KiemTra",
        parameters: {
          FacID: facId,
          InvoiceNo: invoiceNo,
        },
      },
    ]);

    // Check if there's valid data
    const data = response.data;
    if (!data || !data.table || data.table.length === 0) {
      notifyError("Không có dữ liệu trả về");
      return undefined;
    }

    // Get result code and message
    const resultCode = Number(data.table[0]?.resultCode) || 0;
    const resultMessage = data.table[0]?.resultMessage || "";

    if (resultCode <= 0) {
      notifyError("Không có dữ liệu trả về");
      return;
    }

    if (resultCode === 200) {
      // Check for detail data
      if (!!data.table1 && data.table1.length > 0) {
        const invoiceId = data.table1[0].invoiceID || "";
        const contractNumber = data.table1[0].soHopDong || "";
        const paymentDate = data.table1[0].invoiceDateThanhToan;

        if (!invoiceId || !paymentDate) {
          notifyError("Không có dữ liệu tham chiếu thanh toán trả về");
          return;
        }

        return {
          invoiceId,
          contractNumber,
          paymentDate: new Date(paymentDate),
        };
      } else {
        notifyError("Không có dữ liệu tham chiếu thanh toán trả về");
      }
    } else {
      notifyError(resultMessage);
    }
  } catch (error) {
    logger.error("ws_BIL_Invoice_KiemTra", error);
    notifyError("Lỗi khi kiểm tra biên lai: " + error);
  }
};
