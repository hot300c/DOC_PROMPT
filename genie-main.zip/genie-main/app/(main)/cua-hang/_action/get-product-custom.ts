"use client";

import { QAHOSGENERICDB } from "@/app/lib/enums";
import { logger } from "@/app/lib/logger";
import { post } from "@/app/lib/network/http";

export const getProductCustomColumns = async (
  facId: string,
  productId: number,
): Promise<
  {
    productID: number;
    custom_TenTruong: any;
    custom_LoaiDuLieu: any;
    productTypeID: number;
    isHienTungDong: boolean;
  }[]
> => {
  try {
    const response = await post("/DataAccess", [
      {
        category: QAHOSGENERICDB,
        command: "ws_L_Product_GetCustomColumn",
        parameters: {
          FacID: facId,
          ProductID: productId,
        },
      },
    ]);
    return response.data.table;
  } catch (error) {
    logger.error("ws_L_Product_GetCustomColumn", error);
    return [];
  }
};
