"use client";
import { QAHOSGENERICDB } from "@/app/lib/enums";
import { logger } from "@/app/lib/logger";
import { post } from "@/app/lib/network/http";
import { Counter } from "../_models/counter-model";

export const getCountersByFacId = async (facId: string): Promise<Counter[]> => {
  try {
    const response = await post("/DataAccess", [
      {
        category: QAHOSGENERICDB,
        command: "ws_L_Counter_List",
        parameters: {
          CounterType: "NT",
          FacID: facId,
        },
      },
    ]);
    return response.data.table;
  } catch (error) {
    logger.error("ws_L_Counter_List", error);
    return [];
  }
};
