import { logger } from "@/app/lib/logger";
import { post } from "@/app/lib/network/http";
import { notifyError } from "@/app/lib/utils";
import { DATE_FORMAT, QAHOSGENERICDB } from "@/app/lib/enums";
import { format } from "date-fns";

// Define response interfaces
interface ResultCheckQTK {
  resultCode: number;
  resultMessage: string;
  invoiceId?: string;
  invoiceDate?: string;
  hopDongId?: string;
}

interface RootRequestQuaTangKem {
  facId: string;
  ngay: string;
  isBillDatTruoc: boolean;
  isBillLe: boolean;
  isBillGoi: boolean;
  maKH: string;
  tongBill: number;
  ngaySinh: string | null;
}

interface QuaTangKemData {
  tenChinhSach: string;
  maSP: string;
  tenSP: string;
  isHieuLuc: boolean;
}

interface RootResponseQuaTangKem {
  success: boolean;
  data: QuaTangKemData[];
}

export const checkBillGiftInfo = async (
  facId: string,
  invoiceNoKiemTra: string,
  patientIdKiemTra: string,
  tenChinhSachChecks: string,
  maSPChecks: string,
  productIdChecks: string,
): Promise<ResultCheckQTK> => {
  const result: ResultCheckQTK = {
    resultCode: 0,
    resultMessage: "Bắt đầu kiểm tra",
  };

  if (!facId || !invoiceNoKiemTra || !patientIdKiemTra) {
    result.resultCode = 404;
    result.resultMessage =
      "Không có thông tin kiểm tra chương trình quà tặng kèm";
    return result;
  }

  if (!tenChinhSachChecks || !maSPChecks || !productIdChecks) {
    result.resultCode = 404;
    result.resultMessage =
      "Không có thông tin sản phẩm quà tặng kèm để đối chiếu API";
    return result;
  }

  try {
    const configApiResponse = await post("/DataAccess", [
      {
        category: "Integration",
        command: "ws_L_API_Config_Load",
        parameters: {
          FacID: facId,
          Key: "LinkAPIQuaTangKem",
        },
      },
      {
        category: "Integration",
        command: "ws_L_API_Config_Load",
        parameters: {
          FacID: facId,
          Key: "SECRETCODEQuaTangKem",
        },
      },
      {
        category: QAHOSGENERICDB,
        command: "ws_MDM_Patient_GetByPatientID",
        parameters: {
          PatientID: patientIdKiemTra,
        },
      },
      {
        category: QAHOSGENERICDB,
        command: "ws_BIL_QuaTangKem_CheckByInvoiceNo",
        parameters: {
          FacID: facId,
          InvoiceNo: invoiceNoKiemTra,
          PatientID: patientIdKiemTra,
        },
      },
    ]);

    if (!configApiResponse?.data) {
      notifyError("Không có dữ liệu trả về");
      return result;
    }

    const configApiResponseData = configApiResponse.data;

    const apiUrl = configApiResponseData.table[0].value || "";
    const secretCode = configApiResponseData.table1[0].value || "";

    const patientData = configApiResponseData.table2[0];
    const dob = patientData?.doB
      ? new Date(patientData.doB)
      : new Date("1900-01-01");
    const patientHospitalId = patientData?.patientHospitalID || "";
    const birthDateStr =
      dob > new Date("1901-01-01") ? format(dob, DATE_FORMAT.YYYY_MM_DD) : "";

    const invoiceCheckResult = configApiResponseData.table3[0];
    let resultCode = 0;
    let resultMessage = "";
    let isBillDatTruoc = false;
    let isBillLe = false;
    let isBillGoi = false;
    let tongBill = 0;

    if (invoiceCheckResult) {
      resultCode = Number(invoiceCheckResult.resultCode) || 0;
      resultMessage = invoiceCheckResult.resultMessage || "";
    }

    const billDetails = configApiResponseData.table4[0];
    if (billDetails) {
      tongBill = Number(billDetails.tongBill) || 0;
      isBillDatTruoc = Boolean(billDetails.isBillDatTruoc);
      isBillLe = Boolean(billDetails.isBillLe);
      isBillGoi = Boolean(billDetails.isBillGoi);
    }

    if (invoiceNoKiemTra && resultCode !== 200) {
      if (resultCode === 0) {
        result.resultCode = 400;
        result.resultMessage = "Số biên lai thanh toán không hợp lệ";
        return result;
      }
      result.resultCode = resultCode;
      result.resultMessage = resultMessage;
      return result;
    }

    if (!secretCode || !apiUrl) {
      result.resultCode = 600;
      result.resultMessage = "Không có thông tin cấu hình API quà tặng kèm";
      return result;
    }

    const apiRequest: RootRequestQuaTangKem = {
      facId: facId,
      ngay: format(new Date(), DATE_FORMAT.YYYY_MM_DD),
      isBillDatTruoc,
      isBillLe,
      isBillGoi,
      maKH: patientHospitalId,
      tongBill,
      ngaySinh: birthDateStr || null,
    };

    const apiResponse = await fetch(apiUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        SECRETCODE: secretCode,
      },
      body: JSON.stringify(apiRequest),
    });

    if (!apiResponse.ok) {
      logger.error(`API error: ${apiResponse.status}`);
      result.resultCode = 601;
      result.resultMessage = "Lỗi kết nối API";
      return result;
    }

    const apiResponseData: RootResponseQuaTangKem = await apiResponse.json();

    if (!apiResponseData?.success || !apiResponseData?.data?.length) {
      result.resultCode = 602;
      result.resultMessage = "Không có kết quả thông tin quà tặng trả về";
      return result;
    }

    const validGifts = apiResponseData.data.filter(
      (item) => item.isHieuLuc && item.tenChinhSach && item.maSP && item.tenSP,
    );

    if (validGifts.length === 0) {
      result.resultCode = 602;
      result.resultMessage = "Không có kết quả thông tin quà tặng trả về";
      return result;
    }

    const tenChinhSachs = validGifts
      .map((g) => g.tenChinhSach.trim())
      .join("|");
    const maSPs = validGifts.map((g) => g.maSP.trim()).join("|");
    const tenSPs = validGifts.map((g) => g.tenSP.trim()).join("|");

    const giftValidationResponse = await post("/DataAccess", [
      {
        category: QAHOSGENERICDB,
        command: "ws_BIL_QuaTangKem_KiemTra",
        parameters: {
          FacID: facId,
          InvoiceNo: invoiceNoKiemTra,
          PatientID: patientIdKiemTra,
          TenChinhSachs: tenChinhSachs,
          MaSPs: maSPs,
          TenSPs: tenSPs,
          TenChinhSachChecks: tenChinhSachChecks,
          MaSPChecks: maSPChecks,
          ProductIDChecks: productIdChecks,
        },
      },
    ]);

    if (!giftValidationResponse?.data) {
      logger.error("ws_BIL_QuaTangKem_KiemTra", "No data returned");
      result.resultCode = 400;
      result.resultMessage = "Lỗi khi kiểm tra quà tặng kèm";
      return result;
    }
    const giftValidationResponseData = giftValidationResponse.data;
    const finalResultData = giftValidationResponseData.table[0];
    const finalResultCode = Number(finalResultData?.resultCode) || 0;
    const finalResultMessage = finalResultData?.resultMessage || "";

    if (finalResultCode > 0) {
      if (finalResultCode === 200) {
        const invoiceData = giftValidationResponseData.table1[0];

        if (invoiceData) {
          const invoiceId = invoiceData.invoiceID || "";
          const hopDongId = invoiceData.hopDongID || "";
          const invoiceDate = invoiceData.invoiceDateThanhToan
            ? new Date(invoiceData.invoiceDateThanhToan)
            : new Date("1900-01-01");

          if (!invoiceId || invoiceDate < new Date("1901-01-01")) {
            result.resultCode = 800;
            result.resultMessage =
              "Không có dữ liệu tham chiếu thanh toán trả về";
          } else {
            result.resultCode = 200;
            result.resultMessage = finalResultMessage;
            result.invoiceId = invoiceId;
            result.invoiceDate = format(invoiceDate, DATE_FORMAT.YYYY_MM_DD);
            result.hopDongId = hopDongId;
          }
        } else {
          result.resultCode = 800;
          result.resultMessage =
            "Không có dữ liệu tham chiếu thanh toán trả về";
        }
      } else {
        result.resultCode = finalResultCode;
        result.resultMessage = finalResultMessage;
      }
    } else {
      result.resultCode = 800;
      result.resultMessage = "Không có dữ liệu tham chiếu thanh toán trả về";
    }
  } catch (error) {
    logger.error("Error QA.Billing_QuaTangKem", error);
    result.resultCode = 601;
    result.resultMessage = "Lỗi kết nối API";
  }

  return result;
};
