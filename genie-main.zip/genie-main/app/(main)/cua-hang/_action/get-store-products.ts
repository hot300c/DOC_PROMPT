"use client";

import { QAHOSGENERICDB } from "@/app/lib/enums";
import { logger } from "@/app/lib/logger";
import { post } from "@/app/lib/network/http";
import { Product } from "@/app/(main)/cua-hang/_models/product-model";

/**
 * Gets all products in the store with optional search filter
 */
export const getAllStoreProducts = async (
  facID: string,
  shopTypeId?: string,
): Promise<Product[]> => {
  try {
    const response = await post("/DataAccess", [
      {
        category: QAHOSGENERICDB,
        command: "ws_L_Product_ListByShopType_Genie",
        parameters: {
          FacID: facID,
          ShopTypeID: shopTypeId || "",
        },
      },
    ]);
    return response.data.table || [];
  } catch (error) {
    logger.error("Failed to get store products", error);
    return [];
  }
};
