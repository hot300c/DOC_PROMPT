"use server";

import { logger } from "@/app/lib/logger";
import {
  PromotionCartItem,
  PromotionRequest,
  PromotionResponse,
} from "@/app/(main)/cua-hang/_models/promotion-models";
import { CartItem } from "@/app/(main)/cua-hang/_models/cart-model";
import { ws_L_API_Config_Load } from "@/app/lib/services/setting";

export const checkPromotionApplicable = async (
  facId: string,
  centerName: string,
  stockName: string,
  customerCode: string,
  customerPhone: string,
  customerName: string,
  customerType: string,
  customerTier: number,
  employeeCode: string,
  employeeType: number,
  cartItems: CartItem[],
  currentTotalAmount: number,
  currentTotalQuantity: number,
): Promise<PromotionResponse | null> => {
  try {
    const linkApiCheckChiDinhPhongKham = await ws_L_API_Config_Load({
      key: "VNVC_API_Domain",
      facId,
    });

    const apiUrl = linkApiCheckChiDinhPhongKham?.value;
    const keySecretCodeData = await ws_L_API_Config_Load({
      key: "KeySECRETCODE",
      facId,
    });

    const secretCode = keySecretCodeData?.value;

    if (!apiUrl || !secretCode) {
      return null;
    }

    // Transform cart items to promotion format
    const promotionCartItems: PromotionCartItem[] = cartItems
      .filter((item) => item.productId)
      .map((item) => ({
        productId: item.productId?.toString() || "",
        productCode: item.code || "",
        productName: item.name || "",
        productBatch: item.batch || "",
        manufacturerId: item.hangSanXuat?.toString() || "",
        expDate: item.expDate
          ? new Date(item.expDate).toISOString().split("T")[0]
          : "2999-01-01",
        quantity: item.quantity || 1,
        price: item.price || 0,
      }));

    const request: PromotionRequest = {
      facID: facId,
      centerName: centerName,
      employeeType: employeeType,
      employeeCode: employeeCode,
      stockName: stockName,
      customerCode: customerCode,
      customerPhone: customerPhone,
      customerName: customerName,
      customerType: customerType,
      customerTier: customerTier,
      cartItems: promotionCartItems,
      currentTotalAmount: currentTotalAmount,
      currentTotalQuantity: currentTotalQuantity,
    };

    const response = await fetch(`${apiUrl}/ShopPromotion/CheckApplicable`, {
      method: "POST",
      headers: {
        accept: "*/*",
        SECRETCODE: secretCode,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(request),
    });

    if (!response.ok) {
      logger.error(`Promotion API error: ${response.status}`);
      return null;
    }

    const responseData: PromotionResponse = await response.json();

    if (!responseData.success) {
      logger.error("Promotion API returned unsuccessful response");
      return null;
    }

    return responseData;
  } catch (error) {
    logger.error("Error checking promotion applicable", error);
    return null;
  }
};
