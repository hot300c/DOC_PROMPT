"use client";

import { QAHOSGENERICDB } from "@/app/lib/enums";
import { logger } from "@/app/lib/logger";
import { post } from "@/app/lib/network/http";
import {
  CustomerDetailsModel,
  CustomerModel,
} from "@/app/(main)/cua-hang/_models/customer-model";

export const getCustomerInfoById = async (
  customerId: string,
): Promise<CustomerDetailsModel | undefined> => {
  try {
    const response = await post("/DataAccess", [
      {
        category: QAHOSGENERICDB,
        command: "ws_MDM_Patient_GetByMaKHOnSiteShop",
        parameters: {
          PatientHospitalID: customerId,
        },
      },
    ]);
    return response.data.table[0];
  } catch (error) {
    logger.error("ws_MDM_Patient_GetByMaKHOnSiteShop", error);
  }
};

export const getCustomerInfoByPhoneNumber = async (
  phoneNumber: string,
  facId: string,
): Promise<CustomerModel[]> => {
  try {
    const response = await post("/DataAccess", [
      {
        category: QAHOSGENERICDB,
        command: "ws_MDM_Patient_GetByPhoneOnSiteShop",
        parameters: {
          Phone: phoneNumber,
          FacID: facId,
        },
      },
    ]);
    return response.data.table;
  } catch (error) {
    logger.error("ws_MDM_Patient_GetByMaKHOnSiteShop", error);
    return [];
  }
};
