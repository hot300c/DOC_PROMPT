"use client";

import {
  DATE_FORMAT,
  QAHOSGENERICDB,
  RevenueTabType,
  RevenueTabTypeToNumber,
} from "@/app/lib/enums";
import { Receipt } from "../_models/recept-model";
import { notifyError } from "@/app/lib/utils";
import { post } from "@/app/lib/network/http";
import { format } from "date-fns";

export const getBillData = async (
  facID: string,
  fromDate: Date,
  toDate: Date,
  receiptType: RevenueTabType,
): Promise<Receipt[]> => {
  try {
    // Validate date range
    if (!fromDate || !toDate) {
      notifyError("Từ ngày đến ngày không được rỗng");
      return [];
    }

    if (toDate < fromDate) {
      notifyError("Đến ngày không được nhỏ hơn từ ngày");
      return [];
    }

    const response = await post("/DataAccess", [
      {
        category: QAHOSGENERICDB,
        command: "ws_BIL_InvoiceBusiness_GetDoanhThuByNgay_Genie",
        parameters: {
          facID,
          fromDate: format(fromDate, DATE_FORMAT.YYYYMMDD_AS_INT),
          thruDate: format(toDate, DATE_FORMAT.YYYYMMDD_AS_INT),
          LoaiPhieu: RevenueTabTypeToNumber[receiptType],
        },
      },
    ]);

    return response.data.table || [];
  } catch (error) {
    console.log(`Failed to get bill data for type: ${receiptType}`, error);
    notifyError(
      "Có lỗi xảy ra trong quá trình lấy dữ liệu, chi tiết: " + error,
    );
    return [];
  }
};
