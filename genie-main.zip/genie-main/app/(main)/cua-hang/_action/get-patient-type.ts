"use client";
import { L_Doituongtinhtien } from "@/app/lib/definitions/patient";
import * as ServiceAdmission from "@/app/lib/services/patient";

export const fetchDoiTuongTinhTienDataAltListData = async (): Promise<
  L_Doituongtinhtien[]
> => {
  const payload = {
    category: "QAHosGenericDB",
    command: "ws_L_DoiTuongTinhTien_List",
    parameters: {},
  };
  const rspData = await ServiceAdmission.fetch_ws_Get_Parameter(payload);
  return (rspData || []) as L_Doituongtinhtien[];
};
