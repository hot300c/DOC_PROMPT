"use client";
import { QAHOSGENERICDB } from "@/app/lib/enums";
import { logger } from "@/app/lib/logger";
import { post } from "@/app/lib/network/http";

interface ActivateItemParams {
  code: string;
  productId?: string;
  invoiceId: string;
  invoiceDetailId?: string;
}

export const activatePurchasedItem = async (
  dataRow: ActivateItemParams,
  customerPhone: string,
  data: { status: string; message?: string },
): Promise<boolean> => {
  try {
    // Log the activation attempt
    await post("/DataAccess", [
      {
        category: QAHOSGENERICDB,
        command: "ws_CN_ScratchcardSaled_Log_Save",
        parameters: {
          Mathe: dataRow.code,
          Phone: customerPhone,
          ProductID: dataRow.productId || "",
          TrangThai: data.status,
          TinNhan: data.status === "1" ? "Thành công" : data.message,
          responseString: JSON.stringify(data),
        },
      },
    ]);

    if (data.status === "1") {
      // Success - Update database records
      await post("/DataAccess", [
        {
          category: QAHOSGENERICDB,
          command: "ws_CN_ScratchcardSaled_Save",
          parameters: {
            Mathe: dataRow.code,
            Phone: customerPhone,
            ProductID: dataRow.productId || "",
            InvoiceID: dataRow.invoiceId,
            TrangThai: 1,
          },
        },
      ]);

      // Update invoice business detail with serial
      await post("/DataAccess", [
        {
          category: QAHOSGENERICDB,
          command: "ws_BIL_InvoiceBusinessDetail_UpdateSerial",
          parameters: {
            InvoiceBusinessID: dataRow.invoiceId,
            InvoiceBusinessDetailID: dataRow.invoiceDetailId || "",
            Mathe: dataRow.code,
          },
        },
      ]);

      return true;
    }

    return false;
  } catch (error) {
    logger.error("activatePurchasedItem", error);
    return false;
  }
};
