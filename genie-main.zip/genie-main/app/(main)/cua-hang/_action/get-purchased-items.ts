"use client";
import { QAHOSGENERICDB } from "@/app/lib/enums";
import { logger } from "@/app/lib/logger";
import { post } from "@/app/lib/network/http";
import { PurchasedItemModel } from "@/app/(main)/cua-hang/_models/purchased-item-model";

export const getPurchasedItems = async (
  facId: string,
  invoiceBusinessID: string,
): Promise<PurchasedItemModel[]> => {
  try {
    const response = await post("/DataAccess", [
      {
        category: QAHOSGENERICDB,
        command: "ws_BIL_InvoiceBusinessDetail_GetBienLaiBanLe_Genie",
        parameters: {
          InvoiceBusinessID: invoiceBusinessID,
          FacID: facId,
        },
      },
    ]);
    return response.data.table;
  } catch (error) {
    logger.error("ws_BIL_InvoiceBusinessDetail_GetBienLaiBanLe_Genie", error);
    return [];
  }
};
