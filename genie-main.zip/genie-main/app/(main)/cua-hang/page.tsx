"use client";
import PointRedeemingTab from "@/app/(main)/cua-hang/_components/_point-redeeming-tab-related/point-redeeming-tab";
import SaleTab from "@/app/(main)/cua-hang/_components/_sale-tab-related/sale-tab";
import CounterSelectModal from "@/app/(main)/cua-hang/_components/counter-select-modal";
import ShopSelectModal from "@/app/(main)/cua-hang/_components/shop-select-modal";
import SummaryTab from "@/app/(main)/cua-hang/_components/summary-tab";
import { Counter } from "@/app/(main)/cua-hang/_models/counter-model";
import { Shop } from "@/app/(main)/cua-hang/_models/shop-model";
import { WorkShift } from "@/app/(main)/cua-hang/_models/work-shift-model";
import { PageName, StoreTabsEnum } from "@/app/lib/enums";
import { ModalPrintProvider } from "@/app/lib/modal-print-provider";
import FacilityInfo from "@/components/facilityInfo";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { StoreIcon } from "lucide-react";
import { useCallback, useEffect, useState } from "react";
import BillSoldTab from "./_components/bill-sold-tab";
import { useAppSelector } from "@/redux/store";
import { selectFaculty } from "@/redux/selectors";
import { getShopsByFacId } from "@/app/(main)/cua-hang/_action/get-shops";
import { QRCodeViewProvider } from "@/app/(main)/thanh-toan/_context/qr-code-view-context";

export default function StorePage() {
  const [storeTabs, setStoreTabs] = useState(StoreTabsEnum.SALES);

  const [isShopModalOpen, setIsShopModalOpen] = useState(false);
  const [isCounterModalOpen, setIsCounterModalOpen] = useState(false);
  const [
    isPointsRedeemingCounterModalOpen,
    setIsPointsRedeemingCounterModalOpen,
  ] = useState(false);
  const [shops, setShops] = useState<Shop[]>([]);
  const [selectedShop, setSelectedShop] = useState<Shop | undefined>(undefined);
  const [selectedStoreCounter, setSelectedStoreCounter] =
    useState<Counter | null>(null);
  const [selectedPointRedeemingCounter, setSelectedPointRedeemingCounter] =
    useState<Counter | null>(null);
  const [selectedStoreWorkShift, setSelectedStoreWorkShift] =
    useState<WorkShift | null>(null);
  const [selectedPointRedeemingWorkShift, setSelectedPointRedeemingWorkShift] =
    useState<WorkShift | null>(null);

  const faculty = useAppSelector(selectFaculty);

  const loadShops = useCallback(async () => {
    try {
      const shopsData = await getShopsByFacId(faculty.facId || "");
      if (shopsData.length === 1 && shopsData[0]) {
        setSelectedShop(shopsData[0]); // Set the first shop as selected by default
        localStorage.setItem("selectedShop", shopsData[0].shopTypeID);
      } else {
        const savedShop = localStorage.getItem("selectedShop");
        if (!!savedShop && shopsData.some((x) => x.shopTypeID === savedShop)) {
          try {
            setSelectedShop(shopsData.find((x) => x.shopTypeID === savedShop));
          } catch (e) {
            console.error("Failed to parse saved shop", e);
          }
        }
      }
      setShops(shopsData);
    } catch (error) {
      console.error("Failed to load shops:", error);
    }
  }, [faculty.facId]);

  const handleShopSelect = (shop: Shop) => {
    setSelectedShop(shop);
    // Save to localStorage for persistence
    localStorage.setItem("selectedShop", shop.shopTypeID);
  };

  useEffect(() => {
    void loadShops();
  }, [loadShops]);

  return (
    <QRCodeViewProvider>
      <ModalPrintProvider>
        <div className="h-full w-full overflow-hidden flex flex-col">
          <header className="w-full z-[49]">
            <FacilityInfo page={PageName.STORE} />
            <section
              className="bg-[#EDF0F5] text-primary-foreground p-4 flex items-center justify-between"
              id="general-info"
            >
              <Button
                variant="ghost"
                className="text-primary flex items-center gap-2 font-medium"
                onClick={() => setIsShopModalOpen(true)}
              >
                <StoreIcon size={18} />
                {selectedShop
                  ? selectedShop.shopTypeName
                  : "Chưa chọn cửa hàng"}
              </Button>

              <ShopSelectModal
                open={isShopModalOpen}
                shops={shops}
                onOpenChange={setIsShopModalOpen}
                onShopSelect={handleShopSelect}
              />

              <CounterSelectModal
                open={isCounterModalOpen}
                onOpenChange={setIsCounterModalOpen}
                onCounterSelect={setSelectedStoreCounter}
                onStoreWorkShiftSelect={setSelectedStoreWorkShift}
              />

              <CounterSelectModal
                open={isPointsRedeemingCounterModalOpen}
                onOpenChange={setIsPointsRedeemingCounterModalOpen}
                onCounterSelect={setSelectedPointRedeemingCounter}
                onStoreWorkShiftSelect={setSelectedPointRedeemingWorkShift}
              />
            </section>
          </header>
          <main className="flex-1 flex bg-light-blue overflow-hidden">
            <div
              className="flex flex-col flex-1 w-full overflow-hidden"
              id="operation-tabs"
            >
              <Tabs
                className="flex flex-col flex-1 w-full overflow-hidden"
                value={storeTabs}
                onValueChange={(value) => setStoreTabs(value as StoreTabsEnum)}
              >
                <TabsList className="justify-start bg-white">
                  <TabsTrigger value={StoreTabsEnum.SALES} id="sales">
                    {StoreTabsEnum.SALES.toString()}
                  </TabsTrigger>
                  <TabsTrigger
                    value={StoreTabsEnum.POINTS_REDEMPTION}
                    id={"points-redemption"}
                  >
                    {StoreTabsEnum.POINTS_REDEMPTION.toString()}
                  </TabsTrigger>
                  <TabsTrigger
                    value={StoreTabsEnum.SOLD_ORDERS}
                    id={"sold-orders"}
                  >
                    {StoreTabsEnum.SOLD_ORDERS.toString()}
                  </TabsTrigger>
                  <TabsTrigger value={StoreTabsEnum.REVENUE_DETAILS}>
                    {StoreTabsEnum.REVENUE_DETAILS.toString()}
                  </TabsTrigger>
                  <TabsTrigger value={StoreTabsEnum.EXCHANGED_ORDERS}>
                    {StoreTabsEnum.EXCHANGED_ORDERS.toString()}
                  </TabsTrigger>
                </TabsList>
                <TabsContent
                  value={StoreTabsEnum.SALES}
                  className="flex-1 overflow-hidden w-full h-full"
                >
                  <SaleTab
                    selectedShopTypeId={selectedShop?.shopTypeID || ""}
                    selectedCounter={selectedStoreCounter}
                    setIsCounterModalOpen={setIsCounterModalOpen}
                    selectedStoreWorkShift={selectedStoreWorkShift}
                  />
                </TabsContent>
                <TabsContent
                  value={StoreTabsEnum.POINTS_REDEMPTION}
                  className="flex-1 overflow-hidden w-full"
                >
                  <PointRedeemingTab
                    selectedShopTypeId={selectedShop?.shopTypeID || ""}
                    selectedCounter={selectedPointRedeemingCounter}
                    setIsCounterModalOpen={setIsPointsRedeemingCounterModalOpen}
                    selectedStoreWorkShift={selectedPointRedeemingWorkShift}
                  />
                </TabsContent>
                <TabsContent
                  value={StoreTabsEnum.SOLD_ORDERS}
                  className="flex-1 overflow-hidden w-full"
                  forceMount
                  hidden={storeTabs != StoreTabsEnum.SOLD_ORDERS}
                >
                  <BillSoldTab />
                </TabsContent>
                <TabsContent
                  value={StoreTabsEnum.REVENUE_DETAILS}
                  className="flex-1 overflow-hidden w-full"
                >
                  <SummaryTab />
                </TabsContent>
                <TabsContent
                  value={StoreTabsEnum.EXCHANGED_ORDERS}
                  className="flex-1 overflow-hidden w-full"
                  forceMount
                  hidden={storeTabs != StoreTabsEnum.EXCHANGED_ORDERS}
                >
                  <BillSoldTab isExchangePoint={true} />
                </TabsContent>
              </Tabs>
            </div>
          </main>
        </div>
      </ModalPrintProvider>
    </QRCodeViewProvider>
  );
}
