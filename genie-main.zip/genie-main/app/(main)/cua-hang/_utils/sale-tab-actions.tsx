"use client";

import {
  getLocalIPv4,
  getMacAddresses,
  GUID_NewSequential,
} from "@/app/lib/utils";
import { CartItem } from "../_models/cart-model";

/**
 * Build request object for direct payment method (transfer, cash, etc.)
 */
export function savePaymentMethodRequests(
  paymentMethod: string,
  invoiceId: string,
  total: number,
  totalDiscount: number,
  patientId: string,
  cardCode: string,
  facId: string,
  counterId: string,
  shiftDailyId: string,
  qaPayCardNumber: string = "",
  invoicePaymentId: string,
) {
  const realTotal = total - totalDiscount;
  const roundedTotal = Math.round(total);

  const commonParams = {
    FacID: facId,
    InvoiceID_Group: invoiceId,
    PatientID: patientId,
    Total: roundedTotal.toString(),
    RealTotal: realTotal.toString(),
    CounterID: counterId,
    Reason: "Thu tiền",
    IPUser: getLocalIPv4(),
    MacAddressUser: getMacAddresses(),
    ShiftDailyID: shiftDailyId,
  };

  switch (paymentMethod) {
    case "1": // Bank Transfer
      return {
        category: "QAHosGenericDB",
        command: "ws_BIL_InvoiceBusiness_Transfer_Save",
        parameters: {
          ...commonParams,
          Invoice_Transfer_ID: invoicePaymentId,
          SoTK: cardCode,
          HinhThucThanhToan: "Chuyển khoản",
        },
      };

    case "2": // Cash
      return {
        category: "QAHosGenericDB",
        command: "ws_BIL_InvoiceBusiness_Cash_Save",
        parameters: {
          ...commonParams,
          Invoice_Cash_ID: invoicePaymentId,
          HinhThucThanhToan: "Tiền mặt",
        },
      };

    case "3": // Card
      return {
        category: "QAHosGenericDB",
        command: "ws_BIL_InvoiceBusiness_Credit_Save_Genie",
        parameters: {
          ...commonParams,
          Invoice_Credit_ID: invoicePaymentId,
          HinhThucThanhToan: "Thẻ",
          SoTK: cardCode,
        },
      };

    case "4": // Other
      return {
        category: "QAHosGenericDB",
        command: "ws_BIL_InvoiceBusiness_Other_Save",
        parameters: {
          ...commonParams,
          Invoice_Other_ID: invoicePaymentId,
          HinhThucThanhToan: "Khác",
        },
      };

    case "5": // Voucher
      return {
        category: "QAHosGenericDB",
        command: "ws_BIL_InvoiceBusiness_Voucher_Save_Genie",
        parameters: {
          ...commonParams,
          Invoice_Voucher_ID: invoicePaymentId,
          VoucherCode: cardCode,
          HinhThucThanhToan: "Voucher",
        },
      };

    case "6": // QAPAY
      return {
        category: "QAHosGenericDB",
        command: "ws_BIL_InvoiceBusiness_QAPAY_Save",
        parameters: {
          ...commonParams,
          Invoice_QAPAY_ID: invoicePaymentId,
          Reason: "VNVC Point thu tiền",
          HinhThucThanhToan: "VNVC Point",
          SoTK: qaPayCardNumber || cardCode,
        },
      };

    case "12": // Credit Card
      return {
        category: "QAHosGenericDB",
        command: "ws_BIL_InvoiceBusiness_Credit_Save_Genie",
        parameters: {
          ...commonParams,
          Invoice_Credit_ID: invoicePaymentId,
          HinhThucThanhToan: "Thẻ tín dụng",
          SoTK: cardCode,
        },
      };

    case "15": // Techcombank
      return {
        category: "QAHosGenericDB",
        command: "ws_BIL_InvoiceBusiness_Credit_Save_Genie",
        parameters: {
          ...commonParams,
          Invoice_Credit_ID: invoicePaymentId,
          HinhThucThanhToan: "Techcombank",
          SoTK: cardCode,
        },
      };

    default:
      throw new Error("Phương thức thanh toán chưa được hỗ trợ!");
  }
}

/**
 * Build request object for *Temp* payment method usage (the “temp” versions).
 */
export function savePaymentMethodTempRequests(
  paymentMethod: string,
  invoiceId: string,
  total: number,
  totalDiscount: number,
  patientId: string,
  cardCode: string,
  facId: string,
  counterId: string,
  shiftDailyId: string,
  qaPayCardNumber: string = "",
  invoicePaymentId: string,
) {
  const realTotal = total - totalDiscount;
  const roundedTotal = Math.round(total);

  const commonParams = {
    FacID: facId,
    InvoiceID_Group: invoiceId,
    PatientID: patientId,
    Total: roundedTotal.toString(),
    RealTotal: realTotal.toString(),
    CounterID: counterId,
    Reason: "Thu tiền",
    IPUser: getLocalIPv4(),
    MacAddressUser: getMacAddresses(),
    ShiftDailyID: shiftDailyId,
  };

  switch (paymentMethod) {
    case "1": // Bank Transfer
      return {
        category: "QAHosGenericDB",
        command: "ws_BIL_InvoiceBusiness_Temp_Transfer_Save",
        parameters: {
          ...commonParams,
          Invoice_Transfer_ID: invoicePaymentId,
          SoTK: cardCode,
          HinhThucThanhToan: "Chuyển khoản",
        },
      };

    case "2": // Cash
      return {
        category: "QAHosGenericDB",
        command: "ws_BIL_InvoiceBusiness_Temp_Cash_Save",
        parameters: {
          ...commonParams,
          Invoice_Cash_ID: invoicePaymentId,
          HinhThucThanhToan: "Tiền mặt",
        },
      };

    case "3": // Card
      return {
        category: "QAHosGenericDB",
        command: "ws_BIL_InvoiceBusiness_Temp_Credit_Save_Genie",
        parameters: {
          ...commonParams,
          Invoice_Credit_ID: invoicePaymentId,
          HinhThucThanhToan: "Thẻ",
          SoTK: cardCode,
        },
      };

    case "4": // Other
      return {
        category: "QAHosGenericDB",
        command: "ws_BIL_InvoiceBusiness_Temp_Other_Save",
        parameters: {
          ...commonParams,
          Invoice_Other_ID: invoicePaymentId,
          HinhThucThanhToan: "Khác",
        },
      };

    case "5": // Voucher
      return {
        category: "QAHosGenericDB",
        command: "ws_BIL_InvoiceBusiness_Temp_Voucher_Save_Genie",
        parameters: {
          ...commonParams,
          Invoice_Voucher_ID: invoicePaymentId,
          VoucherCode: cardCode,
          HinhThucThanhToan: "Voucher",
        },
      };

    case "6": // QAPAY
      return {
        category: "QAHosGenericDB",
        command: "ws_BIL_InvoiceBusiness_Temp_QAPAY_Save",
        parameters: {
          ...commonParams,
          Invoice_QAPAY_ID: invoicePaymentId,
          Reason: "VNVC Point thu tiền",
          HinhThucThanhToan: "VNVC Point",
          SoTK: qaPayCardNumber || cardCode,
        },
      };

    case "12": // Credit Card
      return {
        category: "QAHosGenericDB",
        command: "ws_BIL_InvoiceBusiness_Temp_Credit_Save_Genie",
        parameters: {
          ...commonParams,
          Invoice_Credit_ID: invoicePaymentId,
          HinhThucThanhToan: "Thẻ tín dụng",
          SoTK: cardCode,
        },
      };

    case "15": // Techcombank
      return {
        category: "QAHosGenericDB",
        command: "ws_BIL_InvoiceBusiness_Temp_Credit_Save_Genie",
        parameters: {
          ...commonParams,
          Invoice_Credit_ID: invoicePaymentId,
          HinhThucThanhToan: "Techcombank",
          SoTK: cardCode,
        },
      };

    default:
      throw new Error("Phương thức thanh toán chưa được hỗ trợ!");
  }
}

interface InvoiceParams {
  invoiceId: string;
  customerId: string;
  customerName: string;
  customerAddress: string;
  customerPhone: string;
  customerEmail: string;
  customerGender: string;
  customerBirthYear: string;
  facId: string;
  counterId: string;
  note: string;
  shiftDailyId: string;
  paymentMethodName?: string;
  stockId?: number;
  stockName?: string;
}

export function buildInvoiceDetailRequests(
  cartItems: CartItem[],
  invoiceId: string,
  facId: string,
  customerId: string,
  customerPhone: string,
) {
  const invoiceDetailRequests: any[] = [];
  const tempDataRequest: any[] = [];
  let totalBeforeTax = 0;
  let totalDiscount = 0;

  cartItems.forEach((item) => {
    const invoiceDetailId = GUID_NewSequential();
    const quantity = item.quantity;
    const price = item.price;
    const afterDiscount = item.thanhTienSauCK;
    const beforeDiscount = item.thanhTienTruocCK;
    const discountAmt = beforeDiscount - afterDiscount;

    const detailParams = {
      FacID: facId,
      InvoiceBusinessDetailID: invoiceDetailId,
      InvoiceBusinessID: invoiceId,
      PatientID: customerId,
      ProductID: item.productId,
      Qty: quantity.toString(),
      Price: price.toString(),
      PatientPay: afterDiscount.toString(),
      TienGiam: discountAmt.toString(),
      PhanTramCK: item.discountPercent,
      Serial: item.serialNo || "",
      SoDT: customerPhone,
      StockID: item.stockId,
      TenChinhSach: item.tenChinhSach || "",
      Batch: item.batch,
      ExpDate: item.expDate,
      ProductName: item.name,
    };

    // Build detail request
    invoiceDetailRequests.push({
      category: "QAHosGenericDB",
      command: "ws_BIL_InvoiceBusinessDetail_Save_Genie",
      parameters: { ...detailParams, Reason: item.reason || "" },
    });

    // "Temp" requests
    tempDataRequest.push({
      category: "QAHosGenericDB",
      command: "ws_BIL_InvoiceBusinessDetail_Temp_Save_Genie",
      parameters: { ...detailParams, Reason: item.reason || "" },
    });

    tempDataRequest.push({
      category: "QAHosGenericDB",
      command: "ws_BIL_InvoiceBusinessDetail_TempForHinhThucThanhToan_Save",
      parameters: {
        ...detailParams,
        TenChinhSach: undefined, // Remove unused param
        Batch: undefined,
        ExpDate: undefined,
      },
    });

    totalBeforeTax += beforeDiscount;
    totalDiscount += discountAmt;
  });

  return {
    invoiceDetailRequests,
    tempDataRequest,
    totalBeforeTax,
    totalDiscount,
  };
}

export function buildInvoiceHeaderRequest(
  params: InvoiceParams,
  totalBeforeTax: number,
  totalDiscount: number,
) {
  return {
    category: "QAHosGenericDB",
    command: "ws_BIL_InvoiceBusiness_SaveOnSiteShop_Genie",
    parameters: {
      InvoiceBusinessID: params.invoiceId,
      PatientID: params.customerId,
      FacID: params.facId,
      TenKhachHang: params.customerName,
      DiaChi: params.customerAddress,
      Phone: params.customerPhone,
      GioiTinh: params.customerGender,
      NamSinh: params.customerBirthYear,
      CounterID: params.counterId,
      ShiftDailyID: params.shiftDailyId,
      shiftName: "",
      Note: params.note,
      RealTotal: (totalBeforeTax - totalDiscount).toString(),
      StockID: params.stockId,
      StockName: params.stockName,
      Email: params.customerEmail,
    },
  };
}

export function buildInvoiceTempRequests(
  params: InvoiceParams,
  totalBeforeTax: number,
  totalDiscount: number,
) {
  const tempRequests = [];

  tempRequests.push({
    category: "QAHosGenericDB",
    command: "ws_BIL_InvoiceBusiness_Temp_SaveOnSiteShop_Genie",
    parameters: {
      InvoiceBusinessID: params.invoiceId,
      PatientID: params.customerId,
      FacID: params.facId,
      TenKhachHang: params.customerName,
      DiaChi: params.customerAddress,
      Phone: params.customerPhone,
      GioiTinh: params.customerGender,
      NamSinh: params.customerBirthYear,
      CounterID: params.counterId,
      ShiftDailyID: params.shiftDailyId,
      shiftName: "",
      Note: params.note,
      RealTotal: (totalBeforeTax - totalDiscount).toString(),
      StockID: params.stockId,
      StockName: params.stockName,
      Email: params.customerEmail,
    },
  });

  tempRequests.push({
    category: "QAHosGenericDB",
    command: "ws_BIL_InvoiceBusiness_TempForHinhThucThanhToan_SaveOnSiteShop",
    parameters: {
      InvoiceBusinessID: params.invoiceId,
      PatientID: params.customerId,
      FacID: params.facId,
      TenKhachHang: params.customerName,
      DiaChi: params.customerAddress,
      Phone: params.customerPhone,
      CounterID: params.counterId,
      ShiftDailyID: params.shiftDailyId,
      shiftName: "",
      RealTotal: (totalBeforeTax - totalDiscount).toString(),
      HinhThucThanhToan: params.paymentMethodName,
    },
  });

  return tempRequests;
}

export function buildInventoryOutputRequest(
  params: InvoiceParams,
  cartItems: CartItem[],
) {
  cartItems = cartItems.filter((item) => item.productId);
  return {
    category: "QAHosGenericDB",
    command: "ws_INV_ApprovedOut_XuatBienLaiBanLe_Genie",
    parameters: {
      FacID: params.facId,
      InvoiceBusinessID: params.invoiceId,
      PatientID: params.customerId,
      TenKhachHang: params.customerName,
      DiaChi: params.customerAddress,
      Phone: params.customerPhone,
      ProductIDs: cartItems.map((it) => it.productId).join("|"),
      Qtys: cartItems.map((it) => it.quantity).join("|"),
      Prices: cartItems.map((it) => it.price).join("|"),
      PatientPays: cartItems.map((it) => it.thanhTienSauCK).join("|"),
      TienGiams: cartItems
        .map((it) => it.thanhTienTruocCK - it.thanhTienSauCK)
        .join("|"),
      PhanTramGiams: cartItems.map((it) => it.discountPercent || 0).join("|"),
      KhoXuatIDs: cartItems.map((it) => it.stockId).join("|"),
      PhuongPhapXuats: cartItems.map(() => "3").join("|"),
      InputBatches: cartItems.map((it) => it.batch).join("|"),
      OutType: 5,
      CounterID: params.counterId,
      ShiftDailyID: params.shiftDailyId,
      Notes: "Xuất biên lai bán lẻ ws_INV_ApprovedOut_XuatBienLaiBanLe",
    },
  };
}
