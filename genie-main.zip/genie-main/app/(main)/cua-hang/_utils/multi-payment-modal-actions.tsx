import { InvoiceItem } from "@/app/(main)/cua-hang/_models/bill-model";
import { CartItem } from "@/app/(main)/cua-hang/_models/cart-model";
import { PaperSize, QAHOSGENERICDB } from "@/app/lib/enums";
import * as utils from "@/app/lib/utils";
import { getLocalIPv4, getMacAddresses, notifyError } from "@/app/lib/utils";
import { Guid } from "js-guid";
import { PaymentRecord } from "../_models/payment-record-model";

// Interface for common parameters
interface CommonParams {
  facId: string;
  invoiceId: string;
  patientId: string;
  totalAmount: number;
  amount: number;
  counterId?: number;
  shiftDailyId?: string;
}

// Generate common request parameters
export const createCommonParams = ({
  facId,
  invoiceId,
  patientId,
  totalAmount,
  amount,
  counterId,
  shiftDailyId,
}: CommonParams) => {
  return {
    FacID: facId,
    InvoiceID_Group: invoiceId,
    PatientID: patientId,
    Total: totalAmount.toString(),
    RealTotal: amount.toString(),
    CounterID: counterId,
    Reason: "Thu tiền",
    IPUser: getLocalIPv4(),
    MacAddressUser: getMacAddresses(),
    ShiftDailyID: shiftDailyId,
  };
};

// Create bank transfer request
export const createBankTransferRequest = (
  commonParams: ReturnType<typeof createCommonParams>,
  paymentId: string,
  cardNumber: string,
  isTemp: boolean,
) => ({
  category: QAHOSGENERICDB,
  command: isTemp
    ? "ws_BIL_InvoiceBusiness_Temp_Transfer_Save"
    : "ws_BIL_InvoiceBusiness_Transfer_Save",
  parameters: {
    ...commonParams,
    Invoice_Transfer_ID: paymentId,
    SoTK: cardNumber,
    HinhThucThanhToan: "Chuyển khoản",
  },
});

// Create cash payment request
export const createCashRequest = (
  commonParams: ReturnType<typeof createCommonParams>,
  paymentId: string,
  isTemp: boolean,
) => ({
  category: QAHOSGENERICDB,
  command: isTemp
    ? "ws_BIL_InvoiceBusiness_Temp_Cash_Save"
    : "ws_BIL_InvoiceBusiness_Cash_Save",
  parameters: {
    ...commonParams,
    Invoice_Cash_ID: paymentId,
    HinhThucThanhToan: "Tiền mặt",
  },
});

// Create card payment request
export const createCardRequest = (
  commonParams: ReturnType<typeof createCommonParams>,
  paymentId: string,
  cardNumber: string,
  isTemp: boolean,
) => ({
  category: QAHOSGENERICDB,
  command: isTemp
    ? "ws_BIL_InvoiceBusiness_Temp_Credit_Save_Genie"
    : "ws_BIL_InvoiceBusiness_Credit_Save_Genie",
  parameters: {
    ...commonParams,
    Invoice_Credit_ID: paymentId,
    SoTK: cardNumber,
    HinhThucThanhToan: "Thẻ",
  },
});

// Create Techcombank payment request
export const createTechcombankRequest = (
  commonParams: ReturnType<typeof createCommonParams>,
  paymentId: string,
  isTemp: boolean,
) => ({
  category: QAHOSGENERICDB,
  command: isTemp
    ? "ws_BIL_InvoiceBusiness_Temp_Credit_Save_Genie"
    : "ws_BIL_InvoiceBusiness_Credit_Save_Genie",
  parameters: {
    ...commonParams,
    Invoice_Credit_ID: paymentId,
    SoTK: "",
    HinhThucThanhToan: "Techcombank",
  },
});

// Tạo hình thức thanh toán Other
export const createOtherRequest = (
  commonParams: ReturnType<typeof createCommonParams>,
  paymentId: string,
  isTemp: boolean,
) => ({
  category: QAHOSGENERICDB,
  command: isTemp
    ? "ws_BIL_InvoiceBusiness_Temp_Other_Save"
    : "ws_BIL_InvoiceBusiness_Other_Save",
  parameters: {
    ...commonParams,
    Invoice_Other_ID: paymentId,
    HinhThucThanhToan: "Khác",
  },
});

// Create voucher payment request
export const createVoucherRequest = (
  commonParams: ReturnType<typeof createCommonParams>,
  paymentId: string,
  voucherCode: string,
  isTemp: boolean,
) => ({
  category: QAHOSGENERICDB,
  command: isTemp
    ? "ws_BIL_InvoiceBusiness_Temp_Voucher_Save_Genie"
    : "ws_BIL_InvoiceBusiness_Voucher_Save_Genie",
  parameters: {
    ...commonParams,
    Invoice_Voucher_ID: paymentId,
    VoucherCode: voucherCode,
    HinhThucThanhToan: "Voucher",
  },
});

// Create QA Pay request
export const createQaPayRequest = (
  commonParams: ReturnType<typeof createCommonParams>,
  paymentId: string,
  cardNumber: string,
  isTemp: boolean,
) => ({
  category: QAHOSGENERICDB,
  command: isTemp
    ? "ws_BIL_InvoiceBusiness_Temp_QAPAY_Save"
    : "ws_BIL_InvoiceBusiness_QAPAY_Save",
  parameters: {
    ...commonParams,
    Invoice_QAPAY_ID: paymentId,
    Reason: "VNVC Point thu tiền",
    HinhThucThanhToan: "VNVC Point",
    SoTK: cardNumber,
  },
});

// Create credit card request
export const createCreditCardRequest = (
  commonParams: ReturnType<typeof createCommonParams>,
  paymentId: string,
  cardNumber: string,
  isTemp: boolean,
) => ({
  category: QAHOSGENERICDB,
  command: isTemp
    ? "ws_BIL_InvoiceBusiness_Temp_Credit_Save_Genie"
    : "ws_BIL_InvoiceBusiness_Credit_Save_Genie",
  parameters: {
    ...commonParams,
    Invoice_Credit_ID: paymentId,
    SoTK: cardNumber,
    HinhThucThanhToan: "Thẻ tín dụng",
  },
});

// Main function to create payment requests based on method ID
export const createPaymentRequests = (
  paymentMethodId: string,
  payment: PaymentRecord,
  invoiceId: string,
  totalAmount: number,
  amount: number,
  invoiceHinhThucThanhToanId: string,
  isTemp: boolean,
  facId: string,
  counterId?: number,
  shiftDailyId?: string,
  patientId?: string,
) => {
  const paymentId = invoiceHinhThucThanhToanId || Guid.newGuid().toString();

  const commonParams = createCommonParams({
    facId,
    invoiceId,
    patientId: patientId || "",
    totalAmount,
    amount,
    counterId,
    shiftDailyId,
  });

  const requests = [];

  // Switch based on payment method ID
  switch (paymentMethodId) {
    // Bank Transfer
    case "1":
      requests.push(
        createBankTransferRequest(
          commonParams,
          paymentId,
          payment.cardNumber || "",
          isTemp,
        ),
      );
      break;

    // Cash
    case "2":
      requests.push(createCashRequest(commonParams, paymentId, isTemp));
      break;

    // Card
    case "3":
      requests.push(
        createCardRequest(
          commonParams,
          paymentId,
          payment.cardNumber || "",
          isTemp,
        ),
      );
      break;

    // Other
    case "4":
      requests.push(createOtherRequest(commonParams, paymentId, isTemp));
      break;

    // Voucher
    case "5":
      requests.push(
        createVoucherRequest(
          commonParams,
          paymentId,
          payment.voucherCode || "",
          isTemp,
        ),
      );
      break;

    // QAPAY
    case "6":
      requests.push(
        createQaPayRequest(
          commonParams,
          paymentId,
          payment.cardNumber || "",
          isTemp,
        ),
      );
      break;

    case "12": // Credit Card
      requests.push(
        createCreditCardRequest(
          commonParams,
          paymentId,
          payment.cardNumber || "",
          isTemp,
        ),
      );
      break;

    case "15": // Techcombank
      requests.push(createTechcombankRequest(commonParams, paymentId, isTemp));
      break;

    default:
      console.warn(`Unsupported payment method ID: ${paymentMethodId}`);
      notifyError("Phương thức thanh toán chưa được hỗ trợ.");
      break;
  }

  return { requests, paymentId };
};

export const createInvoiceDetailQueries = (
  cartItems: CartItem[],
  newInvoiceId: string,
  facId: string,
  customerId: string,
  customerPhone: string,
) => {
  return cartItems.map((item) => {
    const detailId = item.invoiceDetailId || Guid.newGuid().toString();
    const quantity = item.quantity || 0;
    const price = item.price || 0;
    const discountPercent = item.discountPercent || 0;
    const amountAfterDiscount = item.thanhTienSauCK || 0;

    return {
      category: QAHOSGENERICDB,
      command: "ws_BIL_InvoiceBusinessDetail_Save_Genie",
      parameters: {
        FacID: facId,
        InvoiceBusinessDetailID: detailId,
        InvoiceBusinessID: newInvoiceId,
        PatientID: customerId || "",
        ProductID: item.productId,
        Qty: quantity.toString(),
        Price: price.toString(),
        PatientPay: amountAfterDiscount.toString(),
        TienGiam: (quantity * price - amountAfterDiscount).toString(),
        PhanTramCK: discountPercent.toString(),
        Serial: item.serialNo || "",
        SoDT: customerPhone || "",
        StockID: item.stockId || "",
        Batch: item.batch || "",
        ExpDate: item.expDate,
        Reason: item.reason || "",
        ProductName: item.name,
        TenChinhSach: item.tenChinhSach || "",
      },
    };
  });
};

// Create invoice detail requests for temporary storage
export const createTempInvoiceDetailRequests = (
  cartItems: CartItem[],
  newInvoiceId: string,
  facId: string,
  customerId: string,
  customerPhone: string,
) => {
  return cartItems.map((item) => {
    const detailId = item.invoiceDetailId || Guid.newGuid().toString();
    const quantity = item.quantity || 0;
    const price = item.price || 0;
    const discountPercent = item.discountPercent || 0;
    const amountAfterDiscount = item.thanhTienSauCK || 0;

    return {
      category: QAHOSGENERICDB,
      command: "ws_BIL_InvoiceBusinessDetail_TempForHinhThucThanhToan_Save",
      parameters: {
        FacID: facId,
        InvoiceBusinessDetailID: detailId,
        InvoiceBusinessID: newInvoiceId,
        PatientID: customerId || "",
        ProductID: item.productId,
        Qty: quantity.toString(),
        Price: price.toString(),
        PatientPay: amountAfterDiscount.toString(),
        TienGiam: (quantity * price - amountAfterDiscount).toString(),
        PhanTramCK: discountPercent.toString(),
        Serial: item.serialNo || "",
        SoDT: customerPhone || "",
        StockID: item.stockId || "",
        Batch: item.batch || "",
        ExpDate: item.expDate,
        ProductName: item.name,
      },
    };
  });
};

// Create invoice business query
export const createInvoiceBusinessQuery = (
  newInvoiceId: string,
  facId: string,
  invoiceParams: {
    customerId: string;
    customerName: string;
    customerAddress: string;
    customerPhone: string;
    customerGender: string;
    customerBirthYear: string;
    counterId: string;
    shiftDailyId: string;
    shiftName: string;
    note: string;
    stockId?: number;
    stockName?: string;
    email?: string;
  },
  totalAmount: number,
) => {
  return {
    category: QAHOSGENERICDB,
    command: "ws_BIL_InvoiceBusiness_SaveOnSiteShop_Genie",
    parameters: {
      InvoiceBusinessID: newInvoiceId,
      PatientID: invoiceParams.customerId || "",
      FacID: facId,
      TenKhachHang: invoiceParams.customerName || "",
      DiaChi: invoiceParams.customerAddress || "",
      Phone: invoiceParams.customerPhone || "",
      GioiTinh: invoiceParams.customerGender || "",
      NamSinh: invoiceParams.customerBirthYear || "",
      InvoiceNo: "",
      CounterID: invoiceParams.counterId || "",
      ShiftDailyID: invoiceParams.shiftDailyId || "",
      shiftName: invoiceParams.shiftName || "",
      RealTotal: totalAmount.toString(),
      StockID: invoiceParams.stockId,
      StockName: invoiceParams.stockName,
      Email: invoiceParams.email || "",
      Note: invoiceParams.note,
    },
  };
};

// Create invoice export query
export const createInvoiceExportQuery = (
  newInvoiceId: string,
  facId: string,
  invoiceParams: {
    customerId: string;
    customerName: string;
    customerAddress: string;
    customerPhone: string;
    counterId: string;
    shiftDailyId: string;
  },
  cartItems: CartItem[],
) => {
  cartItems = cartItems.filter((item) => item.productId);
  return {
    category: QAHOSGENERICDB,
    command: "ws_INV_ApprovedOut_XuatBienLaiBanLe_Genie",
    parameters: {
      FacID: facId,
      InvoiceBusinessID: newInvoiceId,
      PatientID: invoiceParams.customerId || "",
      TenKhachHang: invoiceParams.customerName || "",
      DiaChi: invoiceParams.customerAddress || "",
      Phone: invoiceParams.customerPhone || "",
      // Join arrays of values with | separator
      ProductIDs: cartItems.map((item) => item.productId).join("|"),
      Qtys: cartItems.map((item) => item.quantity.toString()).join("|"),
      Prices: cartItems.map((item) => item.price.toString()).join("|"),
      PatientPays: cartItems
        .map((item) => item.thanhTienSauCK.toString())
        .join("|"),
      InputBatches: cartItems.map((it) => it.batch).join("|"),
      TienGiams: cartItems
        .map((item) =>
          (item.price * item.quantity - item.thanhTienSauCK).toString(),
        )
        .join("|"),
      PhanTramGiams: cartItems
        .map((item) => (item.discountPercent || "0").toString())
        .join("|"),
      KhoXuatIDs: cartItems.map((item) => item.stockId || "").join("|"),
      PhuongPhapXuats: cartItems.map(() => "").join("|"),
      OutType: 5,
      CounterID: invoiceParams.counterId || "",
      ShiftDailyID: invoiceParams.shiftDailyId || "",
      Notes: "Xuất biên lai bán lẻ ws_INV_ApprovedOut_XuatBienLaiBanLe_Genie",
    },
  };
};

// Create invoice update query for multi-payment modal
export const createInvoiceUpdateQuery = (newInvoiceId: string) => {
  return {
    category: QAHOSGENERICDB,
    command: "ws_BilInvoicebusiness_UpdateInvoiceNo_Genie",
    parameters: {
      InvoiceID: newInvoiceId,
    },
  };
};

// Create temp invoice cleanup query
export const createTempInvoiceCleanupQuery = (newInvoiceId: string) => {
  return {
    category: QAHOSGENERICDB,
    command: "ws_BilInvoicebusiness_KTXoaBangTamPhuongThucThanhToan_Genie",
    parameters: {
      InvoiceID: newInvoiceId,
    },
  };
};

// Create temp invoice business request
export const createTempInvoiceBusinessRequest = (
  newInvoiceId: string,
  facId: string,
  invoiceParams: {
    customerId: string;
    customerName: string;
    customerAddress: string;
    customerPhone: string;
    customerGender: string;
    customerBirthYear: string;
    counterId: string;
    shiftDailyId: string;
    shiftName: string;
    email: string;
  },
  totalAmount: number,
  paymentMethodName: string,
) => {
  return {
    category: QAHOSGENERICDB,
    command: "ws_BIL_InvoiceBusiness_TempForHinhThucThanhToan_SaveOnSiteShop",
    parameters: {
      InvoiceBusinessID: newInvoiceId,
      PatientID: invoiceParams.customerId || "",
      FacID: facId,
      TenKhachHang: invoiceParams.customerName || "",
      DiaChi: invoiceParams.customerAddress || "",
      Phone: invoiceParams.customerPhone || "",
      GioiTinh: invoiceParams.customerGender || "",
      NamSinh: invoiceParams.customerBirthYear || "",
      CounterID: invoiceParams.counterId || "",
      ShiftDailyID: invoiceParams.shiftDailyId || "",
      shiftName: invoiceParams.shiftName || "",
      InvoiceNo: "",
      RealTotal: totalAmount.toString(),
      Email: invoiceParams.email,
      HinhThucThanhToan: paymentMethodName,
    },
  };
};

// Create payment requests for processing
export const createPaymentProcessingRequests = (
  payment: PaymentRecord,
  newInvoiceId: string,
  selectedInvoice: InvoiceItem | undefined,
  paymentMethodId: string,
  facId: string,
  invoiceParams: {
    customerId: string;
    customerName: string;
    customerAddress: string;
    customerPhone: string;
    customerGender: string;
    customerBirthYear: string;
    counterId: string;
    shiftDailyId: string;
    shiftName: string;
    note: string;
    stockId?: number;
    stockName?: string;
    email: string;
  },
  cartItems: CartItem[],
  isFullPayment: boolean,
) => {
  // Create collections for queries and requests
  const query: {
    category: string;
    command: string;
    parameters: any;
  }[] = [];
  const requests: {
    category: string;
    command: string;
    parameters: any;
  }[] = [];

  // Create payment method queries and requests
  const { requests: paymentRequests, paymentId } = createPaymentRequests(
    paymentMethodId,
    payment,
    newInvoiceId,
    payment.totalAmount,
    payment.amount,
    payment.invoiceHinhThucThanhToanId || "",
    true, // isTemp
    facId,
    invoiceParams.counterId ? parseInt(invoiceParams.counterId) : undefined,
    invoiceParams.shiftDailyId,
    invoiceParams.customerId,
  );

  const { requests: permanentPaymentRequests } = createPaymentRequests(
    paymentMethodId,
    payment,
    newInvoiceId,
    payment.totalAmount,
    payment.amount,
    payment.invoiceHinhThucThanhToanId || paymentId,
    false, // isTemp
    facId,
    invoiceParams.counterId ? parseInt(invoiceParams.counterId) : undefined,
    invoiceParams.shiftDailyId,
    invoiceParams.customerId,
  );

  if (permanentPaymentRequests?.length) {
    query.push(...permanentPaymentRequests);
  }

  if (paymentRequests?.length) {
    requests.push(...paymentRequests);
  }

  // Add temp invoice detail requests
  const tempInvoiceDetailRequests = createTempInvoiceDetailRequests(
    cartItems,
    newInvoiceId,
    facId,
    invoiceParams.customerId,
    invoiceParams.customerPhone,
  );
  requests.push(...tempInvoiceDetailRequests);

  // If full payment, add permanent invoice detail and business queries
  if (isFullPayment) {
    const invoiceDetailQueries = createInvoiceDetailQueries(
      cartItems,
      newInvoiceId,
      facId,
      invoiceParams.customerId,
      invoiceParams.customerPhone,
    );
    query.push(...invoiceDetailQueries);

    if (selectedInvoice) {
      // Add invoice business query
      const invoiceBusinessQuery = createInvoiceBusinessQuery(
        newInvoiceId,
        facId,
        invoiceParams,
        selectedInvoice.patientPay,
      );
      query.push(invoiceBusinessQuery);

      // Add invoice export query
      const invoiceExportQuery = createInvoiceExportQuery(
        newInvoiceId,
        facId,
        invoiceParams,
        cartItems,
      );
      query.push(invoiceExportQuery);
    }

    // Add invoice update query
    const invoiceUpdateQuery = createInvoiceUpdateQuery(newInvoiceId);
    query.push(invoiceUpdateQuery);
  }

  // Add temp invoice business request
  if (selectedInvoice) {
    const tempInvoiceBusinessRequest = createTempInvoiceBusinessRequest(
      newInvoiceId,
      facId,
      invoiceParams,
      selectedInvoice.patientPay,
      payment.paymentMethodName,
    );
    requests.push(tempInvoiceBusinessRequest);
  }

  return { query, requests, paymentId };
};

// Generate report parameters
export const generateReportParams = (
  newInvoiceId: string,
  facId: string,
  paymentId: string,
) => {
  return {
    InvoiceBusinessID: newInvoiceId,
    FacID: facId,
    Invoice_HinhThucThanhToan_ID: paymentId,
    IsTemp: 1,
  };
};

// Generate report parameters
export const generateSummaryReportParams = (
  newInvoiceId: string,
  facId: string,
) => {
  return {
    InvoiceBusinessID: newInvoiceId,
    FacID: facId,
  };
};

// Process the payment report
export const processPaymentReport = async (
  reportId: string,
  reportParams: any,
  baseSettings: any[],
) => {
  try {
    return await utils.handleBase64(
      reportId,
      reportParams.FacID,
      reportParams,
      baseSettings,
      true,
      PaperSize.A5,
    );
  } catch (error) {
    console.error("Error processing payment report:", error);
    return null;
  }
};

// Find payment method ID by name
export const findPaymentMethodId = (
  paymentMethods: any[],
  paymentMethodName: string,
) => {
  const method = paymentMethods.find((x) => x.ten === paymentMethodName);
  return method ? method.id.toString() : "";
};
