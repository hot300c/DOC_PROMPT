import { InvoiceItem } from "@/app/(main)/cua-hang/_models/bill-model";
import { formatCurrency } from "@/app/lib/utils";
import { Button } from "@/components/ui/button";
import { DataTableColumnHeaderSort } from "@/components/ui/dataTable";
import { ColumnDef } from "@tanstack/react-table";
import { Printer, Trash2 } from "lucide-react";
import { useMemo } from "react";
import { PaymentRecord } from "../_models/payment-record-model";

export const INVOICE_COLUMNS: ColumnDef<InvoiceItem>[] = [
  {
    id: "thanhTien",
    accessorKey: "thanhTien",
    header: "Thành tiền",
    cell: ({ row }) => (
      <div className="min-w-24 text-right">
        {formatCurrency(row.original.thanhTien, false)}
      </div>
    ),
  },
  {
    id: "patientPay",
    accessorKey: "patientPay",
    header: "Khách hàng",
    cell: ({ row }) => (
      <div className="min-w-24 text-right">
        {formatCurrency(row.original.patientPay, false)}
      </div>
    ),
  },
  {
    id: "moneyPaid",
    accessorKey: "moneyPaid",
    header: "Đã thanh toán",
    cell: ({ row }) => (
      <div className="min-w-24 text-right">
        {formatCurrency(row.original.moneyPaid, false)}
      </div>
    ),
  },
  {
    id: "moneyOwe",
    accessorKey: "moneyOwe",
    header: "Còn lại",
    cell: ({ row }) => (
      <div className="min-w-24 text-right">
        {formatCurrency(row.original.moneyOwe, false)}
      </div>
    ),
  },
];

export const usePaymentColumns = (
  handleDeletePayment: (payment: PaymentRecord) => Promise<void>,
  handleProcessPayment: (payment: PaymentRecord) => Promise<void>,
  isPrintOpening: boolean,
) => {
  return useMemo(() => {
    const PAYMENT_COLUMNS: ColumnDef<PaymentRecord>[] = [
      {
        id: "actions",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} className="w-5" title="" />
        ),
        cell: ({ row }) => (
          <div className="text-center">
            <Button
              size="sm"
              variant="destructive"
              className="h-8 w-8 p-0"
              onClick={() => handleDeletePayment(row.original)}
              disabled={
                !!row.original.invoiceHinhThucThanhToanId ||
                row.original.isPrinted
              }
            >
              <Trash2 className="h-4 w-4 " />
            </Button>
          </div>
        ),
      },
      {
        id: "paymentMethodName",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Phương thức TT"
            className="w-15"
          />
        ),
        cell: ({ row }) => row.original.paymentMethodName,
      },
      {
        id: "totalAmount",
        accessorKey: "totalAmount",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Tổng tiền"
            className="w-20"
          />
        ),
        cell: ({ row }) => (
          <div className="text-right">
            {formatCurrency(row.original.totalAmount, false)}
          </div>
        ),
      },
      {
        id: "amount",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Số tiền"
            className="w-15"
          />
        ),
        cell: ({ row }) => (
          <div className="text-right">
            {formatCurrency(row.original.amount, false)}
          </div>
        ),
      },
      {
        id: "cardNumber",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Mã thẻ/TK"
            className="w-15"
          />
        ),
        cell: ({ row }) => row.original.cardNumber || "-",
      },
      {
        id: "voucherCode",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Mã KM"
            className="w-15"
          />
        ),
        cell: ({ row }) => row.original.voucherCode || "-",
      },
      {
        id: "isPrinted",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Đã in"
            className="w-15"
          />
        ),
        cell: ({ row }) => (row.original.isPrinted ? "Đã xử lý" : "Chưa xử lý"),
      },
      {
        id: "print",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title=""
            className="w-5 text-center"
          />
        ),
        cell: ({ row }) => (
          <div className="text-center">
            <Button
              size="sm"
              variant="outline"
              className="h-8 w-8 p-0"
              onClick={() => handleProcessPayment(row.original)}
              disabled={row.original.isPrinted || isPrintOpening}
            >
              <Printer className="h-4 w-4" />
            </Button>
          </div>
        ),
      },
    ];
    return PAYMENT_COLUMNS;
  }, [handleDeletePayment, handleProcessPayment, isPrintOpening]);
};

export const getPaymentColumns = usePaymentColumns;
