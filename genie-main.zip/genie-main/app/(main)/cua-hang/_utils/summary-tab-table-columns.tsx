import { ColumnDef } from "@tanstack/react-table";
import { Receipt } from "@/app/(main)/cua-hang/_models/recept-model";
import { DataTableColumnHeaderSort } from "@/components/ui/dataTable";
import { format } from "date-fns";
import { DATE_FORMAT } from "@/app/lib/enums";
import { formatCurrencyVND } from "@/app/lib/utils";

const formatCurrency = (value?: number, fractionDigits = 0) => {
  return formatCurrencyVND(value, fractionDigits, false);
};

export const RECEIPT_COLUMNS: ColumnDef<Receipt>[] = [
  {
    id: "soPhieu",
    accessorKey: "soPhieu",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Số phiếu" />
    ),
    cell: ({ row }) => (
      <div className="min-w-[120px]">{row.original.soPhieu}</div>
    ),
    footer: ({ table }) => {
      return <div>TC: {table.getFilteredRowModel().rows.length}</div>;
    },
  },
  {
    id: "ngayThu",
    accessorKey: "ngayThu",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Ngày thu" />
    ),
    cell: ({ row }) => (
      <div className="min-w-[80px]">
        {format(new Date(row.original.ngayThu), DATE_FORMAT.DD_MM_YYYY_VI)}
      </div>
    ),
    sortingFn: "datetime",
  },
  {
    id: "ngayDoanhThu",
    accessorKey: "ngayDoanhThu",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Ngày doanh thu" />
    ),
    cell: ({ row }) => (
      <div className="min-w-[80px]">
        {format(row.original.ngayDoanhThu, DATE_FORMAT.DD_MM_YYYY_VI)}
      </div>
    ),
    sortingFn: "datetime",
  },
  {
    id: "loaiPhieu",
    accessorKey: "loaiPhieu",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Loại phiếu" />
    ),
    cell: ({ row }) => (
      <div className="min-w-[100px]">{row.original.loaiPhieu}</div>
    ),
  },
  {
    id: "hoTen",
    accessorKey: "hoTen",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Họ tên" />
    ),
    cell: ({ row }) => (
      <div className="min-w-[150px] whitespace-normal">
        {row.original.hoTen}
      </div>
    ),
  },
  {
    id: "liDo",
    accessorKey: "liDo",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Lý do CK" />
    ),
    cell: ({ row }) => (
      <div className="min-w-[150px] whitespace-normal">{row.original.liDo}</div>
    ),
  },
  {
    id: "totalMoney",
    accessorKey: "totalMoney",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Số tiền" />
    ),
    cell: ({ row }) => (
      <div className="min-w-[100px] text-right">
        {formatCurrency(row.original.totalMoney)}
      </div>
    ),
  },
  {
    id: "realTotalMoney",
    accessorKey: "realTotalMoney",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Thực thu" />
    ),
    cell: ({ row }) => (
      <div className="min-w-[100px] text-right">
        {formatCurrency(row.original.realTotalMoney)}
      </div>
    ),
    footer: ({ table }) => {
      const total = table
        .getFilteredRowModel()
        .rows.reduce((sum, row) => sum + (row.original.realTotalMoney || 0), 0);
      return (
        <div className="text-right font-semibold bg-white p-1">
          {formatCurrency(total)}
        </div>
      );
    },
  },
  {
    id: "trangThai",
    accessorKey: "trangThai",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Trạng thái" />
    ),
    cell: ({ row }) => (
      <div className="min-w-[120px]">{row.original.trangThai}</div>
    ),
  },
  {
    id: "nguoiThu",
    accessorKey: "nguoiThu",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Người thu" />
    ),
    cell: ({ row }) => (
      <div className="min-w-[120px] whitespace-normal">
        {row.original.nguoiThu}
      </div>
    ),
  },
  {
    id: "quay",
    accessorKey: "quay",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Quầy thu" />
    ),
    cell: ({ row }) => <div className="min-w-[100px]">{row.original.quay}</div>,
  },
  {
    id: "caThu",
    accessorKey: "caThu",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Ca thu" />
    ),
    cell: ({ row }) => (
      <div className="min-w-[120px]">{row.original.caThu}</div>
    ),
  },
  {
    id: "pttt",
    accessorKey: "pttt",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="PTTT" />
    ),
    cell: ({ row }) => (
      <div className="min-w-[170px] whitespace-normal">{row.original.pttt}</div>
    ),
  },
  {
    id: "serial",
    accessorKey: "serial",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Số serial" />
    ),
    cell: ({ row }) => (
      <div className="min-w-[100px] max-w-[100px]">{row.original.serial}</div>
    ),
  },
  {
    id: "note",
    accessorKey: "note",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Ghi chú" />
    ),
    cell: ({ row }) => (
      <div className="min-w-[120px] whitespace-normal">{row.original.note}</div>
    ),
  },
  {
    id: "invoiceNoThanhToan",
    accessorKey: "invoiceNoThanhToan",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Số BL tham chiếu" />
    ),
    cell: ({ row }) => (
      <div className="min-w-[120px]">{row.original.invoiceNoThanhToan}</div>
    ),
  },
  {
    id: "invoiceDateThanhToan",
    accessorKey: "invoiceDateThanhToan",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Ngày BL tham chiếu" />
    ),
    cell: ({ row }) => (
      <div className="min-w-[80px]">
        {row.original.invoiceDateThanhToan
          ? format(
              new Date(row.original.invoiceDateThanhToan),
              DATE_FORMAT.DD_MM_YYYY_VI,
            )
          : ""}
      </div>
    ),
  },
  {
    id: "soHopDongThanhToan",
    accessorKey: "soHopDongThanhToan",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Số hợp đồng" />
    ),
    cell: ({ row }) => (
      <div className="min-w-[120px]">{row.original.soHopDongThanhToan}</div>
    ),
  },
];

export const REFUNDED_COLUMNS: ColumnDef<Receipt>[] = [
  {
    accessorKey: "soPhieu",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Số phiếu" />
    ),
    cell: ({ row }) => (
      <div className="min-w-[120px]">{row.original.soPhieu}</div>
    ),
    footer: ({ table }) => {
      return <div>TC: {table.getFilteredRowModel().rows.length}</div>;
    },
  },
  {
    accessorKey: "phieuThu",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Phiếu thu" />
    ),
    cell: ({ row }) => (
      <div className="min-w-[120px]">{row.original.phieuThu}</div>
    ),
  },
  {
    accessorKey: "ngayHoan",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Ngày h.phí" />
    ),
    cell: ({ row }) => (
      <div className="min-w-[100px]">
        {format(new Date(row.original.ngayHoan), DATE_FORMAT.DD_MM_YYYY_VI)}
      </div>
    ),
  },
  {
    accessorKey: "hoTen",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Họ tên" />
    ),
    cell: ({ row }) => (
      <div className="min-w-[150px] whitespace-normal">
        {row.original.hoTen}
      </div>
    ),
  },
  {
    accessorKey: "totalmoney",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Số tiền" />
    ),
    cell: ({ row }) => (
      <div className="min-w-[100px] text-right">
        {formatCurrency(row.original.totalmoney)}
      </div>
    ),
    footer: ({ table }) => {
      const total = table
        .getFilteredRowModel()
        .rows.reduce((sum, row) => sum + (row.original.totalmoney || 0), 0);
      return (
        <div className="text-right font-semibold bg-white p-1">
          {formatCurrency(total)}
        </div>
      );
    },
  },
  {
    accessorKey: "liDo",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Lí do" />
    ),
    cell: ({ row }) => (
      <div className="min-w-[150px] whitespace-normal">{row.original.liDo}</div>
    ),
  },
  {
    accessorKey: "stockName",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Tên kho" />
    ),
    cell: ({ row }) => (
      <div className="min-w-[150px] whitespace-normal">
        {row.original.stockName}
      </div>
    ),
  },
  {
    accessorKey: "nguoiHoan",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Người h.phí" />
    ),
    cell: ({ row }) => (
      <div className="min-w-[140px] whitespace-normal">
        {row.original.nguoiHoan}
      </div>
    ),
  },
  {
    accessorKey: "quayHoan",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Quầy h.phí" />
    ),
    cell: ({ row }) => (
      <div className="min-w-[120px]">{row.original.quayHoan}</div>
    ),
  },
  {
    accessorKey: "caHoan",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Ca hoàn" />
    ),
    cell: ({ row }) => (
      <div className="min-w-[100px]">{row.original.caHoan}</div>
    ),
  },
];

export const CANCELLED_COLUMNS: ColumnDef<Receipt>[] = [
  {
    accessorKey: "soPhieu",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Số phiếu" />
    ),
    cell: ({ row }) => (
      <div className="min-w-[120px]">{row.original.soPhieu}</div>
    ),
    footer: ({ table }) => {
      return <div>TC: {table.getFilteredRowModel().rows.length}</div>;
    },
  },
  {
    accessorKey: "phieuThu",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Phiếu thu" />
    ),
    cell: ({ row }) => (
      <div className="min-w-[120px]">{row.original.phieuThu}</div>
    ),
  },
  {
    accessorKey: "ngayHuy",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Ngày hủy" />
    ),
    cell: ({ row }) => (
      <div className="min-w-[100px]">
        {format(new Date(row.original.ngayHuy), DATE_FORMAT.DD_MM_YYYY_VI)}
      </div>
    ),
  },
  {
    accessorKey: "hoTen",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Họ tên" />
    ),
    cell: ({ row }) => (
      <div className="min-w-[150px] whitespace-normal">
        {row.original.hoTen}
      </div>
    ),
  },
  {
    accessorKey: "liDo",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Lí do" />
    ),
    cell: ({ row }) => (
      <div className="min-w-[150px] whitespace-normal">{row.original.liDo}</div>
    ),
  },
  {
    accessorKey: "stockName",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Tên kho" />
    ),
    cell: ({ row }) => (
      <div className="min-w-[150px] whitespace-normal">
        {row.original.stockName}
      </div>
    ),
  },
  {
    accessorKey: "totalmoney",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Số tiền" />
    ),
    cell: ({ row }) => (
      <div className="min-w-[100px] text-right">
        {formatCurrency(row.original.totalmoney)}
      </div>
    ),
    footer: ({ table }) => {
      const total = table
        .getFilteredRowModel()
        .rows.reduce((sum, row) => sum + (row.original.totalmoney || 0), 0);
      return (
        <div className="text-right font-semibold bg-white p-1">
          {formatCurrency(total)}
        </div>
      );
    },
  },
  {
    accessorKey: "nguoiHuy",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Người hủy" />
    ),
    cell: ({ row }) => (
      <div className="min-w-[140px] whitespace-normal">
        {row.original.nguoiHuy}
      </div>
    ),
  },
  {
    accessorKey: "quayHuy",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Quầy hủy" />
    ),
    cell: ({ row }) => (
      <div className="min-w-[120px]">{row.original.quayHuy}</div>
    ),
  },
  {
    accessorKey: "caHuy",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Ca hủy" />
    ),
    cell: ({ row }) => (
      <div className="min-w-[100px]">{row.original.caHuy}</div>
    ),
  },
];

export const DETAIL_COLUMNS: ColumnDef<Receipt>[] = [
  {
    accessorKey: "soPhieu",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Số phiếu" />
    ),
    cell: ({ row }) => (
      <div className="min-w-[120px]">{row.original.soPhieu}</div>
    ),
    footer: ({ table }) => {
      return <div>TC: {table.getFilteredRowModel().rows.length}</div>;
    },
  },
  {
    accessorKey: "ngayThu",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Ngày thu" />
    ),
    cell: ({ row }) => (
      <div className="min-w-[100px]">
        {format(new Date(row.original.ngayThu), DATE_FORMAT.DD_MM_YYYY_VI)}
      </div>
    ),
  },
  {
    accessorKey: "ngayDoanhThu",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Ngày doanh thu" />
    ),
    cell: ({ row }) => (
      <div className="min-w-[120px]">
        {format(new Date(row.original.ngayDoanhThu), DATE_FORMAT.DD_MM_YYYY_VI)}
      </div>
    ),
  },
  {
    accessorKey: "loaiPhieu",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Loại phiếu" />
    ),
    cell: ({ row }) => (
      <div className="min-w-[120px]">{row.original.loaiPhieu}</div>
    ),
  },
  {
    accessorKey: "maKH",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Mã KH" />
    ),
    cell: ({ row }) => <div className="min-w-[100px]">{row.original.maKH}</div>,
  },
  {
    accessorKey: "hoTen",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Họ tên" />
    ),
    cell: ({ row }) => (
      <div className="min-w-[150px] whitespace-normal">
        {row.original.hoTen}
      </div>
    ),
  },
  {
    accessorKey: "diaChi",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Địa chỉ" />
    ),
    cell: ({ row }) => (
      <div className="min-w-[250px] whitespace-normal">
        {row.original.diaChi}
      </div>
    ),
  },
  {
    accessorKey: "invoiceNoThanhToan",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Số BL tham chiếu" />
    ),
    cell: ({ row }) => (
      <div className="min-w-[130px]">{row.original.invoiceNoThanhToan}</div>
    ),
  },
  {
    accessorKey: "invoiceDateThanhToan",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Ngày BL thanh toán" />
    ),
    cell: ({ row }) => (
      <div className="min-w-[120px]">
        {row.original.invoiceDateThanhToan
          ? format(
              new Date(row.original.invoiceDateThanhToan),
              DATE_FORMAT.DD_MM_YYYY_VI,
            )
          : ""}
      </div>
    ),
  },
  {
    accessorKey: "soHopDongThanhToan",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Số hợp đồng" />
    ),
    cell: ({ row }) => (
      <div className="min-w-[120px]">{row.original.soHopDongThanhToan}</div>
    ),
  },
  {
    accessorKey: "liDo",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Lí do CK" />
    ),
    cell: ({ row }) => (
      <div className="min-w-[150px] whitespace-normal">{row.original.liDo}</div>
    ),
  },
  {
    accessorKey: "stockName",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Tên kho" />
    ),
    cell: ({ row }) => (
      <div className="min-w-[150px] whitespace-normal">
        {row.original.stockName}
      </div>
    ),
  },
  {
    accessorKey: "tenChinhSach",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Chính sách" />
    ),
    cell: ({ row }) => (
      <div className="min-w-[150px] whitespace-normal">
        {row.original.tenChinhSach}
      </div>
    ),
  },
  {
    accessorKey: "productCode",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Mã SP" />
    ),
    cell: ({ row }) => (
      <div className="min-w-[100px]">{row.original.productCode}</div>
    ),
  },
  {
    accessorKey: "productName",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Tên SP" />
    ),
    cell: ({ row }) => (
      <div className="min-w-[180px] whitespace-normal">
        {row.original.productName}
      </div>
    ),
  },
  {
    accessorKey: "batch",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Số lô" />
    ),
  },
  {
    accessorKey: "expDate",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="HSD" />
    ),
    cell: ({ row }) => (
      <div className="min-w-[100px]">
        {row.original.expDate
          ? format(new Date(row.original.expDate), DATE_FORMAT.DD_MM_YYYY_VI)
          : ""}
      </div>
    ),
  },
  {
    accessorKey: "qty",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="SL" />
    ),
    cell: ({ row }) => (
      <div className="min-w-[60px] text-right">{row.original.qty}</div>
    ),
  },
  {
    accessorKey: "price",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Đơn giá" />
    ),
    cell: ({ row }) => (
      <div className="min-w-[100px] text-right">
        {formatCurrency(row.original.price)}
      </div>
    ),
  },
  {
    accessorKey: "patientPay",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Số tiền" />
    ),
    cell: ({ row }) => (
      <div className="min-w-[100px] text-right">
        {formatCurrency(row.original.patientPay)}
      </div>
    ),
    footer: ({ table }) => {
      const total = table
        .getFilteredRowModel()
        .rows.reduce((sum, row) => sum + (row.original.patientPay || 0), 0);
      return (
        <div className="text-right font-semibold bg-white p-1">
          {formatCurrency(total)}
        </div>
      );
    },
  },
  {
    accessorKey: "tienCK",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Tiền CK" />
    ),
    cell: ({ row }) => (
      <div className="min-w-[100px] text-right">
        {formatCurrency(row.original.tienCK)}
      </div>
    ),
    footer: ({ table }) => {
      const total = table
        .getFilteredRowModel()
        .rows.reduce((sum, row) => sum + (row.original.tienCK || 0), 0);
      return (
        <div className="text-right font-semibold bg-white p-1">
          {formatCurrency(total)}
        </div>
      );
    },
  },
  {
    accessorKey: "thucThu",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Thực thu" />
    ),
    cell: ({ row }) => (
      <div className="min-w-[100px] text-right">
        {formatCurrency(row.original.thucThu)}
      </div>
    ),
    footer: ({ table }) => {
      const total = table
        .getFilteredRowModel()
        .rows.reduce((sum, row) => sum + (row.original.thucThu || 0), 0);
      return (
        <div className="text-right font-semibold bg-white p-1">
          {formatCurrency(total)}
        </div>
      );
    },
  },
  {
    accessorKey: "pttt",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="PTTT" />
    ),
    cell: ({ row }) => (
      <div className="min-w-[140px] whitespace-normal">{row.original.pttt}</div>
    ),
  },
  {
    accessorKey: "trangThai",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Trạng thái" />
    ),
    cell: ({ row }) => (
      <div className="min-w-[120px]">{row.original.trangThai}</div>
    ),
  },
  {
    accessorKey: "nguoiThu",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Người thu" />
    ),
    cell: ({ row }) => (
      <div className="min-w-[140px] whitespace-normal">
        {row.original.nguoiThu}
      </div>
    ),
  },
  {
    accessorKey: "quay",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Quầy thu" />
    ),
    cell: ({ row }) => <div className="min-w-[120px]">{row.original.quay}</div>,
  },
  {
    accessorKey: "caThu",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Ca thu" />
    ),
    cell: ({ row }) => (
      <div className="min-w-[100px]">{row.original.caThu}</div>
    ),
  },
  {
    accessorKey: "serial",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Số serial" />
    ),
    cell: ({ row }) => (
      <div className="min-w-[120px]">{row.original.serial}</div>
    ),
  },
  {
    accessorKey: "note",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Ghi chú" />
    ),
    cell: ({ row }) => (
      <div className="min-w-[150px] whitespace-normal">{row.original.note}</div>
    ),
  },
];
