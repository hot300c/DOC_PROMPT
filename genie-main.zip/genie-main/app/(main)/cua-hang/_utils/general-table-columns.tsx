import { ColumnDef } from "@tanstack/react-table";
import { Counter } from "@/app/(main)/cua-hang/_models/counter-model";
import { DataTableColumnHeaderSort } from "@/components/ui/dataTable";
import { Shop } from "@/app/(main)/cua-hang/_models/shop-model";

export const COUNTER_COLUMNS: ColumnDef<Counter>[] = [
  {
    accessorKey: "counterName",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Tên quầy" />
    ),
    cell: ({ row }) => row.original.counterName,
  },
];

export const SHOP_COLUMNS: ColumnDef<Shop>[] = [
  {
    accessorKey: "ShopTypeName",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Tên cửa hàng" />
    ),
    cell: ({ row }) => row.original.shopTypeName,
  },
];
