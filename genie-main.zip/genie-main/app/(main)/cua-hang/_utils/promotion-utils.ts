import { checkPromotionApplicable } from "../_action/check-promotion";
import { CartItem } from "../_models/cart-model";

export interface ProcessedPromotion {
  checkId: string;
  totalDiscountAmount: number;
  autoGiftItems: CartItem[];
  choiceGiftItems: GiftChoiceGroup[];
  discountAppliedItems: CartItem[];
  hasChoiceGifts: boolean; // Add flag to indicate if user choice is needed
}

export interface GiftChoiceGroup {
  promotionName: string;
  promotionId: string;
  giftProducts: {
    giftProductId: string;
    giftProductCode: string;
    giftProductName: string;
    quantity: number;
  }[];
}

export const processPromotions = async (
  cartItems: CartItem[],
  facId: string,
  facName: string,
  customerInfo: {
    name: string;
    id: string;
    tier: number;
    employeeId?: string;
    customerTypeId?: number;
  },
  customerPhone?: string,
  customerHospitalId?: string,
): Promise<ProcessedPromotion | null> => {
  try {
    // Calculate totals
    const currentTotalAmount = cartItems.reduce(
      (acc, item) => acc + item.price * item.quantity,
      0,
    );
    const currentTotalQuantity = cartItems.reduce(
      (acc, item) => acc + item.quantity,
      0,
    );

    const promotionResponse = await checkPromotionApplicable(
      facId,
      facName,
      cartItems[0]?.stockName || "",
      customerHospitalId || "",
      customerPhone || "",
      customerInfo?.name || "",
      "NORMAL", // customer type
      customerInfo.tier,
      customerInfo.employeeId || "", // employee code
      customerInfo.customerTypeId || 0, // employee type
      cartItems,
      currentTotalAmount,
      currentTotalQuantity,
    );

    if (!promotionResponse || !promotionResponse.success) {
      return null;
    }

    const { checkID, totalDiscountAmount, promotion, giftProducts } =
      promotionResponse.data;

    const autoGiftItems: CartItem[] = [];
    const choiceGiftItems: GiftChoiceGroup[] = [];
    const updatedCartItems = [...cartItems];

    // Process top-level gift products (one-time promotion gifts)
    for (const giftGroup of giftProducts) {
      if (giftGroup.typeGift === 2) {
        // Auto apply gifts
        for (const gift of giftGroup.giftProductsDetail) {
          const giftCartItem: CartItem = {
            id: `gift-${gift.giftProductId}-${Date.now()}-${Math.random()}`,
            productId: parseInt(gift.giftProductId),
            code: gift.giftProductCode,
            name: gift.giftProductName,
            price: 0, // Gift items are free
            quantity: gift.quantity,
            hangSanXuat: null,
            stockId: cartItems[0]?.stockId || 0,
            stockName: cartItems[0]?.stockName || "",
            loaiXuat: "Gift",
            discount: 0,
            discountPercent: 0,
            tt: "Quà tặng",
            thanhTienTruocCK: 0,
            thanhTienSauCK: 0,
            tenChinhSach: giftGroup.name,
            invoiceId: null,
            invoiceDetailId: null,
            batch: "",
          };
          autoGiftItems.push(giftCartItem);
        }
      } else if (giftGroup.typeGift === 1) {
        // Require user choice for top-level gifts
        choiceGiftItems.push({
          promotionName: giftGroup.name,
          promotionId: giftGroup.promotionId,
          giftProducts: giftGroup.giftProductsDetail,
        });
      }
    }

    // Process individual product promotions
    for (const promo of promotion) {
      // Apply discounts to cart items
      const cartItemIndex = updatedCartItems.findIndex(
        (item) =>
          item.productId?.toString() === promo.productId &&
          item.batch === promo.productBatch,
      );

      if (cartItemIndex !== -1 && updatedCartItems[cartItemIndex]) {
        const cartItem = updatedCartItems[cartItemIndex]!;

        // Apply total discount amount
        if (promo.totalDiscountAmount > 0) {
          updatedCartItems[cartItemIndex] = {
            ...cartItem,
            discount: promo.totalDiscountAmount,
            thanhTienSauCK:
              cartItem.price * cartItem.quantity - promo.totalDiscountAmount,
            tenChinhSach: promo.name,
            discountPercent: !promo.price
              ? 0
              : (promo.totalDiscountAmount * 100) /
                (promo.price * promo.quantity),
          };
        }
      }

      // Process product-specific gift products
      for (const giftGroup of promo.giftProducts) {
        if (giftGroup.typeGift === 2) {
          // Auto apply gifts
          for (const gift of giftGroup.giftProductsDetail) {
            const giftCartItem: CartItem = {
              id: `gift-${gift.giftProductId}-${Date.now()}-${Math.random()}`,
              productId: parseInt(gift.giftProductId),
              code: gift.giftProductCode,
              name: gift.giftProductName,
              price: 0, // Gift items are free
              quantity: gift.quantity,
              hangSanXuat: null,
              stockId: cartItems[0]?.stockId || 0,
              stockName: cartItems[0]?.stockName || "",
              loaiXuat: "Gift",
              discount: 0,
              discountPercent: 0,
              tt: "Quà tặng",
              thanhTienTruocCK: 0,
              thanhTienSauCK: 0,
              tenChinhSach: giftGroup.name,
              invoiceId: null,
              invoiceDetailId: null,
              batch: "",
            };
            autoGiftItems.push(giftCartItem);
          }
        } else if (giftGroup.typeGift === 1) {
          // Require user choice for product-specific gifts
          choiceGiftItems.push({
            promotionName: giftGroup.name,
            promotionId: giftGroup.promotionId,
            giftProducts: giftGroup.giftProductsDetail,
          });
        }
      }
    }

    return {
      checkId: checkID,
      totalDiscountAmount,
      autoGiftItems,
      choiceGiftItems,
      discountAppliedItems: updatedCartItems,
      hasChoiceGifts: choiceGiftItems.length > 0,
    };
  } catch (error) {
    console.error("Error processing promotions:", error);
    return null;
  }
};

export const createGiftCartItem = (
  gift: {
    giftProductId: string;
    giftProductCode: string;
    giftProductName: string;
    quantity: number;
  },
  promotionName: string,
  stockId: number,
  stockName: string,
  batch: string = "",
  expDate?: Date | null,
): CartItem => {
  return {
    id: `gift-${gift.giftProductId}-${Date.now()}`,
    productId: parseInt(gift.giftProductId),
    code: gift.giftProductCode,
    name: gift.giftProductName,
    price: 0, // Gift items are free
    quantity: gift.quantity,
    stockId,
    stockName,
    loaiXuat: "Gift",
    discount: 0,
    hangSanXuat: null,
    discountPercent: 0,
    tt: "Quà tặng",
    thanhTienTruocCK: 0,
    thanhTienSauCK: 0,
    tenChinhSach: promotionName,
    invoiceId: null,
    invoiceDetailId: null,
    batch: batch,
    expDate: expDate,
  };
};
