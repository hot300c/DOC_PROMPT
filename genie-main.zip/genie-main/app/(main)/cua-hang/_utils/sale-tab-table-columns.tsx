import { CustomerModel } from "@/app/(main)/cua-hang/_models/customer-model";
import { DATE_FORMAT, SHIPPING_SERVICE_NAME } from "@/app/lib/enums";
import { cn, formatCurrencyVND, formatNumber } from "@/app/lib/utils";
import { Button } from "@/components/ui/button";
import { DataTableColumnHeaderSort } from "@/components/ui/dataTable";
import { Input, inputVariants } from "@/components/ui/input";
import { ColumnDef } from "@tanstack/react-table";
import { format } from "date-fns";
import { Check, Plus, Trash2 } from "lucide-react";
import React, { useMemo, useRef } from "react";
import { CartItem } from "../_models/cart-model";
import { Product } from "../_models/product-model";

export const useProductColumns = (
  handleAddToCart: (product: Product) => void,
  isPaid: boolean,
) => {
  return useMemo(() => {
    const PRODUCT_COLUMNS: ColumnDef<Product>[] = [
      {
        id: "actions",
        header: "",
        cell: ({ row }) => (
          <Button
            size="icon"
            variant="ghost"
            onClick={() => handleAddToCart(row.original)}
            disabled={isPaid}
          >
            <Plus className="h-4 w-4 text-green-500" />
          </Button>
        ),
      },
      {
        id: "hospitalCode",
        accessorKey: "hospitalCode",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Mã"
            className="w-[100px] min-w-[100px]"
          />
        ),
      },
      {
        id: "productName",
        accessorKey: "productName",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Tên"
            className="w-[250px] min-w-[200px]"
          />
        ),
      },
      {
        id: "price",
        accessorKey: "price",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Giá bán"
            className="w-[70px] min-w-[70px] text-right"
          />
        ),
        cell: ({ row }) => (
          <div className="text-right">
            {formatCurrencyVND(row.getValue("price"), 0, false)}
          </div>
        ),
      },
      {
        id: "batch",
        accessorKey: "batch",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Lô"
            className="w-[70px] min-w-[70px] max-w-[70px] truncate"
          />
        ),
      },
      {
        id: "expDate",
        accessorKey: "expDate",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="HSD"
            className="w-[70px] min-w-[70px]"
          />
        ),
        cell: ({ row }) => {
          const date = new Date(row.getValue("expDate")) ?? new Date();
          return (
            <div className="text-center">
              {format(date, DATE_FORMAT.DD_MM_YYYY_VI)}
            </div>
          );
        },
      },
      {
        id: "qty",
        accessorKey: "qty",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="SL tồn"
            className="w-[80px] min-w-[80px] text-right"
          />
        ),
        cell: ({ row }) => (
          <div className="text-right">{formatNumber(row.original.qty)}</div>
        ),
      },
    ];
    return PRODUCT_COLUMNS;
  }, [handleAddToCart, isPaid]);
};

export const useCartColumns = (
  handleRemoveFromCart: (index: number) => void,
  isPaid: boolean,
  handleChangeQuantity?: (item: CartItem, quantity: number) => void,
  setCartItem?: (item: CartItem) => void,
) => {
  const policyNameRef = useRef("");
  const quantityRef = useRef("0");
  return useMemo(() => {
    const CART_COLUMNS: ColumnDef<CartItem>[] = [
      {
        id: "actions",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Xóa"
            className="text-center"
          />
        ),
        cell: ({ row }) => (
          <Button
            size="icon"
            variant="ghost"
            onClick={() => handleRemoveFromCart(row.index)}
            disabled={isPaid}
          >
            <Trash2 className="h-4 w-4 text-red-500" />
          </Button>
        ),
      },
      {
        id: "tenChinhSach",
        accessorKey: "tenChinhSach",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Chính sách" />
        ),
        cell: ({ row }) => {
          const handleInputChange = (
            e: React.ChangeEvent<HTMLInputElement>,
          ) => {
            policyNameRef.current = e.target.value;
            // set the row value to the input
            row.original.tenChinhSach = e.target.value;
          };
          return (
            <Input
              defaultValue={row.original?.tenChinhSach || ""}
              onChange={(e) => handleInputChange(e)}
              className={cn(inputVariants(), "w-full")}
              disabled={isPaid}
            />
          );
        },
      },
      {
        id: "code",
        accessorKey: "code",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Mã" />
        ),
        cell: ({ row }) => (
          <div className="w-[100px] min-w-[100px] max-w-[100px] truncate">
            {row.original.code}
          </div>
        ),
      },
      {
        id: "name",
        accessorKey: "name",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Tên" />
        ),
        cell: ({ row }) => (
          <div
            className="w-[150px] min-w-[100px] max-w-[200px] line-clamp-2"
            title={row.original.name}
          >
            {row.original.name}
          </div>
        ),
      },
      {
        id: "quantity",
        accessorKey: "quantity",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="SL" />
        ),
        cell: ({ row }) => {
          const value = row.original.quantity;
          const handleInputChange = (
            e: React.ChangeEvent<HTMLInputElement>,
          ) => {
            const quantity = Number(e.target.value || "1");
            if (isNaN(quantity)) {
              e.preventDefault();
              return;
            }
            quantityRef.current = e.target.value;
            if (quantity < 1) {
              quantityRef.current = "1";
              row.original.quantity = 1;
            } else {
              row.original.quantity = quantity;
            }
          };
          return (
            <Input
              readOnly={row.original.name === SHIPPING_SERVICE_NAME}
              className="text-right w-[70px] min-w-[70px] max-w-[70px]"
              defaultValue={row.original?.quantity || "0"}
              onClick={(e) => {
                const quantity = Number(
                  (e.target as HTMLInputElement).value || "1",
                );
                if (!isNaN(quantity)) {
                  quantityRef.current = String(quantity);
                }
              }}
              onChange={(e) => handleInputChange(e)}
              onBlur={(e) => {
                const quantity = Number(e.target.value || "1");
                if (value === quantity) return;
                if (handleChangeQuantity) {
                  handleChangeQuantity(
                    row.original,
                    Number(quantityRef.current),
                  );
                }
              }}
              disabled={isPaid}
            />
          );
        },
      },
      {
        id: "price",
        accessorKey: "price",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Giá" />
        ),
        cell: ({ row }) => (
          <div className="text-right">
            {formatCurrencyVND(row.getValue("price"), 0, false)}
          </div>
        ),
      },
      {
        id: "discount",
        accessorKey: "discount",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="CK" />
        ),
        cell: ({ row }) => {
          return (
            <Input
              className="text-right w-[120px]"
              onDoubleClick={() => {
                if (setCartItem && !isPaid) setCartItem(row.original);
              }}
              defaultValue={
                formatCurrencyVND(row.original?.discount, 0, false) || "0"
              }
              readOnly={true}
            />
          );
        },
      },
      {
        id: "total",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Thành tiền" />
        ),
        cell: ({ row }) => (
          <div className="text-right">
            {formatCurrencyVND(row.original.thanhTienSauCK, 0, false)}
          </div>
        ),
      },
      {
        id: "batch",
        accessorKey: "batch",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Lô"
            className="w-[70px] min-w-[70px] max-w-[70px] truncate"
          />
        ),
      },
      {
        id: "expDate",
        accessorKey: "expDate",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="HSD"
            className="w-[70px] min-w-[70px]"
          />
        ),
        cell: ({ row }) => {
          return (
            <div className="text-center">
              {row.original.expDate
                ? format(
                    new Date(row.original.expDate),
                    DATE_FORMAT.DD_MM_YYYY_VI,
                  )
                : ""}
            </div>
          );
        },
      },
    ];
    return CART_COLUMNS;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [handleRemoveFromCart, isPaid]);
};

export const useCustomerColumns = (
  onSelectCustomer: (customer: CustomerModel) => void,
) => {
  return useMemo<ColumnDef<CustomerModel>[]>(
    () => [
      {
        id: "actions",
        header: "",
        cell: ({ row }) => (
          <Button
            size="icon"
            variant="ghost"
            onClick={() => onSelectCustomer(row.original)}
          >
            <Check className="h-4 w-4 text-green-500" />
          </Button>
        ),
      },
      {
        id: "patientHospitalID",
        accessorKey: "patientHospitalID",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Mã KH" />
        ),
      },
      {
        id: "fullName",
        accessorKey: "fullName",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Họ tên" />
        ),
      },
      {
        id: "mobile",
        accessorKey: "mobile",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Số điện thoại" />
        ),
      },
      {
        id: "gioiTinh",
        accessorKey: "gioiTinh",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Giới tính" />
        ),
      },
      {
        id: "ngaySinh",
        accessorKey: "ngaySinh",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Ngày sinh" />
        ),
      },
      {
        id: "diaChi",
        accessorKey: "diaChi",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Địa chỉ" />
        ),
        cell: ({ row }) => (
          <div className="truncate max-w-[500px]" title={row.original.diaChi}>
            {row.original.diaChi}
          </div>
        ),
      },
      {
        id: "loaiKhach",
        accessorKey: "loaiKhach",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Loại khách" />
        ),
      },
    ],
    [onSelectCustomer],
  );
};

export const getProductColumns = useProductColumns;
export const getCartColumns = useCartColumns;
export const getCustomerColumns = useCustomerColumns;
