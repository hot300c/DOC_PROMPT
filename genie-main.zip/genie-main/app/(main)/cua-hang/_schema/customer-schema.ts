import * as z from "zod";

export const customerFormSchema = z.object({
  patientId: z.string().optional(),
  fullName: z.string().min(1, "Vui lòng thêm thông tin tên khách hàng"),
  birthDate: z.date(),
  gender: z.number(),
  genderText: z.string(),
  streetNo: z.string(),
  province: z.string(),
  district: z.string(),
  ward: z.string(),
  phone: z
    .string()
    .min(10, "Số điện thoại phải có ít nhất 10 chữ số")
    .max(11, "Số điện thoại không được quá 11 chữ số")
    .regex(/^\d{10,11}$/, "Số điện thoại phải có từ 10 đến 11 chữ số"),
  taxId: z.string(),
  company: z.string(),
  email: z.union([z.literal(""), z.string().email()]),
  isWalkInCustomer: z.boolean(),
});

export type CustomerFormValues = z.infer<typeof customerFormSchema>;
