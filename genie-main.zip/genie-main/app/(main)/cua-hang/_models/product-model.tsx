export interface Product {
  productID: number;
  hospitalCode: string;
  productName: string;
  price: number;
  hangSanXuat: number;
  stockName: string;
  stockID: number;
  qty_Text: string;
  qty: number;
  moTaSanPham: any;
  apiKetThuc: any;
  apiHuy: any;
  productNameNoUnicode: any;
  phuongPhapXuat: string;
  batch: string;
  expDate: Date;
}
