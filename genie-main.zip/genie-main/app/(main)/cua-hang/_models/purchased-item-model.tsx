export interface PurchasedItemModel {
  stt: number;
  invoiceID: string;
  productID: number;
  unitID: number;
  qty: number;
  price: number;
  patientPay: number;
  productCode: string;
  hospitalCode: string;
  productName: string;
  unitName: string;
  tienGiam: number;
  chietKhau: number;
  thanhTienTruocCK: number;
  thanhTienSauCK: number;
  thanhTien: number;
  tt: string;
  serial: string;
  invoiceDetailID: string;
  tenChinhSach: any;
  batch: string;
  expDate: string;
}
