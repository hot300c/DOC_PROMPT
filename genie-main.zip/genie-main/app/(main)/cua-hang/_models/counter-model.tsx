export interface Counter {
  counterID: number;
  counterCode: string;
  counterName: string;
  counterType: string;
  isQuayThuoc: boolean;
  orderIndex: any;
  counterCode1: string;
  stt: any;
}
