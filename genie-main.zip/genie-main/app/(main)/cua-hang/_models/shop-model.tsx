export interface Shop {
  shopTypeID: string;
  shopTypeName: string;
  isActive: boolean;
  facID: string;
}
