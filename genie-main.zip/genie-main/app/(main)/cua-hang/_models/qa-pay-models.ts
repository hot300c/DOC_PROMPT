export interface CardHolderInfo {
  OwnerID: string;
  FullName: string;
  Phone: string;
  CMND: string; // National ID
  TongTien: number; // Total money
  TongDiem: number; // Total points
  Mathe: string; // Card number
  Mataikhoan: string; // Account number
  Link?: string; // API endpoint
}

export interface QaPayResponse {
  ThongTinChuThe: CardHolderInfo[];
}
