export interface PaymentRecord {
  id: string;
  paymentMethodId: string;
  paymentMethodName: string;
  amount: number;
  cardNumber?: string;
  voucherCode?: string;
  totalAmount: number;
  invoiceId?: string;
  invoiceHinhThucThanhToanId?: string;
  isPrinted: boolean;
}
