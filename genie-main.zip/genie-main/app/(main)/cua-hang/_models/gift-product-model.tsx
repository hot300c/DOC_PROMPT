export interface GiftProduct {
  giftProductId: string;
  giftProductCode: string;
  giftProductName: string;
  quantity: number;
  isSelected?: boolean;
}
