export interface CartItem {
  id: string;
  productId: number | null;
  code: string;
  name: string;
  price: number;
  hangSanXuat: number | null;
  quantity: number;
  stockId: number;
  stockName: string;
  loaiXuat: string;
  discount: number;
  discountPercent: number;
  tt: string;
  serialNo?: string;
  thanhTienTruocCK: number;
  thanhTienSauCK: number;
  tenChinhSach: string;
  invoiceId: string | null;
  invoiceDetailId: string | null;
  expDate?: Date | null;
  batch: string;
  reason?: string;
}
