export interface ShiftDailyModel {
  shiftDailyID: string;
  shiftName: string;
  ngayDoanhThu: Date;
}

export interface InvoiceBusiness {
  stt: number;
  invoiceBusinessID: string;
  invoiceNo: string;
  total: number;
  tenKhachHang: string;
  shiftDailyID: string;
  ngayThu: string;
  nguoiThu: string | null;
  nguoiThuID: string;
  phone: string;
  trangThaiHoan: number;
  isHoanhuy: boolean;
  invoiceIDThanhToan: string | null;
  invoiceNoThanhToan: string | null;
  invoiceDateThanhToan: string | null;
  hopDongIDThanhToan: string | null;
  soHopDongThanhToan: string | null;
  phieuXuatId: string | null;
  stockName: string | null;
  email: string | null;
}
export interface InvoiceBusinessDetail {
  stt: number;
  invoiceID: string;
  productID: number;
  unitID: number;
  qty: number;
  price: number;
  patientPay: number;
  productCode: string;
  hospitalCode: string;
  productName: string;
  unitName: string;
  tienGiam: number;
  chietKhau: number;
  thanhTienTruocCK: number;
  thanhTienSauCK: number;
  thanhTien: number;
  tt: string;
  serial: string | null;
  invoiceDetailID: string;
  tenChinhSach: string;
  batch: string;
  expDate: Date;
}
export interface ScratchcardSold {
  isCheck: boolean;
  serial: string;
  phone: string;
  productID: number;
  tenSanPham: string;
  invoiceID: string;
  maBienLai: string;
  trangThai: string;
  ngayKichHoat: string;
  ngayHuy: string | null;
}
export interface RetailInvoiceInfo {
  invoiceBusinessID: string;
  maPhieu: string;
  tenKhachHang: string;
  phone: string;
  diaChi: string;
  createdBy: string;
  nguoiXuat: string | null;
  ngayXuat: string;
  shiftDailyIDXuat: string;
  thanhTien: number;
  caXuat: string;
  phieuXuatID: string;
}
export interface ApprovedOutDetail {
  approvedOutID: string;
  approvedOutDetailID: string;
  productID: number;
  maSP: string;
  tenSP: string;
  unitName: string;
  approvedQty: number;
  refundQty: number;
  batch: string;
  expdate: string;
  price: number | null;
  avgPrice: number;
  thanhTienHoan: number | null;
  serial: string | null;
  phone: string | null;
  invoiceBusinessDetailID: string;
}
export interface ResponseTemService {
  status: number;
  message: string;
}
