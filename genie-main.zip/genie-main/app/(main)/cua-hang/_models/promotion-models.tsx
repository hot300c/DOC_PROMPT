export interface PromotionCartItem {
  productId: string;
  productCode: string;
  productName: string;
  productBatch: string;
  expDate: string | undefined;
  quantity: number;
  price: number;
  manufacturerId?: string;
}

export interface PromotionRequest {
  facID: string;
  centerName: string;
  employeeType: number;
  employeeCode: string;
  stockName: string;
  customerCode: string;
  customerPhone: string;
  customerName: string;
  customerType: string;
  customerTier: number;
  cartItems: PromotionCartItem[];
  currentTotalAmount: number;
  currentTotalQuantity: number;
}

export interface GiftProduct {
  giftProductId: string;
  giftProductCode: string;
  giftProductName: string;
  quantity: number;
}

export interface GiftProductGroup {
  giftProductsDetail: GiftProduct[];
  promotionId: string;
  type: string;
  name: string;
  description: string;
  typeGift: number; // 1 = user choice required, 2 = auto apply
}

export interface PromotionItem {
  manufacturerId?: string;
  productId: string;
  productCode: string;
  productName: string;
  productBatch: string;
  expDate: string;
  quantity: number;
  price?: number;
  promotionId: string;
  name: string;
  type: string;
  description: string;
  discountAmount?: number;
  totalDiscountAmount: number;
  giftProducts: GiftProductGroup[];
}

export interface PromotionResponse {
  success: boolean;
  message: string;
  data: {
    checkID: string;
    promotionId: string;
    name: string;
    type: string;
    description: string;
    discountAmount: number;
    discountPercentage: number;
    totalDiscountAmount: number;
    giftProducts: GiftProductGroup[];
    promotion: PromotionItem[];
    messages: string[] | null;
  };
}
