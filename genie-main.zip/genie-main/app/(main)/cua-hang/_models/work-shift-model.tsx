export interface WorkShift {
  shiftDailyId: string;
  shiftId: number;
  shiftName: string;
  openedOn: string;
  ngayDoanhThu: string;
}
