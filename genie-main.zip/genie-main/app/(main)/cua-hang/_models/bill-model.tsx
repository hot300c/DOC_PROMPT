export interface InvoiceItem {
  invoiceId?: string;
  invoiceNo?: string;
  patientPay: number;
  moneyPaid: number;
  moneyOwe: number;
  thanhTien: number;
}
