export interface LocationData {
  id: string;
  name: string;
  code: string;
  type: string;
  maQuocGia: number;
  nameNoUnicode: string;
  districtID: string;
  wardID: string;
  maHuyenQuocGia: number;
}
