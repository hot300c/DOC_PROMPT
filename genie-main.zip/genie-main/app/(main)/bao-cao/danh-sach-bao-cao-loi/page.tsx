import FacilityInfo from "@/components/facilityInfo";
import { Suspense } from "react";
import DanhSachBaoCaoLoiContainer from "./_components/danh-sach-bao-cao-loi-container";
import { Loading } from "./_components/loading";
import { LoadingDanhSachBaoCaoLoiProvider } from "./_contexts/loading-danh-sach-bao-cao-loi-context";

// Source: https://git.vnvc.info/vnvc-qas/qas-app/-/blob/a1ee8fb73bba286279af5efa0a4ce38182af2a16/QA.ViewReportErrors/QA.ViewReportErrors/ViewReportErrorsControl.cs
export default async function Page() {
  return (
    <LoadingDanhSachBaoCaoLoiProvider>
      <FacilityInfo page={"BÁO CÁO | DANH SÁCH BÁO CÁO LỖI"} />
      <Suspense fallback={<Loading />}>
        <DanhSachBaoCaoLoiContainer />
      </Suspense>
    </LoadingDanhSachBaoCaoLoiProvider>
  );
}
