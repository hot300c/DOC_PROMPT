"use client";
import { ELoadingMessages } from "@/app/lib/enums";
import useLoading from "@/components/loading";
import { createContext, ReactNode, useContext, useRef } from "react";

interface LoadingDanhSachBaoCaoLoiContextType {
  setLoadingDanhSachBaoCaoLoi: (loading: boolean) => void;
}

const LoadingDanhSachBaoCaoLoiContext = createContext<
  LoadingDanhSachBaoCaoLoiContextType | undefined
>(undefined);

export const LoadingDanhSachBaoCaoLoiProvider = ({
  children,
}: {
  children: ReactNode;
}) => {
  const { showLoading, hideLoading } = useLoading();
  const loadingIdRef = useRef<string>("");

  const setLoadingDanhSachBaoCaoLoi = (loading: boolean) => {
    if (loading) {
      if (loadingIdRef.current) return;
      loadingIdRef.current = showLoading(ELoadingMessages.WAITING);
    } else {
      setTimeout(() => {
        hideLoading(loadingIdRef.current);
        loadingIdRef.current = "";
      });
    }
  };

  return (
    <LoadingDanhSachBaoCaoLoiContext.Provider
      value={{ setLoadingDanhSachBaoCaoLoi }}
    >
      {children}
    </LoadingDanhSachBaoCaoLoiContext.Provider>
  );
};

export const useLoadingDanhSachBaoCaoLoi =
  (): LoadingDanhSachBaoCaoLoiContextType => {
    const context = useContext(LoadingDanhSachBaoCaoLoiContext);
    if (context === undefined) {
      throw new Error(
        "useLoadingDanhSachBaoCaoLoi must be used within a LoadingDanhSachBaoCaoLoiProvider",
      );
    }
    return context;
  };
