"use client";

import { createContext, useContext, useState } from "react";
import { ReportErrors_List } from "../_utils/definitions/danh-sach-bao-cao-loi.dto";

type DanhSachBaoCaoLoiContextType = {
  reportsError: ReportErrors_List[];
  setReportsError: (data: ReportErrors_List[]) => void;
  facId: string;
  userId: string;
};

const DanhSachBaoCaoLoiContext = createContext<
  DanhSachBaoCaoLoiContextType | undefined
>(undefined);

export const useDanhSachBaoCaoLoi = () => {
  const context = useContext(DanhSachBaoCaoLoiContext);
  if (!context) {
    throw new Error(
      "useDanhSachBaoCaoLoi must be used within a DanhSachBaoCaoLoiProvider",
    );
  }
  return context;
};

interface DanhSachBaoCaoLoiProviderProps {
  children: React.ReactNode;
  facId: string;
  userId: string;
  reportsError: ReportErrors_List[];
}

export const DanhSachBaoCaoLoiProvider: React.FC<
  DanhSachBaoCaoLoiProviderProps
> = ({ facId, userId, reportsError: initialReportsError, children }) => {
  const [reportsError, setReportsError] = useState<ReportErrors_List[]>(
    initialReportsError || [],
  );

  return (
    <DanhSachBaoCaoLoiContext.Provider
      value={{
        reportsError,
        setReportsError,
        facId,
        userId,
      }}
    >
      {children}
    </DanhSachBaoCaoLoiContext.Provider>
  );
};
