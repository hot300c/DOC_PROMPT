import loadDataInit from "../_actions/load-data-init";
import { DanhSachBaoCaoLoiProvider } from "../_contexts/danh-sach-bao-cao-loi-context";
import DanhSachBaoCaoLoiPresentation from "./danh-sach-bao-cao-loi-presentation";

export default async function DanhSachBaoCaoLoiContainer() {
  const { reportsError, facId, userId } = await loadDataInit();

  return (
    <DanhSachBaoCaoLoiProvider
      facId={facId}
      userId={userId}
      reportsError={reportsError}
    >
      <DanhSachBaoCaoLoiPresentation />
    </DanhSachBaoCaoLoiProvider>
  );
}
