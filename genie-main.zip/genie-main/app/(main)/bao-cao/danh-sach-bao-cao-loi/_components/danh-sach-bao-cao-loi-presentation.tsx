"use client";

import {
  DataTable,
  DataTableColumnHeaderSort,
} from "@/components/ui/dataTable";
import { ColumnDef } from "@tanstack/react-table";
import { useRouter } from "next/navigation";
import { useEffect } from "react";
import { useDanhSachBaoCaoLoi } from "../_contexts/danh-sach-bao-cao-loi-context";
import { ReportErrors_List } from "../_utils/definitions/danh-sach-bao-cao-loi.dto";

const COLUMNS: ColumnDef<ReportErrors_List>[] = [
  {
    id: "reportID",
    accessorKey: "reportID",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="ReportID" />
    ),
    cell: ({ row }) => (
      <p
        className="line-clamp-1 min-w-[264px]"
        title={row.getValue("reportID")}
      >
        {row.getValue("reportID")}
      </p>
    ),
  },
  {
    id: "reportName",
    accessorKey: "reportName",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Tên Report" />
    ),
    cell: ({ row }) => (
      <p className="line-clamp-1 min-w-64" title={row.getValue("reportName")}>
        {row.getValue("reportName")}
      </p>
    ),
  },
  {
    id: "message",
    accessorKey: "message",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Thông báo" />
    ),
    cell: ({ row }) => (
      <p className="line-clamp-1 max-w-[15vw]" title={row.getValue("message")}>
        {row.getValue("message")}
      </p>
    ),
  },
  {
    id: "reportDataProc",
    accessorKey: "reportDataProc",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="DataProc" />
    ),
  },

  {
    id: "sql",
    accessorKey: "sql",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="SQL" />
    ),
    cell: ({ row }) => (
      <p className="line-clamp-1 max-w-[15vw]" title={row.getValue("sql")}>
        {row.getValue("sql")}
      </p>
    ),
  },
];

export default function DanhSachBaoCaoLoiPresentation() {
  const { reportsError } = useDanhSachBaoCaoLoi();
  const router = useRouter();

  useEffect(() => {
    const interval = setInterval(() => {
      router.refresh();
    }, 5000);

    return () => clearInterval(interval);
  }, [router]);
  return (
    <div className="flex flex-col flex-1 w-full overflow-hidden">
      <div className="w-full flex flex-col overflow-hidden flex-1 h-full">
        <DataTable
          columns={COLUMNS}
          data={reportsError || []}
          className="w-full h-full overflow-auto border"
          enablePaging={false}
          enableColumnFilter={true}
        />
      </div>
    </div>
  );
}
