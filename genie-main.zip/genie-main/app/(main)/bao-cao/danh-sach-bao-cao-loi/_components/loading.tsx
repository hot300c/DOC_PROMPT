import { Skeleton } from "@/components/ui/skeleton";

export const Loading = () => {
  return (
    <main className="w-full flex space-x-3 overflow-auto flex-1">
      <div className="w-full flex-1 flex-col flex space-y-2 items-center">
        <div className="w-full">
          <div className="flex flex-row gap-2 p-2">
            <Skeleton className="h-7 flex-1" />
            <Skeleton className="h-7 flex-1" />
            <Skeleton className="h-7 flex-1" />
            <Skeleton className="h-7 flex-1" />
            <Skeleton className="h-7 flex-1" />
          </div>
          <div className="px-2 space-y-2">
            <Skeleton className="h-7 flex-1" />
            <Skeleton className="h-7 flex-1" />
            <Skeleton className="h-7 flex-1" />
            <Skeleton className="h-7 flex-1" />
            <Skeleton className="h-7 flex-1" />
            <Skeleton className="h-7 flex-1" />
          </div>
        </div>
      </div>
    </main>
  );
};
