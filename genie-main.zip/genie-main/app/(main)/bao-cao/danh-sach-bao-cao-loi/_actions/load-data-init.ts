"use server";

import { getUserSession } from "@/actions/get-user-session";
import { ws_ReportErrors_List } from "../_utils/services/danh-sach-bao-cao-loi.api";

async function loadDataInit() {
  const { facId, userId } = await getUserSession();
  const reportsError = await ws_ReportErrors_List(facId);

  return {
    facId,
    userId,
    reportsError,
  };
}

export default loadDataInit;
