import * as httpService from "@/app/lib/network/http";
import { ReportErrors_List } from "../definitions/danh-sach-bao-cao-loi.dto";

export async function ws_ReportErrors_List(
  facId: string,
): Promise<ReportErrors_List[]> {
  const response = await httpService.post("/DataAccess", [
    {
      category: "Reports",
      command: "ws_ReportErrors_List",
      parameters: {
        FacID: facId,
      },
    },
  ]);

  return response.data.table;
}
