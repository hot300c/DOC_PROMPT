export type ReportErrors_List = {
  queueSeq: number;
  facID: string | null;
  reportID: string;
  reportName: string;
  reportParams: string;
  reportType: string;
  reportProgID: string;
  reportDataProc: string;
  sql: string;
  message: string;
  createdDate: string;
};
