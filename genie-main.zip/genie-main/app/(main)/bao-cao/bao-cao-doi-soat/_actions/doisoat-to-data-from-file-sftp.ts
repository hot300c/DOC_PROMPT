import {
  ReconciliationItemModel,
  DataFromFileSFTPModel,
} from "../_utils/definitions/model";
import { CANH_BAO } from "@/app/lib/enums";

//Đối soát từ data đọc từ file SFTP
export const onDoiSoatToDataFromFileSFTP = async (
  dataFromFileSFTP: DataFromFileSFTPModel[],
  dataFromSP: ReconciliationItemModel[],
  alert: any,
): Promise<ReconciliationItemModel[]> => {
  const sftpData = dataFromFileSFTP ?? [];
  const spData = dataFromSP ?? [];

  if (spData.length === 0) {
    await alert({
      title: CANH_BAO,
      content: "Chưa có dữ liệu trên phần mềm, vui lòng load dữ liệu trước.",
    });
    return dataFromSP;
  }

  if (sftpData.length === 0) {
    await alert({
      title: CANH_BAO,
      content: "Chưa có dữ liệu file SFTP, vui lòng load dữ liệu SFTP trước.",
    });
    return dataFromSP;
  }

  //Reset backColor
  const processedDataFromSP = dataFromSP.map((item) => ({
    ...item,
    backColor: "",
  }));

  // 1. Duyệt từ dataFromSFTP
  sftpData.forEach((dataFromFile: DataFromFileSFTPModel) => {
    // 1.1 Xử lý PAYMENT
    if (dataFromFile.TransactionType === "PAYMENT") {
      let isNotMatched = true;

      processedDataFromSP.forEach((dataFromSP) => {
        if (dataFromSP.id === dataFromFile.ID && !dataFromSP.isChenhLech) {
          dataFromSP.note = "Khớp";
          // Kiểm tra chênh lệch số tiền
          const spAmount = parseInt(
            dataFromSP.transactionAmountVNVC?.split(".")[0] || "0",
          );
          const sftpAmount = parseInt(dataFromFile.TransactionAmount);
          //console.log("spAmount/sftpAmount: ", spAmount+"/"+sftpAmount)
          if (spAmount !== sftpAmount) {
            dataFromSP.backColor = "Y";
            dataFromSP.transactionAmount = dataFromFile.TransactionAmount;
            dataFromSP.isChenhLech = true;
          }
        } else {
          isNotMatched = true;
        }
      });

      // Nếu không tìm thấy trong SP, thêm mới
      if (isNotMatched) {
        const newRow: ReconciliationItemModel = {
          sttWrapper: 0,
          note: "Không có giao dịch ở PM",
          transactionlogid: dataFromFile.ID,
          isHoanPhi: false,
          isChenhLech: true,
          accountedAmount: dataFromFile.AccountedAmount,
          backColor: "B",
          createdByUser: "",
          createdByUserName: "",
          createdByUserRefund: "",
          createdByUserRefundName: "",
          createdOnByUser: "",
          createdOnByUserRefund: "",
          currency: "VND",
          facID: "",
          facName: "",
          ftid: dataFromFile.FTID,
          id: dataFromFile.ID,
          tecombankInvoiceID: "",
          patientID: "",
          maKH: "",
          merchantOrderID: dataFromFile.MerchantOrderID,
          merchantCode: "",
          merchantName: "",
          merchantRef1: dataFromFile.MerchantRef1,
          merchantRef2: dataFromFile.MerchantRef2,
          merchantRef3: dataFromFile.MerchantRef3,
          merchantRef4: dataFromFile.MerchantRef4,
          merchantRef5: dataFromFile.MerchantRef5,
          orderdescription: dataFromFile.Orderdescription,
          partnerStoreID: dataFromFile.PartnerStoreID,
          partnerStoreName: "",
          partnerStoreIDRefund: "",
          partnerTerminalID: dataFromFile.PartnerTerminalID,
          partnerTerminalName: "",
          partnerTerminalIDRefund: "",
          paymentchannel: dataFromFile.Paymentchannel,
          refundAmountVNVC: "0",
          refundAmount: "0",
          refunddescription: "",
          refundNo: "",
          refundTransactionID: "",
          refundInvoiceID: "",
          senderaccountname: dataFromFile.Senderaccountname,
          senderaccountnumber: dataFromFile.Senderaccountnumber,
          senderbankname: dataFromFile.Senderbankname,
          receiveraccountname: "",
          receiveraccountnumber: "",
          receiverbankname: "",
          serviceName: dataFromFile.ServiceName,
          soPhieu: "",
          tcbStoreID: "",
          tcbTerminalID: "",
          tcbTransactionID: "",
          tenKH: dataFromFile.Senderaccountname,
          transactionAmountVNVC: dataFromFile.TransactionAmount,
          transactionAmount: dataFromFile.TransactionAmount,
          transactionTime: dataFromFile.TransactionTime,
          genQRTime: "",
          completeTime: "",
          refundTime: "",
          transactionType: dataFromFile.Paymentchannel,
          valuedate: "",
          //backColor: "R",
        };

        /* Logic cũ là ở đây push luôn: dẫn đến là nó push luôn cả các dòng đã tồn tại trong processedDataFromSP */
        // processedDataFromSP.push(newRow);

        /*Logic mới: Quyền kiểm tra xem dữ liệu đã tồn tại trong processedDataFromSP chưa, rồi mới push vào*/
        if (!processedDataFromSP.some((item) => item.id === newRow.id)) {
          processedDataFromSP.push(newRow);
        }
      }
    }
    // 1.2 Xử lý REFUND
    else if (dataFromFile.TransactionType === "REFUND") {
      let isRefundNotMatched = true;

      processedDataFromSP.forEach((dataFromSP) => {
        if (
          dataFromSP.refundTransactionID === dataFromFile.ID &&
          !dataFromSP.isChenhLech
        ) {
          const spRefundAmount = parseInt(
            dataFromSP.refundAmountVNVC?.split(".")[0] || "0",
          );
          const sftpAmount = parseInt(dataFromFile.TransactionAmount);

          if (spRefundAmount !== sftpAmount) {
            dataFromSP.backColor = "Y";
            dataFromSP.refundAmount = dataFromFile.TransactionAmount;
          }
        } else {
          isRefundNotMatched = true;
        }
      });

      // Nếu không tìm thấy refund trong SP, thêm mới
      if (isRefundNotMatched) {
        const newRefundRow: ReconciliationItemModel = {
          sttWrapper: 0,
          note: "Không có giao dịch ở PM",
          transactionlogid: dataFromFile.ID,
          isHoanPhi: false,
          isChenhLech: true,
          accountedAmount: dataFromFile.AccountedAmount,
          backColor: "B",
          createdByUser: "",
          createdByUserName: "",
          createdByUserRefund: "",
          createdByUserRefundName: "",
          createdOnByUser: "",
          createdOnByUserRefund: "",
          currency: "VND",
          facID: "",
          facName: "",
          ftid: dataFromFile.FTID,
          id: dataFromFile.ID,
          tecombankInvoiceID: "",
          patientID: "",
          maKH: "",
          merchantOrderID: dataFromFile.MerchantOrderID,
          merchantCode: "",
          merchantName: "",
          merchantRef1: dataFromFile.MerchantRef1,
          merchantRef2: dataFromFile.MerchantRef2,
          merchantRef3: dataFromFile.MerchantRef3,
          merchantRef4: dataFromFile.MerchantRef4,
          merchantRef5: dataFromFile.MerchantRef5,
          orderdescription: dataFromFile.Orderdescription,
          partnerStoreID: dataFromFile.PartnerStoreID,
          partnerStoreName: "",
          partnerStoreIDRefund: "",
          partnerTerminalID: dataFromFile.PartnerTerminalID,
          partnerTerminalName: "",
          partnerTerminalIDRefund: "",
          paymentchannel: dataFromFile.Paymentchannel,
          refundAmountVNVC: "0",
          refundAmount: "0",
          refunddescription: "",
          refundNo: "",
          refundTransactionID: "",
          refundInvoiceID: "",
          senderaccountname: dataFromFile.Senderaccountname,
          senderaccountnumber: dataFromFile.Senderaccountnumber,
          senderbankname: dataFromFile.Senderbankname,
          receiveraccountname: "",
          receiveraccountnumber: "",
          receiverbankname: "",
          serviceName: dataFromFile.ServiceName,
          soPhieu: "",
          tcbStoreID: "",
          tcbTerminalID: "",
          tcbTransactionID: "",
          tenKH: dataFromFile.Senderaccountname,
          transactionAmountVNVC: dataFromFile.TransactionAmount,
          transactionAmount: dataFromFile.TransactionAmount,
          transactionTime: dataFromFile.TransactionTime,
          genQRTime: "",
          completeTime: "",
          refundTime: "",
          transactionType: dataFromFile.Paymentchannel,
          valuedate: "",
        };

        /* Logic cũ là ở đây push luôn: dẫn đến là nó push luôn cả các dòng đã tồn tại trong processedDataFromSP */
        processedDataFromSP.push(newRefundRow);
        /*Logic mới: Quyền kiểm tra xem dữ liệu đã tồn tại trong processedDataFromSP chưa, rồi mới push vào*/
        if (processedDataFromSP.some((item) => item.id === newRefundRow.id)) {
          processedDataFromSP.push(newRefundRow);
        }
      }
    }
  });

  // Kiểm tra ngược lại từ SP những giao dịch không có trong SFTP
  processedDataFromSP.forEach((dataFromSP) => {
    if (!dataFromSP.isHoanPhi) {
      const found = (sftpData as DataFromFileSFTPModel[]).some(
        (item) => item.ID === dataFromSP.id,
      );
      if (!found) {
        dataFromSP.backColor = "B";
        dataFromSP.note = "Không có giao dịch ở Portal";
      }
    } else {
      const found = (sftpData as DataFromFileSFTPModel[]).some(
        (item) => item.ID === dataFromSP.refundTransactionID,
      );
      if (!found) {
        dataFromSP.backColor = "B";
        dataFromSP.note = "Không có giao dịch ở Portal";
      }
    }
  });

  return processedDataFromSP;
};
