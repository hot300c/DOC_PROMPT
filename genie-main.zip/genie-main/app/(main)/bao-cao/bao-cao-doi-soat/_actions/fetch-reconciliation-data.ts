"use server";

import { ReconciliationItemModel } from "../_utils/definitions/model";
import { SearchParams } from "../_utils/definitions/schema";
import { fetchReconciliationList } from "../_utils/services/fetch-reconciliation-list";

const fetchReconciliationData = async (searchParams?: SearchParams) => {
  let data: ReconciliationItemModel[] = [];
  if (searchParams?.fromDate && searchParams?.toDate) {
    data =
      (await fetchReconciliationList({
        bankCode: searchParams?.bankCode ?? "",
        fromDate: searchParams?.fromDate,
        toDate: searchParams?.toDate,
        isFileSFTP: searchParams?.isFileSFTP,
      })) || [];
  }

  return data;
};

export default fetchReconciliationData;
