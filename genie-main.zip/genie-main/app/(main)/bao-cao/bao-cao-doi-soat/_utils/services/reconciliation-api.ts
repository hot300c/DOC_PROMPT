"use server";
import { ws_L_API_Config_Load } from "@/app/lib/services/setting";

import { fetchVNVCApiResponse } from "@/app/lib/services/fetch-vnvc-api-response";
import * as utils from "@/app/lib/utils";
import {
  ConfigSFTPParamModel,
  DataFromExcelModel,
  ReconciliationTechcombankFTPParamModel,
} from "../definitions/model";
import { SearchParams } from "../definitions/schema";

export const reconciliationTechcombankApi = async (
  searchParams: SearchParams,
): Promise<DataFromExcelModel> => {
  const params: SearchParams = await searchParams;
  try {
    const [
      ipPostFTPTechcombank,
      usernameFTPTechcombank,
      passFTPTechcombank,
      linkGetFileSFTPTechcombank,
      usernameFTPTechcombankMB,
      passFTPTechcombankMB,
    ] = await Promise.all([
      ws_L_API_Config_Load({ facId: "8.1", key: "IpPostFTPTechcombank" }),
      ws_L_API_Config_Load({ facId: "8.1", key: "UsernameFTPTechcombank" }),
      ws_L_API_Config_Load({ facId: "8.1", key: "PassFTPTechcombank" }),
      ws_L_API_Config_Load({ facId: "8.1", key: "LinkGetFileSFTPTechcombank" }),
      ws_L_API_Config_Load({ facId: "8.1", key: "UsernameFTPTechcombankMB" }),
      ws_L_API_Config_Load({ facId: "8.1", key: "PassFTPTechcombankMB" }),
    ]);

    const value: ReconciliationTechcombankFTPParamModel = {
      ipPostFTPTechcombank: ipPostFTPTechcombank?.value || "",
      usernameFTPTechcombank: usernameFTPTechcombank?.value || "",
      passFTPTechcombank: passFTPTechcombank?.value || "",
      linkGetFileSFTPTechcombank: linkGetFileSFTPTechcombank?.value || "",
      usernameFTPTechcombankMB: usernameFTPTechcombankMB?.value || "",
      passFTPTechcombankMB: passFTPTechcombankMB?.value || "",
    };

    const sFTPConfig: ConfigSFTPParamModel = {
      ip: value.ipPostFTPTechcombank,
      date: utils.FormatDateToYYYYMMDD(new Date().toString()).replace(/-/g, ""),
      user: value.usernameFTPTechcombank,
      pass: value.passFTPTechcombank,
      facid: "8.1",
      port: 2022,
      filenameSFTP: `INPUT/${params?.tenFileMN ?? ""}`,
      //filenameSFTP: "INPUT/Tpay_VNVCMN_20250220_1", //khi cần test có thể hard code này dùng để test cho dễ
    };

    const result = await fetchVNVCApiResponse<DataFromExcelModel>(
      value.linkGetFileSFTPTechcombank,
      JSON.stringify(sFTPConfig),
      undefined,
      2,
    );

    if (!result)
      return { success: false, msg: "No data found" } as DataFromExcelModel;
    return result;
  } catch (error) {
    return { success: false, msg: error } as DataFromExcelModel;
  }
};
