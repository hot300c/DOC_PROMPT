import { getUserSession } from "@/actions/get-user-session";
import { logger } from "@/app/lib/logger";
import * as httpService from "@/app/lib/network/http";
import { ReconciliationItemModel } from "../definitions/model";

export const fetchReconciliationList = async ({
  bankCode,
  fromDate,
  toDate,
  isFileSFTP,
}: {
  bankCode: string;
  fromDate: string;
  toDate: string;
  isFileSFTP: boolean;
}): Promise<ReconciliationItemModel[] | undefined> => {
  try {
    let command: string =
      "ws_BIL_Invoice_Techcom_Transactions_Result_Get_ByCondition"; //default command lấy dữ liệu từ TCB
    if (bankCode.toLowerCase() === "tcb") {
      command = "ws_BIL_Invoice_Techcom_Transactions_Result_Get_ByCondition";
    } else if (bankCode.toLowerCase() === "mbb") {
      command = "ws_BIL_Invoice_MB_Transactions_Result_Get_ByCondition";
    }

    const { sessionId } = await getUserSession();
    const response = await httpService.post("/DataAccess", [
      {
        category: "QAHosGenericDB",
        command: command,
        parameters: {
          SessionID: sessionId,
          Fromdate: `${fromDate} 00:00:00.000`,
          Thrudate: `${toDate} 23:59:59.000`,
          SFTP: isFileSFTP,
        },
      },
    ]);

    return response.data.table;
  } catch (error) {
    logger.error("fetchReconciliationList: ", error);
  }
};
