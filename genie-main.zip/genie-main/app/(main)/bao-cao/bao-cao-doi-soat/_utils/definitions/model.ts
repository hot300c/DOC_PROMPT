export interface ReconciliationTechcombankFTPParamModel {
  ipPostFTPTechcombank: string;
  usernameFTPTechcombank: string;
  passFTPTechcombank: string;
  linkGetFileSFTPTechcombank: string;
  usernameFTPTechcombankMB: string;
  passFTPTechcombankMB: string;
}

export interface ConfigSFTPParamModel {
  ip: string;
  date: string;
  user: string;
  pass: string;
  facid: string;
  port: number;
  filenameSFTP: string;
}

/**
 * Model maping dữ liệu sau khi đọc dữ liệu từ file Excel (upload file excel)
 * - Dùng cho thực hiện đối soát (trong chức năng báo cáo đối soát)
 */
export interface DataFromExcelModel {
  STT?: number;
  ID: string;
  MerchantOrderID: string;
  TCBTransactionID: string;
  FTID: string;
  TransactionType: string;
  ServiceName: string;
  Currency: string;
  TransactionAmount: string; // Nếu cần xử lý số học, có thể đổi thành number
  AccountedAmount: string; // Nếu cần xử lý số học, có thể đổi thành number
  Orderdescription: string;
  TCBStoreID: string;
  PartnerStoreID: string;
  TCBTerminalID: string;
  PartnerTerminalID: string;
  TransactionTime: string; // Nếu cần xử lý ngày giờ, có thể đổi thành Date
  Valuedate: string; // Nếu cần xử lý ngày giờ, có thể đổi thành Date
  MerchantRef1: string;
  MerchantRef2: string;
  MerchantRef3: string;
  MerchantRef4: string;
  MerchantRef5: string;
  Senderaccountname: string;
  Senderaccountnumber: string;
  Senderbankname: string;
  Paymentchannel: string;
  isHoanPhi?: boolean;
  isChenhLech?: boolean;
  sttWrapper?: number;
  success?: boolean;
  msg?: string;
}

/**
 * Model maping dữ liệu json trả về dạng cell/row khi đọc dữ liệu trả về từ upload file Excel
 [
    {
        "0": "4a2b01da9c72497183a93f333ddea912",
        "1": "TE-055250220-00024-81159",
        "2": "195225fcb85bJHaj"
    }
]
 */
export interface DataFromExcelCellNoModel {
  [key: string]: string;
}

/**
 * Model maping dữ liệu sau khi gọi function reconciliationTechcombankApi đọc dữ liệu từ file trên sFTP (hay gọi là File sFTP)
 * - Trong function reconciliationTechcombankApi này sẽ xử lý parameter để sau đó call được API https://apivnvc.vnvc.info/api/Techcombank/BaoCaoDoiSoat/Get
 * - API này dùng để đọc dữ liệu từ file trên sFTP (hay gọi là File sFTP) => trả về Json dùng để Merge với data excecute từ SP: [QAHosGenericDB]..[ws_BIL_Invoice_Techcom_Transactions_Result_Get_ByCondition]
 * - Dùng cho thực hiện đối soát (trong chức năng báo cáo đối soát)
 */
export interface DataFromFileSFTPModel {
  ID: string;
  MerchantOrderID: string;
  TCBTransactionID: string;
  FTID: string;
  TransactionType: string;
  ServiceName: string;
  Currency: string;
  TransactionAmount: string; // Nếu cần xử lý số học, có thể đổi thành number
  AccountedAmount: string; // Nếu cần xử lý số học, có thể đổi thành number
  Orderdescription: string;
  TCBStoreID: string;
  PartnerStoreID: string;
  TCBTerminalID: string;
  PartnerTerminalID: string;
  TransactionTime: string; // Nếu cần xử lý ngày giờ, có thể đổi thành Date
  Valuedate: string; // Nếu cần xử lý ngày giờ, có thể đổi thành Date
  MerchantRef1: string;
  MerchantRef2: string;
  MerchantRef3: string;
  MerchantRef4: string;
  MerchantRef5: string;
  Senderaccountname: string;
  Senderaccountnumber: string;
  Senderbankname: string;
  Paymentchannel: string;
  isHoanPhi: boolean;
  isChenhLech: boolean;
  sttWrapper?: number;
  success?: boolean;
  msg?: string;
}

/**
 * Model maping dữ liệu từ execute SP: [QAHosGenericDB]..[ws_BIL_Invoice_Techcom_Transactions_Result_Get_ByCondition]
 * Field sttWrapper này ko có trong SP: [QAHosGenericDB]..[ws_BIL_Invoice_Techcom_Transactions_Result_Get_ByCondition]
 * - Nhưng ReconciliationItemModel vẫn có để xử lý STT khi render lên table
 */
export interface ReconciliationItemModel {
  sttWrapper: number;
  note: string;
  transactionlogid: string;
  isHoanPhi: boolean;
  isChenhLech: boolean;
  accountedAmount: string;
  backColor: string;
  createdByUser: string;
  createdByUserName: string;
  createdByUserRefund: string;
  createdByUserRefundName: string;
  createdOnByUser: string;
  createdOnByUserRefund: string;
  currency: string;
  facID: string;
  facName: string;
  ftid: string;
  id: string;
  tecombankInvoiceID: string;
  patientID: string;
  maKH: string;
  merchantOrderID: string;
  merchantCode: string;
  merchantName: string;
  merchantRef1: string;
  merchantRef2: string;
  merchantRef3: string;
  merchantRef4: string;
  merchantRef5: string;
  orderdescription: string;
  partnerStoreID: string;
  partnerStoreName: string;
  partnerStoreIDRefund: string;
  partnerTerminalID: string;
  partnerTerminalName: string;
  partnerTerminalIDRefund: string;
  paymentchannel: string;
  refundAmountVNVC: string;
  refundAmount: string;
  refunddescription: string;
  refundNo: string;
  refundTransactionID: string;
  refundInvoiceID: string;
  senderaccountname: string;
  senderaccountnumber: string;
  senderbankname: string;
  receiveraccountname: string;
  receiveraccountnumber: string;
  receiverbankname: string;
  serviceName: string;
  soPhieu: string;
  tcbStoreID: string;
  tcbTerminalID: string;
  tcbTransactionID: string;
  tenKH: string;
  transactionAmountVNVC: string;
  transactionAmount: string;
  transactionTime: string;
  genQRTime: string;
  completeTime: string;
  refundTime: string;
  transactionType: string;
  valuedate: string;
}

export type MBBankConfig = {
  access_code: string;
  hash_secret: string;
  merchant_id: string;
  channel: string;
  init_url: string;
  init_url_Genie: string;
  inquiry_url: string;
  inquiry_url_Genie: string;
  return_url: string;
  return_url_Genie: string;
  refund_url: string;
  refund_url_Genie: string;
  cancel_url: string;
  cancel_url_Genie: string;
  ipn_url: string;
  ipn_url_Genie: string;
  pay_type: string;
  payment_method: string;
  merchant_user_reference: string;
};
