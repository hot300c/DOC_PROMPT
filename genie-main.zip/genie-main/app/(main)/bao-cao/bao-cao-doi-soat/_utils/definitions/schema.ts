import { z } from "zod";

export const ReconciliationSearchParamSchema = z.object({
  fromDate: z
    .string({
      required_error: "Vui lòng chọn ngày",
    })
    .min(1, { message: "Vui lòng chọn ngày" }),
  toDate: z
    .string({
      required_error: "Vui lòng chọn ngày",
    })
    .min(1, { message: "Vui lòng chọn ngày" }),
  bankCode: z.string().optional(),
  tenFileMN: z.string().optional(),
  tenFileMB: z.string().optional(),
  isFileSFTP: z.boolean(),
});

export type SearchParams = z.infer<typeof ReconciliationSearchParamSchema>;
