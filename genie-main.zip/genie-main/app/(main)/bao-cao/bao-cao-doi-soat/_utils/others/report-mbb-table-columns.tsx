import { ColumnDef } from "@tanstack/react-table";
import { ReconciliationItemModel } from "../definitions/model";
import { DataTableColumnHeaderSort } from "@/components/ui/dataTable";
import { Checkbox } from "@/components/ui/checkbox";
import { cn } from "@/app/lib/utils";
import * as utils from "@/app/lib/utils";
import _ from "lodash";

export const reportMBBColumns: ColumnDef<ReconciliationItemModel>[] = [
  {
    id: "sttWrapper",
    accessorKey: "sttWrapper",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="STT" />
    ),
    cell: ({ row }) => (
      <p title={row.original.sttWrapper?.toString()}>
        {row.original.sttWrapper}
      </p>
    ),
  },
  {
    id: "note",
    accessorKey: "note",
    header: ({ column }) => (
      <DataTableColumnHeaderSort
        column={column}
        title="Ghi chú (KQ đối soát)"
        className="w-[200px]"
      />
    ),
    cell: ({ row }) => (
      <p className="line-clamp-1" title={row.original.note}>
        {row.original.note}
      </p>
    ),
  },
  {
    id: "isChenhLech",
    accessorKey: "isChenhLech",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Chênh Lệch" />
    ),
    cell: ({ row }) => (
      <div
        className={cn("text-center", {
          "bg-red-500": row.original.isChenhLech,
        })}
      >
        <Checkbox checked={row.original.isChenhLech} />
      </div>
    ),
  },
  {
    id: "isHoanPhi",
    accessorKey: "isHoanPhi",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Hoàn Phí" />
    ),
    cell: ({ row }) => (
      <div
        className={cn("text-center", {
          "bg-red-500": row.original.isHoanPhi,
        })}
      >
        <Checkbox checked={row.original.isHoanPhi} />
      </div>
    ),
  },
  {
    id: "facName",
    accessorKey: "facName",
    header: ({ column }) => (
      <DataTableColumnHeaderSort
        column={column}
        title="Cơ sở"
        className="w-[300px]"
      />
    ),
    cell: ({ row }) => (
      <p className="line-clamp-1" title={row.original.facName}>
        {row.original.facName}
      </p>
    ),
  },
  {
    id: "maKH",
    accessorKey: "maKH",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Mã KH" />
    ),
    cell: ({ row }) => (
      <p className="line-clamp-1" title={row.original.maKH}>
        {row.original.maKH}
      </p>
    ),
  },
  {
    id: "tenKH",
    accessorKey: "tenKH",
    header: ({ column }) => (
      <DataTableColumnHeaderSort
        column={column}
        title="Tên KH"
        className="w-[200px]"
      />
    ),
    cell: ({ row }) => (
      <p className="line-clamp-1" title={row.original.tenKH}>
        {row.original.tenKH}
      </p>
    ),
  },
  {
    id: "soPhieu",
    accessorKey: "soPhieu",
    header: ({ column }) => (
      <DataTableColumnHeaderSort
        column={column}
        title="Số phiếu"
        className="w-[150px]"
      />
    ),
    footer: ({ table }) => (
      <div className="text-right font-semibold bg-white p-1">{`TC: ${table.getSortedRowModel().rows.length}`}</div>
    ),
    cell: ({ row }) => (
      <p className="line-clamp-1" title={row.original.soPhieu}>
        {row.original.soPhieu}
      </p>
    ),
  },
  {
    id: "partnerStoreID",
    accessorKey: "partnerStoreID",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Mã Cửa Hàng" />
    ),
    cell: ({ row }) => (
      <p className="line-clamp-1" title={row.original.partnerStoreID}>
        {row.original.partnerStoreID}
      </p>
    ),
  },
  {
    id: "partnerTerminalID",
    accessorKey: "partnerTerminalID",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Mã Quầy" />
    ),
    cell: ({ row }) => (
      <p className="line-clamp-1" title={row.original.partnerTerminalID}>
        {row.original.partnerTerminalID}
      </p>
    ),
  },
  {
    id: "id",
    accessorKey: "id",
    header: ({ column }) => (
      <DataTableColumnHeaderSort
        column={column}
        title="ID Thanh Toán MBB"
        className="w-[150px]"
      />
    ),
    cell: ({ row }) => (
      <p className="line-clamp-1" title={row.original.id}>
        {row.original.id}
      </p>
    ),
  },
  {
    id: "tCBTransactionID",
    accessorKey: "tCBTransactionID",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Mã Giao Dịch MBB" />
    ),
    cell: ({ row }) => (
      <p className="line-clamp-1" title={row.original.tcbTransactionID}>
        {row.original.tcbTransactionID}
      </p>
    ),
  },
  {
    id: "fTID",
    accessorKey: "fTID",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Mã Hoàn Phí MBB" />
    ),
    cell: ({ row }) => (
      <p className="line-clamp-1" title={row.original.ftid}>
        {row.original.ftid}
      </p>
    ),
  },
  {
    id: "transactionAmountVNVC",
    accessorKey: "transactionAmountVNVC",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Thanh toán VNVC" />
    ),
    cell: ({ row }) => (
      <div className="text-right">
        {utils.formatCurrency(
          parseFloat(row.original.transactionAmountVNVC),
          false,
        )}
      </div>
    ),
    footer: ({ table }) => (
      <div className="text-right font-semibold bg-white p-1">
        {utils.formatCurrency(
          _.sumBy(table.getSortedRowModel().rows, (row) =>
            parseFloat(row.original.transactionAmountVNVC ?? "0"),
          ),
          false,
        )}
      </div>
    ),
  },
  {
    id: "transactionTime",
    accessorKey: "transactionTime",
    header: ({ column }) => (
      <DataTableColumnHeaderSort
        column={column}
        title="Thời Gian Tạo Giao Dịch"
      />
    ),
    cell: ({ row }) => (
      <p className="line-clamp-1" title={row.original.transactionTime}>
        {row.original.transactionTime}
      </p>
    ),
  },
  {
    id: "orderdescription",
    accessorKey: "orderdescription",
    header: ({ column }) => (
      <DataTableColumnHeaderSort
        column={column}
        title="Mô Tả TT"
        className="w-[200px]"
      />
    ),
    cell: ({ row }) => (
      <p className="line-clamp-1" title={row.original.orderdescription}>
        {row.original.orderdescription}
      </p>
    ),
  },
  {
    id: "merchantOrderID",
    accessorKey: "merchantOrderID",
    header: ({ column }) => (
      <DataTableColumnHeaderSort
        column={column}
        title="Mã HĐ MBB"
        className="w-[170px]"
      />
    ),
    cell: ({ row }) => (
      <p className="line-clamp-1" title={row.original.merchantOrderID}>
        {row.original.merchantOrderID}
      </p>
    ),
  },
  {
    id: "transactionAmount",
    accessorKey: "transactionAmount",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Thanh Toán MBB" />
    ),
    cell: ({ row }) => (
      <div className="text-right">
        {utils.formatCurrency(
          parseFloat(row.original.transactionAmount),
          false,
        )}
      </div>
    ),
    footer: ({ table }) => (
      <div className="text-right font-semibold bg-white p-1">
        {utils.formatCurrency(
          _.sumBy(table.getSortedRowModel().rows, (row) =>
            parseFloat(row.original.transactionAmount ?? "0"),
          ),
          false,
        )}
      </div>
    ),
  },

  {
    id: "refundTransactionID",
    accessorKey: "refundTransactionID",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="ID Hoàn Phí" />
    ),
    cell: ({ row }) => (
      <p className="line-clamp-1" title={row.original.refundTransactionID}>
        {row.original.refundTransactionID}
      </p>
    ),
  },

  {
    id: "refundNo",
    accessorKey: "refundNo",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Mã Hoàn HP VNVC" />
    ),
    cell: ({ row }) => (
      <p className="line-clamp-1" title={row.original.refundNo}>
        {row.original.refundNo}
      </p>
    ),
  },
  {
    id: "refundAmountVNVC",
    accessorKey: "refundAmountVNVC",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Hoàn Phí VNVC" />
    ),
    cell: ({ row }) => (
      <div className="text-right">
        {utils.formatCurrency(
          parseFloat(row.original.refundAmountVNVC ?? "0"),
          false,
        )}
      </div>
    ),
    footer: ({ table }) => (
      <div className="text-right font-semibold bg-white p-1">
        {utils.formatCurrency(
          _.sumBy(table.getSortedRowModel().rows, (row) =>
            parseFloat(row.original.refundAmountVNVC ?? "0"),
          ),
          false,
        )}
      </div>
    ),
  },
  {
    id: "refundAmount",
    accessorKey: "refundAmount",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Hoàn Phí MBB" />
    ),
    cell: ({ row }) => (
      <div className="text-right">
        {utils.formatCurrency(
          parseFloat(row.original.refundAmount ?? "0"),
          false,
        )}
      </div>
    ),
    footer: ({ table }) => (
      <div className="text-right font-semibold bg-white p-1">
        {utils.formatCurrency(
          _.sumBy(table.getSortedRowModel().rows, (row) =>
            parseFloat(row.original.refundAmount ?? "0"),
          ),
          false,
        )}
      </div>
    ),
  },

  {
    id: "refunddescription",
    accessorKey: "refunddescription",
    header: ({ column }) => (
      <DataTableColumnHeaderSort
        column={column}
        title="Mô Tả HP"
        className="w-[200px]"
      />
    ),
    cell: ({ row }) => (
      <p className="line-clamp-1" title={row.original.refunddescription}>
        {row.original.refunddescription}
      </p>
    ),
  },

  {
    id: "createdByUserName",
    accessorKey: "createdByUserName",
    header: ({ column }) => (
      <DataTableColumnHeaderSort
        column={column}
        title="Nhân Viên TT"
        className="w-[200px]"
      />
    ),
    cell: ({ row }) => (
      <p className="line-clamp-1" title={row.original.createdByUserName}>
        {row.original.createdByUserName}
      </p>
    ),
  },

  {
    id: "createdByUserRefundName",
    accessorKey: "createdByUserRefundName",
    header: ({ column }) => (
      <DataTableColumnHeaderSort
        column={column}
        title="Nhân Viên HP"
        className="w-[200px]"
      />
    ),
    cell: ({ row }) => (
      <p className="line-clamp-1" title={row.original.createdByUserRefundName}>
        {row.original.createdByUserRefundName}
      </p>
    ),
  },

  {
    id: "senderaccountnumber",
    accessorKey: "senderaccountnumber",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Số TK Chuyển" />
    ),
    cell: ({ row }) => (
      <p className="line-clamp-1" title={row.original.senderaccountnumber}>
        {row.original.senderaccountnumber}
      </p>
    ),
  },

  {
    id: "receiveraccountnumber",
    accessorKey: "receiveraccountnumber",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Số TK Nhận" />
    ),
    cell: ({ row }) => (
      <p className="line-clamp-1" title={row.original.receiveraccountnumber}>
        {row.original.receiveraccountnumber}
      </p>
    ),
  },

  {
    id: "merchantCode",
    accessorKey: "merchantCode",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Mã Nhà Cung Cấp" />
    ),
    cell: ({ row }) => (
      <p className="line-clamp-1" title={row.original.merchantCode}>
        {row.original.merchantCode}
      </p>
    ),
  },

  {
    id: "merchantName",
    accessorKey: "merchantName",
    header: ({ column }) => (
      <DataTableColumnHeaderSort
        column={column}
        title="Tên Nhà Cung Cấp"
        className="w-[250px]"
      />
    ),
    cell: ({ row }) => (
      <p className="line-clamp-1" title={row.original.merchantName}>
        {row.original.merchantName}
      </p>
    ),
  },

  {
    id: "partnerStoreName",
    accessorKey: "partnerStoreName",
    header: ({ column }) => (
      <DataTableColumnHeaderSort
        column={column}
        title="Tên Cửa Hàng"
        className="w-[250px]"
      />
    ),
    cell: ({ row }) => (
      <p className="line-clamp-1" title={row.original.partnerStoreName}>
        {row.original.partnerStoreName}
      </p>
    ),
  },

  {
    id: "partnerTerminalName",
    accessorKey: "partnerTerminalName",
    header: ({ column }) => (
      <DataTableColumnHeaderSort
        column={column}
        title="Tên Quầy"
        className="w-[250px]"
      />
    ),
    cell: ({ row }) => (
      <p className="line-clamp-1" title={row.original.partnerTerminalName}>
        {row.original.partnerTerminalName}
      </p>
    ),
  },

  {
    id: "genQRTime",
    accessorKey: "genQRTime",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Thời Gian Tạo QR" />
    ),
    cell: ({ row }) => (
      <p className="line-clamp-1" title={row.original.genQRTime}>
        {row.original.genQRTime}
      </p>
    ),
  },

  {
    id: "refundTime",
    accessorKey: "refundTime",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Thời Gian Hoàn Phí" />
    ),
    cell: ({ row }) => (
      <p className="line-clamp-1" title={row.original.refundTime}>
        {row.original.refundTime}
      </p>
    ),
  },

  {
    id: "paymentchannel",
    accessorKey: "paymentchannel",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Kênh Xử Lý" />
    ),
    cell: ({ row }) => (
      <p className="line-clamp-1" title={row.original.paymentchannel}>
        {row.original.paymentchannel}
      </p>
    ),
  },

  // transactionType trên QAS không có, nhưng trên này hiển thị để check đối soát
  {
    id: "transactionType",
    accessorKey: "transactionType",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Transaction Type" />
    ),
    cell: ({ row }) => (
      <p className="line-clamp-1" title={row.original.transactionType}>
        {row.original.transactionType}
      </p>
    ),
  },
];
