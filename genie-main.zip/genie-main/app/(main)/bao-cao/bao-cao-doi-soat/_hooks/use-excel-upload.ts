"use client";
import { useState } from "react";
import {
  DataFromExcelModel,
  DataFromExcelCellNoModel,
} from "../_utils/definitions/model";
import { processExcelFile } from "@/app/lib/utils/handle-excel";

// hooks/useExcelUpload.ts
export const useExcelUpload = (
  setLoading: (loading: boolean) => void,
  setDataFromFileSFTP: (data: any[]) => void,
) => {
  // Local states
  const [dataFileExcel, setDataFileExcel] = useState<DataFromExcelModel[]>([]);
  const [countDataFromFile, setCountDataFromFile] = useState(0);
  // Handler functions
  const handleExcelUpload = async (
    event: React.ChangeEvent<HTMLInputElement>,
  ) => {
    const file = event.target.files?.[0];
    if (file) {
      setLoading(true);
      try {
        const jsonDataFromExcel = await processExcelFile(file);
        setCountDataFromFile(jsonDataFromExcel?.length ?? 0);
        const jsonDataWrapper = mapExcelDataToModel(jsonDataFromExcel);
        setDataFileExcel(jsonDataWrapper);
        setDataFromFileSFTP([]); // Xóa data SFTP khi upload file excel
      } catch (error) {
        console.error("Error processing excel file:", error);
        setLoading(false);
      } finally {
        setLoading(false);
      }
    }
    if (event.target) {
      event.target.value = "";
    }
  };

  // Return hook values
  return {
    dataFileExcel,
    countDataFromFile,
    handleExcelUpload,
    setDataFileExcel,
  };
};

function mapExcelDataToModel(
  jsonDataFromExcel: DataFromExcelCellNoModel[] | null,
): DataFromExcelModel[] {
  if (!jsonDataFromExcel) return [];
  return jsonDataFromExcel.map(
    (item: DataFromExcelCellNoModel, index: number) => ({
      STT: index + 1,
      ID: item["0"] ?? "",
      MerchantOrderID: item["1"] ?? "",
      TCBTransactionID: item["2"] ?? "",
      FTID: item["3"] ?? "",
      TransactionType: item["4"] ?? "",
      ServiceName: item["5"] ?? "",
      Currency: item["6"] ?? "",
      TransactionAmount: item["7"] ?? "",
      AccountedAmount: item["8"] ?? "",
      Orderdescription: item["9"] ?? "",
      TCBStoreID: item["10"] ?? "",
      PartnerStoreID: item["11"] ?? "",
      TCBTerminalID: item["12"] ?? "",
      PartnerTerminalID: item["13"] ?? "",
      TransactionTime: item["14"] ?? "",
      Valuedate: item["15"] ?? "",
      MerchantRef1: item["16"] ?? "",
      MerchantRef2: item["17"] ?? "",
      MerchantRef3: item["18"] ?? "",
      MerchantRef4: item["19"] ?? "",
      MerchantRef5: item["20"] ?? "",
      Senderaccountname: item["21"] ?? "",
      Senderaccountnumber: item["22"] ?? "",
      Senderbankname: item["23"] ?? "",
      Paymentchannel: item["24"] ?? "",
    }),
  );
}
