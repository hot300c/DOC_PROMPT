"use client";
import { useState } from "react";
import { SearchParams } from "../_utils/definitions/schema";
import { useRouter } from "next/navigation";

// hooks/useFilterAndRouting.ts
export const useFilterAndRouting = (
  initialFilter: SearchParams,
  initialBank: string,
  setLoading: (loading: boolean) => void,
) => {
  const router = useRouter();
  const [filter, setFilter] = useState(initialFilter);
  const [bankCodeActiveTab, setBankCodeActiveTab] = useState(
    initialBank ?? "TCB",
  );

  const handleFilterChange = async (newFilter: SearchParams) => {
    setLoading(true);
    setFilter(newFilter);
    await updateURL(newFilter, bankCodeActiveTab);
  };

  const handleTabChange = (value: string) => {
    // Chỉ cập nhật state local, không trigger server render
    setBankCodeActiveTab(value);
  };

  const updateURL = async (filterParams: SearchParams, bankCode: string) => {
    const params = new URLSearchParams({
      bankCode,
      fromDate: filterParams.fromDate,
      toDate: filterParams.toDate,
      tenFileMN: filterParams.tenFileMN ?? "",
      tenFileMB: filterParams.tenFileMB ?? "",
      isFileSFTP: String(filterParams.isFileSFTP),
    });
    await router.push(`?${params.toString()}`);
  };

  return {
    filter,
    bankCodeActiveTab,
    handleFilterChange,
    handleTabChange,
  };
};
