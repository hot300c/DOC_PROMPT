"use server";
import ClientComponent from "./_components/ClientComponent";
import React from "react";
import { format } from "date-fns";
import { DATE_FORMAT } from "@/app/lib/enums";
import fetchReconciliationData from "./_actions/fetch-reconciliation-data";
import { SearchParams } from "./_utils/definitions/schema";
import {
  DataFromFileSFTPModel,
  ReconciliationItemModel,
} from "./_utils/definitions/model";
import { reconciliationTechcombankApi } from "./_utils/services/reconciliation-api";

const initialState: SearchParams = {
  bankCode: "TCB",
  fromDate: format(new Date(), DATE_FORMAT.YYYY_MM_DD),
  toDate: format(new Date(), DATE_FORMAT.YYYY_MM_DD),
  tenFileMN: `Tpay_VNVCMN_${new Date().toISOString().slice(0, 10).replace(/-/g, "")}_1`,
  tenFileMB: `Tpay_VNVCMB_${new Date().toISOString().slice(0, 10).replace(/-/g, "")}_1`,
  isFileSFTP: true,
};

export default async function Page({
  searchParams,
}: {
  searchParams: Promise<SearchParams>;
}) {
  const params: SearchParams = await searchParams;
  const bankCode = params?.bankCode || initialState.bankCode;

  const isFileSFTP = params?.isFileSFTP?.toString() === "true";

  const filter = {
    bankCode: bankCode,
    fromDate: params?.fromDate || initialState.fromDate,
    toDate: params?.toDate || initialState.toDate,
    isFileSFTP:
      params?.isFileSFTP !== undefined ? isFileSFTP : initialState?.isFileSFTP,
    tenFileMN: params?.tenFileMN || initialState.tenFileMN,
    tenFileMB: params?.tenFileMB || initialState.tenFileMB,
  };

  const data = await fetchReconciliationData(filter);
  const dataFromSP = data.map(
    (item: ReconciliationItemModel, index: number) => {
      return {
        ...item,
        sttWrapper: index + 1,
      };
    },
  );

  let dataFromFileSFTP: DataFromFileSFTPModel[] = [];
  const isFileSFTPstr = String(filter.isFileSFTP);
  if (isFileSFTPstr === "true") {
    // If checked isFileSFTP => all API get data from file SFTP
    const result = await reconciliationTechcombankApi(params);
    dataFromFileSFTP = (
      Array.isArray(result) ? result : [result]
    ) as DataFromFileSFTPModel[];
  }

  return (
    <ClientComponent
      dataFromSP={dataFromSP}
      dataFromFileSFTP={dataFromFileSFTP || []}
      initialBank={bankCode || ""}
      initialFilter={filter}
    />
  );
}
