"use client";

import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { useState } from "react";
import { Loader2 } from "lucide-react";

type FooterProps = {
  exportToExcel: () => Promise<void>;
  doiSoat: () => Promise<void>;
  showDataFromExcel: () => void;
  showDataFromSFTP: () => void;
  visibleDoiSoat?: boolean;
  countDataFromSP?: number;
  countDataFromExcel?: number;
  countDataFromFileSFTP?: number;
};

const Footer: React.FC<FooterProps> = ({
  exportToExcel,
  doiSoat,
  showDataFromExcel,
  showDataFromSFTP,
  countDataFromSP,
  countDataFromExcel,
  countDataFromFileSFTP,
}) => {
  const [isExporting, setIsExporting] = useState(false);
  const [isDoiSoat, setIsDoiSoat] = useState(false);

  const handleExportExcel = async () => {
    setIsExporting(true);
    try {
      await exportToExcel();
    } finally {
      setIsExporting(false);
    }
  };

  const handleDoiSoat = async () => {
    setIsDoiSoat(true);
    try {
      await doiSoat();
    } finally {
      setIsDoiSoat(false);
    }
  };

  return (
    <div className="w-full fixed bottom-0 left-0 bg-muted py-2 px-4">
      <div className="flex justify-end">
        <div className="flex space-x-2 items-center">
          <div className="flex items-center gap-2 p-2 bg-gray-100 rounded-md">
            <div className="font-semibold">Ghi chú</div>
            <div className="flex items-center gap-1">
              <span className="text-sm">: Không có giao dịch ở Portal |</span>
            </div>

            <div className="flex items-center gap-1.5">
              <Checkbox
                id="portal-check"
                className="h-4 w-4 rounded border-gray-300"
              />
              <label htmlFor="portal-check" className="text-sm">
                Chênh lệch
              </label>
              <span className="text-sm">: Không có giao dịch ở PM |</span>
            </div>

            <div className="flex items-center gap-1.5">
              <Checkbox
                id="pm-check"
                className="h-4 w-4 rounded border-gray-300"
              />
              <label htmlFor="pm-check" className="text-sm">
                Chênh lệch
              </label>
            </div>

            <div className="flex items-center gap-1.5">
              <div className="bg-red-500 h-4 w-4"></div>
              <span className="text-sm">
                : Chênh lệch tiền thanh toán/hoàn hủy
              </span>
            </div>

            <div className="ml-auto flex gap-2">
              <div className="flex items-center gap-1">
                <span className="text-sm">
                  {(countDataFromSP ?? 0) > 0 &&
                    `| Dữ liệu từ phần mềm: ${countDataFromSP} |`}
                </span>
                <span
                  className="text-sm text-blue-500 cursor-pointer"
                  onClick={showDataFromExcel}
                >
                  {(countDataFromExcel ?? 0) > 0 &&
                    `Dữ liệu từ upload file: ${countDataFromExcel} |`}
                </span>

                {(countDataFromExcel ?? 0) === 0 && (
                  <span
                    className="text-sm text-blue-500 cursor-pointer"
                    onClick={showDataFromSFTP}
                  >
                    {(countDataFromFileSFTP ?? 0) > 1 &&
                      `Dữ liệu từ SFTP file: ${countDataFromFileSFTP} |`}
                  </span>
                )}
              </div>

              <Button
                disabled={isExporting}
                variant="outline"
                size="sm"
                className="bg-gray-200 hover:bg-gray-300 text-black"
                onClick={handleExportExcel}
              >
                {isExporting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Đang xuất Excel...
                  </>
                ) : (
                  "Xuất Excel"
                )}
              </Button>

              <Button
                disabled={
                  isDoiSoat ||
                  ((countDataFromExcel ?? 0) === 0 &&
                    (countDataFromFileSFTP ?? 0) <= 1)
                }
                variant="outline"
                size="sm"
                className="bg-gray-200 hover:bg-gray-300 text-black"
                onClick={handleDoiSoat}
              >
                {isDoiSoat ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Đang đối soát...
                  </>
                ) : (
                  "Đối soát"
                )}
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Footer;
