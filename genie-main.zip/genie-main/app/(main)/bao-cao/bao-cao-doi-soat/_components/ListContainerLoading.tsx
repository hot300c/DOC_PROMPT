import { Skeleton } from "@/components/ui/skeleton";
import React from "react";

const ListContainerLoading: React.FC = () => {
  return (
    <>
      <main className="w-full overflow-auto h-[calc(100vh-48px-90px-80px)]">
        <div className="flex flex-row gap-2 p-2">
          <Skeleton className="h-7 flex-1" />
          <Skeleton className="h-7 flex-1" />
          <Skeleton className="h-7 flex-1" />
          <Skeleton className="h-7 flex-1" />
          <Skeleton className="h-7 flex-1" />
          <Skeleton className="h-7 flex-1" />
        </div>
        <div className="px-2 space-y-2">
          <Skeleton className="h-7 flex-1" />
          <Skeleton className="h-7 flex-1" />
          <Skeleton className="h-7 flex-1" />
          <Skeleton className="h-7 flex-1" />
          <Skeleton className="h-7 flex-1" />
          <Skeleton className="h-7 flex-1" />
        </div>
      </main>
    </>
  );
};

export default ListContainerLoading;
