"use client";
import { ETitleConfirm } from "@/app/lib/enums";
import { useFeedbackDialog } from "@/app/lib/feedback-dialog-provider";
import { exportToExcel } from "@/app/lib/utils/exportToExcel ";
import { Button } from "@/components/ui/button";
import { DataTable } from "@/components/ui/dataTable";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogOverlay,
  DialogTitle,
} from "@/components/ui/dialog";
import { Description } from "@radix-ui/react-dialog";
import { Row } from "@tanstack/react-table";
import { useMemo, useState } from "react";
import ListContainerLoading from "../../../../../components/stories/list-container-loading";
import { onDoiSoatToDataFromExcel } from "../_actions/doisoat-to-data-from-file-excel";
import { onDoiSoatToDataFromFileSFTP } from "../_actions/doisoat-to-data-from-file-sftp";
import {
  DataFromExcelModel,
  DataFromFileSFTPModel,
  ReconciliationItemModel,
} from "../_utils/definitions/model";
import { reportMBBColumns } from "../_utils/others/report-mbb-table-columns";
import { reportTableConfig } from "../_utils/others/report-table-config";
import { reportTCBColumns } from "../_utils/others/report-tcb-table-columns";
import Footer from "./footer";
import GridDataFromExcel from "./GridDataFromExcel";
import GridDataFromSFTP from "./GridDataFromSFTP";

export type ReconciliationReport = {
  bankCode: string;
  dataFromSP: ReconciliationItemModel[];
  dataFromExcel: DataFromExcelModel[];
  dataFromFileSFTP: DataFromFileSFTPModel[];
};

const ReconciliationReport = ({
  bankCode,
  dataFromSP,
  dataFromExcel,
  dataFromFileSFTP,
}: ReconciliationReport) => {
  const [selectedInvoice, setSelectedInvoice] =
    useState<ReconciliationItemModel>();
  const [isShowDetails, setIsShowDetails] = useState(false);
  const [isShowDataFromExcel, setIsShowDataFromExcel] = useState(false);
  const [isShowDataFromSFTP, setIsShowDataFromSFTP] = useState(false);
  const [doiSoatProcessing, setDoiSoatProcessing] = useState(false);
  const [doiSoatResultData, setDoiSoatResultData] = useState<
    ReconciliationItemModel[]
  >([]);
  const handleDoubleClick = async (doiSoat: ReconciliationItemModel) => {
    setSelectedInvoice(doiSoat);
    setIsShowDetails(true);
  };

  const [filteredData, setFilteredData] = useState<ReconciliationItemModel[]>(
    [],
  );

  const { alert } = useFeedbackDialog();

  const onExportData = async () => {
    //Data trước lúc Filter là doiSoatResultData hoặc dataFromSP: Tức là nếu có đối soát thì dataBeforeFilter = doiSoatResultData, nếu chưa đối soát thì dataBeforeFilter = dataFromSP
    const dataBeforeFilter =
      doiSoatResultData?.length > 0 ? doiSoatResultData : (dataFromSP ?? []);

    await exportToExcel(
      reportTableConfig(
        /*Nếu có filter export dữ liệu đã filter, nếu chưa chưa filter thì export dữ liệu từ dataBeforeFilter*/
        (filteredData?.length ?? 0) > 0 ? filteredData : dataBeforeFilter,
        bankCode,
      ),
    );
  };

  const columns = useMemo(() => {
    if (bankCode?.toLowerCase() === "tcb") {
      return reportTCBColumns;
    } else if (bankCode?.toLowerCase() === "mbb") {
      return reportMBBColumns;
    }
    return reportTCBColumns;
  }, [bankCode]);

  const handleFilteredDataChange = (
    filteredRows: Row<ReconciliationItemModel>[],
  ) => {
    const dataFilterResult = filteredRows.map((row) => row.original);
    setFilteredData(dataFilterResult);
  };

  //Đối soát từ data đọc từ file SFTP
  const handleDoiSoatToDataFromFileSFTP = async () => {
    setDoiSoatProcessing(true);
    const spDataUpdated = await onDoiSoatToDataFromFileSFTP(
      dataFromFileSFTP,
      dataFromSP,
      alert,
    );

    const checkDataKhop = spDataUpdated.filter(
      (x: ReconciliationItemModel) => x.note === "Khớp",
    );

    const checkDataKoCoTrenSP = spDataUpdated.filter(
      (x: ReconciliationItemModel) => x.note === "Không có giao dịch ở PM",
    );

    const checkDataKoCoTrenSFTP = spDataUpdated.filter(
      (x: ReconciliationItemModel) => x.note === "Không có giao dịch ở Portal",
    );

    const checkDataChenhLech = spDataUpdated.filter(
      (x: ReconciliationItemModel) => x.isChenhLech === true,
    );

    const spDataUpdatedWrapper = spDataUpdated.map(
      (x: ReconciliationItemModel, index: number) => {
        x.sttWrapper = index + 1;
        return x;
      },
    );

    setDoiSoatResultData(spDataUpdatedWrapper);
    setDoiSoatProcessing(false);

    await alert({
      title: ETitleConfirm.THONG_BAO,
      content: `${checkDataKhop.length} Khớp, ${checkDataKoCoTrenSP.length} Không có giao dịch ở PM, ${checkDataKoCoTrenSFTP.length} Không có giao dịch ở Portal, ${checkDataChenhLech.length} Chênh lệch`,
    });
  };

  //Đối soát từ data đọc từ file Excel
  const handleDoiSoatToDataFromExcel = async () => {
    setDoiSoatProcessing(true);
    const spDataUpdated = await onDoiSoatToDataFromExcel(
      dataFromExcel,
      dataFromSP,
      alert,
    );

    const spDataUpdatedWrapper = spDataUpdated.map(
      (x: ReconciliationItemModel, index: number) => {
        x.sttWrapper = index + 1;
        x.refundAmount = (
          isNaN(parseFloat(x.refundAmount)) ? 0 : x.refundAmount
        ).toString();
        x.refundAmountVNVC = (
          isNaN(parseFloat(x.refundAmountVNVC)) ? 0 : x.refundAmountVNVC
        ).toString();
        return x;
      },
    );

    const checkDataKhop = spDataUpdatedWrapper.filter(
      (x: ReconciliationItemModel) => x.note === "Khớp",
    );

    const checkDataKoCoTrenSP = spDataUpdatedWrapper.filter(
      (x: ReconciliationItemModel) => x.note === "Không có giao dịch ở PM",
    );

    const checkDataKoCoTrenSFTP = spDataUpdatedWrapper.filter(
      (x: ReconciliationItemModel) => x.note === "Không có giao dịch ở Portal",
    );

    const checkDataChenhLech = spDataUpdatedWrapper.filter(
      (x: ReconciliationItemModel) => x.isChenhLech === true,
    );

    setDoiSoatResultData(spDataUpdatedWrapper);
    setDoiSoatProcessing(false);

    await alert({
      title: ETitleConfirm.THONG_BAO,
      content: `${checkDataKhop.length} Khớp, ${checkDataKoCoTrenSP.length} Không có giao dịch ở PM, ${checkDataKoCoTrenSFTP.length} Không có giao dịch ở Portal, ${checkDataChenhLech.length} Chênh lệch`,
    });
  };

  const handleDoiSoat = async () => {
    if ((dataFromExcel?.length ?? 0) > 0) {
      await handleDoiSoatToDataFromExcel();
    } else if ((dataFromFileSFTP?.length ?? 0) > 0) {
      await handleDoiSoatToDataFromFileSFTP();
    }
  };

  return (
    <>
      {doiSoatProcessing ? (
        <ListContainerLoading />
      ) : (
        <>
          {doiSoatResultData.length > 0 ? (
            <DataTable
              className="h-[calc(100vh-220px)] w-full overflow-auto border"
              tHeadClass="z-40"
              tRowClass="cursor-pointer"
              data={doiSoatResultData ?? []}
              columns={columns}
              enablePaging={true}
              enableColumnFilter={true}
              enableFooter={true}
              onRowDoubleClick={handleDoubleClick}
              onFilteredRowCountChange={handleFilteredDataChange}
            />
          ) : (
            <DataTable
              className="h-[calc(100vh-220px)] w-full overflow-auto border"
              tHeadClass="z-40"
              tRowClass="cursor-pointer"
              data={dataFromSP ?? []}
              columns={columns}
              enablePaging={true}
              enableColumnFilter={true}
              enableFooter={true}
              onRowDoubleClick={handleDoubleClick}
              onFilteredRowCountChange={handleFilteredDataChange}
            />
          )}

          <Footer
            exportToExcel={onExportData}
            doiSoat={handleDoiSoat}
            countDataFromSP={dataFromSP?.length ?? 0}
            countDataFromExcel={dataFromExcel?.length ?? 0}
            countDataFromFileSFTP={dataFromFileSFTP?.length ?? 0}
            showDataFromExcel={() => setIsShowDataFromExcel(true)}
            showDataFromSFTP={() => setIsShowDataFromSFTP(true)}
          />

          {isShowDetails && (
            <div>
              {selectedInvoice && (
                <Dialog
                  //open={isShowDetails}
                  open={false} //tạm thời ẩn đi vì chưa làm đầy đủ (để xem User cần ko mới làm)
                  onOpenChange={() => setIsShowDetails(!isShowDetails)}
                >
                  <DialogOverlay />
                  <DialogContent
                    className="content-start sm:max-w-[50vw] min-h-[20vh] z-100 bg-white"
                    aria-describedby={undefined}
                  >
                    <DialogHeader>
                      <DialogTitle className="text-sm">{`<${selectedInvoice?.tecombankInvoiceID}>`}</DialogTitle>
                    </DialogHeader>
                    <Description></Description>

                    <>
                      <p>STT: {selectedInvoice.sttWrapper}</p>
                      <p>isChenhLech: {selectedInvoice.isChenhLech}</p>
                      <p>isHoanPhi: {selectedInvoice.isHoanPhi}</p>
                    </>

                    <DialogFooter>
                      <Button variant={"outline"}>In & Đóng</Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              )}
            </div>
          )}

          {isShowDataFromExcel && (
            <div>
              {dataFromExcel && (
                <Dialog
                  open={isShowDataFromExcel}
                  onOpenChange={() =>
                    setIsShowDataFromExcel(!isShowDataFromExcel)
                  }
                >
                  <DialogOverlay />
                  <DialogContent
                    className="content-start sm:max-w-[95vw] min-h-[5vh] z-100 bg-white"
                    aria-describedby={undefined}
                  >
                    <DialogHeader>
                      <DialogTitle className="text-sm">
                        Dữ liệu từ Upload excel
                      </DialogTitle>
                    </DialogHeader>
                    <Description></Description>
                    <GridDataFromExcel
                      dataFromExcel={dataFromExcel}
                      bankCode={bankCode}
                    />
                  </DialogContent>
                </Dialog>
              )}
            </div>
          )}

          {isShowDataFromSFTP && (
            <div>
              {dataFromExcel && (
                <Dialog
                  open={isShowDataFromSFTP}
                  onOpenChange={() =>
                    setIsShowDataFromSFTP(!isShowDataFromSFTP)
                  }
                >
                  <DialogOverlay />
                  <DialogContent
                    className="content-start sm:max-w-[95vw] min-h-[5vh] z-100 bg-white"
                    aria-describedby={undefined}
                  >
                    <DialogHeader>
                      <DialogTitle className="text-sm">
                        Dữ liệu từ file SFTP
                      </DialogTitle>
                    </DialogHeader>
                    <Description></Description>
                    <GridDataFromSFTP
                      dataFromSFTP={dataFromFileSFTP}
                      bankCode={bankCode}
                    />
                  </DialogContent>
                </Dialog>
              )}
            </div>
          )}
        </>
      )}
    </>
  );
};

export default ReconciliationReport;
