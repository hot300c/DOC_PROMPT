"use client";
import {
  DataTable,
  DataTableColumnHeaderSort,
} from "@/components/ui/dataTable";
import { ColumnDef, Row } from "@tanstack/react-table";
import _ from "lodash";
import { useMemo, useState } from "react";

import { DataFromFileSFTPModel } from "../_utils/definitions/model";
import * as utils from "@/app/lib/utils";
import { exportToExcel, TableConfig } from "@/app/lib/utils/exportToExcel ";
import FooterDataFromSFTP from "./FooterDataFromSFTP";

interface GridDataFromSFTPProp {
  bankCode: string;
  dataFromSFTP: DataFromFileSFTPModel[];
}

const GridDataFromSFTP: React.FC<GridDataFromSFTPProp> = ({
  bankCode,
  dataFromSFTP,
}) => {
  const visibleFooter = false; //Tạm thời để vậy để ẩn footer
  const [filteredData, setFilteredData] =
    useState<DataFromFileSFTPModel[]>(dataFromSFTP);

  const onExportData = async () => {
    const dataToExport = filteredData;

    await exportToExcel({
      ...tableConfig,
      data: dataToExport.map((row, index) => [
        index + 1,
        (row.sttWrapper = index + 1),
        row.isChenhLech,
        row.isHoanPhi,
        row.FTID,
        row.TransactionType,
        row.ServiceName,
        row.Currency,
        utils.formatCurrencyExcel(parseFloat(row.TransactionAmount)),
        utils.formatCurrencyExcel(parseFloat(row.AccountedAmount)),
        row.Orderdescription,
        row.TCBStoreID,
        row.PartnerStoreID,
        row.TCBTerminalID,
        row.PartnerTerminalID,
        row.TransactionTime,
        row.Valuedate,
        row.MerchantRef1,
        row.Senderaccountname,
        row.Senderaccountnumber,
        row.Senderbankname,
        row.Paymentchannel,
      ]),
    });
  };

  const tableConfig: TableConfig = {
    columns: {
      STT: { width: 10, alignment: "center" },
      // isChenhLech: { width: 30, alignment: "left" },
      // isHoanPhi: { width: 30, alignment: "left" },
      FTID: { width: 30, alignment: "left" },
      TransactionType: { width: 30, alignment: "left" },
      ServiceName: { width: 30, alignment: "left" },
      Currency: { width: 30, alignment: "left" },
      TransactionAmount: { width: 30, alignment: "left" },
      AccountedAmount: { width: 30, alignment: "left" },
      Orderdescription: { width: 30, alignment: "left" },
      TCBStoreID: { width: 30, alignment: "left" },
      PartnerStoreID: { width: 30, alignment: "left" },
      TCBTerminalID: { width: 30, alignment: "left" },
      PartnerTerminalID: { width: 30, alignment: "left" },
      TransactionTime: { width: 30, alignment: "left" },
      Valuedate: { width: 30, alignment: "left" },
      MerchantRef1: { width: 30, alignment: "left" },
      Senderaccountname: { width: 30, alignment: "left" },
      Senderaccountnumber: { width: 30, alignment: "left" },
      Senderbankname: { width: 30, alignment: "left" },
      Paymentchannel: { width: 30, alignment: "left" },
    },
    data:
      !!dataFromSFTP && dataFromSFTP.length > 0
        ? dataFromSFTP.map((row, index) => [
            index + 1,
            (row.sttWrapper = index + 1),
            row.isChenhLech,
            row.isHoanPhi,
            row.FTID,
            row.TransactionType,
            row.ServiceName,
            row.Currency,
            utils.formatCurrencyExcel(parseFloat(row.TransactionAmount)),
            utils.formatCurrencyExcel(parseFloat(row.AccountedAmount)),
            row.Orderdescription,
            row.TCBStoreID,
            row.PartnerStoreID,
            row.TCBTerminalID,
            row.PartnerTerminalID,
            row.TransactionTime,
            row.Valuedate,
            row.MerchantRef1,
            row.Senderaccountname,
            row.Senderaccountnumber,
            row.Senderbankname,
            row.Paymentchannel,
          ])
        : [],
    sheetName: `data_${bankCode?.toLowerCase()}_lists`,
    fileName: `data_${bankCode?.toLowerCase()}_lists.xlsx`,
  };

  const columns = useMemo(() => {
    const result: ColumnDef<DataFromFileSFTPModel>[] = [
      {
        id: "sttWrapper",
        accessorKey: "sttWrapper",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="STT" />
        ),
        cell: ({ row }) => (
          <p title={row.original.sttWrapper?.toString()}>
            {row.original.sttWrapper}
          </p>
        ),
      },
      {
        id: "FTID",
        accessorKey: "FTID",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Mã Hoàn Phí TCB"
            className="w-[120px]"
          />
        ),
        cell: ({ row }) => (
          <p className="line-clamp-1" title={row.original.FTID}>
            {row.original.FTID}
          </p>
        ),
      },
      {
        id: "TransactionType",
        accessorKey: "TransactionType",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="TransactionType"
            className="w-[120px]"
          />
        ),
        cell: ({ row }) => (
          <p className="line-clamp-1" title={row.original.TransactionType}>
            {row.original.TransactionType}
          </p>
        ),
      },
      {
        id: "ServiceName",
        accessorKey: "ServiceName",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="ServiceName"
            className="w-[200px]"
          />
        ),
        cell: ({ row }) => (
          <p className="line-clamp-1" title={row.original.ServiceName}>
            {row.original.ServiceName}
          </p>
        ),
      },
      {
        id: "Currency",
        accessorKey: "Currency",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Currency"
            className="w-[100px]"
          />
        ),
        footer: ({ table }) => (
          <div className="text-right font-semibold bg-white p-1">{`TC: ${table.getSortedRowModel().rows.length}`}</div>
        ),
        cell: ({ row }) => (
          <p className="line-clamp-1" title={row.original.Currency}>
            {row.original.Currency}
          </p>
        ),
      },

      {
        id: "TransactionAmount",
        accessorKey: "TransactionAmount",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Thanh Toán TCB" />
        ),
        cell: ({ row }) => (
          <div className="text-right">
            {utils.formatCurrency(
              parseFloat(row.original.TransactionAmount),
              false,
            )}
          </div>
        ),
        footer: ({ table }) => (
          <div className="text-right font-semibold bg-white p-1">
            {utils.formatCurrency(
              _.sumBy(table.getSortedRowModel().rows, (row) =>
                parseFloat(row.original.TransactionAmount ?? "0"),
              ),
              false,
            )}
          </div>
        ),
      },
      {
        id: "AccountedAmount",
        accessorKey: "AccountedAmount",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="AccountedAmount" />
        ),
        cell: ({ row }) => (
          <div className="text-right">
            {utils.formatCurrency(
              parseFloat(row.original.AccountedAmount),
              false,
            )}
          </div>
        ),
        footer: ({ table }) => (
          <div className="text-right font-semibold bg-white p-1">
            {utils.formatCurrency(
              _.sumBy(table.getSortedRowModel().rows, (row) =>
                parseFloat(row.original.AccountedAmount ?? "0"),
              ),
              false,
            )}
          </div>
        ),
      },
      {
        id: "Orderdescription",
        accessorKey: "Orderdescription",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Mô Tả TT"
            className="w-[200px]"
          />
        ),
        cell: ({ row }) => (
          <p className="line-clamp-1" title={row.original.Orderdescription}>
            {row.original.Orderdescription}
          </p>
        ),
      },
      {
        id: "TCBStoreID",
        accessorKey: "TCBStoreID",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="TCBStoreID" />
        ),
        cell: ({ row }) => (
          <p className="line-clamp-1" title={row.original.TCBStoreID}>
            {row.original.TCBStoreID}
          </p>
        ),
      },
      {
        id: "PartnerStoreID",
        accessorKey: "PartnerStoreID",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Mã Cửa Hàng"
            className="w-[150px]"
          />
        ),
        cell: ({ row }) => (
          <p className="line-clamp-1" title={row.original.PartnerStoreID}>
            {row.original.PartnerStoreID}
          </p>
        ),
      },
      {
        id: "TCBTerminalID",
        accessorKey: "TCBTerminalID",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="TCBTerminalID" />
        ),
        cell: ({ row }) => (
          <p className="line-clamp-1" title={row.original.TCBTerminalID}>
            {row.original.TCBTerminalID}
          </p>
        ),
      },
      {
        id: "PartnerTerminalID",
        accessorKey: "PartnerTerminalID",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Mã Quầy"
            className="w-[130px]"
          />
        ),
        cell: ({ row }) => (
          <p className="line-clamp-1" title={row.original.PartnerTerminalID}>
            {row.original.PartnerTerminalID}
          </p>
        ),
      },
      {
        id: "TransactionTime",
        accessorKey: "TransactionTime",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Thời Gian Tạo Giao Dịch"
            className="w-[200px]"
          />
        ),
        cell: ({ row }) => (
          <p className="line-clamp-1" title={row.original.TransactionTime}>
            {row.original.TransactionTime}
          </p>
        ),
      },
      {
        id: "Valuedate",
        accessorKey: "Valuedate",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Valuedate" />
        ),
        cell: ({ row }) => (
          <p className="line-clamp-1" title={row.original.Valuedate}>
            {row.original.Valuedate}
          </p>
        ),
      },
      {
        id: "MerchantRef1",
        accessorKey: "MerchantRef1",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="MerchantRef1" />
        ),
        cell: ({ row }) => (
          <p className="line-clamp-1" title={row.original.MerchantRef1}>
            {row.original.MerchantRef1}
          </p>
        ),
      },
      {
        id: "Senderaccountname",
        accessorKey: "Senderaccountname",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Senderaccountname"
            className="w-[150px]"
          />
        ),
        cell: ({ row }) => (
          <p className="line-clamp-1" title={row.original.Senderaccountname}>
            {row.original.Senderaccountname}
          </p>
        ),
      },
      {
        id: "Senderaccountnumber",
        accessorKey: "Senderaccountnumber",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Số TK Chuyển"
            className="w-[100px]"
          />
        ),
        cell: ({ row }) => (
          <p className="line-clamp-1" title={row.original.Senderaccountnumber}>
            {row.original.Senderaccountnumber}
          </p>
        ),
      },

      {
        id: "Senderbankname",
        accessorKey: "Senderbankname",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Tên TK Chuyển"
            className="w-[100px]"
          />
        ),
        cell: ({ row }) => (
          <p className="line-clamp-1" title={row.original.Senderbankname}>
            {row.original.Senderbankname}
          </p>
        ),
      },
      {
        id: "Paymentchannel",
        accessorKey: "paymPaymentchannelentchannel",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Kênh Xử Lý" />
        ),
        cell: ({ row }) => (
          <p className="line-clamp-1" title={row.original.Paymentchannel}>
            {row.original.Paymentchannel}
          </p>
        ),
      },
    ];

    return result;
  }, []);

  const handleFilteredDataChange = (
    filteredRows: Row<DataFromFileSFTPModel>[],
  ) => {
    const dataFilterResult = filteredRows.map((row) => row.original);
    setFilteredData(dataFilterResult);
  };

  return (
    <>
      <DataTable
        className="h-[calc(100vh-220px)] w-full overflow-auto border"
        tHeadClass="z-40"
        tRowClass="cursor-pointer"
        data={dataFromSFTP ?? []}
        columns={columns}
        enablePaging={true}
        enableColumnFilter={true}
        enableFooter={true}
        onFilteredRowCountChange={handleFilteredDataChange}
      />
      {visibleFooter && (
        <FooterDataFromSFTP
          exportToExcel={onExportData}
          countDataFromSFTP={filteredData.length}
        />
      )}
    </>
  );
};

export default GridDataFromSFTP;
