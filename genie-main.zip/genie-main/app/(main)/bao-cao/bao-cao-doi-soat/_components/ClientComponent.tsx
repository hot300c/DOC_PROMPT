"use client";

import { useCallback, useEffect, useState } from "react";
import { useExcelUpload } from "../_hooks/use-excel-upload";
import { useFilterAndRouting } from "../_hooks/use-filter-and-routing";
import ListContainerLoading from "./ListContainerLoading";
import ReconciliationReport from "./ReconciliationReport";
import { PageName } from "@/app/lib/enums";
import CenterInfo from "@/components/facilityInfo";
import RiconciliationFilterForm from "./ReconciliationFilterForm";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function ClientComponent({
  dataFromSP,
  dataFromFileSFTP: initialDataFromFileSFTP,
  initialBank,
  initialFilter,
}: {
  dataFromSP: any;
  dataFromFileSFTP: any;
  initialBank: string;
  initialFilter: any;
}) {
  const [loading, setLoading] = useState(false);
  const [dataFromFileSFTP, setDataFromFileSFTP] = useState(
    initialDataFromFileSFTP,
  );
  const [tabChangeTime, setTabChangeTime] = useState<number | null>(null);

  const {
    dataFileExcel,
    countDataFromFile,
    handleExcelUpload,
    setDataFileExcel,
  } = useExcelUpload(setLoading, setDataFromFileSFTP);

  const { filter, bankCodeActiveTab, handleFilterChange, handleTabChange } =
    useFilterAndRouting(initialFilter, initialBank, setLoading);

  useEffect(() => {
    setDataFromFileSFTP(initialDataFromFileSFTP);
    setLoading(false);
  }, [initialDataFromFileSFTP]);

  const handleClearDataFromExcel = useCallback(() => {
    setDataFileExcel([]);
  }, [setDataFileExcel]);

  const handleRenderComplete = useCallback(() => {
    setLoading(false);
  }, []);

  const handleBankTabChange = useCallback(
    (value: string) => {
      setDataFileExcel([]);
      setDataFromFileSFTP([]);
      handleTabChange(value);
      setTabChangeTime(Date.now());
    },
    [setDataFileExcel, setDataFromFileSFTP, handleTabChange],
  );

  useEffect(() => {
    //Khi chuyển tab sau 1 giây, sẽ tự động submit filter để load lại data cho Tab mới
    if (tabChangeTime) {
      const autoFilter = async () => {
        await new Promise((resolve) => {
          const timeLeft = 1000 - (Date.now() - tabChangeTime);
          if (timeLeft > 0) {
            setTimeout(resolve, timeLeft);
          } else {
            resolve(undefined);
          }
        });

        const submitButton = document.getElementById("submit-filter");
        submitButton?.click();
        setTabChangeTime(null);
      };

      void autoFilter();
    }
  }, [tabChangeTime]);

  useEffect(() => {
    handleRenderComplete();
  }, [handleRenderComplete, dataFromFileSFTP]);

  const renderContent = useCallback(
    (bankCode: string) => {
      if (loading) return <ListContainerLoading />;

      return (
        <ReconciliationReport
          bankCode={bankCode}
          dataFromSP={dataFromSP}
          dataFromExcel={dataFileExcel}
          dataFromFileSFTP={dataFromFileSFTP}
        />
      );
    },
    [dataFileExcel, dataFromFileSFTP, dataFromSP, loading],
  );

  return (
    <div className="w-full overflow-y-hidden">
      <CenterInfo page={PageName.RECONCILIATION_REPORT} />

      <RiconciliationFilterForm
        bankCode={bankCodeActiveTab}
        searchParams={filter}
        countDataFromFile={countDataFromFile}
        handleExcelUpload={handleExcelUpload}
        onFilterChange={handleFilterChange}
        dataFileExcel={dataFileExcel}
        setdataFileExcel={setDataFileExcel}
        onClearDataFromExcel={handleClearDataFromExcel}
        loading={loading}
      />

      <Tabs
        className="w-full flex-1"
        value={bankCodeActiveTab}
        onValueChange={handleBankTabChange}
      >
        <div className="p-[5px]">
          <TabsList>
            <TabsTrigger value="TCB">Techcombank</TabsTrigger>
            <TabsTrigger value="MBB">MBBank</TabsTrigger>
          </TabsList>

          <TabsContent value="TCB">
            {renderContent(bankCodeActiveTab)}
          </TabsContent>

          <TabsContent value="MBB">
            {renderContent(bankCodeActiveTab)}
          </TabsContent>
        </div>
      </Tabs>
    </div>
  );
}
