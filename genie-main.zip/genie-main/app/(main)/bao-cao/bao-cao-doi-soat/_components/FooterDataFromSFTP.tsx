"use client";

import { Button } from "@/components/ui/button";

type FooterDataFromSFTPProps = {
  exportToExcel: () => void;
  countDataFromSFTP?: number;
};

const FooterDataFromSFTP: React.FC<FooterDataFromSFTPProps> = ({
  exportToExcel,
  countDataFromSFTP,
}) => {
  return (
    <div className="w-full fixed bottom-0 left-0 bg-muted py-2 px-4">
      <div className="flex justify-end">
        <div className="flex space-x-2 items-center">
          <div className="flex items-center gap-2 p-2 bg-gray-100 rounded-md">
            <div className="ml-auto flex gap-2">
              <div className="flex items-center gap-1">
                <span className="text-sm">
                  {(countDataFromSFTP ?? 0) &&
                    `Dữ liệu từ file SFTP: ${countDataFromSFTP} |`}
                </span>
              </div>

              <Button
                variant="outline"
                size="sm"
                className="bg-gray-200 hover:bg-gray-300 text-black"
                onClick={exportToExcel}
              >
                Xuất Excel
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FooterDataFromSFTP;
