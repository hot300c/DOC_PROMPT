"use client";
import React, { useCallback, useEffect } from "react";
import { useRouter, usePathname } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { InputDatePicker } from "@/components/input-date-picker";
import { Button } from "@/components/ui/button";
import { Loader2 } from "lucide-react";

import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";

import {
  ReconciliationSearchParamSchema,
  SearchParams,
} from "../_utils/definitions/schema";
import * as utils from "@/app/lib/utils";

import { DataFromExcelModel } from "../_utils/definitions/model";
import { cn } from "@/app/lib/utils";
import { Checkbox } from "@/components/ui/checkbox";

interface RiconciliationFilterFormProps {
  bankCode: string;
  searchParams: SearchParams;
  className?: string;
  countDataFromFile?: number;
  handleExcelUpload: (
    event: React.ChangeEvent<HTMLInputElement>,
  ) => Promise<void>;
  onFilterChange: (filter: SearchParams) => void;
  dataFileExcel: DataFromExcelModel[];
  setdataFileExcel: (data: DataFromExcelModel[]) => void;
  onClearDataFromExcel: () => void; // Thêm callback function
  loading?: boolean;
}

const RiconciliationFilterForm: React.FC<RiconciliationFilterFormProps> = ({
  bankCode,
  searchParams,
  className,
  handleExcelUpload,
  onFilterChange,
  onClearDataFromExcel, // Nhận callback function
  loading,
}) => {
  const router = useRouter();
  const pathname = usePathname();

  // Sử dụng form với defaultValues
  const form = useForm<SearchParams>({
    resolver: zodResolver(ReconciliationSearchParamSchema),
    defaultValues: {
      ...searchParams,
      isFileSFTP: Boolean(searchParams.isFileSFTP),
    },
  });

  // Sử dụng watch để theo dõi các giá trị thay đổi
  const isFileSFTP = form.watch("isFileSFTP");
  const fromDate = form.watch("fromDate");

  const setQueryRouter = useCallback(
    (values: SearchParams) => {
      const filteredValues = Object.fromEntries(
        Object.entries(values).filter(([_, value]) => value),
      );
      const query = new URLSearchParams(
        Object.entries(filteredValues).map(([key, value]) => [
          key,
          String(value),
        ]),
      ).toString();
      router.push(`${pathname}?${query}`, undefined);
    },
    [pathname, router],
  );

  useEffect(() => {
    const values = form.getValues();
    setQueryRouter(values);
  }, [isFileSFTP, form, setQueryRouter]);

  useEffect(() => {
    if (fromDate && isFileSFTP) {
      const formattedDate = fromDate.replace(/-/g, "");
      const tenfileMN = `Tpay_VNVCMN_${formattedDate}_1`;
      const tenfileMB = `Tpay_VNVCMB_${formattedDate}_1`;

      if ((bankCode ?? "tcb").toLowerCase() === "tcb") {
        form.setValue("tenFileMN", tenfileMN);
        form.setValue("tenFileMB", tenfileMB);
      } else if ((bankCode ?? "tcb").toLowerCase() === "mbb") {
        form.setValue("tenFileMN", `XM_${formattedDate}_TC`);
      }
    }
  }, [fromDate, isFileSFTP, form, bankCode]);

  const onSubmit = (values: SearchParams) => {
    onFilterChange(values);
  };

  const handleFilterClick = () => {
    onClearDataFromExcel();
    void form.handleSubmit(onSubmit)();
  };

  return (
    <>
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)}>
          <div className={cn(`flex flex-col p-2`, className)}>
            <div className="flex items-baseline gap-4">
              <FormField
                control={form.control}
                name="fromDate"
                render={({ field }) => (
                  <FormItem className="inline-flex items-center space-y-0">
                    <FormLabel className="w-18">Từ ngày</FormLabel>
                    <FormControl>
                      <InputDatePicker
                        value={field.value ? new Date(field.value) : undefined}
                        onChange={(date) => {
                          if (date) {
                            field.onChange(
                              utils.FormatDateToYYYYMMDD(date.toString()),
                            );
                          }
                        }}
                      />
                    </FormControl>
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="toDate"
                render={({ field }) => (
                  <FormItem className="inline-flex items-center space-y-0">
                    <FormLabel className="w-18">Đến ngày</FormLabel>
                    <FormControl>
                      <InputDatePicker
                        value={new Date(field.value)}
                        onChange={(date) => {
                          if (date) {
                            field.onChange(
                              utils.FormatDateToYYYYMMDD(date.toString()),
                            );
                          }
                        }}
                      />
                    </FormControl>
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="tenFileMN"
                render={({ field }) => (
                  <FormItem className="inline-flex items-center space-y-0">
                    <FormLabel className="w-25">Tên file MN</FormLabel>
                    <FormControl>
                      <Input
                        disabled={!isFileSFTP}
                        placeholder="Nhập tên file miền Nam"
                        value={field.value}
                        onChange={(e) => {
                          field.onChange(e.target.value);
                        }}
                      />
                    </FormControl>
                  </FormItem>
                )}
              ></FormField>
              {(bankCode ?? "tcb").toLowerCase() === "tcb" && (
                <FormField
                  control={form.control}
                  name="tenFileMB"
                  render={({ field }) => (
                    <FormItem className="inline-flex items-center space-y-0">
                      <FormLabel className="w-25">Tên file MB</FormLabel>
                      <FormControl>
                        <Input
                          disabled={!isFileSFTP}
                          placeholder="Nhập tên file miền Bắc"
                          value={field.value}
                          onChange={(e) => {
                            field.onChange(e.target.value);
                          }}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                ></FormField>
              )}

              <FormField
                control={form.control}
                name="isFileSFTP"
                render={({ field }) => (
                  <FormItem className="inline-flex items-center space-y-0">
                    <FormControl>
                      <div className="flex items-center gap-2">
                        <FormLabel>File SFTP</FormLabel>
                        <Checkbox
                          checked={isFileSFTP}
                          onCheckedChange={field.onChange}
                        />
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              ></FormField>
              <Button id="submit-filter" className="w-25 hidden">
                Submit Lọc
              </Button>
              <Button
                className="w-25"
                type="button"
                onClick={handleFilterClick}
                disabled={loading}
              >
                {loading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Đang lọc...
                  </>
                ) : (
                  "Lọc"
                )}
              </Button>
            </div>
          </div>
        </form>
      </Form>
      {/* Chỉ hiển thi upload file khi bankCode là TCB */}
      {(bankCode ?? "tcb").toLowerCase() === "tcb" && (
        <div className="flex gap-2 px-2 items-center">
          <label
            htmlFor="fileInput"
            className={cn(
              "cursor-pointer text-white py-1 px-2 rounded text-sm",
              isFileSFTP
                ? "bg-gray-400 cursor-not-allowed"
                : "bg-blue-500 hover:bg-blue-600",
            )}
          >
            Upload file
          </label>
          <input
            disabled={isFileSFTP}
            id="fileInput"
            type="file"
            accept=".xlsx, .xls"
            className="hidden"
            onChange={handleExcelUpload}
          />
        </div>
      )}
    </>
  );
};

export default RiconciliationFilterForm;
