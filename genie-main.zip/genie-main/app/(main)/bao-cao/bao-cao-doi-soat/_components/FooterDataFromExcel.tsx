"use client";

import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";

type FooterDataFromExcelProps = {
  exportToExcel: () => void;
  countDataFromExcel?: number;
};

const FooterDataFromExcel: React.FC<FooterDataFromExcelProps> = ({
  exportToExcel,
  countDataFromExcel,
}) => {
  return (
    <div className="w-full fixed bottom-0 left-0 bg-muted py-2 px-4">
      <div className="flex justify-end">
        <div className="flex space-x-2 items-center">
          <div className="flex items-center gap-2 p-2 bg-gray-100 rounded-md">
            <div className="font-semibold">ABC</div>
            <div className="flex items-center gap-1">
              <span className="text-sm">: Không có giao dịch ở Portal |</span>
            </div>

            <div className="flex items-center gap-1.5">
              <Checkbox
                id="portal-check"
                className="h-4 w-4 rounded border-gray-300"
              />
              <label htmlFor="portal-check" className="text-sm">
                Chênh lệch
              </label>
              <span className="text-sm">: Không có giao dịch ở PM |</span>
            </div>

            <div className="flex items-center gap-1.5">
              <Checkbox
                id="pm-check"
                className="h-4 w-4 rounded border-gray-300"
              />
              <label htmlFor="pm-check" className="text-sm">
                Chênh lệch
              </label>
            </div>

            <div className="flex items-center gap-1.5">
              <div className="bg-red-500 h-4 w-4"></div>
              <span className="text-sm">
                : Chênh lệch tiền thanh toán/hoàn hủy
              </span>
            </div>

            <div className="ml-auto flex gap-2">
              <div className="flex items-center gap-1">
                <span className="text-sm">
                  {(countDataFromExcel ?? 0) &&
                    `Dữ liệu từ upload file: ${countDataFromExcel} |`}
                </span>
              </div>

              <Button
                variant="outline"
                size="sm"
                className="bg-gray-200 hover:bg-gray-300 text-black"
                onClick={exportToExcel}
              >
                Xuất Excel
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FooterDataFromExcel;
