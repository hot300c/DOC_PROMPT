import loadDataInit from "../_actions/load-data-init";
import XemBaoCaoPresentation from "./xem-bao-cao-presentation";

export default async function XemBaoCaoContainer() {
  const { reportsByUser, facId, userId } = await loadDataInit();

  return (
    <XemBaoCaoPresentation
      reportsByUser={reportsByUser}
      facId={facId}
      userId={userId}
    />
  );
}
