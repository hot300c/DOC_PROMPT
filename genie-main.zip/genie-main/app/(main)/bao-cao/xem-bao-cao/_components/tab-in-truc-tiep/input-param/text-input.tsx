import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  L_ReportParams_List,
  ReportParamsValue,
} from "../../../_utils/definitions/xem-bao-cao.dto";

type InputThamSoProps = {
  paramsValue: ReportParamsValue[];
  setValueParam: (name: string, value: string | null) => void;
  report: L_ReportParams_List;
};

export const TextInput = ({ paramsValue, setValueParam }: InputThamSoProps) => {
  const param1 = paramsValue[0];
  if (paramsValue.length === 0 || !param1) return null;

  return (
    <div className="grid grid-cols-12 gap-2">
      <Label className="col-span-4">{param1.caption}</Label>
      <Input
        className="col-span-8"
        value={param1.value || ""}
        onChange={(e) => {
          const value = e.target.value;
          setValueParam(param1.name, value);
        }}
        type="text"
      ></Input>
    </div>
  );
};
