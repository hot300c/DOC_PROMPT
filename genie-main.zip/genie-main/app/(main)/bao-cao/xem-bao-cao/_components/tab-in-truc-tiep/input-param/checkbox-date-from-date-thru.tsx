import { Label } from "@/components/ui/label";
import {
  L_ReportParams_List,
  ReportParamsValue,
} from "../../../_utils/definitions/xem-bao-cao.dto";
import { Checkbox } from "@/components/ui/checkbox";
import { InputDatePicker } from "@/components/input-date-picker";
import { format } from "date-fns";
import { DATE_FORMAT } from "@/app/lib/enums";
import { useCallback, useEffect, useState } from "react";
import { CheckedState } from "@radix-ui/react-checkbox";
import { cn } from "@/app/lib/utils";
import { useFeedbackDialog } from "@/app/lib/feedback-dialog-provider";

type InputThamSoProps = {
  paramsValue: ReportParamsValue[];
  setValueParam: (name: string, value: string | null) => void;
  report: L_ReportParams_List;
};

export const CheckBoxDateFromDateThru = ({
  paramsValue,
  setValueParam,
  report,
}: InputThamSoProps) => {
  const param1 = paramsValue[0];
  const param2 = paramsValue[1];
  const [isEnableInputDate, setIsEnableInputDate] = useState(false);
  const { alert } = useFeedbackDialog();

  const resetParam = useCallback(() => {
    if (!param1 || !param2) return;
    setValueParam(param1.name, "1900-01-01");
    setValueParam(param2.name, "1900-01-01");
  }, [param1, param2, setValueParam]);

  const handleChangeEnableInputDate = useCallback(
    (checked: CheckedState) => {
      const isChecked = checked === true ? true : false;
      setIsEnableInputDate(isChecked);
      if (!isChecked) {
        resetParam();
      } else {
        if (!param1 || !param2) return;
        const todayStr = format(new Date(), DATE_FORMAT.YYYY_MM_DD);
        param1.value = todayStr;
        param2.value = todayStr;
        setValueParam(param1.name, param1.value);
        setValueParam(param2.name, param2.value);
      }
    },
    [resetParam, param1, param2, setValueParam],
  );

  const kiemTraNgayPhuHop = useCallback(
    async ({
      strNgay1,
      strNgay2,
    }: {
      strNgay1: string | null;
      strNgay2: string | null;
    }) => {
      const ngayBatDau = new Date(strNgay1 || "");
      const ngayKetThuc = new Date(strNgay2 || "");
      if (ngayBatDau > ngayKetThuc) {
        await alert({
          title: "",
          content: "Ngày bắt đầu không được lớn hơn ngày kết thúc.",
        });
        return false;
      } else {
        return true;
      }
    },
    [alert],
  );

  useEffect(() => {
    if (!param1 || !param2 || param1.value != null || param2.value != null)
      return;
    resetParam();
  }, [resetParam, param1, param2]);

  if (paramsValue.length === 0 || !param1 || !param2) return null;
  return (
    <div className="grid grid-cols-12 gap-2">
      {/* line enable input */}
      <Label className="col-span-full flex items-center">
        <Checkbox
          checked={isEnableInputDate}
          onCheckedChange={handleChangeEnableInputDate}
        ></Checkbox>
        <span className="pl-2">Ngày tạo hợp đồng</span>
      </Label>

      {/* line 1 */}
      <Label className="col-span-4">{param1.caption}</Label>
      <InputDatePicker
        className={cn(
          "col-span-8",
          !isEnableInputDate && "bg-gray-100 text-gray-100",
        )}
        value={param1.value ? new Date(param1.value) : undefined}
        onChange={async (date) => {
          if (!date) {
            setValueParam(param1.name, "");
          } else {
            const newDateStr = format(date, DATE_FORMAT.YYYY_MM_DD);
            if (
              await kiemTraNgayPhuHop({
                strNgay1: newDateStr,
                strNgay2: param2.value,
              })
            ) {
              setValueParam(param1.name, newDateStr);
            } else {
              setValueParam(param1.name, param1.value);
            }
          }
        }}
        disabled={!isEnableInputDate}
      ></InputDatePicker>

      {/* line 2 */}
      <Label className="col-span-4">{param2.caption}</Label>
      <InputDatePicker
        className={cn(
          "col-span-8",
          !isEnableInputDate && "bg-gray-100 text-gray-100",
        )}
        value={param2.value ? new Date(param2.value) : undefined}
        onChange={async (date) => {
          if (!date) {
            setValueParam(param2.name, "");
          } else {
            const newDateStr = format(date, DATE_FORMAT.YYYY_MM_DD);
            if (
              await kiemTraNgayPhuHop({
                strNgay1: param1.value,
                strNgay2: newDateStr,
              })
            ) {
              setValueParam(param2.name, newDateStr);
            } else {
              setValueParam(param2.name, param2.value);
            }
          }
        }}
        disabled={!isEnableInputDate}
      ></InputDatePicker>
    </div>
  );
};
