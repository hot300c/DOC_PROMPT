import { Input } from "@/components/ui/input";
import { useEffect } from "react";
import { useTabInTrucTiep } from "../../../_contexts/tab-in-truc-tiep-context";
import {
  L_ReportParams_List,
  ReportParamsValue,
} from "../../../_utils/definitions/xem-bao-cao.dto";

type InputThamSoProps = {
  paramsValue: ReportParamsValue[];
  setValueParam: (name: string, value: string) => void;
  report: L_ReportParams_List;
};

export const TextFacID = ({ paramsValue, setValueParam }: InputThamSoProps) => {
  const { facId } = useTabInTrucTiep();
  useEffect(() => {
    if (paramsValue.length === 0 || !paramsValue[0]) return;
    const param1 = paramsValue[0];
    if (param1.value === null) {
      param1.value = facId;
      setValueParam(param1.name, param1.value);
    }
  }, [paramsValue, setValueParam, facId]);

  if (paramsValue.length === 0 || !paramsValue[0]) return null;
  const param1 = paramsValue[0];
  return (
    <Input
      type="hidden"
      value={param1.value || ""}
      name={param1.name}
      onChange={(e) => setValueParam(param1.name, e.target.value)}
    ></Input>
  );
};
