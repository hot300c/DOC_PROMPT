import { notifyError } from "@/app/lib/utils";
import { getErrorMessage } from "@/app/lib/utils/errorUtils";
import { TableSelect } from "@/components/select/table-select";
import { DataTableColumnHeaderSort } from "@/components/ui/dataTable";
import { Label } from "@/components/ui/label";
import { ColumnDef } from "@tanstack/react-table";
import { useEffect, useState } from "react";
import { useLoadingBaoCao } from "../../../_contexts/loading-bao-cao-context";
import { useTabInTrucTiep } from "../../../_contexts/tab-in-truc-tiep-context";
import {
  L_FacIDNotAll_List,
  L_ReportParams_List,
  List_FinaciUser_FacID,
  LoadCounterNameParentID,
  ReportParamsValue,
} from "../../../_utils/definitions/xem-bao-cao.dto";
import { getDataFromReport } from "../../../_utils/services/xem-bao-cao.api";

type InputThamSoProps = {
  paramsValue: ReportParamsValue[];
  setValueParam: (name: string, value: string | null) => void;
  report: L_ReportParams_List;
};

const COLUMNS1: ColumnDef<L_FacIDNotAll_List>[] = [
  {
    id: "id",
    accessorKey: "id",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="ID" />
    ),
  },
  {
    id: "text",
    accessorKey: "text",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Text" />
    ),
    cell: ({ row }) => (
      <p title={row.getValue("text")} className="line-clamp-1">
        {row.getValue("text")}
      </p>
    ),
  },
];

const COLUMNS2: ColumnDef<List_FinaciUser_FacID>[] = [
  {
    id: "idValue",
    accessorKey: "idValue",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Mã" />
    ),
  },
  {
    id: "text",
    accessorKey: "text",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Tên" />
    ),
    cell: ({ row }) => (
      <p title={row.getValue("text")} className="line-clamp-1">
        {row.getValue("text")}
      </p>
    ),
  },
];

const COLUMNS3: ColumnDef<LoadCounterNameParentID>[] = [
  {
    id: "idValue",
    accessorKey: "idValue",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Mã" />
    ),
  },
  {
    id: "text",
    accessorKey: "text",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Tên" />
    ),
    cell: ({ row }) => (
      <p title={row.getValue("text")} className="line-clamp-1">
        {row.getValue("text")}
      </p>
    ),
  },
];

export const GridLookUpVer3 = ({
  paramsValue,
  setValueParam,
  report,
}: InputThamSoProps) => {
  const { facId, userId } = useTabInTrucTiep();
  const param1 = paramsValue[0];
  const param2 = paramsValue[1];
  const param3 = paramsValue[2];
  const [data1s, setData1s] = useState<L_FacIDNotAll_List[]>([]);
  const [data2s, setData2s] = useState<List_FinaciUser_FacID[]>([]);
  const [data3s, setData3s] = useState<LoadCounterNameParentID[]>([]);
  const { setLoadingBaoCao } = useLoadingBaoCao();

  useEffect(() => {
    async function init() {
      try {
        setLoadingBaoCao(true);
        const result = await getDataFromReport({
          report,
        });
        setData1s(result.table || []);
        setData2s(result.table1 || []);
        setData3s(result.table2 || []);
      } catch (error) {
        console.log(error);
        notifyError(getErrorMessage(error));
      } finally {
        setLoadingBaoCao(false);
      }
    }
    void init();
  }, [facId, report, setLoadingBaoCao]);

  useEffect(() => {
    if (paramsValue.length === 0 || !param1) return;
    if (param1.value === null) {
      param1.value = facId || "";
      setValueParam(param1.name, param1.value);
    }
  }, [paramsValue, setValueParam, param1, facId]);

  useEffect(() => {
    if (paramsValue.length === 0 || !param1 || !param2) return;
    if (param2.value === null) {
      const data2sFilter = data2s.filter(
        (nguoi) => nguoi.parentID === param1?.value,
      );
      // app hiện random dữ liệu? => ở genie ưu tiên lấy người đang login
      const data2Selected =
        data2sFilter.length > 0
          ? data2sFilter.find((nguoi) => String(nguoi.id) === userId) ||
            data2sFilter[0]
          : null;
      if (!data2Selected) return;
      param2.value = data2Selected.id;
      setValueParam(param2.name, param2.value);
    }
  }, [
    paramsValue,
    setValueParam,
    data2s,
    param1,
    param2,
    param2?.value,
    userId,
  ]);

  useEffect(() => {
    if (paramsValue.length === 0 || !param1 || !param3) return;
    if (param3.value === null) {
      const data3sFilter = data3s.filter(
        (quay) => quay.parentID === param1?.value,
      );
      const data3Selected =
        data3s.length > 0
          ? data3sFilter.find((quay) => String(quay.idValue) === "0") ||
            data3s[0]
          : null;
      if (!data3Selected) return;
      param3.value = String(data3Selected.id);
      setValueParam(param3.name, param3.value);
    }
  }, [paramsValue, setValueParam, data3s, param1, param3, param3?.value]);

  if (paramsValue.length === 0 || !param1 || !param2 || !param3) return null;
  const data1Selected = data1s.find((v) => String(v.id) === param1.value);

  return (
    <div className="grid grid-cols-12 gap-2">
      {/* line 1 */}
      <Label className="col-span-4">{param1.caption}</Label>
      <TableSelect
        columns={COLUMNS1}
        data={data1s}
        labelKey={"text"}
        valueKey={"id"}
        className="col-span-8"
        placeholder="Chọn dữ liệu..."
        value={data1Selected}
        onChange={(value) => {
          if (value) {
            param1.value = String(value.id);
            setValueParam(param1.name, param1.value);
            setValueParam(param2.name, null);
            setValueParam(param3.name, null);
          }
        }}
      ></TableSelect>

      {/* line 2 */}
      <Label className="col-span-4">{param2.caption}</Label>
      <TableSelect
        columns={COLUMNS2}
        data={
          data1Selected
            ? data2s.filter((v) => v.parentID === data1Selected.id)
            : []
        }
        labelKey={"text"}
        valueKey={"id"}
        className="col-span-8"
        placeholder="Chọn dữ liệu..."
        value={data2s.find((v) => String(v.id) === param2.value)}
        onChange={(value) => {
          if (value) {
            param2.value = String(value.id);
            setValueParam(param2.name, param2.value);
          }
        }}
      ></TableSelect>

      {/* line 3 */}
      <Label className="col-span-4">{param3.caption}</Label>
      <TableSelect
        columns={COLUMNS3}
        data={
          data1Selected
            ? data3s.filter((v) => v.parentID === data1Selected.id)
            : []
        }
        labelKey={"text"}
        valueKey={"id"}
        className="col-span-8"
        placeholder="Chọn dữ liệu..."
        value={
          data1Selected
            ? data3s.find(
                (v) =>
                  String(v.id) === param3.value &&
                  v.parentID === data1Selected!.id,
              )
            : null
        }
        onChange={(value) => {
          if (value) {
            param3.value = String(value.id);
            setValueParam(param3.name, param3.value);
          }
        }}
      ></TableSelect>
    </div>
  );
};
