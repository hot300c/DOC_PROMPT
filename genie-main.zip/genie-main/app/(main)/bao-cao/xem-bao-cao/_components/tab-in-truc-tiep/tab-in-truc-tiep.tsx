"use client";

import BaoCao from "./bao-cao";
import ChuyenMuc from "./chuyen-muc";
import ThamSo from "./tham-so";

const TabInTrucTiep = () => {
  return (
    <div className="w-full flex flex-row overflow-hidden flex-1 overflow-y-hidden h-full space-x-1">
      <section className="flex flex-col w-[20vw] overflow-hidden h-full">
        <ChuyenMuc />
      </section>
      <section className="flex flex-col flex-1 overflow-hidden h-full">
        <BaoCao />
      </section>
      <section className="flex flex-col w-[400px] overflow-hidden h-full">
        <ThamSo />
      </section>
    </div>
  );
};

export default TabInTrucTiep;
