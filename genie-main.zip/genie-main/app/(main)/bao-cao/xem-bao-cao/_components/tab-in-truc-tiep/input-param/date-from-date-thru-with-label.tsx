import {
  L_ReportParams_List,
  ReportParamsValue,
} from "../../../_utils/definitions/xem-bao-cao.dto";
import { Label } from "@/components/ui/label";
import { InputDatePicker } from "@/components/input-date-picker";
import { format } from "date-fns";
import { DATE_FORMAT } from "@/app/lib/enums";
import { useCallback, useEffect } from "react";
import { useFeedbackDialog } from "@/app/lib/feedback-dialog-provider";

type InputThamSoProps = {
  paramsValue: ReportParamsValue[];
  setValueParam: (name: string, value: string | null) => void;
  report: L_ReportParams_List;
};

export const DateFromDateThruWithLabel = ({
  paramsValue,
  setValueParam,
  report,
}: InputThamSoProps) => {
  const param1 = paramsValue[0];
  const param2 = paramsValue[1];
  const { alert } = useFeedbackDialog();

  const kiemTraNgayPhuHop = useCallback(
    async ({
      strNgay1,
      strNgay2,
    }: {
      strNgay1: string | null;
      strNgay2: string | null;
    }) => {
      const ngayBatDau = new Date(strNgay1 || "");
      const ngayKetThuc = new Date(strNgay2 || "");
      if (ngayBatDau > ngayKetThuc) {
        await alert({
          title: "",
          content: "Ngày bắt đầu không được lớn hơn ngày kết thúc.",
        });
        return false;
      } else {
        return true;
      }
    },
    [alert],
  );

  useEffect(() => {
    if (!param1 || !param2 || param1.value !== null || param2.value !== null)
      return;
    const todayStr = format(new Date(), DATE_FORMAT.YYYY_MM_DD);
    param1.value = todayStr;
    param2.value = todayStr;
    setValueParam(param1.name, param1.value);
    setValueParam(param2.name, param2.value);
  }, [param1, param2, setValueParam]);

  if (paramsValue.length === 0 || !param1 || !param2) return null;
  return (
    <div className="grid grid-cols-12 gap-2">
      {/* line label */}
      <Label className="col-span-full flex items-center">
        Ngày dự kiến hết hạn hợp đồng
      </Label>

      {/* line 1 */}
      <Label className="col-span-4">{param1.caption}</Label>
      <InputDatePicker
        className="col-span-8"
        value={param1.value ? new Date(param1.value) : undefined}
        onChange={async (date) => {
          if (!date) {
            setValueParam(param1.name, "");
          } else {
            const newDateStr = format(date, DATE_FORMAT.YYYY_MM_DD);
            if (
              await kiemTraNgayPhuHop({
                strNgay1: newDateStr,
                strNgay2: param2.value,
              })
            ) {
              setValueParam(param1.name, newDateStr);
            } else {
              setValueParam(param1.name, param1.value);
            }
          }
        }}
      ></InputDatePicker>

      {/* line 2 */}
      <Label className="col-span-4">{param2.caption}</Label>
      <InputDatePicker
        className="col-span-8"
        value={param2.value ? new Date(param2.value) : undefined}
        onChange={async (date) => {
          if (!date) {
            setValueParam(param2.name, "");
          } else {
            const newDateStr = format(date, DATE_FORMAT.YYYY_MM_DD);
            if (
              await kiemTraNgayPhuHop({
                strNgay1: param1.value,
                strNgay2: newDateStr,
              })
            ) {
              setValueParam(param2.name, newDateStr);
            } else {
              setValueParam(param2.name, param2.value);
            }
          }
        }}
      ></InputDatePicker>
    </div>
  );
};
