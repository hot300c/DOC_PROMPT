"use client";

import { DataTable } from "@/components/ui/dataTable";
import { ColumnDef } from "@tanstack/react-table";
import { useTabInTrucTiep } from "../../_contexts/tab-in-truc-tiep-context";
import { ChuyenMuc as ChuyenMucModel } from "../../_utils/definitions/xem-bao-cao.dto";

const COLUMNS: ColumnDef<ChuyenMucModel>[] = [
  {
    id: "name",
    accessorKey: "name",
    header: "Chuyên mục",
    cell: ({ row }) => (
      <p className="line-clamp-1" title={row.getValue("name")}>
        {row.getValue("name")}
      </p>
    ),
  },
];

const ChuyenMuc = () => {
  const { chuyenMucs, setChuyenMucSelected, chuyenMucSelected } =
    useTabInTrucTiep();

  return (
    <div className="w-full flex flex-row overflow-hidden flex-1 overflow-y-hidden h-full">
      <DataTable
        columns={COLUMNS}
        data={chuyenMucs}
        className="w-full h-full overflow-auto border-r"
        enablePaging={false}
        enableColumnFilter={false}
        onRowClick={(row) => {
          setChuyenMucSelected(row);
        }}
        enableScrollTo={false}
        indexScrollTo={chuyenMucs.findIndex(
          (chuyenMuc) => chuyenMuc.name === chuyenMucSelected?.name,
        )}
      />
    </div>
  );
};

export default ChuyenMuc;
