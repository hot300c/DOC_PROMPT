import { Input } from "@/components/ui/input";
import { useEffect } from "react";
import { useTabInTrucTiep } from "../../../_contexts/tab-in-truc-tiep-context";
import {
  L_ReportParams_List,
  ReportParamsValue,
} from "../../../_utils/definitions/xem-bao-cao.dto";

type InputThamSoProps = {
  paramsValue: ReportParamsValue[];
  setValueParam: (name: string, value: string) => void;
  report: L_ReportParams_List;
};

export const TextUserID = ({
  paramsValue,
  setValueParam,
}: InputThamSoProps) => {
  const { userId } = useTabInTrucTiep();
  useEffect(() => {
    if (paramsValue.length === 0 || !paramsValue[0]) return;
    const param1 = paramsValue[0];
    if (param1.value === null) {
      param1.value = userId;
      setValueParam(param1.name, param1.value);
    }
  }, [paramsValue, setValueParam, userId]);
  if (paramsValue.length === 0 || !paramsValue[0]) return null;
  const param = paramsValue[0];
  return (
    <Input
      type="hidden"
      value={param.value || ""}
      name={param.name}
      onChange={(e) => setValueParam(param.name, e.target.value)}
    ></Input>
  );
};
