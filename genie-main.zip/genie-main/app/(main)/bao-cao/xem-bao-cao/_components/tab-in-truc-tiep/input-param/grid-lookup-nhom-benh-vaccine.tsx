import { notifyError } from "@/app/lib/utils";
import { getErrorMessage } from "@/app/lib/utils/errorUtils";
import { TableSelect } from "@/components/select/table-select";
import { DataTableColumnHeaderSort } from "@/components/ui/dataTable";
import { Label } from "@/components/ui/label";
import { ColumnDef } from "@tanstack/react-table";
import { useEffect, useState } from "react";
import { useLoadingBaoCao } from "../../../_contexts/loading-bao-cao-context";
import {
  L_ReportParams_List,
  LoadNhomBenh,
  LoadVaccineMaChung,
  ReportParamsValue,
} from "../../../_utils/definitions/xem-bao-cao.dto";
import { getDataFromReport } from "../../../_utils/services/xem-bao-cao.api";

type InputThamSoProps = {
  paramsValue: ReportParamsValue[];
  setValueParam: (name: string, value: string | null) => void;
  report: L_ReportParams_List;
};

const COLUMNS1: ColumnDef<LoadNhomBenh>[] = [
  {
    id: "id",
    accessorKey: "id",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="ID" />
    ),
  },
  {
    id: "text",
    accessorKey: "text",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Text" />
    ),
    cell: ({ row }) => (
      <p title={row.getValue("text")} className="line-clamp-1">
        {row.getValue("text")}
      </p>
    ),
  },
];

const COLUMNS2: ColumnDef<LoadVaccineMaChung>[] = [
  {
    id: "hospitalCode",
    accessorKey: "hospitalCode",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Mã" />
    ),
  },
  {
    id: "text",
    accessorKey: "text",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Vaccine" />
    ),
    cell: ({ row }) => (
      <p title={row.getValue("text")} className="line-clamp-1">
        {row.getValue("text")}
      </p>
    ),
  },
];

export const GridLookupNhomBenhVaccine = ({
  paramsValue,
  setValueParam,
  report,
}: InputThamSoProps) => {
  const param1 = paramsValue[0];
  const param2 = paramsValue[1];
  const [data1s, setData1s] = useState<LoadNhomBenh[]>([]);
  const [data2s, setData2s] = useState<LoadVaccineMaChung[]>([]);
  const { setLoadingBaoCao } = useLoadingBaoCao();

  useEffect(() => {
    async function init() {
      try {
        setLoadingBaoCao(true);
        const result = await getDataFromReport({
          report,
        });
        setData1s(result.table || []);
        setData2s(result.table1 || []);
      } catch (error) {
        console.log(error);
        notifyError(getErrorMessage(error));
      } finally {
        setLoadingBaoCao(false);
      }
    }
    void init();
  }, [report, setLoadingBaoCao]);

  useEffect(() => {
    if (paramsValue.length === 0 || !param1 || !param2) return;
    if (param2.value === null) {
      const data2sFilter = data2s.filter(
        (v) => String(v.nhomBenhID) === param1.value,
      );
      const data2Selected = data2sFilter.length > 0 ? data2sFilter[0] : null;
      if (!data2Selected) return;
      param2.value = String(data2Selected.id);
      setValueParam(param2.name, param2.value);
    }
  }, [paramsValue, setValueParam, data2s, param1, param2]);

  if (paramsValue.length === 0 || !param1 || !param2) return null;

  return (
    <div className="grid grid-cols-12 gap-2">
      {/* line 1 */}
      <Label className="col-span-4">{param1.caption}</Label>
      <TableSelect
        columns={COLUMNS1}
        data={data1s}
        labelKey={"text"}
        valueKey={"id"}
        className="col-span-8"
        placeholder="Chọn dữ liệu..."
        value={data1s.find((v) => String(v.id) === param1.value)}
        onChange={(value) => {
          if (value) {
            param1.value = String(value.id);
            setValueParam(param1.name, param1.value);
            setValueParam(param2.name, null);
          }
        }}
      ></TableSelect>

      {/* line 2 */}
      <Label className="col-span-4">{param2.caption}</Label>
      <TableSelect
        columns={COLUMNS2}
        data={data2s.filter((v) => String(v.nhomBenhID) === param1.value)}
        labelKey={"text"}
        valueKey={"id"}
        className="col-span-8"
        placeholder="Chọn dữ liệu..."
        value={data2s.find((v) => String(v.id) === param2.value)}
        onChange={(value) => {
          if (value) {
            param2.value = String(value.id);
            setValueParam(param2.name, param2.value);
          }
        }}
      ></TableSelect>
    </div>
  );
};
