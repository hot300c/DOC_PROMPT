"use client";

import {
  L_ReportParams_List,
  ReportParamsValue,
} from "../../../_utils/definitions/xem-bao-cao.dto";

type InputThamSoProps = {
  paramsValue: ReportParamsValue[];
  setValueParam: (name: string, value: string) => void;
  report: L_ReportParams_List;
};

export const DebugInput = ({ paramsValue, report }: InputThamSoProps) => {
  if (paramsValue.length === 0 || !paramsValue[0])
    return (
      <div className="overflow-auto border text-sm">
        <ul>
          <li>paramsValue is empty or paramsValue[0] is null</li>
          <li>Report: {JSON.stringify(report)}</li>
        </ul>
      </div>
    );

  return (
    <div className="overflow-auto border text-sm">
      <ul>
        <li>Caption: {paramsValue.map((p) => p.caption).join(",")}</li>
        <li>Value: {paramsValue.map((p) => p.value).join(",")}</li>
        <li>Report: {JSON.stringify(report)}</li>
      </ul>
    </div>
  );
};
