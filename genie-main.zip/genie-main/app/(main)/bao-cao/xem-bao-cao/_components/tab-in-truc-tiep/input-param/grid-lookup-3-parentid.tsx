import { notifyError } from "@/app/lib/utils";
import { getErrorMessage } from "@/app/lib/utils/errorUtils";
import { TableSelect } from "@/components/select/table-select";
import { DataTableColumnHeaderSort } from "@/components/ui/dataTable";
import { Label } from "@/components/ui/label";
import { ColumnDef } from "@tanstack/react-table";
import { useEffect, useState } from "react";
import { useLoadingBaoCao } from "../../../_contexts/loading-bao-cao-context";
import { useTabInTrucTiep } from "../../../_contexts/tab-in-truc-tiep-context";
import {
  L_FacID_List,
  L_ReportParams_List,
  LoadComboStockName,
  LoadProductTheoKhoV1,
  LoadProductTypeV1,
  ReportParamsValue,
} from "../../../_utils/definitions/xem-bao-cao.dto";
import { getDataFromReport } from "../../../_utils/services/xem-bao-cao.api";

type InputThamSoProps = {
  paramsValue: ReportParamsValue[];
  setValueParam: (name: string, value: string | null) => void;
  report: L_ReportParams_List;
};

const COLUMNS1: ColumnDef<L_FacID_List>[] = [
  {
    id: "id",
    accessorKey: "id",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="ID" />
    ),
  },
  {
    id: "text",
    accessorKey: "text",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Text" />
    ),
    cell: ({ row }) => (
      <p title={row.getValue("text")} className="line-clamp-1">
        {row.getValue("text")}
      </p>
    ),
  },
];

const COLUMNS2: ColumnDef<LoadComboStockName>[] = [
  {
    id: "idValue",
    accessorKey: "idValue",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Mã" />
    ),
  },
  {
    id: "text",
    accessorKey: "text",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Tên" />
    ),
    cell: ({ row }) => (
      <p title={row.getValue("text")} className="line-clamp-1">
        {row.getValue("text")}
      </p>
    ),
  },
];

const COLUMNS3: ColumnDef<LoadProductTypeV1>[] = [
  {
    id: "idValue",
    accessorKey: "idValue",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Mã" />
    ),
  },
  {
    id: "text",
    accessorKey: "text",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Tên" />
    ),
    cell: ({ row }) => (
      <p title={row.getValue("text")} className="line-clamp-1">
        {row.getValue("text")}
      </p>
    ),
  },
];

const COLUMNS4: ColumnDef<LoadProductTheoKhoV1>[] = [
  {
    id: "idValue",
    accessorKey: "idValue",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Mã" />
    ),
  },
  {
    id: "text",
    accessorKey: "text",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Tên" />
    ),
    cell: ({ row }) => (
      <p title={row.getValue("text")} className="line-clamp-1">
        {row.getValue("text")}
      </p>
    ),
  },
];

export const GridLookUp3ParentID = ({
  paramsValue,
  setValueParam,
  report,
}: InputThamSoProps) => {
  const { facId } = useTabInTrucTiep();
  const param1 = paramsValue[0];
  const param2 = paramsValue[1];
  const param3 = paramsValue[2];
  const param4 = paramsValue[3];
  const [data1s, setData1s] = useState<L_FacID_List[]>([]);
  const [data2s, setData2s] = useState<LoadComboStockName[]>([]);
  const [data3s, setData3s] = useState<LoadProductTypeV1[]>([]);
  const [data4s, setData4s] = useState<LoadProductTheoKhoV1[]>([]);
  const [data1Selected, setData1Selected] = useState<L_FacID_List>();
  const [data2Selected, setData2Selected] = useState<LoadComboStockName>();
  const [data3Selected, setData3Selected] = useState<LoadProductTypeV1>();
  const [data4Selected, setData4Selected] = useState<LoadProductTheoKhoV1>();
  const { setLoadingBaoCao } = useLoadingBaoCao();

  useEffect(() => {
    async function init() {
      try {
        setLoadingBaoCao(true);
        const result = await getDataFromReport({
          report,
          updateRequest(request, variant) {
            if (variant.option.DefautParams) {
              if (
                (variant.indexRequest === 2 || variant.indexRequest === 3) &&
                variant.option.DefautParams.includes("ParamFacID3")
              ) {
                request.parameters = {
                  FacID: facId,
                };
              }
            }
          },
        });
        setData1s(result.table || []);
        setData2s(result.table1 || []);
        const sp3s = (result.table2 || []) as LoadProductTypeV1[];
        setData3s(sp3s.map((v, index) => ({ ...v, uid: String(index) })));
        const sp4s = (result.table3 || []) as LoadProductTheoKhoV1[];
        setData4s(sp4s.map((v, index) => ({ ...v, uid: String(index) })));
      } catch (error) {
        console.log(error);
        notifyError(getErrorMessage(error));
      } finally {
        setLoadingBaoCao(false);
      }
    }
    void init();
  }, [facId, report, setLoadingBaoCao]);

  useEffect(() => {
    if (paramsValue.length === 0 || !param1) return;
    if (param1.value === null && data1s.length > 0) {
      param1.value = facId || "";
      setValueParam(param1.name, param1.value);
      setData1Selected(data1s.find((v) => String(v.id) === param1.value));
    }
  }, [paramsValue, setValueParam, param1, facId, data1s]);

  useEffect(() => {
    if (paramsValue.length === 0 || !param1 || !param2) return;
    if (param2.value === null) {
      const data2sFilter = data2s.filter((v) => v.parentID === param1?.value);
      const data2Selected =
        data2sFilter.length > 0
          ? data2sFilter.find((v) => String(v.idValue) === "0") ||
            data2sFilter[0]
          : null;
      if (!data2Selected) return;
      param2.value = data2Selected.id;
      setValueParam(param2.name, param2.value);
      setData2Selected(data2Selected);
    }
  }, [paramsValue, setValueParam, data2s, param1, param2, param2?.value]);

  useEffect(() => {
    if (paramsValue.length === 0 || !param1 || !param2 || !param3) return;
    if (param3.value === null) {
      const data3sFilter = data3s.filter(
        (v) =>
          String(v.parentID) === param1.value &&
          String(v.parentSecondID) === param2?.value,
      );
      const data3selected = data3sFilter.length > 0 ? data3sFilter[0] : null;
      if (!data3selected) return;
      param3.value = String(data3selected.id);
      setValueParam(param3.name, param3.value);
      setData3Selected(data3selected);
    }
  }, [
    paramsValue,
    setValueParam,
    data3s,
    param1,
    param2,
    param3,
    param3?.value,
  ]);

  useEffect(() => {
    if (paramsValue.length === 0 || !param1 || !param2 || !param3 || !param4)
      return;
    if (param4.value === null) {
      const data4sFilter = data4s.filter(
        (v) =>
          String(v.parentID) === param1.value &&
          String(v.parentSecondID) === param2?.value &&
          String(v.parentThirID) === param3?.value,
      );
      const data4selected = data4sFilter.length > 0 ? data4sFilter[0] : null;
      if (!data4selected) return;
      param4.value = String(data4selected.id);
      setValueParam(param4.name, param4.value);
      setData4Selected(data4selected);
    }
  }, [
    paramsValue,
    setValueParam,
    data4s,
    param1,
    param2,
    param3,
    param4,
    param4?.value,
  ]);

  if (paramsValue.length === 0 || !param1 || !param2 || !param3 || !param4)
    return null;

  return (
    <div className="grid grid-cols-12 gap-2">
      {/* line 1 */}
      <Label className="col-span-4">{param1.caption}</Label>
      <TableSelect
        columns={COLUMNS1}
        data={data1s}
        labelKey={"text"}
        valueKey={"id"}
        className="col-span-8"
        placeholder="Chọn dữ liệu..."
        value={data1Selected}
        onChange={(value) => {
          if (value) {
            param1.value = String(value.id);
            setValueParam(param1.name, param1.value);
            setValueParam(param2.name, null);
            setValueParam(param3.name, null);
            setValueParam(param4.name, null);
            setData1Selected(value);
            setData2Selected(undefined);
            setData3Selected(undefined);
            setData4Selected(undefined);
          }
        }}
      ></TableSelect>

      {/* line 2 */}
      <Label className="col-span-4">{param2.caption}</Label>
      <TableSelect
        columns={COLUMNS2}
        data={
          data1Selected
            ? data2s.filter((v) => v.parentID === data1Selected.id)
            : []
        }
        labelKey={"text"}
        valueKey={"id"}
        className="col-span-8"
        classNamePopover="min-w-96"
        placeholder="Chọn dữ liệu..."
        value={data2Selected}
        onChange={(value) => {
          if (value) {
            param2.value = String(value.id);
            setValueParam(param2.name, param2.value);
            setValueParam(param3.name, null);
            setValueParam(param4.name, null);
            setData2Selected(value);
            setData3Selected(undefined);
            setData4Selected(undefined);
          }
        }}
      ></TableSelect>

      {/* line 3 */}
      <Label className="col-span-4">{param3.caption}</Label>
      <TableSelect
        columns={COLUMNS3}
        data={
          data1Selected && data2Selected
            ? data3s.filter(
                (v) =>
                  String(v.parentID) === String(data1Selected.id) &&
                  String(v.parentSecondID) === String(data2Selected.id),
              )
            : []
        }
        labelKey={"text"}
        valueKey={"uid"}
        className="col-span-8"
        classNamePopover="min-w-96"
        placeholder="Chọn dữ liệu..."
        value={data3Selected}
        onChange={(value) => {
          if (value) {
            param3.value = String(value.id);
            setValueParam(param3.name, param3.value);
            setValueParam(param4.name, null);
            setData3Selected(value);
            setData4Selected(undefined);
          }
        }}
      ></TableSelect>

      {/* line 4 */}
      <Label className="col-span-4">{param4.caption}</Label>
      <TableSelect
        columns={COLUMNS4}
        data={
          data1Selected && data2Selected && data3Selected
            ? data4s.filter(
                (v) =>
                  String(v.parentID) === String(data1Selected.id) &&
                  String(v.parentSecondID) === String(data2Selected.id) &&
                  String(v.parentThirID) === String(data3Selected.id),
              )
            : []
        }
        labelKey={"text"}
        valueKey={"uid"}
        className="col-span-8"
        classNamePopover="min-w-96"
        placeholder="Chọn dữ liệu..."
        value={data4Selected}
        onChange={(value) => {
          if (value) {
            param4.value = String(value.id);
            setValueParam(param4.name, param4.value);
            setData4Selected(value);
          }
        }}
      ></TableSelect>
    </div>
  );
};
