import { notifyError } from "@/app/lib/utils";
import { getErrorMessage } from "@/app/lib/utils/errorUtils";
import { TableSelect } from "@/components/select/table-select";
import { DataTableColumnHeaderSort } from "@/components/ui/dataTable";
import { Label } from "@/components/ui/label";
import { ColumnDef } from "@tanstack/react-table";
import { useEffect, useState } from "react";
import { useLoadingBaoCao } from "../../../_contexts/loading-bao-cao-context";
import { useTabInTrucTiep } from "../../../_contexts/tab-in-truc-tiep-context";
import {
  L_FacID_List,
  L_ReportParams_List,
  LoadPhongTiem,
  ReportParamsValue,
} from "../../../_utils/definitions/xem-bao-cao.dto";
import { getDataFromReport } from "../../../_utils/services/xem-bao-cao.api";

type InputThamSoProps = {
  paramsValue: ReportParamsValue[];
  setValueParam: (name: string, value: string | null) => void;
  report: L_ReportParams_List;
};

const COLUMNS1: ColumnDef<L_FacID_List>[] = [
  {
    id: "id",
    accessorKey: "id",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="ID" />
    ),
  },
  {
    id: "text",
    accessorKey: "text",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Text" />
    ),
    cell: ({ row }) => (
      <p title={row.getValue("text")} className="line-clamp-1">
        {row.getValue("text")}
      </p>
    ),
  },
];

const COLUMNS2: ColumnDef<LoadPhongTiem>[] = [
  {
    id: "hospitalCode",
    accessorKey: "hospitalCode", // ở đây app cài hospitalCode
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Mã" />
    ),
  },
  {
    id: "text",
    accessorKey: "text",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Text" />
    ),
    cell: ({ row }) => (
      <p title={row.getValue("text")} className="line-clamp-1">
        {row.getValue("text")}
      </p>
    ),
  },
];

export const GridLookUpVer2 = ({
  paramsValue,
  setValueParam,
  report,
}: InputThamSoProps) => {
  const { facId } = useTabInTrucTiep();
  const param1 = paramsValue[0];
  const param2 = paramsValue[1];
  const [data1s, setData1s] = useState<L_FacID_List[]>([]);
  const [data2s, setData2s] = useState<LoadPhongTiem[]>([]);
  const { setLoadingBaoCao } = useLoadingBaoCao();

  useEffect(() => {
    async function init() {
      try {
        setLoadingBaoCao(true);
        const result = await getDataFromReport({
          report,
          updateRequest(request, variant) {
            if (variant.option.DefautParams) {
              if (variant.option.DefautParams.includes("FacID")) {
                request.parameters = {
                  FacID: facId,
                };
              }
            }
          },
        });
        setData1s(result.table || []);
        setData2s(result.table1 || []);
      } catch (error) {
        console.log(error);
        notifyError(getErrorMessage(error));
      } finally {
        setLoadingBaoCao(false);
      }
    }
    void init();
  }, [facId, report, setLoadingBaoCao]);

  useEffect(() => {
    if (paramsValue.length === 0 || !param1 || !param2) return;
    if (param1.value === null) {
      param1.value = facId || "";
      setValueParam(param1.name, param1.value);
      setValueParam(param2.name, null);
    }
  }, [paramsValue, setValueParam, param1, param2, facId]);

  useEffect(() => {
    if (paramsValue.length === 0 || !param1 || !param2) return;
    if (param2.value === null) {
      const data2sFilter = data2s.filter((v) => v.parentID === param1.value);
      const data2Selected =
        data2sFilter.length > 0
          ? data2sFilter.find((v) => String(v.id) === "0") || data2sFilter[0]
          : null;
      if (!data2Selected) return;
      param2.value = String(data2Selected.id);
      setValueParam(param2.name, param2.value);
    }
  }, [paramsValue, setValueParam, data2s, param1, param2, facId]);

  useEffect(() => {
    if (paramsValue.length === 0 || !param2) return;
    setValueParam(param2.name, null);
    // TODO reset param2 when list data2s change
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [data2s]);

  if (paramsValue.length === 0 || !param1 || !param2) return null;

  return (
    <div className="grid grid-cols-12 gap-2">
      {/* line 1 */}
      <Label className="col-span-4">{param1.caption}</Label>
      <TableSelect
        columns={COLUMNS1}
        data={data1s}
        labelKey={"text"}
        valueKey={"id"}
        className="col-span-8"
        placeholder="Chọn dữ liệu..."
        value={data1s.find((v) => String(v.id) === param1.value)}
        onChange={(value) => {
          if (value) {
            param1.value = String(value.id);
            setValueParam(param1.name, param1.value);
            setValueParam(param2.name, null);
          }
        }}
      ></TableSelect>

      {/* line 2 */}
      <Label className="col-span-4">{param2.caption}</Label>
      <TableSelect
        columns={COLUMNS2}
        data={data2s.filter((v) => v.parentID === param1.value)}
        labelKey={"text"}
        valueKey={"id"}
        className="col-span-8"
        placeholder="Chọn dữ liệu..."
        value={data2s.find(
          (v) => String(v.id) === param2.value && v.parentID === param1.value,
        )}
        onChange={(value) => {
          if (value) {
            param2.value = String(value.id);
            setValueParam(param2.name, param2.value);
          }
        }}
      ></TableSelect>
    </div>
  );
};
