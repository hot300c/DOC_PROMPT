import { ColumnDef } from "@tanstack/react-table";
import {
  L_FacID_List_WithAll_V2,
  L_ReportParams_List,
  ReportParamsValue,
} from "../../../_utils/definitions/xem-bao-cao.dto";
import { DataTableColumnHeaderSort } from "@/components/ui/dataTable";
import { useTabInTrucTiep } from "../../../_contexts/tab-in-truc-tiep-context";
import { useEffect, useState } from "react";
import { useLoadingBaoCao } from "../../../_contexts/loading-bao-cao-context";
import { getDataFromReport } from "../../../_utils/services/xem-bao-cao.api";
import { notifyError, notifyWarning } from "@/app/lib/utils";
import { getErrorMessage } from "@/app/lib/utils/errorUtils";
import { Label } from "@/components/ui/label";
import { TableSelect } from "@/components/select/table-select";

type InputThamSoProps = {
  paramsValue: ReportParamsValue[];
  setValueParam: (name: string, value: string | null) => void;
  report: L_ReportParams_List;
};

const COLUMNS1: ColumnDef<L_FacID_List_WithAll_V2>[] = [
  {
    id: "id",
    accessorKey: "id",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="ID" />
    ),
  },
  {
    id: "text",
    accessorKey: "text",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Text" />
    ),
    cell: ({ row }) => (
      <p title={row.getValue("text")} className="line-clamp-1">
        {row.getValue("text")}
      </p>
    ),
  },
  {
    id: "parentID",
    accessorKey: "parentID",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Parent ID" />
    ),
  },
];

const COLUMNS2 = COLUMNS1;

// https://git.vnvc.info/vnvc-qas/qas-app/-/blob/a1852a712db469207ac4543124088bd37f7ae2ba/QA.ReportParams/ReportParamTypes/GridLookUpPickOneAllFacID.cs#L115
function restrictValueAll(
  value1: string | null,
  value2: string | null,
): boolean {
  if (value1 === "ALL" && value2 === "ALL") {
    notifyWarning("Vì vấn đề hiệu năng, không cho phép 2 params đều là Tất cả");
    return true;
  }
  return false;
}

export const GridLookUpPickOneAllFacID = ({
  paramsValue,
  setValueParam,
  report,
}: InputThamSoProps) => {
  const { facId } = useTabInTrucTiep();
  const param1 = paramsValue[0];
  const param2 = paramsValue[1];
  const param3 = paramsValue[2];
  const [data1s, setData1s] = useState<L_FacID_List_WithAll_V2[]>([]);
  const [data2s, setData2s] = useState<L_FacID_List_WithAll_V2[]>([]);
  const [data1Selected, setData1Selected] = useState<L_FacID_List_WithAll_V2>();
  const [data2Selected, setData2Selected] = useState<L_FacID_List_WithAll_V2>();
  const { setLoadingBaoCao } = useLoadingBaoCao();

  useEffect(() => {
    async function init() {
      try {
        setLoadingBaoCao(true);
        const result = await getDataFromReport({
          report,
          updateRequest(request, variant) {
            request.parameters = {
              FacID: facId,
            };
          },
        });
        setData1s(result.table || []);
        setData2s(result.table || []);
      } catch (error) {
        console.log(error);
        notifyError(getErrorMessage(error));
      } finally {
        setLoadingBaoCao(false);
      }
    }
    void init();
  }, [facId, report, setLoadingBaoCao]);

  useEffect(() => {
    if (paramsValue.length === 0 || !param1 || !param2 || !param3) return;
    if (param1.value === null && data1s.length > 0) {
      param1.value = facId || "";
      setValueParam(param1.name, param1.value);
      setData1Selected(data1s.find((v) => String(v.id) === param1.value));
    }
    if (param2.value === null && data2s.length > 0) {
      param2.value = facId || "";
      setValueParam(param2.name, param2.value);
      setData2Selected(data2s.find((v) => String(v.id) === param2.value));
    }
    if (param3.value === null) {
      param3.value = facId || "";
      setValueParam(param3.name, param3.value);
    }
  }, [
    paramsValue,
    setValueParam,
    param1,
    param2,
    facId,
    data1s,
    data2s,
    param3,
  ]);

  if (paramsValue.length === 0 || !param1 || !param2 || !param3) return null;

  return (
    <div className="grid grid-cols-12 gap-2">
      {/* line 1 */}
      <Label className="col-span-4">{param1.caption}</Label>
      <TableSelect
        columns={COLUMNS1}
        data={data1s}
        labelKey={"text"}
        valueKey={"id"}
        className="col-span-8"
        placeholder="Chọn dữ liệu..."
        value={data1Selected}
        onChange={(value) => {
          if (value) {
            if (restrictValueAll(value.id, param2.value)) return;
            param1.value = String(value.id);
            setValueParam(param1.name, param1.value);
            setData1Selected(value);
          }
        }}
      ></TableSelect>

      {/* line 2 */}
      <Label className="col-span-4">{param2.caption}</Label>
      <TableSelect
        columns={COLUMNS2}
        data={data2s}
        labelKey={"text"}
        valueKey={"id"}
        className="col-span-8"
        placeholder="Chọn dữ liệu..."
        value={data2Selected}
        onChange={(value) => {
          if (value) {
            if (restrictValueAll(value.id, param1.value)) return;
            param2.value = String(value.id);
            setValueParam(param2.name, param2.value);
            setData2Selected(value);
          }
        }}
      ></TableSelect>
    </div>
  );
};
