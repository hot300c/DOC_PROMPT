import { notifyError } from "@/app/lib/utils";
import { getErrorMessage } from "@/app/lib/utils/errorUtils";
import { MultiSelect } from "@/components/select/multi-select";
import { Label } from "@/components/ui/label";
import { useEffect, useState } from "react";
import { useLoadingBaoCao } from "../../../_contexts/loading-bao-cao-context";
import { useTabInTrucTiep } from "../../../_contexts/tab-in-truc-tiep-context";
import {
  L_FacID_List,
  L_ReportParams_List,
  ReportParamsValue,
} from "../../../_utils/definitions/xem-bao-cao.dto";
import { getDataFromReport } from "../../../_utils/services/xem-bao-cao.api";

type InputThamSoProps = {
  paramsValue: ReportParamsValue[];
  setValueParam: (name: string, value: string | null) => void;
  report: L_ReportParams_List;
};

export const CheckCombo = ({
  paramsValue,
  setValueParam,
  report,
}: InputThamSoProps) => {
  const { facId } = useTabInTrucTiep();
  const param1 = paramsValue[0];
  const [datas, setDatas] = useState<L_FacID_List[]>([]);
  const { setLoadingBaoCao } = useLoadingBaoCao();

  useEffect(() => {
    async function init() {
      try {
        setLoadingBaoCao(true);
        const result = await getDataFromReport({
          report,
          updateRequest(request, variant) {
            if (variant.option.DefautParams) {
              if (variant.option.DefautParams.includes("FacID")) {
                request.parameters = {
                  FacID: facId,
                };
              }
            }
          },
        });
        setDatas(result.table || []);
      } catch (error) {
        console.log(error);
        notifyError(getErrorMessage(error));
      } finally {
        setLoadingBaoCao(false);
      }
    }
    void init();
  }, [facId, report, setLoadingBaoCao]);

  if (paramsValue.length === 0 || !param1) return null;

  return (
    <div className="grid grid-cols-12 gap-2">
      <Label className="col-span-4">{param1.caption}</Label>
      <MultiSelect
        placeholder="Chọn dữ liệu..."
        options={datas?.map((s) => ({
          value: String(s.id),
          label: s.text,
        }))}
        className="col-span-8"
        value={param1.value?.split(",").map((s) => String(s))}
        onChange={(value) => {
          if (value.length > 0) {
            param1.value = value.join(",");
            setValueParam(param1.name, param1.value);
          } else {
            param1.value = null;
            setValueParam(param1.name, param1.value);
          }
        }}
      ></MultiSelect>
    </div>
  );
};
