import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useEffect, useState } from "react";
import {
  L_ReportParams_List,
  ReportParamsValue,
} from "../../../_utils/definitions/xem-bao-cao.dto";

type InputThamSoProps = {
  paramsValue: ReportParamsValue[];
  setValueParam: (name: string, value: string | null) => void;
  report: L_ReportParams_List;
};

export const CheckAndText = ({
  paramsValue,
  setValueParam,
}: InputThamSoProps) => {
  const paramCheck = paramsValue[0];
  const paramText = paramsValue[1];
  const [ngay, setNgay] = useState(""); // dùng cái này để hiển thị rỗng giống Qas lúc mới init

  useEffect(() => {
    if (paramsValue.length === 0 || !paramCheck || !paramText) return;
    if (paramCheck.value === null) {
      paramCheck.value = "0";
      setValueParam(paramCheck.name, paramCheck.value);
    }
    if (paramText.value === null) {
      paramText.value = "0";
      setValueParam(paramText.name, paramText.value);
      setNgay("");
    }
  }, [paramsValue, setValueParam, paramCheck, paramText]);

  if (paramsValue.length === 0 || !paramCheck || !paramText) return null;

  return (
    <div className="grid grid-cols-12 gap-2">
      {/* line 1 */}
      <Label className="col-span-full flex items-center">
        <Checkbox
          checked={paramCheck.value === "1"}
          onCheckedChange={(checked) => {
            setValueParam(paramCheck.name, checked ? "1" : "0");
          }}
        ></Checkbox>
        <span className="pl-2">{paramCheck.caption}</span>
      </Label>

      {/* line 2 */}
      <Label className="col-span-4">{paramText.caption}</Label>
      <Input
        className="col-span-8"
        value={ngay}
        onChange={(e) => {
          const value = e.target.value;
          if (/^\d*$/.test(value)) {
            setValueParam(paramText.name, value);
            setNgay(value);
          }
        }}
        disabled={paramCheck.value === "1"}
        type="text"
      ></Input>
    </div>
  );
};
