import {
  L_ReportParams_List,
  ReportParamsValue,
} from "../../../_utils/definitions/xem-bao-cao.dto";
import { DebugInput } from "./debug-input";

type InputThamSoProps = {
  paramsValue: ReportParamsValue[];
  setValueParam: (name: string, value: string) => void;
  report: L_ReportParams_List;
};

export const CheckComboBoxSearchEdit = ({
  paramsValue,
  setValueParam,
  report,
}: InputThamSoProps) => {
  // TODO chỗ này tạo trước structure cho tham số các báo cáo
  return (
    <DebugInput
      paramsValue={paramsValue}
      setValueParam={setValueParam}
      report={report}
    />
  );
};
