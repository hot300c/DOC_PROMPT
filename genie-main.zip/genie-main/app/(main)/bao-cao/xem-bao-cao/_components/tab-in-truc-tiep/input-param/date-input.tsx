"use client";

import { DATE_FORMAT } from "@/app/lib/enums";
import { InputDatePicker } from "@/components/input-date-picker";
import { Label } from "@/components/ui/label";
import { format } from "date-fns";
import { useEffect } from "react";
import {
  L_ReportParams_List,
  ReportParamsValue,
} from "../../../_utils/definitions/xem-bao-cao.dto";

type InputThamSoProps = {
  paramsValue: ReportParamsValue[];
  setValueParam: (name: string, value: string) => void;
  report: L_ReportParams_List;
};

export const DateInput = ({ paramsValue, setValueParam }: InputThamSoProps) => {
  useEffect(() => {
    if (paramsValue.length === 0 || !paramsValue[0]) return;
    const param1 = paramsValue[0];
    if (param1.value === null) {
      param1.value = format(new Date(), DATE_FORMAT.YYYY_MM_DD);
      setValueParam(param1.name, param1.value);
    }
  }, [paramsValue, setValueParam]);

  if (paramsValue.length === 0 || !paramsValue[0]) return null;
  const param1 = paramsValue[0];

  return (
    <div className="grid grid-cols-12 gap-2">
      <Label className="col-span-4">{param1.caption}</Label>
      <InputDatePicker
        className="col-span-8"
        value={param1.value ? new Date(param1.value) : undefined}
        onChange={(date) => {
          if (!date) {
            setValueParam(param1.name, "");
          } else {
            setValueParam(param1.name, format(date, DATE_FORMAT.YYYY_MM_DD));
          }
        }}
      ></InputDatePicker>
    </div>
  );
};
