"use client";

import { DataTable } from "@/components/ui/dataTable";
import { ColumnDef } from "@tanstack/react-table";
import { useCallback } from "react";
import { useTabInTrucTiep } from "../../_contexts/tab-in-truc-tiep-context";
import { L_Reports_ListByUser } from "../../_utils/definitions/xem-bao-cao.dto";

const COLUMNS: ColumnDef<L_Reports_ListByUser>[] = [
  {
    id: "name",
    accessorKey: "name",
    header: "Tên Báo Cáo",
    cell: ({ row }) => (
      <p className="line-clamp-1 min-w-52" title={row.getValue("name")}>
        {row.getValue("name")}
      </p>
    ),
    meta: {
      className: "text-left",
    },
  },
  {
    id: "description",
    accessorKey: "description",
    header: "Mô Tả",
    cell: ({ row }) => (
      <p className="line-clamp-1" title={row.getValue("description")}>
        {row.getValue("description")}
      </p>
    ),
    meta: {
      className: "text-left",
    },
  },
  {
    id: "type",
    accessorKey: "type",
    header: "Loại",
    meta: {
      className: "text-left",
    },
  },
];

const BaoCao = () => {
  const { chuyenMucSelected, reportSelected, setReportSelected } =
    useTabInTrucTiep();

  const groupBy = useCallback((row: L_Reports_ListByUser) => {
    return `Chuyên mục: ${row.category}`;
  }, []);

  return (
    <div className="w-full flex flex-row overflow-hidden flex-1 h-full">
      <DataTable
        columns={COLUMNS}
        data={chuyenMucSelected?.reports || []}
        className="w-full h-full overflow-auto border"
        enablePaging={false}
        enableColumnFilter={true}
        onRowClick={(row) => {
          setReportSelected(row);
        }}
        groupBy={groupBy}
        enableGrouping={true}
        tRowClass="cursor-pointer"
        enableScrollTo={false}
        indexScrollTo={
          chuyenMucSelected
            ? chuyenMucSelected.reports.findIndex(
                (report) => report.id === reportSelected?.id,
              )
            : -1
        }
      />
    </div>
  );
};

export default BaoCao;
