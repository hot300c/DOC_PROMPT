import { notifyError } from "@/app/lib/utils";
import { getErrorMessage } from "@/app/lib/utils/errorUtils";
import { Select } from "@/components/select/select";
import { Label } from "@/components/ui/label";
import { useEffect, useState } from "react";
import { useLoadingBaoCao } from "../../../_contexts/loading-bao-cao-context";
import { useTabInTrucTiep } from "../../../_contexts/tab-in-truc-tiep-context";
import {
  L_FacID_List,
  L_ReportParams_List,
  ReportParamsValue,
} from "../../../_utils/definitions/xem-bao-cao.dto";
import { getDataFromReport } from "../../../_utils/services/xem-bao-cao.api";

type InputThamSoProps = {
  paramsValue: ReportParamsValue[];
  setValueParam: (name: string, value: string | null) => void;
  report: L_ReportParams_List;
};

export const Dropdown = ({
  paramsValue,
  setValueParam,
  report,
}: InputThamSoProps) => {
  const { facId } = useTabInTrucTiep();
  const param1 = paramsValue[0];
  const [data1s, setData1s] = useState<L_FacID_List[]>([]);
  const { setLoadingBaoCao } = useLoadingBaoCao();
  const [isNeedInitParamValue, setIsNeedInitParamValue] = useState(false);

  function getInitValue1(list: L_FacID_List[], facId: string) {
    // genie mặc định lấy option facId rồi mới đến item bắt đầu
    if (list.length === 0) return null;
    let itemFirstSelect = list.find((_) => String(_.id) === facId);
    if (!itemFirstSelect) itemFirstSelect = list[0];
    return itemFirstSelect?.id.toString() || "";
  }

  useEffect(() => {
    async function init() {
      try {
        setLoadingBaoCao(true);
        const result = await getDataFromReport({
          report,
          updateRequest(request, variant) {
            if (variant.option.DefautParams) {
              if (variant.option.DefautParams.includes("FacID")) {
                request.parameters = {
                  FacID: facId,
                };
              }
            }
          },
        });
        const data1sNew = (result.table || []) as L_FacID_List[];
        setData1s(data1sNew);
        setIsNeedInitParamValue(true);
      } catch (error) {
        console.log(error);
        notifyError(getErrorMessage(error));
      } finally {
        setLoadingBaoCao(false);
      }
    }
    void init();
  }, [facId, report, setLoadingBaoCao]);

  useEffect(() => {
    if (isNeedInitParamValue && param1) {
      param1.value = getInitValue1(data1s, facId);
      setValueParam(param1.name, param1.value);
      setIsNeedInitParamValue(false);
    }
  }, [isNeedInitParamValue, setValueParam, param1, facId, data1s]);

  if (paramsValue.length === 0 || !param1) return null;

  return (
    <div className="grid grid-cols-12 gap-2">
      <Label className="col-span-4">{param1.caption}</Label>
      <div className="col-span-8">
        <Select
          placeholder="Chọn dữ liệu..."
          className="w-full"
          classNamePopover="w-auto"
          options={data1s.map((_) => ({ value: _.id, label: _.text }))}
          value={param1.value?.toString()}
          onChange={(value) => setValueParam(param1.name, value)}
        ></Select>
      </div>
    </div>
  );
};
