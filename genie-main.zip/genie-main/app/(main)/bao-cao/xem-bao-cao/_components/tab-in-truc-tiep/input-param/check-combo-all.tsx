import { notifyError } from "@/app/lib/utils";
import { getErrorMessage } from "@/app/lib/utils/errorUtils";
import { MultiSelect } from "@/components/select/multi-select";
import { Label } from "@/components/ui/label";
import { useEffect, useState } from "react";
import { useLoadingBaoCao } from "../../../_contexts/loading-bao-cao-context";
import { useTabInTrucTiep } from "../../../_contexts/tab-in-truc-tiep-context";
import {
  DanhSachVaccineKhongNhanTin,
  L_ReportParams_List,
  ReportParamsValue,
} from "../../../_utils/definitions/xem-bao-cao.dto";
import { getDataFromReport } from "../../../_utils/services/xem-bao-cao.api";

type InputThamSoProps = {
  paramsValue: ReportParamsValue[];
  setValueParam: (name: string, value: string | null) => void;
  report: L_ReportParams_List;
};

export const CheckComboAll = ({
  paramsValue,
  setValueParam,
  report,
}: InputThamSoProps) => {
  const { facId } = useTabInTrucTiep();
  const param1 = paramsValue[0];
  const [datas, setDatas] = useState<DanhSachVaccineKhongNhanTin[]>([]);
  const { setLoadingBaoCao } = useLoadingBaoCao();

  useEffect(() => {
    async function init() {
      try {
        setLoadingBaoCao(true);
        const result = await getDataFromReport({
          report,
          updateRequest(request, variant) {
            request.parameters = {
              FacID: facId,
            };
          },
        });
        setDatas(result.table || []);
      } catch (error) {
        console.log(error);
        notifyError(getErrorMessage(error));
      } finally {
        setLoadingBaoCao(false);
      }
    }
    void init();
  }, [facId, report, setLoadingBaoCao]);

  useEffect(() => {
    if (param1 && param1.value === null && datas.length > 0) {
      param1.value = datas.map((s) => s.id).join(",");
      setValueParam(param1.name, param1.value);
    }
  }, [datas, param1, setValueParam]);

  if (paramsValue.length === 0 || !param1) return null;

  return (
    <div className="grid grid-cols-12 gap-2">
      <Label className="col-span-4">{param1.caption}</Label>
      <MultiSelect
        placeholder="Chọn dữ liệu..."
        options={datas?.map((s) => ({
          value: s.id,
          label: s.text,
        }))}
        className="col-span-8"
        value={param1.value?.split(",")}
        onChange={(value) => {
          if (value.length > 0) {
            param1.value = value.join(",");
            setValueParam(param1.name, param1.value);
            return;
          }
          param1.value = null;
          setValueParam(param1.name, param1.value);
        }}
      ></MultiSelect>
    </div>
  );
};
