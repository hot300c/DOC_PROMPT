import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { useEffect } from "react";
import {
  L_ReportParams_List,
  ReportParamsValue,
} from "../../../_utils/definitions/xem-bao-cao.dto";

type InputThamSoProps = {
  paramsValue: ReportParamsValue[];
  setValueParam: (name: string, value: string) => void;
  report: L_ReportParams_List;
};

export const Check = ({ paramsValue, setValueParam }: InputThamSoProps) => {
  useEffect(() => {
    if (paramsValue.length === 0 || !paramsValue[0]) return;
    const param1 = paramsValue[0];
    if (param1.value === null) {
      param1.value = "0";
      setValueParam(param1.name, param1.value);
    }
  }, [paramsValue, setValueParam]);

  if (paramsValue.length === 0 || !paramsValue[0]) return null;
  const param1 = paramsValue[0];
  return (
    <Label className="flex items-center">
      <Checkbox
        className="col-span-8"
        checked={param1.value === "1"}
        onCheckedChange={(checked) => {
          setValueParam(param1.name, checked ? "1" : "0");
        }}
      ></Checkbox>
      <span className="pl-2">{param1.caption}</span>
    </Label>
  );
};
