import { SequenceRequest } from "@/app/lib/definitions/setting";
import { DATE_FORMAT } from "@/app/lib/enums";
import { executeTransaction } from "@/app/lib/services/system";
import { notifyError } from "@/app/lib/utils";
import { getErrorMessage } from "@/app/lib/utils/errorUtils";
import { InputDatePicker } from "@/components/input-date-picker";
import { MultiSelect } from "@/components/select/multi-select";
import { Select } from "@/components/select/select";
import { Label } from "@/components/ui/label";
import { format } from "date-fns";
import { isString } from "lodash";
import { useEffect, useRef, useState } from "react";
import { useLoadingBaoCao } from "../../../_contexts/loading-bao-cao-context";
import { useTabInTrucTiep } from "../../../_contexts/tab-in-truc-tiep-context";
import {
  FacID_List_WithAll,
  L_InventoryStock_GetListByFacID,
  L_ReportParams_List,
  L_ReportParams_List_Option,
  ReportParamsValue,
} from "../../../_utils/definitions/xem-bao-cao.dto";

function getRequestQueryParams(report: L_ReportParams_List) {
  const option = JSON.parse(
    report.options || "{}",
  ) as L_ReportParams_List_Option;
  const requests = [] as SequenceRequest[];
  if (option.SP) {
    let sps = option.SP;
    if (isString(sps)) {
      sps = [sps];
    }
    sps.forEach((sp, index) => {
      const arrSp = sp.split("..");
      const category = arrSp[0];
      const command = arrSp[1];
      if (!category || !command) {
        throw new Error(
          "callApiFromOption lỗi cấu hình: " + JSON.stringify(option),
        );
      }
      const request = {
        category: category,
        command: command,
      } as SequenceRequest;
      requests.push(request);
    });
  }
  return requests;
}

type InputThamSoProps = {
  paramsValue: ReportParamsValue[];
  setValueParam: (name: string, value: string | null) => void;
  report: L_ReportParams_List;
};

export const CheckComboCaTuNgayDenNgayGroupByFacID = ({
  paramsValue,
  setValueParam,
  report,
}: InputThamSoProps) => {
  const { facId } = useTabInTrucTiep();
  const param1 = paramsValue[0];
  const param2 = paramsValue[1];
  const param3 = paramsValue[2];
  const param4 = paramsValue[3];
  const [data1s, setData1s] = useState<FacID_List_WithAll[]>([]);
  const [data4s, setData4s] = useState<L_InventoryStock_GetListByFacID[]>([]);
  const [data1Selected, setData1Selected] = useState<FacID_List_WithAll>();
  const { setLoadingBaoCao } = useLoadingBaoCao();
  const requests = useRef<SequenceRequest[]>([]);
  const isNeedReloadData4s = useRef<boolean>(false);

  async function reloadData4s() {
    if (!isNeedReloadData4s.current) return;
    try {
      setLoadingBaoCao(true);
      const request = requests.current[1];
      if (!request) return;
      request.parameters = {
        FacID: data1Selected?.id.toString(),
        FromDate: param2?.value?.toString() || "",
        ThurDate: param3?.value?.toString() || "",
      };
      const result = await executeTransaction({ request: [request] });
      setData4s(result.table || []);
      isNeedReloadData4s.current = false;
    } catch (error) {
      console.log(error);
      notifyError(getErrorMessage(error));
    } finally {
      setLoadingBaoCao(false);
    }
  }

  useEffect(() => {
    if (paramsValue.length === 0 || !param2 || !param3) return;
    if (param2.value === null && param3.value === null) {
      param2.value = format(new Date(), DATE_FORMAT.YYYY_MM_DD);
      param3.value = format(new Date(), DATE_FORMAT.YYYY_MM_DD);
      setValueParam(param2.name, param2.value);
      setValueParam(param3.name, param3.value);
    }
  }, [paramsValue, setValueParam, param2, param3]);

  useEffect(() => {
    async function init() {
      try {
        setLoadingBaoCao(true);
        requests.current = getRequestQueryParams(report);
        const request = requests.current[0];
        if (!request) return;
        request.parameters = {
          FacID: facId,
        };
        const result = await executeTransaction({ request: [request] });
        setData1s(result.table || []);
      } catch (error) {
        console.log(error);
        notifyError(getErrorMessage(error));
      } finally {
        setLoadingBaoCao(false);
      }
    }
    if (!param1) return;
    void init();
  }, [facId, param1, report, setLoadingBaoCao]);

  useEffect(() => {
    if (paramsValue.length === 0 || !param1) return;
    if (param1.value === null && data1s.length > 0) {
      param1.value = facId || "";
      setValueParam(param1.name, param1.value);
      setData1Selected(data1s.find((v) => String(v.id) === param1.value));
    }
  }, [paramsValue, setValueParam, param1, facId, data1s]);

  useEffect(() => {
    isNeedReloadData4s.current = true;
  }, [data1Selected, param2?.value, param3?.value]);

  if (paramsValue.length === 0 || !param1 || !param2 || !param3 || !param4)
    return null;

  return (
    <div className="grid grid-cols-12 gap-2">
      {/* line 1 */}
      <Label className="col-span-4">{param1.caption}</Label>
      <Select
        className="col-span-8"
        classNamePopover="w-auto"
        value={param1.value || ""}
        options={data1s.map((v) => ({ value: String(v.id), label: v.text }))}
        onChange={(value) => {
          if (value) {
            param1.value = String(value);
            setValueParam(param1.name, param1.value);
            setData1Selected(data1s.find((v) => String(v.id) === param1.value));
            setValueParam(param4.name, null);
          }
        }}
      ></Select>

      {/* line 2 */}
      <Label className="col-span-4">{param2.caption}</Label>
      <InputDatePicker
        className="col-span-8"
        value={param2.value ? new Date(param2.value) : undefined}
        onChange={(date) => {
          if (!date) {
            setValueParam(param2.name, "");
          } else {
            setValueParam(param2.name, format(date, DATE_FORMAT.YYYY_MM_DD));
          }
        }}
      ></InputDatePicker>

      {/* line 3 */}
      <Label className="col-span-4">{param3.caption}</Label>
      <InputDatePicker
        className="col-span-8"
        value={param3.value ? new Date(param3.value) : undefined}
        onChange={(date) => {
          if (!date) {
            setValueParam(param3.name, "");
          } else {
            setValueParam(param3.name, format(date, DATE_FORMAT.YYYY_MM_DD));
          }
        }}
      ></InputDatePicker>

      {/* line 4 */}
      {/* TODO ở đây core ui chưa support group */}
      <Label className="col-span-4">{param4.caption}</Label>
      <MultiSelect
        placeholder="Chọn dữ liệu..."
        options={data4s.map((v) => ({
          label: v.text,
          value: String(v.id),
        }))}
        className="col-span-8"
        value={param4.value?.split(",")}
        onChange={(value) => {
          if (value.length > 0) {
            param4.value = value.join(",");
            setValueParam(param4.name, param4.value);
          } else {
            param4.value = null;
            setValueParam(param4.name, param4.value);
          }
        }}
        onClick={reloadData4s}
      ></MultiSelect>
    </div>
  );
};
