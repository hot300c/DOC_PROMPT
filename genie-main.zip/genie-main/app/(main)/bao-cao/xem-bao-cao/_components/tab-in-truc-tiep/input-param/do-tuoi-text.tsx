import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useEffect } from "react";
import {
  L_ReportParams_List,
  ReportParamsValue,
} from "../../../_utils/definitions/xem-bao-cao.dto";

type InputThamSoProps = {
  paramsValue: ReportParamsValue[];
  setValueParam: (name: string, value: string | null) => void;
  report: L_ReportParams_List;
};

export const DoTuoiText = ({
  paramsValue,
  setValueParam,
}: InputThamSoProps) => {
  const param1 = paramsValue[0];
  const param2 = paramsValue[1];

  useEffect(() => {
    if (paramsValue.length === 0 || !param1 || !param2) return;
    if (param1.value === null && param2.value === null) {
      param1.value = "0";
      param2.value = "99";
      setValueParam(param1.name, param1.value);
      setValueParam(param2.name, param2.value);
    }
  }, [paramsValue, setValueParam, param1, param2]);

  if (paramsValue.length === 0 || !param1 || !param2) return null;

  return (
    <div className="grid grid-cols-12 gap-2">
      {/* line 1 */}
      <Label className="col-span-4">Từ tuổi</Label>
      <Input
        className="col-span-8"
        value={param1.value || ""}
        onChange={(e) => {
          const value = e.target.value;
          if (/^\d*$/.test(value)) {
            setValueParam(param1.name, value);
          }
        }}
        type="text"
      ></Input>

      {/* line 2: chưa có CoreUI Input datetime nên dùng Input native */}
      <Label className="col-span-4">Đến tuổi</Label>
      <Input
        className="col-span-8"
        value={param2.value || ""}
        onChange={(e) => {
          const value = e.target.value;
          if (/^\d*$/.test(value)) {
            setValueParam(param2.name, value);
          }
        }}
        type="text"
      ></Input>
    </div>
  );
};
