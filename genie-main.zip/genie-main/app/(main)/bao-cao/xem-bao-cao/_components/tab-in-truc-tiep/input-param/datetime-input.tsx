"use client";

import { DATE_FORMAT } from "@/app/lib/enums";
import { Label } from "@/components/ui/label";
import { format, setHours, setMinutes, setSeconds } from "date-fns";
import { useEffect } from "react";
import { ParamType } from "../../../_utils/constants/param-type-constant";
import {
  L_ReportParams_List,
  ReportParamsValue,
} from "../../../_utils/definitions/xem-bao-cao.dto";

type InputThamSoProps = {
  paramsValue: ReportParamsValue[];
  setValueParam: (name: string, value: string) => void;
  report: L_ReportParams_List;
};

export const DateTimeInput = ({
  paramsValue,
  setValueParam,
  report,
}: InputThamSoProps) => {
  useEffect(() => {
    if (paramsValue.length === 0 || !paramsValue[0]) return;
    const param1 = paramsValue[0];
    if (report.type === ParamType.DateFromV2 && param1.value === null) {
      const now = new Date();
      const dateAt7AM = setSeconds(setMinutes(setHours(now, 7), 0), 0);
      param1.value = format(dateAt7AM, DATE_FORMAT.DATE_TIME_WITH_HH_MM);
      setValueParam(param1.name, param1.value);
    }
    if (report.type === ParamType.DateThruV2 && param1.value === null) {
      const now = new Date();
      param1.value = format(now, DATE_FORMAT.DATE_TIME_WITH_HH_MM);
      setValueParam(param1.name, param1.value);
    }
  }, [paramsValue, setValueParam, report.type]);

  if (paramsValue.length === 0 || !paramsValue[0]) return null;
  const param1 = paramsValue[0];

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setValueParam(param1.name, e.target.value);
  };

  return (
    <div className="grid grid-cols-12 gap-2">
      <Label className="col-span-4">{param1.caption}</Label>
      <input
        type="datetime-local"
        value={param1.value || ""}
        onChange={handleChange}
        className="col-span-8 border rounded-md p-0 text-sm px-2 text-accent-foreground bg-white"
      />
    </div>
  );
};
