import { notifyError } from "@/app/lib/utils";
import { getErrorMessage } from "@/app/lib/utils/errorUtils";
import { TableSelect } from "@/components/select/table-select";
import { DataTableColumnHeaderSort } from "@/components/ui/dataTable";
import { Label } from "@/components/ui/label";
import { ColumnDef } from "@tanstack/react-table";
import { useEffect, useState } from "react";
import { useLoadingBaoCao } from "../../../_contexts/loading-bao-cao-context";
import { useTabInTrucTiep } from "../../../_contexts/tab-in-truc-tiep-context";
import {
  L_FacID_List_Default,
  L_ReportParams_List,
  ReportParamsValue,
} from "../../../_utils/definitions/xem-bao-cao.dto";
import { getDataFromReport } from "../../../_utils/services/xem-bao-cao.api";

type InputThamSoProps = {
  paramsValue: ReportParamsValue[];
  setValueParam: (name: string, value: string | null) => void;
  report: L_ReportParams_List;
};

const COLUMNS: ColumnDef<L_FacID_List_Default>[] = [
  {
    id: "id",
    accessorKey: "id",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="ID" />
    ),
  },
  {
    id: "text",
    accessorKey: "text",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Text" />
    ),
    cell: ({ row }) => (
      <p title={row.getValue("text")} className="line-clamp-1">
        {row.getValue("text")}
      </p>
    ),
  },
];

export const GridLookUp = ({
  paramsValue,
  setValueParam,
  report,
}: InputThamSoProps) => {
  const { facId } = useTabInTrucTiep();
  const param1 = paramsValue[0];
  const [datas, setDatas] = useState<L_FacID_List_Default[]>([]);
  const { setLoadingBaoCao } = useLoadingBaoCao();

  useEffect(() => {
    async function init() {
      try {
        setLoadingBaoCao(true);
        const result = await getDataFromReport({
          report,
          updateRequest(request, variant) {
            if (variant.option.DefautParams) {
              if (variant.option.DefautParams.includes("FacID")) {
                request.parameters = {
                  FacID: facId,
                };
              }
            }
          },
        });
        setDatas(result.table || []);
      } catch (error) {
        console.log(error);
        notifyError(getErrorMessage(error));
      } finally {
        setLoadingBaoCao(false);
      }
    }
    void init();
  }, [facId, report, setLoadingBaoCao]);

  useEffect(() => {
    if (paramsValue.length === 0 || !param1) return;
    if (param1.value === null) {
      param1.value = facId || "";
      setValueParam(param1.name, param1.value);
    }
  }, [paramsValue, setValueParam, param1, facId]);

  if (paramsValue.length === 0 || !param1) return null;

  return (
    <div className="grid grid-cols-12 gap-2">
      <Label className="col-span-4">{param1.caption}</Label>
      <TableSelect
        columns={COLUMNS}
        data={datas}
        labelKey={"text"}
        valueKey={"id"}
        className="col-span-8"
        placeholder="Chọn dữ liệu..."
        value={datas.find((v) => String(v.id) === param1.value)}
        onChange={(value) => {
          if (value) {
            param1.value = String(value.id);
            setValueParam(param1.name, param1.value);
          }
        }}
      ></TableSelect>
    </div>
  );
};
