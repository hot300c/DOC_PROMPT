"use client";

import { DEFAULT_GUID } from "@/app/lib/enums";
import { useFeedbackDialog } from "@/app/lib/feedback-dialog-provider";
import { notifyError } from "@/app/lib/utils";
import { getErrorMessage } from "@/app/lib/utils/errorUtils";
import { Button } from "@/components/ui/button";
import { Download } from "lucide-react";
import { useCallback, useEffect, useState } from "react";
import { useLoadingBaoCao } from "../../_contexts/loading-bao-cao-context";
import { useTabInTrucTiep } from "../../_contexts/tab-in-truc-tiep-context";
import { ParamType } from "../../_utils/constants/param-type-constant";
import {
  L_ReportParams_List,
  ReportParamsValue,
} from "../../_utils/definitions/xem-bao-cao.dto";
import { downloadReportInBrowser } from "../../_utils/download-report-in-browser";
import getReportParams from "../../_utils/get-report-params";
import populateParams from "../../_utils/populate-params";
import {
  ws_L_ReportParams_List,
  ws_ReportQueue_Push,
} from "../../_utils/services/xem-bao-cao.api";
import { Check } from "./input-param/check";
import { CheckAndText } from "./input-param/check-and-text";
import { CheckCombo } from "./input-param/check-combo";
import { CheckComboAll } from "./input-param/check-combo-all";
import { CheckComboByFacID } from "./input-param/check-combo-by-facid";
import { CheckComboCaQuayTuNgayDenNgay } from "./input-param/check-combo-ca-quay-tu-ngay-den-ngay";
import { CheckComboCaTuNgayDenNgay } from "./input-param/check-combo-ca-tu-ngay-den-ngay";
import { CheckComboCaTuNgayDenNgayGroupByFacID } from "./input-param/check-combo-ca-tu-ngay-den-ngay-group-by-facid";
import { CheckComboBoxSearchEdit } from "./input-param/check-combobox-search-edit";
import { CheckLisboxBacSi } from "./input-param/check-lisbox-bac-si";
import { CheckListboxNCC } from "./input-param/check-listbox-ncc";
import { CheckListboxProduct } from "./input-param/check-listbox-product";
import { CheckBoxDateFromDateThru } from "./input-param/checkbox-date-from-date-thru";
import { CheckBoxReports } from "./input-param/checkbox-reports";
import { DateFromDateThruWithLabel } from "./input-param/date-from-date-thru-with-label";
import { DateFromDateThur2Quy } from "./input-param/date-from-date-thur-2-quy";
import { DateInput } from "./input-param/date-input";
import { DateInputV3 } from "./input-param/date-input-v3";
import { DateTimeInput } from "./input-param/datetime-input";
import { DebugInput } from "./input-param/debug-input";
import { DeptID } from "./input-param/deptid";
import { DoTuoiText } from "./input-param/do-tuoi-text";
import { Dropdown } from "./input-param/dropdown";
import { DropdownByFac } from "./input-param/dropdown-by-fac";
import { DropdownMonth } from "./input-param/dropdown-month";
import { DropdownParentChild } from "./input-param/dropdown-parent-child";
import { DropdownVer2 } from "./input-param/dropdown-ver2";
import { DropdownYear } from "./input-param/dropdown-year";
import { FacID } from "./input-param/facid";
import { GridLookUp } from "./input-param/grid-lookup";
import { GridLookUp2ParamTuNgayDenNgay } from "./input-param/grid-lookup-2-param-tu-ngay-den-ngay";
import { GridLookUp2ParamTuNgayDenNgayTheoCS } from "./input-param/grid-lookup-2-param-tu-ngay-den-ngay-theo-cs";
import { GridLookUp2ParentID } from "./input-param/grid-lookup-2-parentid";
import { GridLookUp3ParentID } from "./input-param/grid-lookup-3-parentid";
import { GridLookUpFacID } from "./input-param/grid-lookup-facid";
import { GridLookupNhomBenhVaccine } from "./input-param/grid-lookup-nhom-benh-vaccine";
import { GridLookupOneInTwo } from "./input-param/grid-lookup-one-in-two";
import { GridLookUpPickOneAllFacID } from "./input-param/grid-lookup-pick-one-all-facid";
import { GridLookUpVerCheckBoxKhu } from "./input-param/grid-lookup-ver-check-box-khu";
import { GridLookUpVerCheckBox } from "./input-param/grid-lookup-ver-checkbox";
import { GridLookUpVerCheckBoxKho } from "./input-param/grid-lookup-ver-checkbox-kho";
import { GridLookUpVerCheckBoxKhoV2 } from "./input-param/grid-lookup-ver-checkbox-kho-v2";
import { GridLookUpVerCheckBoxMultiTuNgayDenNgay } from "./input-param/grid-lookup-ver-checkbox-multi-tu-ngay-den-ngay";
import { GridLookUpVerCheckBoxMuti } from "./input-param/grid-lookup-ver-checkbox-muti";
import { GridLookUpVerCheckBoxStockByFac } from "./input-param/grid-lookup-ver-checkbox-stock-by-fac";
import { GridLookUpVer2 } from "./input-param/grid-lookup-ver2";
import { GridLookUpVer2CheckList } from "./input-param/grid-lookup-ver2-check-list";
import { GridLookUpVer2ThurDate } from "./input-param/grid-lookup-ver2-thur-date";
import { GridLookUpVer3 } from "./input-param/grid-lookup-ver3";
import { LookupVerCheckBoxFacID } from "./input-param/lookup-ver-checkbox-facid";
import { NotAllCheckCombo } from "./input-param/not-all-check-combo";
import { Options } from "./input-param/options";
import { RoomID } from "./input-param/roomid";
import { SearchLK } from "./input-param/search-lk";
import { SearchLK2 } from "./input-param/search-lk2";
import { TextFacID } from "./input-param/text-facid";
import { TextInput } from "./input-param/text-input";
import { TextMaskOnlyNumber } from "./input-param/text-mask-only-number";
import { TextUserID } from "./input-param/text-userid";
import { UC_XemTonKho } from "./input-param/uc-xem-ton-kho";
import { UC_XemTonKhoFacID } from "./input-param/uc-xem-ton-kho-facid";
import { UC_XemTonKhoFacIDThur } from "./input-param/uc-xem-ton-kho-facid-thur";
import { UC_XemTonKhoThur } from "./input-param/uc-xem-ton-kho-thur";
import { UC_XemTonKhoTuNgayDenNgay } from "./input-param/uc-xem-ton-kho-tu-ngay-den-ngay";

// Source: https://git.vnvc.info/vnvc-qas/qas-app/-/blob/a1ee8fb73bba286279af5efa0a4ce38182af2a16/QA.Reports/QA.Reports/uReportsRunParams.cs
const ThamSo = () => {
  const { reportSelected, facId } = useTabInTrucTiep();
  const [reportParams, setReportParams] = useState<L_ReportParams_List[]>([]);
  const [paramsValue, setParamsValue] = useState<ReportParamsValue[]>([]);
  const { alert } = useFeedbackDialog();
  const { setLoadingBaoCao } = useLoadingBaoCao();

  async function handlePrint() {
    try {
      setLoadingBaoCao(true);
      const result = getReportParams({ reportParams, paramsValue, facId });
      console.log("print paramsValue", paramsValue, "result", result);
      if (result.error) {
        await alert({
          title: "Cảnh báo",
          content: result.error,
        });
        return;
      }
      const queueSeq = await ws_ReportQueue_Push({
        reportId: reportSelected?.id ?? "",
        reportParams: JSON.stringify(result.obj),
        userId: DEFAULT_GUID, // 00000000-0000-0000-0000-000000000000
        facID: facId,
      });
      const { isDone, isError } = await downloadReportInBrowser({ queueSeq });
      if (!isDone) {
        void alert({
          title: "Cảnh báo",
          content:
            "Do thời gian tạo báo cáo quá lâu, vui lòng qua tab Xem báo cáo để tiếp tục coi trạng thái báo cáo. Xin cám ơn!",
        });
        return;
      }
      if (isError) {
        await alert({
          title: "Cảnh báo",
          content:
            "Vui lòng qua tab Xem báo cáo để coi trạng thái báo cáo. Xin cám ơn!",
        });
        return;
      }
    } catch (error) {
      console.log(error);
      notifyError(getErrorMessage(error));
    } finally {
      setLoadingBaoCao(false);
    }
  }

  const renderParamInput = useCallback(() => {
    // TODO tham số option: isSchedule; ca, Group default value, permission,...
    const setValueParam = (name: string, value: string | null) => {
      const param = paramsValue.find((param) => param.name === name);
      if (param) {
        param.value = value;
      }
      setParamsValue([...paramsValue]);
    };
    return (
      <div className="flex-1 flex flex-col space-y-2 overflow-hidden">
        {reportParams.map((report) => {
          const paramsValueCurrent = paramsValue.filter(
            (p) => p.reportParams.name === report.name,
          );
          const key = `${report.index}-${report.name}-${report.reportId}`;
          // Chỗ này để track theo thứ tự xây dựng như App input param cho báo cáo cho dễ theo dõi
          switch (report.type) {
            case ParamType.TextUserID:
              return (
                <TextUserID
                  key={key}
                  paramsValue={paramsValueCurrent}
                  setValueParam={setValueParam}
                  report={report}
                />
              );
            case ParamType.TextFacID:
              return (
                <TextFacID
                  key={key}
                  paramsValue={paramsValueCurrent}
                  setValueParam={setValueParam}
                  report={report}
                />
              );
            case ParamType.Check:
              return (
                <Check
                  key={key}
                  paramsValue={paramsValueCurrent}
                  setValueParam={setValueParam}
                  report={report}
                />
              );
            case ParamType.Date:
            case ParamType.DateFrom:
            case ParamType.DateThru:
              return (
                <DateInput
                  key={key}
                  paramsValue={paramsValueCurrent}
                  setValueParam={setValueParam}
                  report={report}
                />
              );
            case ParamType.Dropdown:
              return (
                <Dropdown
                  key={key}
                  paramsValue={paramsValueCurrent}
                  setValueParam={setValueParam}
                  report={report}
                />
              );
            case ParamType.Options:
              return (
                <Options
                  key={key}
                  paramsValue={paramsValueCurrent}
                  setValueParam={setValueParam}
                  report={report}
                />
              );
            case ParamType.Text:
              return (
                <TextInput
                  key={key}
                  paramsValue={paramsValueCurrent}
                  setValueParam={setValueParam}
                  report={report}
                />
              );
            case ParamType.DropdownVer2:
              return (
                <DropdownVer2
                  key={key}
                  paramsValue={paramsValueCurrent}
                  setValueParam={setValueParam}
                  report={report}
                />
              );
            case ParamType.GridLookUp:
              return (
                <GridLookUp
                  key={key}
                  paramsValue={paramsValueCurrent}
                  setValueParam={setValueParam}
                  report={report}
                />
              );
            case ParamType.GridLookUpVer2:
              return (
                <GridLookUpVer2
                  key={key}
                  paramsValue={paramsValueCurrent}
                  setValueParam={setValueParam}
                  report={report}
                />
              );
            case ParamType.GridLookUpVerCheckBox:
              return (
                <GridLookUpVerCheckBox
                  key={key}
                  paramsValue={paramsValueCurrent}
                  setValueParam={setValueParam}
                  report={report}
                />
              );
            case ParamType.GridLookUpVer2CheckList:
              return (
                <GridLookUpVer2CheckList
                  key={key}
                  paramsValue={paramsValueCurrent}
                  setValueParam={setValueParam}
                  report={report}
                />
              );
            case ParamType.GridLookupNhomBenhVaccine:
              return (
                <GridLookupNhomBenhVaccine
                  key={key}
                  paramsValue={paramsValueCurrent}
                  setValueParam={setValueParam}
                  report={report}
                />
              );
            case ParamType.CheckCombo:
              return (
                <CheckCombo
                  key={key}
                  paramsValue={paramsValueCurrent}
                  setValueParam={setValueParam}
                  report={report}
                />
              );
            case ParamType.CheckComboByFacID:
              return (
                <CheckComboByFacID
                  key={key}
                  paramsValue={paramsValueCurrent}
                  setValueParam={setValueParam}
                  report={report}
                />
              );
            case ParamType.DateFromV2:
            case ParamType.DateThruV2:
              return (
                <DateTimeInput
                  key={key}
                  paramsValue={paramsValueCurrent}
                  setValueParam={setValueParam}
                  report={report}
                />
              );
            case ParamType.ucXemTonKho:
              return (
                <UC_XemTonKho
                  key={key}
                  paramsValue={paramsValueCurrent}
                  setValueParam={setValueParam}
                  report={report}
                />
              );
            case ParamType.ucXemTonKhoThur:
              return (
                <UC_XemTonKhoThur
                  key={key}
                  paramsValue={paramsValueCurrent}
                  setValueParam={setValueParam}
                  report={report}
                />
              );
            case ParamType.GridLookUpVerCheckBoxKhu:
              return (
                <GridLookUpVerCheckBoxKhu
                  key={key}
                  paramsValue={paramsValueCurrent}
                  setValueParam={setValueParam}
                  report={report}
                />
              );
            case ParamType.GridLookUpVerCheckBoxMuti:
              return (
                <GridLookUpVerCheckBoxMuti
                  key={key}
                  paramsValue={paramsValueCurrent}
                  setValueParam={setValueParam}
                  report={report}
                />
              );
            case ParamType.ucXemTonKhoTuNgayDenNgay:
              return (
                <UC_XemTonKhoTuNgayDenNgay
                  key={key}
                  paramsValue={paramsValueCurrent}
                  setValueParam={setValueParam}
                  report={report}
                />
              );
            case ParamType.GridLookUpPickOneAllFacID:
              return (
                <GridLookUpPickOneAllFacID
                  key={key}
                  paramsValue={paramsValueCurrent}
                  setValueParam={setValueParam}
                  report={report}
                />
              );
            case ParamType.GridLookUpVer2ThurDate:
              return (
                <GridLookUpVer2ThurDate
                  key={key}
                  paramsValue={paramsValueCurrent}
                  setValueParam={setValueParam}
                  report={report}
                />
              );
            case ParamType.DateFromDateThur2Quy:
              return (
                <DateFromDateThur2Quy
                  key={key}
                  paramsValue={paramsValueCurrent}
                  setValueParam={setValueParam}
                  report={report}
                />
              );
            case ParamType.GridLookUpVer3:
              return (
                <GridLookUpVer3
                  key={key}
                  paramsValue={paramsValueCurrent}
                  setValueParam={setValueParam}
                  report={report}
                />
              );
            case ParamType.GridLookUp2ParentID:
              return (
                <GridLookUp2ParentID
                  key={key}
                  paramsValue={paramsValueCurrent}
                  setValueParam={setValueParam}
                  report={report}
                />
              );
            case ParamType.GridLookUp3ParentID:
              return (
                <GridLookUp3ParentID
                  key={key}
                  paramsValue={paramsValueCurrent}
                  setValueParam={setValueParam}
                  report={report}
                />
              );
            case ParamType.GridLookUpFacID:
              return (
                <GridLookUpFacID
                  key={key}
                  paramsValue={paramsValueCurrent}
                  setValueParam={setValueParam}
                  report={report}
                />
              );
            case ParamType.CheckAndText:
              return (
                <CheckAndText
                  key={key}
                  paramsValue={paramsValueCurrent}
                  setValueParam={setValueParam}
                  report={report}
                />
              );
            case ParamType.ucXemTonKhoFacID:
              return (
                <UC_XemTonKhoFacID
                  key={key}
                  paramsValue={paramsValueCurrent}
                  setValueParam={setValueParam}
                  report={report}
                />
              );
            case ParamType.ucXemTonKhoFacIDThur:
              return (
                <UC_XemTonKhoFacIDThur
                  key={key}
                  paramsValue={paramsValueCurrent}
                  setValueParam={setValueParam}
                  report={report}
                />
              );
            case ParamType.NotAllCheckCombo:
              return (
                <NotAllCheckCombo
                  key={key}
                  paramsValue={paramsValueCurrent}
                  setValueParam={setValueParam}
                  report={report}
                />
              );
            case ParamType.CheckComboCaTuNgayDenNgay:
              return (
                <CheckComboCaTuNgayDenNgay
                  key={key}
                  paramsValue={paramsValueCurrent}
                  setValueParam={setValueParam}
                  report={report}
                />
              );
            case ParamType.GridLookupOneInTwo:
              return (
                <GridLookupOneInTwo
                  key={key}
                  paramsValue={paramsValueCurrent}
                  setValueParam={setValueParam}
                  report={report}
                />
              );
            case ParamType.CheckComboCaTuNgayDenNgayGroupByFacID:
              return (
                <CheckComboCaTuNgayDenNgayGroupByFacID
                  key={key}
                  paramsValue={paramsValueCurrent}
                  setValueParam={setValueParam}
                  report={report}
                />
              );
            case ParamType.GridLookUp2ParamTuNgayDenNgay:
              return (
                <GridLookUp2ParamTuNgayDenNgay
                  key={key}
                  paramsValue={paramsValueCurrent}
                  setValueParam={setValueParam}
                  report={report}
                />
              );
            case ParamType.FacID:
              return (
                <FacID
                  key={key}
                  paramsValue={paramsValueCurrent}
                  setValueParam={setValueParam}
                  report={report}
                />
              );
            case ParamType.DeptID:
              return (
                <DeptID
                  key={key}
                  paramsValue={paramsValueCurrent}
                  setValueParam={setValueParam}
                  report={report}
                />
              );
            case ParamType.RoomID:
              return (
                <RoomID
                  key={key}
                  paramsValue={paramsValueCurrent}
                  setValueParam={setValueParam}
                  report={report}
                />
              );
            case ParamType.DropdownByFac:
              return (
                <DropdownByFac
                  key={key}
                  paramsValue={paramsValueCurrent}
                  setValueParam={setValueParam}
                  report={report}
                />
              );
            case ParamType.DropdownMonth:
              return (
                <DropdownMonth
                  key={key}
                  paramsValue={paramsValueCurrent}
                  setValueParam={setValueParam}
                  report={report}
                />
              );
            case ParamType.DropdownYear:
              return (
                <DropdownYear
                  key={key}
                  paramsValue={paramsValueCurrent}
                  setValueParam={setValueParam}
                  report={report}
                />
              );
            case ParamType.TextMaskOnlyNumber:
              return (
                <TextMaskOnlyNumber
                  key={key}
                  paramsValue={paramsValueCurrent}
                  setValueParam={setValueParam}
                  report={report}
                />
              );
            case ParamType.GridLookUp2ParamTuNgayDenNgayTheoCS:
              return (
                <GridLookUp2ParamTuNgayDenNgayTheoCS
                  key={key}
                  paramsValue={paramsValueCurrent}
                  setValueParam={setValueParam}
                  report={report}
                />
              );
            case ParamType.GridLookUpVerCheckBoxStockByFac:
              return (
                <GridLookUpVerCheckBoxStockByFac
                  key={key}
                  paramsValue={paramsValueCurrent}
                  setValueParam={setValueParam}
                  report={report}
                />
              );
            case ParamType.CheckComboALL:
              return (
                <CheckComboAll
                  key={key}
                  paramsValue={paramsValueCurrent}
                  setValueParam={setValueParam}
                  report={report}
                />
              );
            case ParamType.LookupVerCheckBoxFacID:
              return (
                <LookupVerCheckBoxFacID
                  key={key}
                  paramsValue={paramsValueCurrent}
                  setValueParam={setValueParam}
                  report={report}
                />
              );
            case ParamType.GridLookUpVerCheckBoxMultiTuNgayDenNgay:
              return (
                <GridLookUpVerCheckBoxMultiTuNgayDenNgay
                  key={key}
                  paramsValue={paramsValueCurrent}
                  setValueParam={setValueParam}
                  report={report}
                />
              );
            case ParamType.CheckLisboxBacSi:
              return (
                <CheckLisboxBacSi
                  key={key}
                  paramsValue={paramsValueCurrent}
                  setValueParam={setValueParam}
                  report={report}
                />
              );
            case ParamType.CheckBoxReports:
              return (
                <CheckBoxReports
                  key={key}
                  paramsValue={paramsValueCurrent}
                  setValueParam={setValueParam}
                  report={report}
                />
              );
            case ParamType.DoTuoiText:
              return (
                <DoTuoiText
                  key={key}
                  paramsValue={paramsValueCurrent}
                  setValueParam={setValueParam}
                  report={report}
                />
              );
            case ParamType.GridLookUpVerCheckBoxKho:
              return (
                <GridLookUpVerCheckBoxKho
                  key={key}
                  paramsValue={paramsValueCurrent}
                  setValueParam={setValueParam}
                  report={report}
                />
              );
            case ParamType.CheckComboCaQuayTuNgayDenNgay:
              return (
                <CheckComboCaQuayTuNgayDenNgay
                  key={key}
                  paramsValue={paramsValueCurrent}
                  setValueParam={setValueParam}
                  report={report}
                />
              );
            case ParamType.CheckListboxNCC:
              return (
                <CheckListboxNCC
                  key={key}
                  paramsValue={paramsValueCurrent}
                  setValueParam={setValueParam}
                  report={report}
                />
              );
            case ParamType.CheckListboxProduct:
              return (
                <CheckListboxProduct
                  key={key}
                  paramsValue={paramsValueCurrent}
                  setValueParam={setValueParam}
                  report={report}
                />
              );
            case ParamType.CheckComboBoxSearchEdit:
              return (
                <CheckComboBoxSearchEdit
                  key={key}
                  paramsValue={paramsValueCurrent}
                  setValueParam={setValueParam}
                  report={report}
                />
              );
            case ParamType.DropdownParentChild:
              return (
                <DropdownParentChild
                  key={key}
                  paramsValue={paramsValueCurrent}
                  setValueParam={setValueParam}
                  report={report}
                />
              );
            case ParamType.GridLookUpVerCheckBoxKhoV2:
              return (
                <GridLookUpVerCheckBoxKhoV2
                  key={key}
                  paramsValue={paramsValueCurrent}
                  setValueParam={setValueParam}
                  report={report}
                />
              );
            case ParamType.SearchLK:
              return (
                <SearchLK
                  key={key}
                  paramsValue={paramsValueCurrent}
                  setValueParam={setValueParam}
                  report={report}
                />
              );
            case ParamType.SearchLK2:
              return (
                <SearchLK2
                  key={key}
                  paramsValue={paramsValueCurrent}
                  setValueParam={setValueParam}
                  report={report}
                />
              );
            case ParamType.DateFromV3:
            case ParamType.DateThruV3:
              return (
                <DateInputV3
                  key={key}
                  paramsValue={paramsValueCurrent}
                  setValueParam={setValueParam}
                  report={report}
                />
              );
            case ParamType.CheckBoxDateFromDateThru:
              return (
                <CheckBoxDateFromDateThru
                  key={key}
                  paramsValue={paramsValueCurrent}
                  setValueParam={setValueParam}
                  report={report}
                />
              );
            case ParamType.DateFromDateThruWithLabel:
              return (
                <DateFromDateThruWithLabel
                  key={key}
                  paramsValue={paramsValueCurrent}
                  setValueParam={setValueParam}
                  report={report}
                />
              );
            default:
              return (
                <DebugInput
                  key={key}
                  paramsValue={paramsValueCurrent}
                  setValueParam={setValueParam}
                  report={report}
                />
              );
          }
        })}
      </div>
    );
  }, [paramsValue, reportParams]);

  useEffect(() => {
    if (reportSelected) {
      async function initReportParams(reportId: string) {
        setLoadingBaoCao(true);
        try {
          const reportParams = await ws_L_ReportParams_List(reportId);
          setReportParams(reportParams);
          console.log("reportParams", reportParams);
          const newParamsValue = populateParams(reportParams);
          setParamsValue(newParamsValue);
        } catch (error) {
          console.log(error);
          notifyError(getErrorMessage(error));
        } finally {
          setLoadingBaoCao(false);
        }
      }
      void initReportParams(reportSelected.id);
    }
  }, [reportSelected, setLoadingBaoCao]);

  return (
    <div className="flex flex-col overflow-hidden relative">
      <div className="absolute left-2 bg-white font-bold">Tham số</div>
      <div className="flex flex-col overflow-hidden gap-2 border rounded-md p-2 pt-4 mt-3 mb-1 mr-1">
        <div className="flex flex-col overflow-auto">
          <div className="h-full">{renderParamInput()}</div>
        </div>
        <Button className="w-24 mt-2" onClick={handlePrint}>
          <Download className="mr-2 w-4" />
          Tải về
          {/* app là nút In bấm vào mở file bằng phần mềm Office Excel */}
        </Button>
      </div>
    </div>
  );
};

export default ThamSo;
