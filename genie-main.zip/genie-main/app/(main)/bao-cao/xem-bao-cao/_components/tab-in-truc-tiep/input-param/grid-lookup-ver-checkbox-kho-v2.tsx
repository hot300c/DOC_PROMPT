import { notifyError } from "@/app/lib/utils";
import { getErrorMessage } from "@/app/lib/utils/errorUtils";
import { MultiSelect } from "@/components/select/multi-select";
import { TableSelect } from "@/components/select/table-select";
import { DataTableColumnHeaderSort } from "@/components/ui/dataTable";
import { Label } from "@/components/ui/label";
import { ColumnDef } from "@tanstack/react-table";
import { useEffect, useState } from "react";
import { useLoadingBaoCao } from "../../../_contexts/loading-bao-cao-context";
import { useTabInTrucTiep } from "../../../_contexts/tab-in-truc-tiep-context";
import {
  L_FacIDNotAll_List,
  L_ReportParams_List,
  LoadComboLoaiSPV2,
  LoadComboStockNameV3,
  ReportParamsValue,
} from "../../../_utils/definitions/xem-bao-cao.dto";
import { getDataFromReport } from "../../../_utils/services/xem-bao-cao.api";

type InputThamSoProps = {
  paramsValue: ReportParamsValue[];
  setValueParam: (name: string, value: string | null) => void;
  report: L_ReportParams_List;
};

const COLUMNS1: ColumnDef<L_FacIDNotAll_List>[] = [
  {
    id: "id",
    accessorKey: "id",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="ID" />
    ),
  },
  {
    id: "text",
    accessorKey: "text",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Text" />
    ),
    cell: ({ row }) => (
      <p title={row.getValue("text")} className="line-clamp-1">
        {row.getValue("text")}
      </p>
    ),
  },
];

const COLUMNS2: ColumnDef<LoadComboLoaiSPV2>[] = [
  {
    id: "id",
    accessorKey: "id",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Mã" />
    ),
  },
  {
    id: "text",
    accessorKey: "text",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Tên" />
    ),
    cell: ({ row }) => (
      <p title={row.getValue("text")} className="line-clamp-1">
        {row.getValue("text")}
      </p>
    ),
  },
];

export const GridLookUpVerCheckBoxKhoV2 = ({
  paramsValue,
  setValueParam,
  report,
}: InputThamSoProps) => {
  const { facId } = useTabInTrucTiep();
  const param1 = paramsValue[0];
  const param2 = paramsValue[1];
  const param3 = paramsValue[2];
  const [data1s, setData1s] = useState<L_FacIDNotAll_List[]>([]);
  const [data2s, setData2s] = useState<LoadComboLoaiSPV2[]>([]);
  const [data3s, setData3s] = useState<LoadComboStockNameV3[]>([]);
  const [data1Selected, setData1Selected] = useState<L_FacIDNotAll_List>();
  const [data2Selected, setData2Selected] = useState<LoadComboLoaiSPV2>();
  const [data2sFilter, setData2sFilter] = useState<LoadComboLoaiSPV2[]>([]);
  const [data3sFilter, setData3sFilter] = useState<LoadComboStockNameV3[]>([]);
  const { setLoadingBaoCao } = useLoadingBaoCao();

  useEffect(() => {
    async function init() {
      try {
        setLoadingBaoCao(true);
        const result = await getDataFromReport({
          report,
        });
        setData1s(result.table || []);
        setData2s(result.table1 || []);
        setData3s(result.table2 || []);
      } catch (error) {
        console.log(error);
        notifyError(getErrorMessage(error));
      } finally {
        setLoadingBaoCao(false);
      }
    }
    void init();
  }, [facId, report, setLoadingBaoCao]);

  useEffect(() => {
    if (paramsValue.length === 0 || !param1) return;
    if (param1.value === null && data1s.length > 0) {
      param1.value = facId || "";
      setValueParam(param1.name, param1.value);
      setData1Selected(data1s.find((v) => String(v.id) === param1.value));
    }
  }, [paramsValue, setValueParam, param1, facId, data1s]);

  useEffect(() => {
    if (paramsValue.length === 0 || !param1 || !param2) return;
    let data2sNew = [...data2s];
    if (param1.value && param1.value !== "0") {
      data2sNew = data2sNew.filter((v) => String(v.parentID) === param1.value);
    }
    setData2sFilter(data2sNew);
    if (param2.value === null && data2s.length > 0) {
      const data2Selected = data2s[0];
      if (data2Selected) {
        param2.value = String(data2Selected.id);
        setValueParam(param2.name, param2.value);
        setData2Selected(data2Selected);
      }
    }
  }, [paramsValue, setValueParam, data2s, param1, param2]);

  useEffect(() => {
    if (paramsValue.length === 0 || !param1 || !param2) return;
    let data3sNew = [...data3s];
    if (param1.value) {
      data3sNew = data3sNew.filter((v) => String(v.parentID) === param1.value);
    }
    if (param2.value && param2.value !== "0") {
      data3sNew = data3sNew.filter((v) => String(v.parentID1) === param2.value);
    }
    setData3sFilter(data3sNew);
  }, [paramsValue, setValueParam, data3s, param1, param2]);

  if (paramsValue.length === 0 || !param1 || !param2 || !param3) return null;

  return (
    <div className="grid grid-cols-12 gap-2">
      {/* line 1 */}
      <Label className="col-span-4">{param1.caption}</Label>
      <TableSelect
        columns={COLUMNS1}
        data={data1s}
        labelKey={"text"}
        valueKey={"id"}
        className="col-span-8"
        placeholder="Chọn dữ liệu..."
        value={data1Selected}
        onChange={(value) => {
          if (value) {
            param1.value = String(value.id);
            setValueParam(param1.name, param1.value);
            setValueParam(param2.name, null);
            setValueParam(param3.name, null);
            setData1Selected(value);
          }
        }}
      ></TableSelect>

      {/* line 2 */}
      <Label className="col-span-4">{param2.caption}</Label>
      <TableSelect
        columns={COLUMNS2}
        data={data2sFilter}
        labelKey={"text"}
        valueKey={"id"}
        className="col-span-8"
        placeholder="Chọn dữ liệu..."
        value={data2Selected}
        onChange={(value) => {
          if (value) {
            param2.value = String(value.id);
            setValueParam(param2.name, param2.value);
            setData2Selected(value);
            setValueParam(param3.name, null);
          }
        }}
      ></TableSelect>

      {/* line 3 */}
      <Label className="col-span-4">{param3.caption}</Label>
      <MultiSelect
        placeholder="Chọn dữ liệu..."
        options={data3sFilter.map((v) => ({
          label: v.text,
          value: String(v.id),
        }))}
        className="col-span-8"
        value={param3.value?.split(",")}
        onChange={(value) => {
          if (value.length > 0) {
            param3.value = value.join(",");
            setValueParam(param3.name, param3.value);
          } else {
            param3.value = null;
            setValueParam(param3.name, param3.value);
          }
        }}
      ></MultiSelect>
    </div>
  );
};
