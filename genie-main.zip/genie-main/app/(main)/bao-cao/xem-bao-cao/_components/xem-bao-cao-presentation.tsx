"use client";

import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useState } from "react";
import { TabInTrucTiepProvider } from "../_contexts/tab-in-truc-tiep-context";
import { TabXemBaoCaoProvider } from "../_contexts/tab-xem-bao-cao-context";
import { L_Reports_ListByUser } from "../_utils/definitions/xem-bao-cao.dto";
import TabInTrucTiep from "./tab-in-truc-tiep/tab-in-truc-tiep";
import TabXemBaoCao from "./tab-xem-bao-cao/tab-xem-bao-cao";

type XemBaoCaoPresentationProps = {
  reportsByUser: L_Reports_ListByUser[];
  facId: string;
  userId: string;
};

export default function XemBaoCaoPresentation({
  reportsByUser,
  facId,
  userId,
}: XemBaoCaoPresentationProps) {
  const [currTab, setCurrTab] = useState("in-truc-tiep");
  function handleTabChange(value: string): void {
    setCurrTab(value);
  }

  return (
    <Tabs
      className="flex flex-col flex-1 w-full overflow-hidden"
      defaultValue="in-truc-tiep"
      value={currTab}
      onValueChange={handleTabChange}
    >
      <TabsList className="justify-start bg-white">
        <TabsTrigger value="in-truc-tiep">In trực tiếp</TabsTrigger>
        <TabsTrigger value="xem-bao-cao">Xem báo cáo</TabsTrigger>
      </TabsList>
      <TabsContent
        value="in-truc-tiep"
        className="w-full flex-1 overflow-hidden"
      >
        <TabInTrucTiepProvider
          facId={facId}
          userId={userId}
          reportsByUser={reportsByUser}
        >
          <TabInTrucTiep />
        </TabInTrucTiepProvider>
      </TabsContent>
      <TabsContent
        value="xem-bao-cao"
        className="w-full flex-1 overflow-hidden"
      >
        <TabXemBaoCaoProvider
          facId={facId}
          userId={userId}
          isCurrTab={currTab === "xem-bao-cao"}
        >
          <TabXemBaoCao />
        </TabXemBaoCaoProvider>
      </TabsContent>
    </Tabs>
  );
}
