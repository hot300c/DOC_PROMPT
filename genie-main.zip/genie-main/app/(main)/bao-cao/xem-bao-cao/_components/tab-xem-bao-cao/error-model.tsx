import { notifyWarning } from "@/app/lib/utils";
import { getErrorMessage } from "@/app/lib/utils/errorUtils";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import React, { useEffect } from "react";
import { useLoadingBaoCao } from "../../_contexts/loading-bao-cao-context";
import { ReportErrors_Get } from "../../_utils/definitions/xem-bao-cao.dto";
import { ws_ReportErrors_Get } from "../../_utils/services/xem-bao-cao.api";

interface ErrorModelProps {
  seq: number;
  onClose: () => void;
}

const ErrorModel: React.FC<ErrorModelProps> = ({ seq, onClose }) => {
  const [report, setReport] = React.useState<ReportErrors_Get | null>(null);
  const { setLoadingBaoCao } = useLoadingBaoCao();

  useEffect(() => {
    async function init() {
      try {
        setLoadingBaoCao(true);
        const reportResult = await ws_ReportErrors_Get(String(seq));
        setReport(reportResult);
      } catch (error) {
        console.log(error);
        notifyWarning(getErrorMessage(error));
      } finally {
        setLoadingBaoCao(false);
      }
    }
    void init();
  }, [seq, setLoadingBaoCao]);

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="bg-white max-w-[800px] flex flex-col max-h-[800px]">
        <DialogHeader className="w-full">
          <DialogTitle className="text-lg">Xem lỗi</DialogTitle>
        </DialogHeader>

        <div className="flex-1 flex flex-col overflow-hidden space-y-2">
          <div className="grid grid-cols-12 gap-4">
            <Label className="col-span-2">ID</Label>
            <Input
              className="col-span-10"
              value={report?.reportID?.toString() || ""}
              readOnly
            ></Input>

            <Label className="col-span-2">Name</Label>
            <Input
              className="col-span-10"
              value={report?.reportName || ""}
              readOnly
            ></Input>

            <Label className="col-span-2">Type</Label>
            <Input
              className="col-span-10"
              value={report?.reportType || ""}
              readOnly
            ></Input>

            <Label className="col-span-2">ProgID</Label>
            <Input
              className="col-span-10"
              value={report?.reportProgID || ""}
              readOnly
            ></Input>

            <Label className="col-span-2">SQL</Label>
            <Textarea
              className="col-span-10"
              value={report?.sql || ""}
              readOnly
              rows={5}
            ></Textarea>

            <Label className="col-span-2">Stack Trace</Label>
            <Textarea
              className="col-span-10"
              value={report?.message || ""}
              readOnly
              rows={10}
            ></Textarea>
          </div>
        </div>

        <div className="mt-auto w-full flex items-center justify-end">
          <Button onClick={onClose} className="min-w-20">
            Đóng
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default ErrorModel;
