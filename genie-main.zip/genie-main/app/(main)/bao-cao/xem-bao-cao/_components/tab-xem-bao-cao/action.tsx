import { notifyError } from "@/app/lib/utils";
import { getErrorMessage } from "@/app/lib/utils/errorUtils";
import { Button } from "@/components/ui/button";
import { Download } from "lucide-react";
import { useLoadingBaoCao } from "../../_contexts/loading-bao-cao-context";
import { useTabXemBaoCao } from "../../_contexts/tab-xem-bao-cao-context";
import { ws_ReportQueue_Resubmit } from "../../_utils/services/xem-bao-cao.api";

interface ActionProps {
  downloadReportSelected: () => void;
}

const Action: React.FC<ActionProps> = ({ downloadReportSelected }) => {
  const { reportSelected, setOpenThamSoModel, setOpenErrorModel } =
    useTabXemBaoCao();
  const { setLoadingBaoCao } = useLoadingBaoCao();
  const { refresh } = useTabXemBaoCao();

  async function handleChayBaoCaoLai() {
    if (!reportSelected) return;
    try {
      setLoadingBaoCao(true);
      await ws_ReportQueue_Resubmit(String(reportSelected.seq));
      await refresh();
    } catch (error) {
      console.log(error);
      notifyError(getErrorMessage(error));
    } finally {
      setLoadingBaoCao(false);
    }
  }

  async function handleRefresh() {
    if (!reportSelected) return;
    try {
      setLoadingBaoCao(true);
      await refresh();
    } catch (error) {
      console.log(error);
      notifyError(getErrorMessage(error));
    } finally {
      setLoadingBaoCao(false);
    }
  }

  function handlePopupThamSo() {
    setOpenThamSoModel(true);
  }

  function handlePopupXemLoi() {
    setOpenErrorModel(true);
  }

  function handleOpen() {
    void downloadReportSelected();
  }

  return (
    <div className="w-full flex flex-row overflow-hidden justify-between p-2">
      <div className="flex space-x-2">
        <Button onClick={handleChayBaoCaoLai}>Chạy báo cáo lại</Button>
        <Button className="min-w-24" onClick={handlePopupXemLoi}>
          Xem lỗi
        </Button>
      </div>
      <div className="flex space-x-2">
        <Button className="min-w-24" onClick={handleOpen}>
          <Download className="mr-2 w-4" />
          Tải về
          {/* app là nút Mở bấm vào mở file */}
        </Button>
        <Button className="min-w-24" onClick={handleRefresh}>
          Làm mới
        </Button>
        <Button className="min-w-24" onClick={handlePopupThamSo}>
          Tham số
        </Button>
      </div>
    </div>
  );
};

export default Action;
