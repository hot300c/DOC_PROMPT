"use client";

import { DATE_FORMAT } from "@/app/lib/enums";
import {
  DataTable,
  DataTableColumnHeaderSort,
} from "@/components/ui/dataTable";
import { ColumnDef } from "@tanstack/react-table";
import { format } from "date-fns";
import { useTabXemBaoCao } from "../../_contexts/tab-xem-bao-cao-context";
import { ReportQueue_List } from "../../_utils/definitions/xem-bao-cao.dto";

const COLUMNS: ColumnDef<ReportQueue_List>[] = [
  {
    id: "category",
    accessorKey: "category",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Chuyên mục" />
    ),
    cell: ({ row }) => (
      <p className="line-clamp-1" title={row.getValue("category")}>
        {row.getValue("category")}
      </p>
    ),
  },
  {
    id: "reportName",
    accessorKey: "reportName",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Tên" />
    ),
    cell: ({ row }) => (
      <p className="line-clamp-1 min-w-40" title={row.getValue("reportName")}>
        {row.getValue("reportName")}
      </p>
    ),
  },
  {
    id: "description",
    accessorKey: "description",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Mô Tả" />
    ),
    cell: ({ row }) => (
      <p className="line-clamp-1" title={row.getValue("description")}>
        {row.getValue("description")}
      </p>
    ),
  },
  {
    id: "reportType",
    accessorKey: "reportType",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Loại" />
    ),
  },
  {
    id: "status",
    accessorKey: "status",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Trạng Thái" />
    ),
  },
  {
    id: "createdOn",
    accessorKey: "createdOn",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Ngày Tạo" />
    ),
    cell: ({ row }) => {
      const value = format(
        row.getValue("createdOn"),
        DATE_FORMAT.DD_MM_YYYY_HH_MM_SS,
      );
      return (
        <p className="line-clamp-1 min-w-32" title={value}>
          {value}
        </p>
      );
    },
  },
  {
    id: "completedOn",
    accessorKey: "completedOn",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Hoàn Tất" />
    ),
    cell: ({ row }) => {
      const value = format(
        row.getValue("completedOn"),
        DATE_FORMAT.DD_MM_YYYY_HH_MM_SS,
      );
      return (
        <p className="line-clamp-1 min-w-32" title={value}>
          {value}
        </p>
      );
    },
  },
  {
    id: "printedByName",
    accessorKey: "printedByName",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Người in" />
    ),
    cell: ({ row }) => (
      <p
        className="line-clamp-1 min-w-32"
        title={row.getValue("printedByName")}
      >
        {row.getValue("printedByName")}
      </p>
    ),
  },
];

interface BaoCaoProps {
  downloadReportSelected: () => void;
}

const BaoCao: React.FC<BaoCaoProps> = ({ downloadReportSelected }) => {
  const { reportsQueue, reportSelected, setReportSelected, setOpenErrorModel } =
    useTabXemBaoCao();

  async function handleDoubleClick(row: ReportQueue_List) {
    if (!row) return;
    if (row.status !== "Pending") {
      if (row.status === "Complete") {
        downloadReportSelected();
      } else {
        setOpenErrorModel(true);
      }
    }
  }

  return (
    <div className="w-full flex flex-col overflow-hidden flex-1 h-full">
      <DataTable
        columns={COLUMNS}
        data={reportsQueue || []}
        className="w-full h-full overflow-auto border"
        enablePaging={false}
        enableColumnFilter={true}
        onRowClick={(row) => {
          setReportSelected(row);
        }}
        onRowDoubleClick={handleDoubleClick}
        enableScrollTo={false}
        getRowClassName={(row) =>
          row === reportSelected ? "bg-amber-200" : ""
        }
      />
    </div>
  );
};

export default BaoCao;
