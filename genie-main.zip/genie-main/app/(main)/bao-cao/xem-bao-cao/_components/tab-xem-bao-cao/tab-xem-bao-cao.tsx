"use client";

import { notifyError, notifyWarning } from "@/app/lib/utils";
import { getErrorMessage } from "@/app/lib/utils/errorUtils";
import { useLoadingBaoCao } from "../../_contexts/loading-bao-cao-context";
import { useTabXemBaoCao } from "../../_contexts/tab-xem-bao-cao-context";
import { downloadReportInBrowser } from "../../_utils/download-report-in-browser";
import Action from "./action";
import BaoCao from "./bao-cao";
import ErrorModel from "./error-model";
import ThamSoModel from "./tham-so-model";
import { useFeedbackDialog } from "@/app/lib/feedback-dialog-provider";

const TabXemBaoCao = () => {
  const {
    reportSelected,
    openThamSoModel,
    setOpenThamSoModel,
    openErrorModel,
    setOpenErrorModel,
  } = useTabXemBaoCao();
  const { setLoadingBaoCao } = useLoadingBaoCao();
  const { alert } = useFeedbackDialog();

  async function downloadReportSelected() {
    if (!reportSelected) return;
    try {
      setLoadingBaoCao(true);
      if (reportSelected.reportType?.toLocaleLowerCase() === "repx") {
        // đây là định dạng được tạo bởi app, coi thêm https://filext.com/file-extension/REPX
        notifyWarning(
          "Định dạng này được tạo bởi XtraReports Developer Express",
        );
      } else {
        const { isDone, isError } = await downloadReportInBrowser({
          queueSeq: String(reportSelected.seq),
        });
        if (!isDone) {
          await alert({
            title: "",
            content: "Chưa nhận được dữ liệu từ máy chủ, vui lòng thử lại.",
          });
          return;
        }
        if (isError) {
          await alert({
            title: "",
            content: "Có lỗi xảy ra, nhấn nút Xem lỗi để biết chi tiết.",
          });
          return;
        }
      }
    } catch (error) {
      console.log(error);
      notifyError(getErrorMessage(error));
    } finally {
      setLoadingBaoCao(false);
    }
  }

  return (
    <>
      <div className="w-full flex flex-col overflow-hidden flex-1 overflow-y-hidden h-full">
        <section className="flex flex-col w-full flex-1 overflow-hidden">
          <BaoCao downloadReportSelected={downloadReportSelected} />
        </section>
        <section className="flex flex-col w-full overflow-hidden">
          <Action downloadReportSelected={downloadReportSelected} />
        </section>
      </div>
      {openThamSoModel && (
        <ThamSoModel
          onClose={() => setOpenThamSoModel(false)}
          seq={reportSelected?.seq || 0}
        />
      )}
      {openErrorModel && reportSelected && (
        <ErrorModel
          onClose={() => setOpenErrorModel(false)}
          seq={reportSelected?.seq || 0}
        />
      )}
    </>
  );
};

export default TabXemBaoCao;
