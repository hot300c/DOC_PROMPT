import { notifyError } from "@/app/lib/utils";
import { getErrorMessage } from "@/app/lib/utils/errorUtils";
import { Button } from "@/components/ui/button";
import {
  DataTable,
  DataTableColumnHeaderSort,
} from "@/components/ui/dataTable";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { ColumnDef } from "@tanstack/react-table";
import React, { useEffect } from "react";
import { useLoadingBaoCao } from "../../_contexts/loading-bao-cao-context";
import {
  ReportQueue_Get,
  ReportQueue_Get_Params,
} from "../../_utils/definitions/xem-bao-cao.dto";
import { ws_ReportQueue_Get } from "../../_utils/services/xem-bao-cao.api";

const REPORT_PARAMS_COLUMN: ColumnDef<ReportQueue_Get_Params>[] = [
  {
    id: "name",
    accessorKey: "name",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Name" />
    ),
    cell: ({ row }) => (
      <p className="line-clamp-1" title={row.getValue("name")}>
        {row.getValue("name")}
      </p>
    ),
  },
  {
    id: "value",
    accessorKey: "value",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Value" />
    ),
    cell: ({ row }) => (
      <p className="line-clamp-1" title={row.getValue("value")}>
        {row.getValue("value")}
      </p>
    ),
  },
];

function safeSQL(input: string): string {
  return String(input)
    .replace(/'/g, "''") // Chuyển đổi dấu nháy đơn thành hai dấu nháy đơn để tránh SQL Injection
    .replace(/--/g, "") // Loại bỏ dấu "--" để tránh comment injection
    .replace(/;/g, ""); // Loại bỏ dấu ";" để tránh thực thi nhiều lệnh SQL
}

function showCommandSqlForView(
  reportDataProc: string,
  reportParams: string,
): string {
  let text = reportDataProc + " ";
  if (reportParams === "") return text;
  const jObject = JSON.parse(reportParams);
  let text2 = "";
  for (const [key, value] of Object.entries(jObject)) {
    text += `${text2}@${key}='${safeSQL(value as string)}'`;
    text2 = ", ";
  }
  return text;
}

function populateReportParams(reportParams: string) {
  const jObject = JSON.parse(reportParams);
  const newReportParams: ReportQueue_Get_Params[] = [];
  for (const [key, value] of Object.entries(jObject)) {
    newReportParams.push({
      name: key,
      value: value ? String(value) : "",
    } as ReportQueue_Get_Params);
  }
  return newReportParams;
}

interface ThamSoModelProps {
  seq: number;
  onClose: () => void;
}

const ThamSoModel: React.FC<ThamSoModelProps> = ({ seq, onClose }) => {
  const [report, setReport] = React.useState<ReportQueue_Get | null>(null);
  const { setLoadingBaoCao } = useLoadingBaoCao();
  const [reportParams, setReportParams] = React.useState<
    ReportQueue_Get_Params[]
  >([]);

  useEffect(() => {
    async function init() {
      try {
        setLoadingBaoCao(true);
        const reportResult = await ws_ReportQueue_Get(String(seq));
        setReport(reportResult);
        const newReportParams = populateReportParams(
          reportResult?.reportParams || "",
        );
        setReportParams(newReportParams);
      } catch (error) {
        console.log(error);
        notifyError(getErrorMessage(error));
      } finally {
        setLoadingBaoCao(false);
      }
    }
    void init();
  }, [seq, setLoadingBaoCao]);

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="bg-white max-w-[600px] flex flex-col max-h-[800px]">
        <DialogHeader className="w-full">
          <DialogTitle className="text-lg">Tham số báo cáo</DialogTitle>
        </DialogHeader>

        <div className="flex-1 flex flex-col overflow-hidden space-y-2">
          <div className="grid grid-cols-12 gap-4">
            <Label className="col-span-2">ReportID</Label>
            <Input
              className="col-span-10"
              value={report?.reportID?.toString() || ""}
              readOnly
            ></Input>

            <Label className="col-span-2">rep_Data</Label>
            <Input
              className="col-span-10"
              value={report?.reportDataProc || ""}
              readOnly
            ></Input>

            <Label className="col-span-2">ProgID</Label>
            <Input
              className="col-span-10"
              value={report?.reportProgID || ""}
              readOnly
            ></Input>

            <Label className="col-span-2">Excepdata</Label>
            <Textarea
              className="col-span-10"
              value={showCommandSqlForView(
                report?.reportDataProc || "",
                report?.reportParams || "",
              )}
              readOnly
              rows={5}
            ></Textarea>
          </div>
          <div className="flex-1 flex flex-col overflow-hidden">
            <DataTable
              columns={REPORT_PARAMS_COLUMN}
              data={reportParams || []}
              className="w-full h-full overflow-auto border"
              enablePaging={false}
              enableColumnFilter={false}
            />
          </div>
        </div>

        <div className="mt-auto w-full flex items-center justify-end">
          <Button onClick={onClose} className="min-w-20">
            Đóng
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default ThamSoModel;
