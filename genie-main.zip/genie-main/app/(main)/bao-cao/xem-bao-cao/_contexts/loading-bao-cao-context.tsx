"use client";
import { ELoadingMessages } from "@/app/lib/enums";
import useLoading from "@/components/loading";
import { createContext, ReactNode, useContext, useRef } from "react";

interface LoadingBaoCaoContextType {
  setLoadingBaoCao: (loading: boolean) => void;
}

const LoadingBaoCaoContext = createContext<
  LoadingBaoCaoContextType | undefined
>(undefined);

export const LoadingBaoCaoProvider = ({
  children,
}: {
  children: ReactNode;
}) => {
  const { showLoading, hideLoading } = useLoading();
  const loadingIdRef = useRef<string>("");
  const loadingCountRef = useRef<number>(0);

  const setLoadingBaoCao = (loading: boolean) => {
    if (loading) {
      if (loadingCountRef.current === 0) {
        if (loadingIdRef.current) {
          hideLoading(loadingIdRef.current);
        }
        loadingIdRef.current = showLoading(ELoadingMessages.WAITING);
      }
      loadingCountRef.current += 1;
    } else {
      if (loadingCountRef.current > 0) {
        loadingCountRef.current -= 1;
        if (loadingCountRef.current === 0) {
          setTimeout(() => {
            hideLoading(loadingIdRef.current);
            loadingIdRef.current = "";
          });
        }
      }
    }
  };

  return (
    <LoadingBaoCaoContext.Provider value={{ setLoadingBaoCao }}>
      {children}
    </LoadingBaoCaoContext.Provider>
  );
};

export const useLoadingBaoCao = (): LoadingBaoCaoContextType => {
  const context = useContext(LoadingBaoCaoContext);
  if (context === undefined) {
    throw new Error(
      "useLoadingBaoCao must be used within a LoadingBaoCaoProvider",
    );
  }
  return context;
};
