"use client";

import { createContext, useContext, useEffect, useState } from "react";
import {
  ChuyenMuc,
  L_Reports_ListByUser,
} from "../_utils/definitions/xem-bao-cao.dto";
import populateCategories from "../_utils/populate-categories";

type TabInTrucTiepContextType = {
  reportsByUser: L_Reports_ListByUser[];
  setReportsByUser: (data: L_Reports_ListByUser[]) => void;
  chuyenMucs: ChuyenMuc[];
  chuyenMucSelected: ChuyenMuc | undefined;
  setChuyenMucSelected: (data: ChuyenMuc | undefined) => void;
  reportSelected: L_Reports_ListByUser | undefined;
  setReportSelected: (data: L_Reports_ListByUser | undefined) => void;
  facId: string;
  userId: string;
};

const TabInTrucTiepContext = createContext<
  TabInTrucTiepContextType | undefined
>(undefined);

export const useTabInTrucTiep = () => {
  const context = useContext(TabInTrucTiepContext);
  if (!context) {
    throw new Error(
      "useTabInTrucTiep must be used within a TabInTrucTiepProvider",
    );
  }
  return context;
};

interface TabInTrucTiepProviderProps {
  children: React.ReactNode;
  facId: string;
  userId: string;
  reportsByUser: L_Reports_ListByUser[];
}

export const TabInTrucTiepProvider: React.FC<TabInTrucTiepProviderProps> = ({
  facId,
  userId,
  reportsByUser: reportsByUserInit,
  children,
}) => {
  const [reportsByUser, setReportsByUser] = useState<L_Reports_ListByUser[]>(
    reportsByUserInit || [],
  );
  const [chuyenMucs, setChuyenMucs] = useState<ChuyenMuc[]>([]);
  const [chuyenMucSelected, setChuyenMucSelected] = useState<
    ChuyenMuc | undefined
  >();
  const [reportSelected, setReportSelected] = useState<L_Reports_ListByUser>();

  useEffect(() => {
    const uniqueChuyenMucs = populateCategories({ reportsByUser });
    setChuyenMucs(uniqueChuyenMucs);
    if (uniqueChuyenMucs.length === 0) {
      setChuyenMucSelected(undefined);
    } else {
      setChuyenMucSelected(uniqueChuyenMucs[0]);
    }
  }, [reportsByUser]);

  useEffect(() => {
    if (chuyenMucSelected) {
      let reportNew = chuyenMucSelected.reports[0];
      if (chuyenMucSelected.name === "All" && chuyenMucs.length >= 1) {
        reportNew = chuyenMucs[1]?.reports[0];
      }
      setReportSelected(reportNew);
    } else {
      setReportSelected(undefined);
    }
  }, [chuyenMucSelected, chuyenMucs]);

  return (
    <TabInTrucTiepContext.Provider
      value={{
        reportsByUser,
        setReportsByUser,
        chuyenMucs,
        chuyenMucSelected,
        setChuyenMucSelected,
        reportSelected,
        setReportSelected,
        facId,
        userId,
      }}
    >
      {children}
    </TabInTrucTiepContext.Provider>
  );
};
