"use client";

import { notifyError } from "@/app/lib/utils";
import { getErrorMessage } from "@/app/lib/utils/errorUtils";
import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useState,
} from "react";
import { ReportQueue_List } from "../_utils/definitions/xem-bao-cao.dto";
import { ws_ReportQueue_List } from "../_utils/services/xem-bao-cao.api";
import { useLoadingBaoCao } from "./loading-bao-cao-context";

type TabXemBaoCaoContextType = {
  reportsQueue: ReportQueue_List[];
  setReportsQueue: (data: ReportQueue_List[]) => void;
  reportSelected: ReportQueue_List | undefined;
  setReportSelected: (data: ReportQueue_List | undefined) => void;
  openThamSoModel: boolean;
  setOpenThamSoModel: (data: boolean) => void;
  openErrorModel: boolean;
  setOpenErrorModel: (data: boolean) => void;
  refresh: () => Promise<void>;
  facId: string;
  userId: string;
};

const TabXemBaoCaoContext = createContext<TabXemBaoCaoContextType | undefined>(
  undefined,
);

export const useTabXemBaoCao = () => {
  const context = useContext(TabXemBaoCaoContext);
  if (!context) {
    throw new Error(
      "useTabXemBaoCao must be used within a TabXemBaoCaoProvider",
    );
  }
  return context;
};

interface TabXemBaoCaoProviderProps {
  children: React.ReactNode;
  facId: string;
  userId: string;
  isCurrTab: boolean;
}

export const TabXemBaoCaoProvider: React.FC<TabXemBaoCaoProviderProps> = ({
  facId,
  userId,
  isCurrTab,
  children,
}) => {
  const [reportsQueue, setReportsQueue] = useState<ReportQueue_List[]>([]);
  const [reportSelected, setReportSelected] = useState<ReportQueue_List>();
  const [openThamSoModel, setOpenThamSoModel] = useState(false);
  const [openErrorModel, setOpenErrorModel] = useState(false);
  const { setLoadingBaoCao } = useLoadingBaoCao();

  const refresh = useCallback(async () => {
    const reportsQueueNew = await ws_ReportQueue_List(facId);
    setReportsQueue(reportsQueueNew);
  }, [facId]);

  useEffect(() => {
    if (!reportSelected) {
      if (reportsQueue.length > 0) {
        setReportSelected(reportsQueue[0]);
      }
    }
  }, [reportsQueue, reportSelected]);

  useEffect(() => {
    if (isCurrTab) {
      async function loadDataInit() {
        try {
          setLoadingBaoCao(true);
          await refresh();
        } catch (error) {
          console.log(error);
          notifyError(getErrorMessage(error));
        } finally {
          setLoadingBaoCao(false);
        }
      }
      void loadDataInit();
    }
  }, [isCurrTab, refresh, setLoadingBaoCao]);

  return (
    <TabXemBaoCaoContext.Provider
      value={{
        reportsQueue,
        setReportsQueue,
        reportSelected,
        setReportSelected,
        openThamSoModel,
        setOpenThamSoModel,
        openErrorModel,
        setOpenErrorModel,
        refresh,
        facId,
        userId,
      }}
    >
      {children}
    </TabXemBaoCaoContext.Provider>
  );
};
