import { ChuyenMuc, L_Reports_ListByUser } from "./definitions/xem-bao-cao.dto";

export default function populateCategories({
  reportsByUser,
}: {
  reportsByUser: L_Reports_ListByUser[];
}): ChuyenMuc[] {
  const reportsAllow = reportsByUser
    .filter((r) =>
      REPORTS_MATCHING_QAS_PARAM_ALLOW.some((a) => a.reportIds.includes(r.id)),
    )
    .map((item) => {
      if (item.category.includes("QAPAY")) {
        return {
          ...item,
          name: item.name.replace(/QAPAY/gi, "VNVC Point"),
          category: item.category.replace(/QAPAY/gi, "VNVC Point"),
          description: item.description.replace(/QAPAY/gi, "VNVC Point"),
        };
      }

      return item;
    });

  const categorizedChuyenMucs = reportsAllow.reduce(
    (acc, report) => {
      const category = report.category.toLowerCase();
      if (!acc[category]) {
        acc[category] = {
          name: report.category,
          reports: [],
        };
      }
      acc[category].reports.push(report);
      return acc;
    },
    {} as { [category: string]: ChuyenMuc },
  );
  const result = [
    {
      name: "All",
      reports: reportsAllow.map((r) => r),
    },
    ...Object.values(categorizedChuyenMucs).sort((a, b) =>
      a.name.localeCompare(b.name),
    ),
  ];
  return result;
}

// TODO bổ sung các báo cáo đã có params matching giống như Qas vào đây (chú ý phân biệt hoa thường & check các báo cáo trước đó đúng tham số trước khi mở!)
type ReportsByCategory = {
  "Báo cáo hệ số mũi tiêm trong ngày": "Báo cáo hệ số mũi tiêm trong ngày";
  "Khám bệnh":
    | "BÁO CÁO KHÁCH HÀNG TIÊM VẮC XIN UỐN VÁN THEO CƠ SỞ"
    | "Báo cáo các trường hợp phản ứng thông thường sau tiêm chủng"
    | "Báo cáo theo dõi tiêm vaccin dại"
    | "Thống kê danh sách bệnh nhân có nhóm bệnh/ vaccine"
    | "BÁO CÁO CÁC TRƯỜNG HỢP TAI BIẾN NẶNG SAU TIÊM CHỦNG";
  Kho:
    | "Báo cáo xuất vaccine - vật tư tại phòng tiêm"
    | "Quản lý vaccine - vật tư tại phòng tiêm"
    | "Báo cáo tồn kho toàn hệ thống"
    | "Thẻ kho"
    | "Thẻ kho(excel)"
    | "báo cáo xuất vaccine trung tâm"
    | "Thẻ kho phòng tiêm"
    | "Báo cáo tồn kho"
    | "Báo cáo số mũi tiêm thực tế"
    | "Báo cáo tình hình sử dụng vaccine tiêm chủng dịch vụ"
    | "Báo cáo tồn kho theo ngày"
    | "Báo cáo tồn kho theo ngày (theo loại SP)"
    | "Báo cáo xuất vaccine - vật tư tại phòng tiêm theo độ tuổi"
    | "Báo cáo xuất kho hàng tháng"
    | "Báo cáo nhập kho hàng tháng"
    | "Báo cáo nhập xuất tồn không hiện cột thành tiền (Excel)"
    | "Báo cáo dự trù vaccine trung tâm"
    | "Báo cáo nhập xuất tồn (Excel) Chọn kho"
    | "Báo cáo tồn kho theo hạn dùng"
    | "Báo cáo chi tiết xuất kho theo sản phẩm"
    | "Sổ chi tiết nhập hàng"
    | "THEO DÕI TỒN KHO THEO CƠ SỞ"
    | "BÁO CÁO THAY ĐỔI SỐ LƯỢNG DỰ TRÙ";
  "Báo cáo kho": "Báo cáo tồn kho vaccine trung tâm";
  "Thanh toán":
    | "Báo cáo thu ngân"
    | "DANH SÁCH KHÁCH HÀNG MUA LẺ ĐẶT TRƯỚC"
    | "DANH SÁCH KHÁCH HÀNG MUA LẺ ĐẶT TRƯỚC THEO TRUNG TÂM"
    | "Danh Sách Mũi Hợp Đồng"
    | "Báo cáo danh sách số lượng tiêm thực tế"
    | "Báo cáo chi tiết doanh thu"
    | "báo cáo doanh thu"
    | "Báo cáo doanh thu"
    | "Báo cáo theo dõi doanh thu gói còn phải thực hiện"
    | "Báo cáo thu ngân theo ca"
    | "DANH SÁCH KHÁCH HÀNG MUA LẺ ĐẶT TRƯỚC"
    | "Danh sách khách tiêm trễ"
    | "Danh sách khách hàng mua gói"
    | "Báo cáo thu ngân V2"
    | "Báo cáo tổng hợp công nợ phải thu theo hợp đồng"
    | "Danh Sách Hợp Đồng"
    | "Báo cáo thu ngân Cửa Hàng"
    | "Báo cáo chi tiết doanh thu Cửa Hàng";
  "Thanh Toán": "Báo cáo thuốc hết date, cận date";
  "Báo cáo":
    | "Báo Cáo Danh Sách Khách Hẹn Tiêm"
    | "thống kê phiếu xuất thực tế tại phòng tiêm"
    | "Báo Cáo Tổng Hợp Vaccine Dại"
    | "DANH SÁCH KHÁCH HÀNG MỚI"
    | " Báo cáo danh sách mũi của khách hàng"
    | "Báo cáo danh sách hợp đồng sắp hết hạn"
    | "Theo dõi các trường hợp phản ứng sau tiêm chủng";
  "Tiếp nhận": "Báo cáo danh sách đổi mũi";
  "Báo cáo hệ số mũi tiêm theo bác sĩ chỉ định": "Báo cáo hệ số mũi tiêm theo bác sĩ chỉ định";
  "Báo cáo hệ số mũi tiêm theo bác sĩ có hệ số tương ứng": "Báo cáo hệ số mũi tiêm theo bác sĩ có hệ số tương ứng";
  "Danh sách KH đã tiêm - Báo cáo Sở Y Tế": "Danh sách KH đã tiêm - Báo cáo Sở Y Tế";
  "Báo cáo hệ số mũi tiêm theo ngày có hệ số tương ứng": "Báo cáo hệ số mũi tiêm theo ngày có hệ số tương ứng";
  "Báo cáo số lượng mũi tiêm theo vaccine, nhóm bệnh": "Báo cáo số lượng mũi tiêm theo vaccine, nhóm bệnh";
  QAPAY:
    | "Báo cáo chi tiết ngày tài khoản QApay"
    | "Báo cáo số dư tài khoản QApay";
};
type ReportsCategory = keyof ReportsByCategory;
const REPORTS_MATCHING_QAS_PARAM_ALLOW: {
  category: ReportsCategory;
  name: ReportsByCategory[ReportsCategory];
  reportIds: string[];
}[] = [
  // 0
  {
    category: "Báo cáo hệ số mũi tiêm trong ngày",
    name: "Báo cáo hệ số mũi tiêm trong ngày",
    reportIds: ["ddd11ee4-c702-47d8-aa52-cbb30072e7a2"],
  },
  {
    category: "Khám bệnh",
    name: "BÁO CÁO KHÁCH HÀNG TIÊM VẮC XIN UỐN VÁN THEO CƠ SỞ",
    reportIds: ["45df05ab-3840-45f9-ba28-00bc1dc10014"],
  },
  {
    category: "Kho",
    name: "Báo cáo xuất vaccine - vật tư tại phòng tiêm",
    reportIds: ["23cc2df8-7034-4675-babb-395c0b37bbd0"],
  },
  {
    category: "Kho",
    name: "Quản lý vaccine - vật tư tại phòng tiêm",
    reportIds: ["f5862f0f-7725-4f87-9000-96659bda48d9"],
  },
  {
    category: "Thanh toán",
    name: "Báo cáo thu ngân",
    reportIds: ["44025e63-2a48-4bf6-b3cc-0475c724b737"],
  },
  {
    category: "Thanh Toán",
    name: "Báo cáo thuốc hết date, cận date",
    reportIds: ["67421130-e847-4575-9178-672cd7ed69c2"],
  },
  {
    category: "Thanh toán",
    name: "DANH SÁCH KHÁCH HÀNG MUA LẺ ĐẶT TRƯỚC",
    reportIds: ["f9cb1eb9-f412-4e00-bbc5-80f1bd0f2a00"],
  },
  {
    category: "Thanh toán",
    name: "DANH SÁCH KHÁCH HÀNG MUA LẺ ĐẶT TRƯỚC THEO TRUNG TÂM",
    reportIds: ["0c36ddec-8723-4bc9-9fa9-01e1cb410398"],
  },
  {
    category: "Thanh toán",
    name: "Danh Sách Mũi Hợp Đồng",
    reportIds: ["5e5a8095-673b-4c42-917a-2ebbd7453563"],
  },
  // 1
  {
    category: "Báo cáo",
    name: "Báo Cáo Danh Sách Khách Hẹn Tiêm",
    reportIds: ["47014f13-3506-4905-ae32-9576e684b8b4"],
  },
  {
    category: "Kho",
    name: "Báo cáo tồn kho toàn hệ thống",
    reportIds: ["cba98bcb-4676-4cb9-bd50-ed0776c8fb77"],
  },
  {
    category: "Kho",
    name: "Thẻ kho", // 2 cái trong đó 1 cái app qas chưa coi được là Thẻ kho có giá tiền (rep_TheKhoThanhTien)
    reportIds: [
      "af079759-3ac0-4b0e-b17e-341ea387ca3c",
      "08b5444f-d6bf-4c3d-bf40-53e1c09bd9ae",
    ],
  },
  // {
  //   category: "Kho",
  //   name: "Thẻ kho(excel)", // 2 cái cả 2 cái app qas chưa coi được nên comment lại: Mô tả chi tiết thẻ kho | Thành Tiền
  // },
  {
    category: "Thanh toán",
    name: "Báo cáo chi tiết doanh thu", // 2 cái trong đó 1 cái app qas chưa coi được là Báo cáo chi tiết doanh thu (rep_BaoCaoChiTietDoanhThuDinhVu)
    reportIds: ["db41a7e0-14e3-4e58-8d7b-108a1858f84e"],
  },
  {
    category: "Thanh toán",
    name: "báo cáo doanh thu",
    reportIds: ["15ba235d-08f5-44c6-81d3-1fe240e224c1"],
  },
  {
    category: "Thanh toán",
    name: "Báo cáo theo dõi doanh thu gói còn phải thực hiện",
    reportIds: ["9dbd8843-18a9-4277-bf1a-e4a32232c79e"],
  },
  // ĐDV
  {
    category: "Báo cáo",
    name: "thống kê phiếu xuất thực tế tại phòng tiêm",
    reportIds: ["57deb2b9-c972-4421-a53b-c925b840c5cf"],
  },
  {
    category: "Khám bệnh",
    name: "Báo cáo các trường hợp phản ứng thông thường sau tiêm chủng",
    reportIds: ["d1191d13-39f8-4a80-bb0e-e5f26bd95dd0"],
  },
  {
    category: "Thanh toán",
    name: "Báo cáo danh sách số lượng tiêm thực tế",
    reportIds: ["c28212fa-dd8a-4196-bf53-bdc72f1489f6"],
  },
  {
    category: "Kho",
    name: "báo cáo xuất vaccine trung tâm",
    reportIds: ["8c776344-d948-4bef-bc77-02c93c6cb863"],
  },
  {
    category: "Kho",
    name: "Thẻ kho phòng tiêm",
    reportIds: ["ab7f2b3a-ca5c-484e-988d-46201b0c39d8"],
  },
  {
    category: "Kho",
    name: "Báo cáo tồn kho",
    reportIds: ["4848591f-e962-4821-bbe4-bc58b3b39b0b"],
  },
  {
    category: "Kho",
    name: "Báo cáo số mũi tiêm thực tế",
    reportIds: ["a6cb7207-3e53-45d9-9461-c03ece23ef47"],
  },
  {
    category: "Kho",
    name: "Báo cáo tình hình sử dụng vaccine tiêm chủng dịch vụ",
    reportIds: ["3e39bafe-6a03-4b30-99a4-d6710f328b45"],
  },
  // {
  //   category: "Kho",
  //   name: "Sổ kho", // app qas test chưa coi được
  // },
  // {
  //   category: "Kho",
  //   name: "Báo cáo nhập xuất tồn", // app qas test chưa coi được
  // },
  // ĐDT
  {
    category: "Báo cáo",
    name: "Báo Cáo Tổng Hợp Vaccine Dại",
    reportIds: ["544a9243-0a5c-4259-9be3-2dbdf5a99705"],
  },
  {
    category: "Khám bệnh",
    name: "Báo cáo theo dõi tiêm vaccin dại",
    reportIds: ["a0417f4f-1365-4f92-9ea9-79e3e3e6c7b1"],
  },
  {
    category: "Kho",
    name: "Báo cáo tồn kho theo ngày",
    reportIds: ["d47f855a-51fb-4858-bf7e-30c02ca5518c"],
  },
  {
    category: "Kho",
    name: "Báo cáo tồn kho theo ngày (theo loại SP)",
    reportIds: ["058fb780-8cf3-41d4-aa74-357f72fa4b3a"],
  },
  // TN
  {
    category: "Tiếp nhận",
    name: "Báo cáo danh sách đổi mũi",
    reportIds: ["e57c003a-b578-4821-b6c5-b348a59c7605"],
  },
  // Thanh toán
  {
    category: "Thanh toán",
    name: "Báo cáo thu ngân theo ca",
    reportIds: ["95fdcf44-2913-44e9-b933-016e2304032a"],
  },
  // KT
  {
    category: "Báo cáo",
    name: "DANH SÁCH KHÁCH HÀNG MỚI",
    reportIds: ["afeb034c-93a0-413e-8d1e-5f9a4f74ec2d"],
  },
  {
    category: "Kho",
    name: "Báo cáo xuất vaccine - vật tư tại phòng tiêm theo độ tuổi",
    reportIds: ["4f68a39e-b281-4860-9f38-43b81fe27ea0"],
  },
  {
    category: "Thanh toán",
    name: "DANH SÁCH KHÁCH HÀNG MUA LẺ ĐẶT TRƯỚC",
    reportIds: ["f9cb1eb9-f412-4e00-bbc5-80f1bd0f2a00"],
  },
  {
    category: "Báo cáo kho",
    name: "Báo cáo tồn kho vaccine trung tâm", // service tạo bc chậm do dữ liệu nhiều
    reportIds: ["913827d8-0d3f-47f5-b0b0-0b5746506777"],
  },
  {
    category: "Báo cáo hệ số mũi tiêm theo bác sĩ chỉ định",
    name: "Báo cáo hệ số mũi tiêm theo bác sĩ chỉ định",
    reportIds: ["e7b04f6d-9518-4776-b1b0-6f7c5e4544c8"],
  },
  {
    category: "Báo cáo hệ số mũi tiêm theo bác sĩ có hệ số tương ứng",
    name: "Báo cáo hệ số mũi tiêm theo bác sĩ có hệ số tương ứng",
    reportIds: ["6bf00b3d-3aaa-479c-be9e-4a3e2272bcf8"],
  },
  {
    category: "Danh sách KH đã tiêm - Báo cáo Sở Y Tế",
    name: "Danh sách KH đã tiêm - Báo cáo Sở Y Tế",
    reportIds: ["a2387190-2a1f-4db2-aed7-2a8daa4fb770"],
  },
  {
    category: "Kho",
    name: "Báo cáo tồn kho theo hạn dùng",
    reportIds: ["2ed96328-cf60-4180-b4eb-dcd647b7c215"],
  },
  {
    category: "QAPAY",
    name: "Báo cáo chi tiết ngày tài khoản QApay",
    reportIds: ["2e8c2ebf-805e-41aa-aa46-cfdb95e63ded"],
  },
  {
    category: "QAPAY",
    name: "Báo cáo số dư tài khoản QApay",
    reportIds: ["d351839e-3fd5-4058-8ba1-ce19e22f519e"],
  },
  {
    category: "Thanh toán",
    name: "Danh sách khách hàng mua gói",
    reportIds: ["02dec13f-221a-40be-bf95-6fc9f3f5c966"],
  },
  {
    category: "Thanh toán",
    name: "Báo cáo thu ngân V2",
    reportIds: ["a7035149-f83b-4528-9d26-6a8679cad016"],
  },
  {
    category: "Thanh toán",
    name: "Báo cáo tổng hợp công nợ phải thu theo hợp đồng",
    reportIds: ["2af5c7e8-ff63-4e35-ad66-55f9f5ae874d"],
  },
  {
    category: "Thanh toán",
    name: "Danh Sách Hợp Đồng",
    reportIds: ["7d2a242a-4770-4924-98c7-4f472e55d64a"],
  },
  // Kho
  {
    category: "Kho",
    name: "Báo cáo xuất kho hàng tháng",
    reportIds: ["39a8f135-f91d-4a66-8856-b03791a7e84e"],
  },
  {
    category: "Kho",
    name: "Báo cáo nhập kho hàng tháng",
    reportIds: ["39a8f135-f91d-4a66-8856-b03791a7e84d"],
  },
  // {
  //   category: "Kho",
  //   name: "Báo cáo xuất kho tại phòng tiêm", // app qas test chưa coi được
  // },
  {
    category: "Kho",
    name: "Báo cáo chi tiết xuất kho theo sản phẩm",
    reportIds: ["fd27c413-db68-4feb-8d3f-440fa3fa1c11"],
  },
  {
    category: "Kho",
    name: "Sổ chi tiết nhập hàng",
    reportIds: ["896cdc16-6034-4b11-9cf9-78a6f7082a72"],
  },
  {
    category: "Kho",
    name: "THEO DÕI TỒN KHO THEO CƠ SỞ",
    reportIds: ["0ba662e9-c957-4126-a546-a480c0f19366"],
  },
  {
    category: "Kho",
    name: "BÁO CÁO THAY ĐỔI SỐ LƯỢNG DỰ TRÙ",
    reportIds: ["fd61587c-fb8c-4442-a45e-cfb6ece576c0"],
  },
  // GĐTT
  {
    category: "Báo cáo hệ số mũi tiêm theo ngày có hệ số tương ứng",
    name: "Báo cáo hệ số mũi tiêm theo ngày có hệ số tương ứng",
    reportIds: ["9814e093-0014-4d3e-adf0-d8e2fe464edd"],
  },
  {
    category: "Thanh toán",
    name: "Danh sách khách tiêm trễ",
    reportIds: ["7374f5f8-869c-4a35-a2e6-cee2a57efdcf"],
  },
  {
    category: "Báo cáo",
    name: " Báo cáo danh sách mũi của khách hàng",
    reportIds: ["24ffc95f-a16a-4a6a-8b2c-a6fa57c95601"],
  },
  {
    category: "Khám bệnh",
    name: "Thống kê danh sách bệnh nhân có nhóm bệnh/ vaccine",
    reportIds: ["2d8f4b7f-4c05-4c4a-8663-8ae68cbe5e2b"],
  },
  {
    category: "Kho",
    name: "Báo cáo nhập xuất tồn không hiện cột thành tiền (Excel)",
    reportIds: ["55ab8dd5-8f98-4690-95da-7e0d72d31fdc"],
  },
  {
    category: "Khám bệnh",
    name: "BÁO CÁO CÁC TRƯỜNG HỢP TAI BIẾN NẶNG SAU TIÊM CHỦNG",
    reportIds: ["d3c8a832-49aa-433a-aebc-67cd70bdecee"],
  },
  {
    category: "Kho",
    name: "Báo cáo dự trù vaccine trung tâm",
    reportIds: ["f1990bd6-a66e-44b0-a8c5-5d20850faa7f"],
  },
  {
    category: "Kho",
    name: "Báo cáo nhập xuất tồn (Excel) Chọn kho",
    reportIds: ["d74fcd47-49e4-4967-9804-5627d1452215"],
  },
  {
    category: "Báo cáo số lượng mũi tiêm theo vaccine, nhóm bệnh",
    name: "Báo cáo số lượng mũi tiêm theo vaccine, nhóm bệnh",
    reportIds: ["fe97e800-8810-483c-a525-2287005ebaff"],
  },
  {
    category: "Báo cáo",
    name: "Báo cáo danh sách hợp đồng sắp hết hạn",
    reportIds: ["da048bc7-c7b1-4e38-afa8-012ea55800d5"],
  },
  // BC
  {
    category: "Báo cáo",
    name: "Theo dõi các trường hợp phản ứng sau tiêm chủng",
    reportIds: ["3cb6cd68-2a68-4323-8b21-c5cba68621a1"],
  },
  // CH
  {
    category: "Thanh toán",
    name: "Báo cáo thu ngân Cửa Hàng",
    reportIds: ["1a244571-5d18-48d0-aa87-e1263fb3a7fe"],
  },
  {
    category: "Thanh toán",
    name: "Báo cáo chi tiết doanh thu Cửa Hàng",
    reportIds: ["85a7772e-56e9-4525-8e41-24758c78de0b"],
  },
];
