import { SequenceRequest } from "@/app/lib/definitions/setting";
import * as httpService from "@/app/lib/network/http";
import { executeTransaction } from "@/app/lib/services/system";
import { isString } from "lodash";
import {
  L_ReportParams_List,
  L_ReportParams_List_Option,
  L_Reports_ListByUser,
  ReportErrors_Get,
  ReportQueue_Get,
  ReportQueue_List,
} from "../definitions/xem-bao-cao.dto";

export async function ws_L_Reports_ListByUser(
  facId: string,
): Promise<L_Reports_ListByUser[]> {
  const response = await httpService.post("/DataAccess", [
    {
      category: "Reports",
      command: "ws_L_Reports_ListByUser",
      parameters: {
        FacID: facId,
      },
    },
  ]);

  return response.data.table;
}

export async function ws_L_ReportParams_List(
  reportId: string,
): Promise<L_ReportParams_List[]> {
  const response = await httpService.post("/DataAccess", [
    {
      category: "Reports",
      command: "ws_L_ReportParams_List",
      parameters: {
        ReportID: reportId,
      },
    },
  ]);

  return response.data.table;
}

export async function getDataFromReport({
  report,
  updateRequest,
}: {
  report: L_ReportParams_List;
  updateRequest?: (
    request: SequenceRequest,
    variant: {
      option: L_ReportParams_List_Option;
      indexRequest: number;
    },
  ) => void;
}): Promise<any> {
  const option = JSON.parse(
    report.options || "{}",
  ) as L_ReportParams_List_Option;
  if (option.SP) {
    // source C#: https://git.vnvc.info/vnvc-qas/qas-app/-/blob/a1ee8fb73bba286279af5efa0a4ce38182af2a16/QA.ReportParams/ReportParamTypes/GridLookUpVer2.cs#L96
    let sps = option.SP;
    const requests = [] as SequenceRequest[];
    if (isString(sps)) {
      sps = [sps];
    }
    sps.forEach((sp, index) => {
      const arrSp = sp.split("..");
      const category = arrSp[0];
      const command = arrSp[1];
      if (!category || !command) {
        throw new Error(
          "callApiFromOption lỗi cấu hình: " + JSON.stringify(option),
        );
      }
      const request = {
        category: category,
        command: command,
      } as SequenceRequest;
      if (updateRequest) {
        updateRequest(request, { option, indexRequest: index });
      }
      requests.push(request);
    });
    const response = await executeTransaction({ request: requests });
    return response;
  } else if (option.Items) {
    // source C#: https://git.vnvc.info/vnvc-qas/qas-app/-/blob/a1ee8fb73bba286279af5efa0a4ce38182af2a16/QA.ReportParams/ReportParamTypes/Dropdown.cs#L110
    return {
      table: option.Items.map((item, index) => ({ id: item, text: item })),
    };
  }
  return null;
}

export async function ws_ReportQueue_Push({
  reportId,
  reportParams,
  userId,
  facID,
}: {
  reportId: string;
  reportParams: string;
  userId: string;
  facID: string;
}): Promise<string> {
  const response = await httpService.post("/DataAccess", [
    {
      category: "Reports",
      command: "ws_ReportQueue_Push",
      parameters: {
        ReportID: reportId,
        ReportParams: reportParams,
        UserID: userId,
        FacID: facID,
      },
    },
  ]);
  return (response.data.table.length > 0 && response.data.table[0]?.seq) || "";
}

export async function ws_ReportQueue_List(
  facId: string,
): Promise<ReportQueue_List[]> {
  const response = await httpService.post("/DataAccess", [
    {
      category: "Reports",
      command: "ws_ReportQueue_List",
      parameters: {
        FacID: facId,
      },
    },
  ]);
  return response.data.table;
}

export async function ws_ReportQueue_Resubmit(seq: string): Promise<void> {
  await httpService.post("/DataAccess", [
    {
      category: "Reports",
      command: "ws_ReportQueue_Resubmit",
      parameters: {
        Seq: seq,
      },
    },
  ]);
}

export async function ws_ReportQueue_Get(
  seq: string,
): Promise<ReportQueue_Get | null> {
  const response = await httpService.post("/DataAccess", [
    {
      category: "Reports",
      command: "ws_ReportQueue_Get",
      parameters: {
        Seq: seq,
      },
    },
  ]);
  return response.data.table.length > 0 ? response.data.table[0] : null;
}

export async function ws_ReportErrors_Get(
  seq: string,
): Promise<ReportErrors_Get | null> {
  const response = await httpService.post("/DataAccess", [
    {
      category: "Reports",
      command: "ws_ReportErrors_Get",
      parameters: {
        Seq: seq,
      },
    },
  ]);
  return response.data.table.length > 0 ? response.data.table[0] : null;
}
