export type L_Reports_ListByUser = {
  id: string;
  idNew?: string | null;
  category: string;
  name: string;
  caption: string;
  description: string;
  type: string;
  progId: string;
  dataProc: string;
  active: boolean;
  reportParamaterSample?: string;
  isScreen: boolean;
  isClient?: boolean | null;
  allowExcel?: boolean | null;
  typeSign: number;
  settings?: string | null;
  note?: string | null;
  createdOn?: string | null;
  createdBy?: string | null;
  highAvailability?: boolean | null;
};

export type ChuyenMuc = {
  name: string;
  reports: L_Reports_ListByUser[];
};

export type L_ReportParams_List = {
  reportId: string;
  index: number;
  name: string;
  caption: string;
  type: string;
  options: string;
  isSchedule: boolean;
};

export type L_ReportParams_List_Option = {
  SP?: string | string[];
  Group?: string;
  DefautParams?: string;
  FromDate?: string;
  ThruDate?: string;
  Items?: string[];
  AdvancedPaymentId?: string;
  CaseChronicDiseasesId?: string;
  FacID?: string;
  CardID?: string;
  Ca?: string;
};

export type ReportParamsValue = {
  name: string;
  caption: string;
  value: string | null;
  reportParams: L_ReportParams_List;
};

export type L_FacID_List = {
  id: string;
  text: string;
  parentID: string;
};

export type LoadComboStockName = {
  id: string;
  text: string;
  parentID: string;
  idValue: string;
};

export type L_FacIDNotAll_List = {
  id: string;
  text: string;
  facID: string;
};

export type List_FinaciUser_FacID = {
  id: string;
  idValue: string | null;
  text: string | null;
  parentID: string;
};

export type LoadCounterNameParentID = {
  id: number;
  idValue: number;
  text: string;
  parentID: string;
};

export type LoadProductV3 = {
  id: string;
  hospitalCode: string;
  text: string;
  parentID: string;
  formula: string | null;
  isCheckin: boolean;
  idValue: string;
  parentSecondID: number;
  uid: string | null;
};

export type L_FacID_List_Default = {
  id: string;
  text: string;
  parentID: string;
};

export type ReportQueue_List = {
  seq: number;
  status: string;
  category: string;
  caption: string;
  description: string;
  reportId: string | null;
  reportName: string;
  reportParams: string;
  reportType: string;
  createdOn: string;
  startedOn: string;
  completedOn: string;
  printedByName: string;
};

export type ReportQueue_Get = {
  seq: number;
  status: string;
  reportID: string | null;
  reportName: string;
  reportParams: string;
  reportType: string;
  reportProgID: string | null;
  reportDataCatalog: string | null;
  reportDataProc: string;
  createdOn: string;
  createdBy: string;
  startedOn: string;
  completedOn: string;
  isScreen: boolean;
};

export type ReportQueue_Get_Params = {
  name: string;
  value: string | null;
};

export type ReportErrors_Get = {
  queueSeq: number;
  facId: string | null;
  reportID: string;
  reportName: string;
  reportParams: string;
  reportType: string;
  reportProgID: string;
  reportDataProc: string;
  sql: string;
  message: string;
  createdDate: string;
};

export type DanhSachVaccineKhongNhanTin = {
  check: boolean;
  id: string;
  text: string;
};

export type LoadPhongTiem = {
  id: number;
  text: string;
  parentID: string;
};

export type LoadNhomBenh = {
  id: string;
  text: string;
};

export type LoadVaccineMaChung = {
  id: string;
  hospitalCode: string;
  text: string;
  nhomBenhID: string;
};

export type LoadComboLoaiSP = {
  id: string;
  text: string;
};

export type LoadComboStockNameV2 = {
  id: string;
  text: string;
  parentID: string;
  parentID1: string;
  idValue: string;
};

export type FacID_List_WithAll = {
  id: number;
  text: string;
  parentID: string;
};

export type L_InventoryStock_GetListByFacID = {
  id: string;
  text: string;
  facID: string;
  check: boolean;
  facName: string;
};

export type LoadComboLoaiSPV2 = {
  parentID: string;
  id: string;
  text: string;
};

export type LoadComboStockNameV3 = {
  id: string;
  text: string;
  parentID: string;
  parentID1: string;
  idValue: string;
};

export type L_FacID_List_WithAll_V2 = {
  id: string;
  text: string;
  parentID: string;
};

export type LoadProductTypeV1 = {
  uid: string;
  id: number;
  text: string;
  parentID: string;
  idValue: string;
  parentSecondID: number;
};

export type LoadProductTheoKhoV1 = {
  uid: string;
  id: number;
  hospitalCode: string;
  text: string;
  parentID: string;
  formula: string | null;
  isCheckin: boolean;
  idValue: string;
  parentSecondID: number;
  parentThirID: number;
};
