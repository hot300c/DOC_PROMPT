import { getReportOutput } from "@/app/lib/services/khamTruocTiemApi";
import { notifyError, sleep } from "@/app/lib/utils";

export const downloadReportInBrowser = async ({
  queueSeq,
}: {
  queueSeq: string;
}): Promise<{ isDone: boolean; isError: boolean }> => {
  const stopwatch = new Date().getTime();
  const timeout = 120000; // 120 seconds
  const interval = 5000; // 5 seconds
  const result = { isDone: false, isError: false };

  while (new Date().getTime() - stopwatch < timeout) {
    await sleep(interval);
    const response = await getReportOutput(queueSeq);
    if (!response) {
      notifyError("Error fetching report output.");
      result.isDone = true;
      break;
    }

    const dataTable = response.table;
    const dataRow = dataTable[0];
    if (dataRow) {
      const fileData = dataRow.fileData;
      const fileExtension = dataRow.fileExtension;
      let fileName = (dataRow.name || "")
        .trim()
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "")
        .replace(/đ/g, "d")
        .replace(/[^\w\s]/gi, "") // Remove special characters
        .replace(/\b\w/g, (char: string) => char.toUpperCase()) // Capitalize first letter of each word
        .replace(/\s+/g, "");
      fileName = fileName.includes("BaoCao")
        ? fileName.replace("Reports", "").replace("Report", "")
        : fileName.replace("Reports", "BaoCao").replace("Report", "BaoCao");
      fileName += dataRow.queueSeq;
      const now = new Date();
      const yyyymmddhh = `${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, "0")}${String(now.getDate()).padStart(2, "0")}${String(now.getHours()).padStart(2, "0")}${String(now.getMinutes()).padStart(2, "0")}`;
      fileName += "_" + yyyymmddhh;

      const byteCharacters = atob(fileData);
      const byteNumbers = Uint8Array.from(byteCharacters, (char) =>
        char.charCodeAt(0),
      );
      const file = new File([byteNumbers], fileName, {
        type: `application/${fileExtension}`,
      });
      const url = URL.createObjectURL(file);
      const a = document.createElement("a");
      a.href = url;
      a.download = `${fileName}.${fileExtension}`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      result.isDone = true;
      break;
    }

    if (response.table1.length > 0) {
      result.isError = true;
      result.isDone = true;
      break;
    }
  }
  return result;
};
