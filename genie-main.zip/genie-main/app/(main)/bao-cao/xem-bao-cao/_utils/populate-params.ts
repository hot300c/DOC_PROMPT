import { ParamType } from "./constants/param-type-constant";
import {
  L_ReportParams_List,
  ReportParamsValue,
} from "./definitions/xem-bao-cao.dto";

export default function populateParams(reportParams: L_ReportParams_List[]) {
  const paramsValue = [] as ReportParamsValue[];

  reportParams.forEach((param) => {
    let name = param.name;
    let caption = param.caption;

    switch (param.type) {
      case ParamType.CheckComboCaTuNgayDenNgayGroupByFacID:
        name = `FacID|FromDate|ThruDate|${param.name}`;
        caption = `Cơ sở|Từ ngày|Đến ngày|${param.caption}`;
        break;
      case ParamType.GridLookUpVerCheckBoxKho:
        name = "FacID||StockID";
        break;
      case ParamType.GridLookUpPickOneAllFacID:
        name = "FacID_HD|FacID_PL|FacID";
        caption = "Trung tâm tạo|Trung tâm đổi|";
        break;
      case ParamType.CheckBoxDateFromDateThru:
        name = `DateFromCheck|DateThruCheck`;
        caption = `Từ ngày|Đến ngày`;
        break;
      case ParamType.DateFromDateThruWithLabel:
        name = `DateFromLabel|DateThruLabel`;
        caption = `Từ ngày|Đến ngày`;
        break;
    }

    const names = name.split("|");
    const captions = caption ? caption.split("|") : names;
    for (let i = 0, n = Math.max(names.length, captions.length); i < n; i++) {
      const name = names.length > i ? names[i] : "";
      const caption = captions.length > i ? captions[i] : "";
      paramsValue.push({
        name: name || "",
        caption: caption || name || "",
        value: null,
        reportParams: param,
      });
    }
  });
  return paramsValue;
}
