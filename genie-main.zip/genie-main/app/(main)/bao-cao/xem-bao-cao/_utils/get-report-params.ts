import { DATE_FORMAT } from "@/app/lib/enums";
import { format } from "date-fns";
import { ParamType } from "./constants/param-type-constant";
import {
  L_ReportParams_List,
  ReportParamsValue,
} from "./definitions/xem-bao-cao.dto";

export default function getReportParams({
  reportParams,
  paramsValue,
  facId,
}: {
  reportParams: L_ReportParams_List[];
  paramsValue: ReportParamsValue[];
  facId: string;
}): { error: string; obj: Record<string, any> } {
  const result = {
    error: "",
    obj: {},
  };
  const obj: Record<string, any> = {};
  let date1: Date | null = null;
  let date2: Date | null = null;
  let hasDate1 = false; // num
  let hasDate2 = false; // num2
  let hasFacId = false; // flag
  for (const reportParam of reportParams) {
    const params = paramsValue.filter(
      (param) => param.reportParams.index === reportParam.index,
    );
    if (params.length === 0) {
      result.error = "Nhập đầy đủ thông số trước khi chạy";
      return result;
    }
    for (const param of params) {
      if (param.value === null || param.value === "") {
        result.error = "Nhập đầy đủ thông số trước khi chạy";
        return result;
      }
      switch (reportParam.type) {
        case ParamType.DateFrom:
        case ParamType.DateThru:
          if (reportParam.type === ParamType.DateFrom) {
            date1 = new Date(param.value!);
            hasDate1 = true;
            obj[param.name] = format(date1, DATE_FORMAT.YYYYMMDD_AS_INT);
          } else if (reportParam.type === ParamType.DateThru) {
            date2 = new Date(param.value!);
            hasDate2 = true;
            obj[param.name] = format(date2, DATE_FORMAT.YYYYMMDD_AS_INT);
          }
          break;
        case ParamType.DateFromV2:
        case ParamType.DateThruV2:
        case ParamType.DateFromV3:
        case ParamType.DateThruV3:
          if (
            reportParam.type === ParamType.DateFromV2 ||
            reportParam.type === ParamType.DateFromV3
          ) {
            date1 = new Date(param.value!);
            hasDate1 = true;
            obj[param.name] = format(date1, "MM/dd/yyyy HH:mm:ss"); // dùng chuỗi vì enum MM_DD_YYYY có sẵn hiện code có thể bị sửa sau này khó trace
          } else if (
            reportParam.type === ParamType.DateThruV2 ||
            reportParam.type === ParamType.DateThruV3
          ) {
            date2 = new Date(param.value!);
            hasDate2 = true;
            obj[param.name] = format(date2, "MM/dd/yyyy HH:mm:ss");
          }
          break;
        default:
          if (param.name) {
            obj[param.name] = param.value;
          }
          break;
      }
      if (param.name === "FacID") {
        hasFacId = true;
      }
      if (hasDate1 && hasDate2 && date2! < date1!) {
        result.error = "Từ ngày không được lớn hơn đến ngày";
        return result;
      }
    }
  }
  if (!hasFacId) {
    obj["FacID"] = facId;
  }
  result.obj = obj;
  return result;
}
