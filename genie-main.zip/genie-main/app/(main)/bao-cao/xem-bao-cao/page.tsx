import FacilityInfo from "@/components/facilityInfo";
import { Suspense } from "react";
import { Loading } from "./_components/loading";
import XemBaoCaoContainer from "./_components/xem-bao-cao-container";
import { LoadingBaoCaoProvider } from "./_contexts/loading-bao-cao-context";

// Source: https://git.vnvc.info/vnvc-qas/qas-app/-/blob/a1ee8fb73bba286279af5efa0a4ce38182af2a16/QA.Reports/QA.Reports/uReportsRunSelect.cs
export default async function Page() {
  return (
    <LoadingBaoCaoProvider>
      <FacilityInfo page={"BÁO CÁO | XEM BÁO CÁO"} />
      <Suspense fallback={<Loading />}>
        <XemBaoCaoContainer />
      </Suspense>
    </LoadingBaoCaoProvider>
  );
}

// TODO Setting: CoHienThiFavReports
