"use server";

import { getUserSession } from "@/actions/get-user-session";
import { ws_L_Reports_ListByUser } from "../_utils/services/xem-bao-cao.api";

async function loadDataInit() {
  const { facId, userId } = await getUserSession();
  const reportsByUser = await ws_L_Reports_ListByUser(facId);

  return {
    facId,
    userId,
    reportsByUser,
  };
}

export default loadDataInit;
