import * as httpService from "@/app/lib/network/http";
import {
  Facility_ListNotGlobal,
  INV_StockOnShopType_List,
  L_INV_StockType_Get,
  L_OnSiteShopType_ListByFacID,
  L_PhuongPhapXuatKho_List,
  L_Product_ListByPermissionStock,
  LoaiKhoModel,
  UserStockPermissions_Get,
} from "../definitions/cai-dat-cua-hang.dto";
import { cachePost } from "@/app/lib/network/cache-http";
import { getUserSession } from "@/actions/get-user-session";
import { generateCacheKey } from "@/app/lib/network/utils";

export async function ws_Facility_ListNotGlobal({
  facId,
}: {
  facId: string;
}): Promise<Facility_ListNotGlobal[]> {
  const { userId } = await getUserSession();
  const response = await cachePost({
    url: "/DataAccess",
    payload: [
      {
        category: "QAHosGenericDB",
        command: "ws_Facility_ListNotGlobal",
        parameters: {
          FacID: facId,
        },
      },
    ],
    cacheKey: generateCacheKey("ws_Facility_ListNotGlobal", { userId, facId }),
    ttl: 3600,
  });
  return response.table;
}

export async function ws_L_INV_StockType_Get({
  customerId,
}: {
  customerId: number;
}): Promise<LoaiKhoModel[]> {
  const response = await cachePost({
    url: "/DataAccess",
    payload: [
      {
        category: "QAHosGenericDB",
        command: "ws_L_INV_StockType_Get",
        parameters: {
          CustomerID: customerId,
        },
      },
    ],
    cacheKey: generateCacheKey("ws_L_INV_StockType_Get", { customerId }),
    ttl: 3600,
    transform: (data) =>
      (data.table || []).map(
        (d: L_INV_StockType_Get) =>
          ({
            stockType: d.stockType,
            stockTypeName: d.stockTypeName,
          }) as LoaiKhoModel,
      ),
  });
  return response;
}

export async function ws_L_PhuongPhapXuatKho_List(): Promise<
  L_PhuongPhapXuatKho_List[]
> {
  const { userId } = await getUserSession();
  const response = await cachePost({
    url: "/DataAccess",
    payload: [
      {
        category: "QAHosGenericDB",
        command: "ws_L_PhuongPhapXuatKho_List",
      },
    ],
    cacheKey: generateCacheKey("ws_L_PhuongPhapXuatKho_List", { userId }),
    ttl: 3600,
  });
  return response.table;
}

export async function ws_UserStockPermissions_Get({
  actionType,
  stockId,
  facId,
  toFacId,
}: {
  actionType: number;
  stockId?: number;
  facId?: string;
  toFacId?: string;
}): Promise<UserStockPermissions_Get[]> {
  const response = await httpService.post("/DataAccess", [
    {
      category: "Security",
      command: "ws_UserStockPermissions_Get",
      parameters: {
        StockID: stockId,
        ActionType: actionType,
        FacID: facId,
        ToFacID: toFacId,
      },
    },
  ]);
  return response.data.table;
}

export async function ws_L_OnSiteShopType_ListByFacID({
  facId,
}: {
  facId: string;
}): Promise<L_OnSiteShopType_ListByFacID[]> {
  const response = await httpService.post("/DataAccess", [
    {
      category: "QAHosGenericDB",
      command: "ws_L_OnSiteShopType_ListByFacID",
      parameters: {
        FacID: facId,
      },
    },
  ]);
  return response.data.table;
}

export async function ws_INV_StockOnShopType_List({
  facId,
  shopTypeId,
}: {
  facId: string;
  shopTypeId: string;
}): Promise<INV_StockOnShopType_List[]> {
  const response = await httpService.post("/DataAccess", [
    {
      category: "QAHosGenericDB",
      command: "ws_INV_StockOnShopType_List",
      parameters: {
        FacID: facId,
        ShopTypeID: shopTypeId,
      },
    },
  ]);
  return response.data.table;
}

export async function ws_L_Product_ListByPermissionStock({
  facId,
  stockId,
}: {
  facId: string;
  stockId: number;
}): Promise<L_Product_ListByPermissionStock[]> {
  const response = await httpService.post("/DataAccess", [
    {
      category: "QAHosGenericDB",
      command: "ws_L_Product_ListByPermissionStock",
      parameters: {
        FacID: facId,
        StockID: stockId,
      },
    },
  ]);
  return response.data.table;
}

export async function ws_L_OnSiteShopType_UpdateFacID({
  facId,
  shopTypeId,
  isActive,
}: {
  facId: string;
  shopTypeId: string;
  isActive: boolean;
}): Promise<void> {
  await httpService.post("/DataAccess", [
    {
      category: "QAHosGenericDB",
      command: "ws_L_OnSiteShopType_UpdateFacID",
      parameters: {
        FacID: facId,
        ShopTypeID: shopTypeId,
        IsActive: isActive,
      },
    },
  ]);
}

export async function ws_L_OnSiteShopType_Save({
  shopTypeId,
  shopTypeName,
  isActive,
}: {
  shopTypeId: string;
  shopTypeName: string;
  isActive: boolean;
}): Promise<boolean> {
  const response = await httpService.post("/DataAccess", [
    {
      category: "QAHosGenericDB",
      command: "ws_L_OnSiteShopType_Save",
      parameters: {
        ShopTypeID: shopTypeId,
        ShopTypeName: shopTypeName,
        IsActive: isActive,
      },
    },
  ]);
  const isSuccess = response.data.table[0].result === "Ok";
  return isSuccess;
}

export async function ws_INV_StockOnShopType_SaveByStockType({
  shopTypeId,
  stockType,
  phuongPhapXuat,
}: {
  shopTypeId: string;
  stockType: number;
  phuongPhapXuat: number;
}): Promise<void> {
  await httpService.post("/DataAccess", [
    {
      category: "QAHosGenericDB",
      command: "ws_INV_StockOnShopType_SaveByStockType",
      parameters: {
        ShopTypeID: shopTypeId,
        StockType: stockType,
        PhuongPhapXuat: phuongPhapXuat,
      },
    },
  ]);
}

export async function ws_INV_StockOnShopType_Delete({
  facId,
  shopTypeId,
  stockId,
}: {
  facId: string;
  shopTypeId: string;
  stockId: number;
}): Promise<void> {
  await httpService.post("/DataAccess", [
    {
      category: "QAHosGenericDB",
      command: "ws_INV_StockOnShopType_Delete",
      parameters: {
        FacID: facId,
        ShopTypeID: shopTypeId,
        StockID: stockId,
      },
    },
  ]);
}

export async function ws_INV_StockOnShopType_Save({
  shopTypeId,
  stockId,
  facId,
  phuongPhapXuat,
}: {
  shopTypeId: string;
  stockId: number;
  facId: string;
  phuongPhapXuat: number;
}): Promise<void> {
  await httpService.post("/DataAccess", [
    {
      category: "QAHosGenericDB",
      command: "ws_INV_StockOnShopType_Save",
      parameters: {
        ShopTypeID: shopTypeId,
        StockID: stockId,
        FacID: facId,
        PhuongPhapXuat: phuongPhapXuat,
      },
    },
  ]);
}
