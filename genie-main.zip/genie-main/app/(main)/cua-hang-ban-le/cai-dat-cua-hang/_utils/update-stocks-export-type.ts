import { SequenceRequest } from "@/app/lib/definitions/setting";
import { executeTransaction } from "@/app/lib/services/system";

export default async function updateStocksExportType({
  facId,
  shopTypeId,
  stockIds,
  phuongPhapXuat,
}: {
  facId: string;
  shopTypeId: string;
  stockIds: number[];
  phuongPhapXuat: number;
}) {
  const requests = [] as SequenceRequest[];
  stockIds.forEach((stockId) => {
    requests.push({
      category: "QAHosGenericDB",
      command: "ws_INV_StockOnShopType_Update",
      parameters: {
        ShopTypeID: shopTypeId,
        StockID: stockId,
        FacID: facId,
        PhuongPhapXuat: phuongPhapXuat,
      },
    });
  });
  await executeTransaction({ request: requests });
}
