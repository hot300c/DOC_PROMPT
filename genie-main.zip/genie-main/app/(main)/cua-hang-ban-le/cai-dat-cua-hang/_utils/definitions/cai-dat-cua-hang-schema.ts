import { z } from "zod";

export const AddShopSchema = z.object({
  shopTypeId: z.string(),
  shopTypeName: z.string(),
  isActive: z.boolean(),
});

export type AddShopParams = z.infer<typeof AddShopSchema>;

export const CaiDatNhanhLoaiKhoSchema = z.object({
  shopTypeId: z.string(),
  stockType: z.number(),
  phuongPhapXuat: z.number(),
});

export type CaiDatNhanhLoaiKhoParams = z.infer<typeof CaiDatNhanhLoaiKhoSchema>;

export const ThemKhoXuatLoaiXuatSchema = z.object({
  shopTypeId: z.string(),
  stockId: z.number(),
  facId: z.string(),
  phuongPhapXuat: z.number(),
});

export type ThemKhoXuatLoaiXuatParams = z.infer<
  typeof ThemKhoXuatLoaiXuatSchema
>;

export const SuaLoaiXuatSchema = z.object({
  shopTypeId: z.string(),
  facId: z.string(),
  phuongPhapXuat: z.number(),
});

export type SuaLoaiXuatParams = z.infer<typeof SuaLoaiXuatSchema>;
