export type Facility_ListNotGlobal = {
  facID: string;
  facName: string;
};

export type L_INV_StockType_Get = {
  stockType: number;
  customerID: number;
  stockTypeName: string;
  description: string | null;
  createdBy: string | null;
  createdOn: string; // hoặc Date nếu bạn xử lý ngày tháng
  modifiedBy: string | null;
  modifiedOn: string; // hoặc Date
  isActive: boolean;
};

export type LoaiKhoModel = {
  stockType: number;
  stockTypeName: string;
};

export type L_PhuongPhapXuatKho_List = {
  id: number;
  name: string;
};

export type UserStockPermissions_Get = {
  userID: string;
  stockID: number;
  facID: string;
  createdOn: string;
  createdBy: string;
  modifiedOn: string;
  modifiedBy: string;
  stockID1: number;
  facID1: string;
  customerID: number;
  aliasName: string;
  name: string;
  location: string;
  deptID: number;
  roomID: number;
  isMedicare: boolean;
  isService: boolean;
  isTayY: boolean;
  isYHCT: boolean;
  allowImport: boolean;
  allowExportForArmy: boolean;
  allowExportForNormalPatient: boolean;
  allowExportForOUT: boolean;
  allowExportForIN: boolean;
  allowSaleRetail: boolean;
  isDrugStock: boolean;
  isVatTu: boolean;
  isForBlood: boolean;
  isEquipment: boolean;
  isCLS: boolean;
  isActive: boolean;
  createdBy1: string;
  createdOn1: string;
  modifiedBy1: string;
  modifiedOn1: string;
  reportID_PhieuNhapKho: string | null;
  reportID_BienBanKiem: string | null;
  reportID_PhieuDeNghiThanhToan: string | null;
  reportID_GiayDeNghiChuyenKhoan: string | null;
  reportID_BienBanKiemNhapKhoKemPhieuNhapKho: string | null;
  reportID_BienBanKiemKeKHo: string | null;
  donViTrucThuoc: string;
  isBenhVien: boolean;
  isTuDongDuyet: boolean;
  stockType: number;
  groupID: number;
  stockCode: string;
  stockClassify: string;
  maKeToan: string | null;
  isUseMaKeToan: boolean | null;
};

export type L_OnSiteShopType_ListByFacID = {
  isCheck: boolean;
  shopTypeID: string;
  shopTypeName: string;
  facID: string;
};

export type INV_StockOnShopType_List = {
  isCheck: boolean;
  stockID: number;
  stockCode: string;
  name: string;
  phuongPhapXuat: number;
};

export type StockMappingModel = INV_StockOnShopType_List & {
  tenPhuongPhapXuat: string;
};

export type L_Product_ListByPermissionStock = {
  productID: number;
  hospitalCode: string;
  productName: string;
};
