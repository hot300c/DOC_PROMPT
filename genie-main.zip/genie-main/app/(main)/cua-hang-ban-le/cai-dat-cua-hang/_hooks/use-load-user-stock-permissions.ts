import { useCallback } from "react";
import { ws_UserStockPermissions_Get } from "../_utils/services/cai-dat-cua-hang.api";
import { useUserStockPermission } from "../_contexts/user-stock-permission-context";

export const useLoadUserStockPermissions = () => {
  const { setUserStockPermissions } = useUserStockPermission();

  const loadUserStockPermissions = useCallback(
    async ({ facId }: { facId: string }) => {
      if (!facId) return [];
      const data = await ws_UserStockPermissions_Get({
        actionType: 18,
        stockId: 0,
        facId,
      });
      setUserStockPermissions(data);
      return data;
    },
    [setUserStockPermissions],
  );

  return { loadUserStockPermissions };
};
