import { useCallback } from "react";
import { useCaiDatCuaHang } from "../_contexts/cai-dat-cua-hang-context";
import { ws_INV_StockOnShopType_List } from "../_utils/services/cai-dat-cua-hang.api";
import { StockMappingModel } from "../_utils/definitions/cai-dat-cua-hang.dto";
import { useLoadProducts } from "./use-load-products";
import { useStockMapping } from "../_contexts/stock-mapping-context";

export const useLoadStockMappings = () => {
  const { deliveryMethods } = useCaiDatCuaHang();
  const { setStockMappings, stockMappings, stockMappingSelectedRef } =
    useStockMapping();
  const { loadProducts } = useLoadProducts();

  const loadStockMappings = useCallback(
    async ({
      facId,
      shopTypeId,
      isRemainChecked,
    }: {
      facId: string;
      shopTypeId: string;
      isRemainChecked?: boolean;
    }) => {
      if (!facId || !shopTypeId) return [];
      const data = (
        await ws_INV_StockOnShopType_List({ facId, shopTypeId })
      ).map(
        (s) =>
          ({
            ...s,
            tenPhuongPhapXuat:
              deliveryMethods.find((d) => d.id === s.phuongPhapXuat)?.name ||
              "",
          }) as StockMappingModel,
      );
      if (isRemainChecked) {
        data.forEach((n) => {
          const org = stockMappings.find((org) => org.stockID === n.stockID);
          if (org) n.isCheck = org.isCheck;
        });
      }
      setStockMappings(data);
      let stockMappingNew = data.find(
        (n) => n.stockID === stockMappingSelectedRef.current?.stockID,
      );
      if (stockMappingNew) {
        if (
          stockMappingNew.stockCode ===
          stockMappingSelectedRef.current?.stockCode
        ) {
          stockMappingNew = undefined;
        }
      } else {
        stockMappingNew = data[0];
      }
      if (stockMappingNew) {
        stockMappingSelectedRef.current = stockMappingNew;
        await loadProducts({ facId, stockId: stockMappingNew.stockID });
      }
      return data;
    },
    [
      loadProducts,
      stockMappings,
      deliveryMethods,
      setStockMappings,
      stockMappingSelectedRef,
    ],
  );

  return { loadStockMappings };
};
