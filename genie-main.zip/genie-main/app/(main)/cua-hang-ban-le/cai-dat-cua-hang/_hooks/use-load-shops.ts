import { useCallback } from "react";
import { ws_L_OnSiteShopType_ListByFacID } from "../_utils/services/cai-dat-cua-hang.api";
import { isEqual } from "lodash";
import { useLoadStockMappings } from "./use-load-stock-mappings";
import { useShop } from "../_contexts/shop-context";

export const useLoadShops = () => {
  const { setShops, shopSelected, setShopSelected } = useShop();
  const { loadStockMappings } = useLoadStockMappings();

  const loadShops = useCallback(
    async ({ facId }: { facId: string }) => {
      if (!facId) return [];
      const data = await ws_L_OnSiteShopType_ListByFacID({ facId });
      setShops(data);
      let shopNew = data.find(
        (n) => n.shopTypeID === shopSelected?.shopTypeID && n.facID === facId,
      );
      if (shopNew) {
        if (isEqual(shopNew, shopSelected)) {
          shopNew = undefined;
        }
      } else {
        shopNew = data[0];
      }
      if (shopNew) {
        setShopSelected(shopNew);
        await loadStockMappings({ facId, shopTypeId: shopNew.shopTypeID });
      }
      return data;
    },
    [shopSelected, loadStockMappings, setShops, setShopSelected],
  );

  return { loadShops };
};
