import { useCallback, useEffect, useMemo } from "react";
import { ws_L_Product_ListByPermissionStock } from "../_utils/services/cai-dat-cua-hang.api";
import { debounce } from "lodash";
import { notifyError } from "@/app/lib/utils";
import { getErrorMessage } from "@/app/lib/utils/errorUtils";
import { useProduct } from "../_contexts/product-context";

export const useLoadProducts = () => {
  const { setProducts, setIsLoadingDelay } = useProduct();

  const loadProducts = useCallback(
    async ({ facId, stockId }: { facId: string; stockId: number }) => {
      if (!facId || !stockId) return [];
      const data = await ws_L_Product_ListByPermissionStock({ facId, stockId });
      setProducts(data);
      return data;
    },
    [setProducts],
  );

  const debouncedLoadProducts = useMemo(() => {
    return debounce(
      async ({ facId, stockId }: { facId: string; stockId: number }) => {
        try {
          await loadProducts({
            facId,
            stockId,
          });
        } catch (error) {
          console.log("useLoadProducts.debouncedLoadProducts", error);
          notifyError(getErrorMessage(error));
        } finally {
          setIsLoadingDelay(false);
        }
      },
      1000,
    );
  }, [loadProducts, setIsLoadingDelay]);

  const loadProductsDelay = useCallback(
    async ({ facId, stockId }: { facId: string; stockId: number }) => {
      setIsLoadingDelay(true);
      await debouncedLoadProducts({ facId, stockId });
    },
    [debouncedLoadProducts, setIsLoadingDelay],
  );

  useEffect(() => {
    return () => {
      setIsLoadingDelay(false);
      debouncedLoadProducts.cancel();
    };
  }, [debouncedLoadProducts, setIsLoadingDelay]);

  return {
    loadProducts,
    loadProductsDelay,
  };
};
