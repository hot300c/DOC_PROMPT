"use server";

import { getUserSession } from "@/actions/get-user-session";
import {
  ws_Facility_ListNotGlobal,
  ws_L_INV_StockType_Get,
  ws_L_PhuongPhapXuatKho_List,
} from "../_utils/services/cai-dat-cua-hang.api";

async function loadDataInit() {
  const { facId, userId, customerId } = await getUserSession();

  if (!facId) {
    throw new Error("Facility ID is required");
  }
  if (!userId) {
    throw new Error("User ID is required");
  }
  if (!customerId) {
    throw new Error("Customer ID is required");
  }

  const [facilities, stockTypes, deliveryMethods] = await Promise.all([
    ws_Facility_ListNotGlobal({ facId }),
    ws_L_INV_StockType_Get({ customerId: Number(customerId) }),
    ws_L_PhuongPhapXuatKho_List(),
  ]);

  return {
    facId,
    userId,
    customerId: Number(customerId),
    facilities,
    stockTypes,
    deliveryMethods,
  };
}

export default loadDataInit;
