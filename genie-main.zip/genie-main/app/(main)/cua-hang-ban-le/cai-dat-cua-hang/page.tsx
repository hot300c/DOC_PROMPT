import FacilityInfo from "@/components/facilityInfo";
import { Suspense } from "react";
import { LoadingProvider } from "./_contexts/loading-context";
import { Loading } from "./_components/loading";
import CaiDatCuaHangContainer from "./_components/cai-dat-cua-hang-container";

// Source: https://git.vnvc.info/vnvc-qas/qas-app/-/blob/c58421c7eacc8b31a03594b846eb6e5cf7ba5d6b/QA.ShopOnSite/QA.ShopOnSite/ucSettingShop.cs
export default async function Page() {
  return (
    <LoadingProvider>
      <FacilityInfo page={"CỬA HÀNG BÁN LẺ | CÀI ĐẶT CỬA HÀNG"} />
      <Suspense fallback={<Loading />}>
        <CaiDatCuaHangContainer />
      </Suspense>
    </LoadingProvider>
  );
}
