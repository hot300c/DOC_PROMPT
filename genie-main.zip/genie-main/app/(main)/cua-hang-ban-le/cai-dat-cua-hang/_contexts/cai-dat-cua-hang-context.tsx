"use client";

import {
  createContext,
  Dispatch,
  SetStateAction,
  useContext,
  useState,
} from "react";
import {
  Facility_ListNotGlobal,
  L_PhuongPhapXuatKho_List,
  LoaiKhoModel,
} from "../_utils/definitions/cai-dat-cua-hang.dto";

type CaiDatCuaHangContextType = {
  facId: string;
  userId: string;
  customerId: number;
  stockTypes: LoaiKhoModel[];
  deliveryMethods: L_PhuongPhapXuatKho_List[];
  facilities: Facility_ListNotGlobal[];
  facilitySelected?: Facility_ListNotGlobal;
  setFacilitySelected: Dispatch<
    SetStateAction<Facility_ListNotGlobal | undefined>
  >;
};

const CaiDatCuaHangContext = createContext<
  CaiDatCuaHangContextType | undefined
>(undefined);

export const useCaiDatCuaHang = () => {
  const context = useContext(CaiDatCuaHangContext);
  if (!context) {
    throw new Error(
      "useCaiDatCuaHang must be used within a CaiDatCuaHangProvider",
    );
  }
  return context;
};

interface CaiDatCuaHangProviderProps {
  children: React.ReactNode;
  facId: string;
  userId: string;
  customerId: number;
  facilities: Facility_ListNotGlobal[];
  stockTypes: LoaiKhoModel[];
  deliveryMethods: L_PhuongPhapXuatKho_List[];
}

export const CaiDatCuaHangProvider: React.FC<CaiDatCuaHangProviderProps> = ({
  facId,
  userId,
  customerId,
  facilities,
  stockTypes,
  deliveryMethods,
  children,
}) => {
  const [facilitySelected, setFacilitySelected] =
    useState<Facility_ListNotGlobal>();

  return (
    <CaiDatCuaHangContext.Provider
      value={{
        facId,
        userId,
        customerId,
        stockTypes,
        deliveryMethods,
        facilities,
        facilitySelected,
        setFacilitySelected,
      }}
    >
      {children}
    </CaiDatCuaHangContext.Provider>
  );
};
