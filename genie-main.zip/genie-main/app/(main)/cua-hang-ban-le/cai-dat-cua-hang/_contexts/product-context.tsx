"use client";

import {
  createContext,
  Dispatch,
  SetStateAction,
  useContext,
  useState,
} from "react";
import { L_Product_ListByPermissionStock } from "../_utils/definitions/cai-dat-cua-hang.dto";

type ProductContextType = {
  products: L_Product_ListByPermissionStock[];
  setProducts: Dispatch<SetStateAction<L_Product_ListByPermissionStock[]>>;
  isLoadingDelay: boolean;
  setIsLoadingDelay: Dispatch<SetStateAction<boolean>>;
};

const ProductContext = createContext<ProductContextType | undefined>(undefined);

export const useProduct = () => {
  const context = useContext(ProductContext);
  if (!context) {
    throw new Error("useProduct must be used within a ProductProvider");
  }
  return context;
};

interface ProductProviderProps {
  children: React.ReactNode;
}

export const ProductProvider: React.FC<ProductProviderProps> = ({
  children,
}) => {
  const [products, setProducts] = useState<L_Product_ListByPermissionStock[]>(
    [],
  );
  const [isLoadingDelay, setIsLoadingDelay] = useState(false);

  return (
    <ProductContext.Provider
      value={{
        products,
        setProducts,
        isLoadingDelay,
        setIsLoadingDelay,
      }}
    >
      {children}
    </ProductContext.Provider>
  );
};
