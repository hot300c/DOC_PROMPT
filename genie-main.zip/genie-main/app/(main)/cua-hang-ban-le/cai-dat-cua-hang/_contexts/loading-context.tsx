"use client";
import { ELoadingMessages } from "@/app/lib/enums";
import useLoadingBase from "@/components/loading";
import { createContext, ReactNode, useContext, useRef } from "react";

interface LoadingContextType {
  setLoading: (loading: boolean) => void;
}

const LoadingContext = createContext<LoadingContextType | undefined>(undefined);

export const LoadingProvider = ({ children }: { children: ReactNode }) => {
  const { showLoading, hideLoading } = useLoadingBase();
  const loadingIdRef = useRef<string>("");
  const loadingCountRef = useRef<number>(0);

  const setLoading = (loading: boolean) => {
    if (loading) {
      if (loadingCountRef.current === 0) {
        if (loadingIdRef.current) {
          hideLoading(loadingIdRef.current);
        }
        loadingIdRef.current = showLoading(ELoadingMessages.WAITING);
      }
      loadingCountRef.current += 1;
    } else {
      if (loadingCountRef.current > 0) {
        loadingCountRef.current -= 1;
        if (loadingCountRef.current === 0) {
          setTimeout(() => {
            hideLoading(loadingIdRef.current);
            loadingIdRef.current = "";
          });
        }
      }
    }
  };

  return (
    <LoadingContext.Provider value={{ setLoading }}>
      {children}
    </LoadingContext.Provider>
  );
};

export const useLoading = (): LoadingContextType => {
  const context = useContext(LoadingContext);
  if (context === undefined) {
    throw new Error("useLoading must be used within a LoadingProvider");
  }
  return context;
};
