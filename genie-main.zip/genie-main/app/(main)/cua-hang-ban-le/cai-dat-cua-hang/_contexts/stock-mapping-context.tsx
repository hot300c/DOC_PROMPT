"use client";

import {
  createContext,
  Dispatch,
  RefObject,
  SetStateAction,
  useContext,
  useRef,
  useState,
} from "react";
import { StockMappingModel } from "../_utils/definitions/cai-dat-cua-hang.dto";

type StockMappingContextType = {
  stockMappings: StockMappingModel[];
  stockMappingSelectedRef: RefObject<StockMappingModel | undefined>;
  setStockMappings: Dispatch<SetStateAction<StockMappingModel[]>>;
};

const StockMappingContext = createContext<StockMappingContextType | undefined>(
  undefined,
);

export const useStockMapping = () => {
  const context = useContext(StockMappingContext);
  if (!context) {
    throw new Error(
      "useStockMapping must be used within a StockMappingProvider",
    );
  }
  return context;
};

interface StockMappingProviderProps {
  children: React.ReactNode;
}

export const StockMappingProvider: React.FC<StockMappingProviderProps> = ({
  children,
}) => {
  const [stockMappings, setStockMappings] = useState<StockMappingModel[]>([]);
  const stockMappingSelectedRef = useRef<StockMappingModel>(undefined);

  return (
    <StockMappingContext.Provider
      value={{
        stockMappings,
        stockMappingSelectedRef,
        setStockMappings,
      }}
    >
      {children}
    </StockMappingContext.Provider>
  );
};
