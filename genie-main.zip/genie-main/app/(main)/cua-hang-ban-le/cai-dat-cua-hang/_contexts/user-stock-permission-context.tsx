"use client";

import {
  createContext,
  Dispatch,
  SetStateAction,
  useContext,
  useState,
} from "react";
import { UserStockPermissions_Get } from "../_utils/definitions/cai-dat-cua-hang.dto";

type UserStockPermissionContextType = {
  userStockPermissions: UserStockPermissions_Get[];
  setUserStockPermissions: Dispatch<SetStateAction<UserStockPermissions_Get[]>>;
};

const UserStockPermissionContext = createContext<
  UserStockPermissionContextType | undefined
>(undefined);

export const useUserStockPermission = () => {
  const context = useContext(UserStockPermissionContext);
  if (!context) {
    throw new Error(
      "useUserStockPermission must be used within a UserStockPermissionProvider",
    );
  }
  return context;
};

interface UserStockPermissionProviderProps {
  children: React.ReactNode;
}

export const UserStockPermissionProvider: React.FC<
  UserStockPermissionProviderProps
> = ({ children }) => {
  const [userStockPermissions, setUserStockPermissions] = useState<
    UserStockPermissions_Get[]
  >([]);

  return (
    <UserStockPermissionContext.Provider
      value={{
        userStockPermissions,
        setUserStockPermissions,
      }}
    >
      {children}
    </UserStockPermissionContext.Provider>
  );
};
