"use client";

import {
  createContext,
  Dispatch,
  SetStateAction,
  useContext,
  useState,
} from "react";
import { L_OnSiteShopType_ListByFacID } from "../_utils/definitions/cai-dat-cua-hang.dto";

type ShopContextType = {
  shops: L_OnSiteShopType_ListByFacID[];
  shopSelected?: L_OnSiteShopType_ListByFacID;
  setShops: Dispatch<SetStateAction<L_OnSiteShopType_ListByFacID[]>>;
  setShopSelected: Dispatch<
    SetStateAction<L_OnSiteShopType_ListByFacID | undefined>
  >;
};

const ShopContext = createContext<ShopContextType | undefined>(undefined);

export const useShop = () => {
  const context = useContext(ShopContext);
  if (!context) {
    throw new Error("useShop must be used within a ShopProvider");
  }
  return context;
};

interface ShopProviderProps {
  children: React.ReactNode;
}

export const ShopProvider: React.FC<ShopProviderProps> = ({ children }) => {
  const [shops, setShops] = useState<L_OnSiteShopType_ListByFacID[]>([]);
  const [shopSelected, setShopSelected] =
    useState<L_OnSiteShopType_ListByFacID>();

  return (
    <ShopContext.Provider
      value={{
        shops,
        shopSelected,
        setShops,
        setShopSelected,
      }}
    >
      {children}
    </ShopContext.Provider>
  );
};
