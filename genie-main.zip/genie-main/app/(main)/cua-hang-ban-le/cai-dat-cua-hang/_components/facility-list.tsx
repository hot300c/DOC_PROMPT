"use client";

import { DataTable } from "@/components/ui/dataTable";
import { ColumnDef } from "@tanstack/react-table";
import { useCaiDatCuaHang } from "../_contexts/cai-dat-cua-hang-context";
import { useCallback } from "react";
import { Facility_ListNotGlobal } from "../_utils/definitions/cai-dat-cua-hang.dto";
import { notifyError } from "@/app/lib/utils";
import { getErrorMessage } from "@/app/lib/utils/errorUtils";
import { useLoading } from "../_contexts/loading-context";
import { isEqual } from "lodash";
import { useLoadShops } from "../_hooks/use-load-shops";
import { useLoadUserStockPermissions } from "../_hooks/use-load-user-stock-permissions";

const COLUMNS: ColumnDef<Facility_ListNotGlobal>[] = [
  {
    id: "facID",
    accessorKey: "facID",
    header: "FacID",
    cell: ({ row }) => (
      <p className="line-clamp-1" title={row.original.facName}>
        {row.getValue("facID")}
      </p>
    ),
  },
];

const FacilityList = () => {
  const { facilities, facilitySelected, setFacilitySelected } =
    useCaiDatCuaHang();
  const { loadShops } = useLoadShops();
  const { loadUserStockPermissions } = useLoadUserStockPermissions();
  const { setLoading } = useLoading();

  const handleRowClick = useCallback(
    async (facility: Facility_ListNotGlobal) => {
      if (isEqual(facility, facilitySelected)) return;
      setFacilitySelected(facility);
      try {
        setLoading(true);
        await Promise.all([
          loadShops({ facId: facility.facID }),
          loadUserStockPermissions({ facId: facility.facID }),
        ]);
      } catch (error) {
        console.error("FacilityList.handleRowClick", error);
        notifyError(getErrorMessage(error));
      } finally {
        setLoading(false);
      }
    },
    [
      facilitySelected,
      setFacilitySelected,
      setLoading,
      loadShops,
      loadUserStockPermissions,
    ],
  );

  return (
    <div className="w-full flex flex-row overflow-hidden flex-1 overflow-y-hidden h-full">
      <DataTable
        columns={COLUMNS}
        data={facilities}
        className="w-full h-full overflow-auto"
        enablePaging={false}
        enableColumnFilter={false}
        onRowClick={handleRowClick}
        enableScrollTo={false}
        indexScrollTo={facilities.findIndex(
          (fac) => fac.facID === facilitySelected?.facID,
        )}
      />
    </div>
  );
};

export default FacilityList;
