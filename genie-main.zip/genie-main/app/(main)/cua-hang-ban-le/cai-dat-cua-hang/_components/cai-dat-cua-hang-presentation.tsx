"use client";

import { useEffect } from "react";
import FacilityList from "./facility-list";
import ShopPresentation from "./shop/shop-presentation";
import StockPresentation from "./stock/stock-presentation";
import { useCaiDatCuaHang } from "../_contexts/cai-dat-cua-hang-context";
import { useLoading } from "../_contexts/loading-context";
import { notifyError } from "@/app/lib/utils";
import { getErrorMessage } from "@/app/lib/utils/errorUtils";
import ProductList from "./product-list";
import { useLoadShops } from "../_hooks/use-load-shops";
import { useLoadUserStockPermissions } from "../_hooks/use-load-user-stock-permissions";

export default function CaiDatCuaHangPresentation() {
  const { facilities, facilitySelected, setFacilitySelected } =
    useCaiDatCuaHang();
  const { loadShops } = useLoadShops();
  const { loadUserStockPermissions } = useLoadUserStockPermissions();
  const { setLoading } = useLoading();

  useEffect(() => {
    if (facilities.length === 0) return;
    if (facilitySelected?.facID) return;
    const facilityInit = facilities[0];
    if (!facilityInit) return;
    setFacilitySelected(facilityInit);
    setLoading(true);
    const load = async () => {
      await Promise.all([
        loadShops({ facId: facilityInit.facID }),
        loadUserStockPermissions({ facId: facilityInit.facID }),
      ]);
    };
    load()
      .catch((error) => {
        console.error("CaiDatCuaHangPresentation", error);
        notifyError(getErrorMessage(error));
      })
      .finally(() => {
        setLoading(false);
      });
  }, [
    facilities,
    facilitySelected?.facID,
    setFacilitySelected,
    setLoading,
    loadShops,
    loadUserStockPermissions,
  ]);

  return (
    <main className="w-full flex flex-row overflow-hidden overflow-y-hidden h-full">
      <section className="flex flex-col w-20 overflow-hidden h-full">
        <FacilityList />
      </section>
      <section className="flex flex-col w-50 overflow-hidden h-full">
        <ShopPresentation />
      </section>
      <section className="flex flex-col flex-1 overflow-hidden h-full">
        <StockPresentation />
      </section>
      <section className="flex flex-col w-80 overflow-hidden h-full">
        <ProductList />
      </section>
    </main>
  );
}
