import { getErrorMessage } from "@/app/lib/utils/errorUtils";
import loadDataInit from "../_actions/load-data-init";
import { CaiDatCuaHangProvider } from "../_contexts/cai-dat-cua-hang-context";
import CaiDatCuaHangPresentation from "./cai-dat-cua-hang-presentation";
import { ProductProvider } from "../_contexts/product-context";
import { StockMappingProvider } from "../_contexts/stock-mapping-context";
import { UserStockPermissionProvider } from "../_contexts/user-stock-permission-context";
import { ShopProvider } from "../_contexts/shop-context";

export default async function CaiDatCuaHangContainer() {
  try {
    const {
      facId,
      userId,
      customerId,
      facilities,
      stockTypes,
      deliveryMethods,
    } = await loadDataInit();

    return (
      <CaiDatCuaHangProvider
        facId={facId}
        userId={userId}
        customerId={customerId}
        facilities={facilities}
        stockTypes={stockTypes}
        deliveryMethods={deliveryMethods}
      >
        <ShopProvider>
          <UserStockPermissionProvider>
            <StockMappingProvider>
              <ProductProvider>
                <CaiDatCuaHangPresentation />
              </ProductProvider>
            </StockMappingProvider>
          </UserStockPermissionProvider>
        </ShopProvider>
      </CaiDatCuaHangProvider>
    );
  } catch (error) {
    console.error("CaiDatCuaHangContainer", error);
    return (
      <div>
        <p>Có lỗi loading dữ liệu: {getErrorMessage(error)}</p>
        <p>Vui lòng nhấn F5 để tải lại màn hình, xin cảm ơn!</p>
      </div>
    );
  }
}
