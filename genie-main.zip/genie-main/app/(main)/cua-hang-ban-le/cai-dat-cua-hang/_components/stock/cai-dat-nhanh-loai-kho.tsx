"use client";

import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { useCaiDatCuaHang } from "../../_contexts/cai-dat-cua-hang-context";
import { LoaiKhoModel } from "../../_utils/definitions/cai-dat-cua-hang.dto";
import { ColumnDef } from "@tanstack/react-table";
import { TableSelect } from "@/components/select/table-select";
import { DataTableColumnHeaderSort } from "@/components/ui/dataTable";
import { useLoading } from "../../_contexts/loading-context";
import {
  CaiDatNhanhLoaiKhoParams,
  CaiDatNhanhLoaiKhoSchema,
} from "../../_utils/definitions/cai-dat-cua-hang-schema";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormField, FormItem } from "@/components/ui/form";
import { useCallback, useEffect } from "react";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { useFeedbackDialog } from "@/app/lib/feedback-dialog-provider";
import { ws_INV_StockOnShopType_SaveByStockType } from "../../_utils/services/cai-dat-cua-hang.api";
import { notifyError } from "@/app/lib/utils";
import { getErrorMessage } from "@/app/lib/utils/errorUtils";
import { useLoadStockMappings } from "../../_hooks/use-load-stock-mappings";
import { useShop } from "../../_contexts/shop-context";

const COLUMNS_LOAI_KHO: ColumnDef<LoaiKhoModel>[] = [
  {
    id: "stockTypeName",
    accessorKey: "stockTypeName",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Loại kho" />
    ),
    cell: ({ row }) => (
      <p className="line-clamp-1" title={row.getValue("stockTypeName")}>
        {row.getValue("stockTypeName")}
      </p>
    ),
  },
];

const CaiDatNhanhLoaiKho = () => {
  const { stockTypes, deliveryMethods, facilitySelected } = useCaiDatCuaHang();
  const { shopSelected } = useShop();
  const { loadStockMappings } = useLoadStockMappings();
  const { setLoading } = useLoading();
  const { alert } = useFeedbackDialog();
  const formData = useForm<CaiDatNhanhLoaiKhoParams>({
    resolver: zodResolver(CaiDatNhanhLoaiKhoSchema),
    defaultValues: {
      shopTypeId: "",
      stockType: 0,
      phuongPhapXuat: 1,
    },
  });

  const onSubmit = useCallback(
    async (data: CaiDatNhanhLoaiKhoParams) => {
      if (!facilitySelected?.facID) {
        await alert({
          title: "",
          content: "Vui lòng chọn cơ sở",
        });
        return;
      }
      if (!data.shopTypeId) {
        await alert({
          title: "",
          content: "Vui lòng chọn shop",
        });
        return;
      }
      if (!data.stockType) {
        await alert({
          title: "",
          content: "Vui lòng chọn loại kho",
        });
        formData.setFocus("stockType");
        return;
      }
      try {
        setLoading(true);
        await ws_INV_StockOnShopType_SaveByStockType({
          shopTypeId: data.shopTypeId,
          stockType: data.stockType,
          phuongPhapXuat: data.phuongPhapXuat,
        });
        await loadStockMappings({
          facId: facilitySelected.facID,
          shopTypeId: data.shopTypeId,
        });
      } catch (error) {
        console.error("CaiDatNhanhLoaiKho.onSubmit", error);
        notifyError(getErrorMessage(error));
      } finally {
        setLoading(false);
      }
    },
    [alert, facilitySelected?.facID, loadStockMappings, setLoading, formData],
  );

  useEffect(() => {
    if (shopSelected?.shopTypeID) {
      formData.setValue("shopTypeId", shopSelected.shopTypeID);
    }
  }, [shopSelected?.shopTypeID, formData]);

  return (
    <div className="flex flex-col overflow-hidden relative">
      <div className="absolute left-3 bg-white font-bold">Cài đặt nhanh</div>
      <Form {...formData}>
        <form
          onSubmit={formData.handleSubmit(onSubmit)}
          className="flex flex-col overflow-hidden gap-1 border rounded p-2 pt-3 mt-3 mx-1"
        >
          <div className="flex flex-row items-baseline">
            <Label className="w-34">Chọn nhanh loại kho:</Label>
            <FormField
              control={formData.control}
              name="stockType"
              render={({ field }) => (
                <FormItem>
                  <TableSelect
                    columns={COLUMNS_LOAI_KHO}
                    data={stockTypes}
                    labelKey={"stockTypeName"}
                    valueKey={"stockType"}
                    className="w-80"
                    placeholder="----Chọn loại kho -----"
                    value={stockTypes.find((v) => v.stockType == field.value)}
                    onChange={(value) => {
                      if (value) {
                        field.onChange(value.stockType);
                      }
                    }}
                  ></TableSelect>
                </FormItem>
              )}
            ></FormField>
          </div>
          <div className="flex flex-row items-baseline">
            <Label className="w-34">Phương pháp xuất:</Label>
            <div className="flex flex-row items-baseline w-80">
              <div className="flex-1">
                <FormField
                  control={formData.control}
                  name="phuongPhapXuat"
                  render={({ field }) => (
                    <FormItem>
                      <RadioGroup
                        value={field.value.toString()}
                        onValueChange={(value) => field.onChange(Number(value))}
                        className="flex flex-row space-x-4 border rounded px-2"
                      >
                        {deliveryMethods.map((item) => (
                          <div
                            key={item.id}
                            className="flex flex-row items-baseline"
                          >
                            <RadioGroupItem
                              value={item.id.toString()}
                              id={`fast-add-export-method-${item.id}`}
                            ></RadioGroupItem>
                            <label
                              htmlFor={`fast-add-export-method-${item.id}`}
                              className="pl-2"
                            >
                              {item.name}
                            </label>
                          </div>
                        ))}
                      </RadioGroup>
                    </FormItem>
                  )}
                ></FormField>
              </div>
              <Button className="ml-2 min-w-36" type="submit">
                Áp dụng
              </Button>
            </div>
          </div>
        </form>
      </Form>
    </div>
  );
};

export default CaiDatNhanhLoaiKho;
