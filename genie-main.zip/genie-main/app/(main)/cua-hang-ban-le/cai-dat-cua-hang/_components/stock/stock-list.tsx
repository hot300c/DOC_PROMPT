"use client";

import { DataTable } from "@/components/ui/dataTable";
import { ColumnDef } from "@tanstack/react-table";
import { useCaiDatCuaHang } from "../../_contexts/cai-dat-cua-hang-context";
import {
  L_PhuongPhapXuatKho_List,
  StockMappingModel,
} from "../../_utils/definitions/cai-dat-cua-hang.dto";
import { useCallback, useMemo } from "react";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { useFeedbackDialog } from "@/app/lib/feedback-dialog-provider";
import { useLoading } from "../../_contexts/loading-context";
import { notifyError, notifySuccess } from "@/app/lib/utils";
import { getErrorMessage } from "@/app/lib/utils/errorUtils";
import { Button } from "@/components/ui/button";
import { Trash2 } from "lucide-react";
import { ws_INV_StockOnShopType_Delete } from "../../_utils/services/cai-dat-cua-hang.api";
import { TableSelect } from "@/components/select/table-select";
import updateStocksExportType from "../../_utils/update-stocks-export-type";
import { useLoadStockMappings } from "../../_hooks/use-load-stock-mappings";
import { useLoadProducts } from "../../_hooks/use-load-products";
import { useStockMapping } from "../../_contexts/stock-mapping-context";
import { useShop } from "../../_contexts/shop-context";

const COLUMNS_LOAI_XUAT: ColumnDef<L_PhuongPhapXuatKho_List>[] = [
  {
    id: "name",
    accessorKey: "name",
    header: "Loại xuất",
    cell: ({ row }) => (
      <p className="line-clamp-1" title={row.getValue("name")}>
        {row.getValue("name")}
      </p>
    ),
  },
];

const StockList = () => {
  const { facilitySelected, deliveryMethods } = useCaiDatCuaHang();
  const { shopSelected } = useShop();
  const { stockMappings, stockMappingSelectedRef } = useStockMapping();
  const { loadStockMappings } = useLoadStockMappings();
  const { loadProductsDelay } = useLoadProducts();
  const { confirm } = useFeedbackDialog();
  const { setLoading } = useLoading();

  const handleChecked = useCallback(
    (stockMapping: StockMappingModel, checked: boolean) => {
      stockMapping.isCheck = checked;
    },
    [],
  );

  const handleDelete = useCallback(
    async (stockMapping: StockMappingModel) => {
      if (!facilitySelected?.facID) {
        await alert({
          title: "",
          content: "Vui lòng chọn cơ sở",
        });
        return;
      }
      if (!shopSelected?.shopTypeID) {
        await alert({
          title: "",
          content: "Vui lòng chọn shop",
        });
        return;
      }
      const isDeleteConfirm = await confirm({
        title: "Bạn có muốn xóa không?",
        content: "Bạn sẽ KHÔNG thể khôi phục lại dữ liệu đã xóa.",
      });
      if (!isDeleteConfirm) return;
      try {
        setLoading(true);
        await ws_INV_StockOnShopType_Delete({
          facId: facilitySelected.facID,
          shopTypeId: shopSelected.shopTypeID,
          stockId: stockMapping.stockID,
        });
        notifySuccess("Đã xóa");
        await loadStockMappings({
          facId: facilitySelected.facID,
          shopTypeId: shopSelected.shopTypeID,
        });
      } catch (error) {
        console.error("StockList.handleDelete", error);
        notifyError(getErrorMessage(error));
      } finally {
        setLoading(false);
      }
    },
    [
      confirm,
      setLoading,
      facilitySelected?.facID,
      shopSelected?.shopTypeID,
      loadStockMappings,
    ],
  );

  const handleChangePhuongPhapXuat = useCallback(
    async (
      stockMapping: StockMappingModel,
      phuongPhapXuat: L_PhuongPhapXuatKho_List,
    ) => {
      if (!facilitySelected?.facID) {
        await alert({
          title: "",
          content: "Vui lòng chọn cơ sở",
        });
        return;
      }
      if (!shopSelected?.shopTypeID) {
        await alert({
          title: "",
          content: "Vui lòng chọn shop",
        });
        return;
      }
      const isConfirmOverride = await confirm({
        title: "",
        content: "Dữ liệu sẽ được ghi đè",
      });
      if (!isConfirmOverride) return;
      try {
        setLoading(true);
        await updateStocksExportType({
          facId: facilitySelected.facID,
          shopTypeId: shopSelected.shopTypeID,
          phuongPhapXuat: phuongPhapXuat.id,
          stockIds: [stockMapping.stockID],
        });
        await loadStockMappings({
          facId: facilitySelected.facID,
          shopTypeId: shopSelected.shopTypeID,
          isRemainChecked: true,
        });
        setLoading(false);
        notifySuccess("Đã lưu");
      } catch (error) {
        setLoading(false);
        console.error("StockList.handleChangePhuongPhapXuat", error);
        notifyError(getErrorMessage(error));
      }
    },
    [
      confirm,
      facilitySelected?.facID,
      shopSelected?.shopTypeID,
      setLoading,
      loadStockMappings,
    ],
  );

  const columnsStockMapping = useMemo(() => {
    const columnsStockMapping: ColumnDef<StockMappingModel>[] = [
      {
        header: "Chọn",
        cell: ({ row }) => (
          <Label className="flex items-center justify-center absolute inset-0 cursor-pointer">
            <Checkbox
              defaultChecked={row.original.isCheck}
              onCheckedChange={(checked) =>
                handleChecked(row.original, Boolean(checked.valueOf()))
              }
            />
          </Label>
        ),
        meta: {
          className: "p-0 relative",
        },
      },
      {
        id: "stockCode",
        accessorKey: "stockCode",
        header: "Mã kho",
        cell: ({ row }) => (
          <p className="line-clamp-1" title={row.getValue("stockCode")}>
            {row.getValue("stockCode")}
          </p>
        ),
      },
      {
        id: "name",
        accessorKey: "name",
        header: "Tên kho",
        cell: ({ row }) => (
          <p className="line-clamp-1" title={row.getValue("name")}>
            {row.getValue("name")}
          </p>
        ),
      },
      {
        id: "tenPhuongPhapXuat",
        accessorKey: "tenPhuongPhapXuat",
        header: "Loại xuất",
        cell: ({ row }) => {
          const phuongPhapXuat = deliveryMethods.find(
            (m) => m.id === row.original.phuongPhapXuat,
          );
          return (
            <TableSelect
              data={deliveryMethods}
              columns={COLUMNS_LOAI_XUAT}
              labelKey="name"
              valueKey="id"
              value={phuongPhapXuat}
              onChange={(value) =>
                handleChangePhuongPhapXuat(row.original, value)
              }
            />
          );
        },
        meta: {
          className: "py-0",
        },
      },
      {
        header: "Xóa",
        cell: ({ row }) => (
          <div className="flex justify-center">
            <Button
              variant="ghost"
              onClick={async () => await handleDelete(row.original)}
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
        ),
        meta: {
          className: "py-0",
        },
      },
    ];
    return columnsStockMapping;
  }, [
    deliveryMethods,
    handleChecked,
    handleDelete,
    handleChangePhuongPhapXuat,
  ]);

  const handleRowClick = useCallback(
    async (stock: StockMappingModel) => {
      if (
        facilitySelected?.facID &&
        stockMappingSelectedRef.current?.stockID !== stock.stockID
      ) {
        await loadProductsDelay({
          facId: facilitySelected?.facID,
          stockId: stock.stockID,
        });
      }
      stockMappingSelectedRef.current = stock;
    },
    [facilitySelected?.facID, stockMappingSelectedRef, loadProductsDelay],
  );

  return (
    <div className="w-full flex flex-col overflow-hidden flex-1 overflow-y-hidden px-1">
      <DataTable
        columns={columnsStockMapping}
        data={stockMappings}
        className="w-full h-full overflow-auto border"
        enablePaging={false}
        enableColumnFilter={false}
        enableGlobalFilter={true}
        placeholderSearch="Nhập mã kho, tên kho, loại xuất để tìm kiếm..."
        onRowClick={handleRowClick}
        enableScrollTo={false}
        indexScrollTo={stockMappings.findIndex(
          (stock) => stock.stockID === stockMappingSelectedRef.current?.stockID,
        )}
      />
    </div>
  );
};

export default StockList;
