"use client";

import CaiDatNhanhLoaiKho from "./cai-dat-nhanh-loai-kho";
import StockList from "./stock-list";
import SuaLoaiXuat from "./sua-loai-xuat";
import ThemKhoXuatLoaiXuat from "./them-kho-xuat-loai-xuat";

const StockPresentation = () => {
  return (
    <div className="w-full flex flex-col overflow-hidden flex-1 overflow-y-hidden h-full border-r">
      <section>
        <CaiDatNhanhLoaiKho />
      </section>
      <section>
        <ThemKhoXuatLoaiXuat />
      </section>
      <section>
        <SuaLoaiXuat />
      </section>
      <section className="w-full flex flex-col overflow-hidden flex-1 overflow-y-hidden mt-1">
        <StockList />
      </section>
    </div>
  );
};

export default StockPresentation;
