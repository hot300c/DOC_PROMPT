"use client";

import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { useCaiDatCuaHang } from "../../_contexts/cai-dat-cua-hang-context";
import { useLoading } from "../../_contexts/loading-context";
import {
  SuaLoaiXuatParams,
  SuaLoaiXuatSchema,
} from "../../_utils/definitions/cai-dat-cua-hang-schema";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormField, FormItem } from "@/components/ui/form";
import { useCallback, useEffect } from "react";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { useFeedbackDialog } from "@/app/lib/feedback-dialog-provider";
import { notifyError } from "@/app/lib/utils";
import { getErrorMessage } from "@/app/lib/utils/errorUtils";
import updateStocksExportType from "../../_utils/update-stocks-export-type";
import { useLoadStockMappings } from "../../_hooks/use-load-stock-mappings";
import { useStockMapping } from "../../_contexts/stock-mapping-context";
import { useShop } from "../../_contexts/shop-context";

const SuaLoaiXuat = () => {
  const { deliveryMethods, facilitySelected } = useCaiDatCuaHang();
  const { shopSelected } = useShop();
  const { stockMappings } = useStockMapping();
  const { loadStockMappings } = useLoadStockMappings();
  const { setLoading } = useLoading();
  const { alert } = useFeedbackDialog();
  const formData = useForm<SuaLoaiXuatParams>({
    resolver: zodResolver(SuaLoaiXuatSchema),
    defaultValues: {
      shopTypeId: "",
      facId: "",
      phuongPhapXuat: 1,
    },
  });

  const onSubmit = useCallback(
    async (data: SuaLoaiXuatParams) => {
      if (!data.facId) {
        await alert({
          title: "",
          content: "Vui lòng chọn cơ sở",
        });
        return;
      }
      if (!data.shopTypeId) {
        await alert({
          title: "",
          content: "Vui lòng chọn shop",
        });
        return;
      }
      const stocksSelected =
        stockMappings?.filter((item) => item.isCheck) || [];
      if (stocksSelected.length === 0) {
        await alert({
          title: "",
          content: "Vui lòng chọn các kho xuất ở danh sách phía dưới",
        });
        return;
      }
      try {
        setLoading(true);
        await updateStocksExportType({
          facId: data.facId,
          shopTypeId: data.shopTypeId,
          stockIds: stocksSelected.map((item) => item.stockID),
          phuongPhapXuat: data.phuongPhapXuat,
        });
        await loadStockMappings({
          facId: data.facId,
          shopTypeId: data.shopTypeId,
          isRemainChecked: true,
        });
      } catch (error) {
        console.error("SuaLoaiXuat.onSubmit", error);
        notifyError(getErrorMessage(error));
      } finally {
        setLoading(false);
      }
    },
    [alert, loadStockMappings, setLoading, stockMappings],
  );

  useEffect(() => {
    if (shopSelected?.shopTypeID) {
      formData.setValue("shopTypeId", shopSelected.shopTypeID);
    }
  }, [shopSelected?.shopTypeID, formData]);

  useEffect(() => {
    if (facilitySelected?.facID) {
      formData.setValue("facId", facilitySelected.facID);
    }
  }, [facilitySelected?.facID, formData]);

  return (
    <div className="flex flex-col overflow-hidden relative">
      <div className="absolute left-3 bg-white font-bold">Sửa loại xuất</div>
      <Form {...formData}>
        <form
          onSubmit={formData.handleSubmit(onSubmit)}
          className="flex flex-col overflow-hidden gap-1 border rounded p-2 pt-3 mt-3 mx-1"
        >
          <div className="flex flex-row items-baseline">
            <Label className="w-34">Phương pháp xuất:</Label>
            <div className="flex flex-row items-baseline w-80">
              <div className="flex-1">
                <FormField
                  control={formData.control}
                  name="phuongPhapXuat"
                  render={({ field }) => (
                    <FormItem>
                      <RadioGroup
                        value={field.value.toString()}
                        onValueChange={(value) => field.onChange(Number(value))}
                        className="flex flex-row space-x-4 border rounded px-2"
                      >
                        {deliveryMethods.map((item) => (
                          <div
                            key={item.id}
                            className="flex flex-row items-baseline"
                          >
                            <RadioGroupItem
                              value={item.id.toString()}
                              id={`update-export-method-${item.id}`}
                            ></RadioGroupItem>
                            <label
                              htmlFor={`update-export-method-${item.id}`}
                              className="pl-2"
                            >
                              {item.name}
                            </label>
                          </div>
                        ))}
                      </RadioGroup>
                    </FormItem>
                  )}
                ></FormField>
              </div>
              <Button className="ml-2 min-w-36" type="submit">
                Áp dụng
              </Button>
            </div>
          </div>
        </form>
      </Form>
    </div>
  );
};

export default SuaLoaiXuat;
