import { Skeleton } from "@/components/ui/skeleton";

export const Loading = () => {
  return (
    <main className="w-full flex flex-row overflow-hidden overflow-y-hidden h-full space-x-1">
      <section className="flex flex-col w-20 overflow-hidden h-full space-y-1">
        <Skeleton className="h-4" />
        <Skeleton className="flex-1" />
      </section>
      <section className="flex flex-col w-50 overflow-hidden h-full space-y-1">
        <div className="w-full flex flex-col overflow-hidden flex-1 overflow-y-hidden h-full space-y-1">
          <section className="w-full flex flex-col overflow-hidden flex-1 overflow-y-hidden h-full space-y-1">
            <Skeleton className="h-4" />
            <Skeleton className="flex-1" />
          </section>
          <section className="flex flex-col space-y-1">
            <Skeleton className="h-16" />
          </section>
        </div>
      </section>
      <section className="flex flex-col flex-1 overflow-hidden h-full space-y-1">
        <Skeleton className="h-20" />
        <Skeleton className="h-20" />
        <Skeleton className="h-16" />
        <Skeleton className="flex-1" />
      </section>
      <section className="flex flex-col w-60 overflow-hidden h-full space-y-1">
        <Skeleton className="h-4" />
        <Skeleton className="flex-1" />
      </section>
    </main>
  );
};
