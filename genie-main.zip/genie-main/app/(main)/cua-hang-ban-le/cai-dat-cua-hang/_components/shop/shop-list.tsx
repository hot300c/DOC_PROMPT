"use client";

import { DataTable } from "@/components/ui/dataTable";
import { ColumnDef } from "@tanstack/react-table";
import { useCaiDatCuaHang } from "../../_contexts/cai-dat-cua-hang-context";
import { L_OnSiteShopType_ListByFacID } from "../../_utils/definitions/cai-dat-cua-hang.dto";
import { useCallback, useMemo } from "react";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { useFeedbackDialog } from "@/app/lib/feedback-dialog-provider";
import { ws_L_OnSiteShopType_UpdateFacID } from "../../_utils/services/cai-dat-cua-hang.api";
import { useLoading } from "../../_contexts/loading-context";
import { notifyError, notifySuccess } from "@/app/lib/utils";
import { getErrorMessage } from "@/app/lib/utils/errorUtils";
import { isEqual } from "lodash";
import { useLoadStockMappings } from "../../_hooks/use-load-stock-mappings";
import { useShop } from "../../_contexts/shop-context";

const ShopList = () => {
  const { facilitySelected } = useCaiDatCuaHang();
  const { shops, setShops, shopSelected, setShopSelected } = useShop();
  const { loadStockMappings } = useLoadStockMappings();
  const { confirm } = useFeedbackDialog();
  const { setLoading } = useLoading();

  const handleChecked = useCallback(
    async (shop: L_OnSiteShopType_ListByFacID) => {
      if (!facilitySelected?.facID) {
        await alert({
          title: "",
          content: "Vui lòng chọn cơ sở",
        });
        return;
      }
      const isConfirmOverride = await confirm({
        title: "",
        content: "Dữ liệu sẽ được ghi đè",
      });
      if (!isConfirmOverride) return;
      try {
        setLoading(true);
        await ws_L_OnSiteShopType_UpdateFacID({
          facId: facilitySelected.facID,
          shopTypeId: shop.shopTypeID,
          isActive: !shop.isCheck,
        });
        setShops(
          shops.map((item) =>
            isEqual(item, shop) ? { ...item, isCheck: !shop.isCheck } : item,
          ),
        );
        setLoading(false);
        notifySuccess("Đã lưu");
      } catch (error) {
        setLoading(false);
        console.error("ShopList.handleChecked", error);
        notifyError(getErrorMessage(error));
      }
    },
    [facilitySelected?.facID, confirm, setLoading, setShops, shops],
  );

  const columns = useMemo(() => {
    const columns: ColumnDef<L_OnSiteShopType_ListByFacID>[] = [
      {
        header: "Chọn",
        cell: ({ row }) => (
          <Label className="flex items-center justify-center absolute inset-0 cursor-pointer">
            <Checkbox
              checked={row.original.isCheck}
              onCheckedChange={(checked) => handleChecked(row.original)}
            />
          </Label>
        ),
        meta: {
          className: "p-0 relative",
        },
      },
      {
        id: "shopTypeName",
        accessorKey: "shopTypeName",
        header: "Tên shop",
        cell: ({ row }) => (
          <p className="line-clamp-1" title={row.getValue("shopTypeName")}>
            {row.getValue("shopTypeName")}
          </p>
        ),
      },
    ];
    return columns;
  }, [handleChecked]);

  const handleRowClick = useCallback(
    async (shop: L_OnSiteShopType_ListByFacID) => {
      setShopSelected(shop);
      if (
        facilitySelected?.facID &&
        shop?.shopTypeID &&
        shop.shopTypeID !== shopSelected?.shopTypeID
      ) {
        try {
          setLoading(true);
          await loadStockMappings({
            facId: facilitySelected?.facID,
            shopTypeId: shop?.shopTypeID,
          });
        } catch (error) {
          console.log("ShopList.handleRowClick", error);
          notifyError(getErrorMessage(error));
        } finally {
          setLoading(false);
        }
      }
    },
    [
      facilitySelected?.facID,
      shopSelected,
      setLoading,
      loadStockMappings,
      setShopSelected,
    ],
  );

  return (
    <div className="w-full flex flex-row overflow-hidden flex-1 overflow-y-hidden">
      <DataTable
        columns={columns}
        data={shops}
        className="w-full h-full overflow-auto"
        enablePaging={false}
        enableColumnFilter={false}
        onRowClick={handleRowClick}
        enableGrouping={false}
        indexScrollTo={shops.findIndex(
          (shop) =>
            shop.shopTypeID === shopSelected?.shopTypeID &&
            shop.facID === shopSelected?.facID,
        )}
      />
    </div>
  );
};

export default ShopList;
