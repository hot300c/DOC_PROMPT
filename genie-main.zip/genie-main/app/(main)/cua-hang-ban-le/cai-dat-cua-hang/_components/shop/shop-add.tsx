import { zodResolver } from "@hookform/resolvers/zod";
import {
  AddShopParams,
  AddShopSchema,
} from "../../_utils/definitions/cai-dat-cua-hang-schema";
import { useForm } from "react-hook-form";
import { Guid } from "js-guid";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useLoading } from "../../_contexts/loading-context";
import { useFeedbackDialog } from "@/app/lib/feedback-dialog-provider";
import { notifyError } from "@/app/lib/utils";
import { getErrorMessage } from "@/app/lib/utils/errorUtils";
import { ws_L_OnSiteShopType_Save } from "../../_utils/services/cai-dat-cua-hang.api";
import { useCaiDatCuaHang } from "../../_contexts/cai-dat-cua-hang-context";
import { useCallback } from "react";
import { useLoadShops } from "../../_hooks/use-load-shops";

const ShopAdd = () => {
  const { setLoading } = useLoading();
  const { facilitySelected } = useCaiDatCuaHang();
  const { loadShops } = useLoadShops();
  const { alert } = useFeedbackDialog();
  const formData = useForm<AddShopParams>({
    resolver: zodResolver(AddShopSchema),
    defaultValues: {
      shopTypeId: Guid.newGuid().toString(),
      shopTypeName: "",
      isActive: true,
    },
  });

  const onSubmit = useCallback(
    async (data: AddShopParams) => {
      if (!facilitySelected?.facID) {
        await alert({
          title: "",
          content: "Vui lòng chọn cơ sở",
        });
        return;
      }
      if (data.shopTypeName === "") {
        await alert({
          title: "",
          content: "Chưa nhập tên loại shop",
        });
        formData.setFocus("shopTypeName");
        return;
      }
      setLoading(true);
      try {
        const isSaveSuccess = await ws_L_OnSiteShopType_Save({
          shopTypeId: data.shopTypeId,
          shopTypeName: data.shopTypeName,
          isActive: data.isActive,
        });
        if (isSaveSuccess) {
          await loadShops({ facId: facilitySelected.facID });
          setLoading(false);
          formData.reset();
          formData.setValue("shopTypeId", Guid.newGuid().toString());
        } else {
          setLoading(false);
          await alert({
            title: "",
            content: "Lưu thất bại",
          });
        }
      } catch (error) {
        setLoading(false);
        console.error("ShopAdd.onSubmit", error);
        notifyError(getErrorMessage(error));
      }
    },
    [alert, facilitySelected, formData, loadShops, setLoading],
  );

  return (
    <Form {...formData}>
      <form
        onSubmit={formData.handleSubmit(onSubmit)}
        className="flex flex-col items-center space-y-2 p-2"
      >
        <FormField
          control={formData.control}
          name="shopTypeName"
          render={({ field }) => (
            <FormItem className="w-full">
              <FormControl>
                <Input placeholder="Nhập tên loại shop..." {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        ></FormField>
        <Button type="submit" className="w-full">
          Thêm
        </Button>
      </form>
    </Form>
  );
};

export default ShopAdd;
