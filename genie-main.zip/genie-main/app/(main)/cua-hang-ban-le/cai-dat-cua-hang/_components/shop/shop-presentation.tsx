"use client";

import ShopAdd from "./shop-add";
import ShopList from "./shop-list";

const ShopPresentation = () => {
  return (
    <div className="w-full flex flex-col overflow-hidden flex-1 overflow-y-hidden h-full border-l border-r">
      <section className="w-full flex flex-col overflow-hidden flex-1 overflow-y-hidden h-full border-b">
        <ShopList />
      </section>
      <section>
        <ShopAdd />
      </section>
    </div>
  );
};

export default ShopPresentation;
