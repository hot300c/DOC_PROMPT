"use client";

import { DataTable } from "@/components/ui/dataTable";
import { ColumnDef } from "@tanstack/react-table";
import { L_Product_ListByPermissionStock } from "../_utils/definitions/cai-dat-cua-hang.dto";
import { useProduct } from "../_contexts/product-context";
import { cn } from "@/app/lib/utils";

const COLUMNS: ColumnDef<L_Product_ListByPermissionStock>[] = [
  {
    id: "hospitalCode",
    accessorKey: "hospitalCode",
    header: () => <span title="Mã sản phẩm">Mã SP</span>,
    cell: ({ row }) => (
      <p className="line-clamp-1 min-w-20" title={row.getValue("hospitalCode")}>
        {row.getValue("hospitalCode")}
      </p>
    ),
  },
  {
    id: "productName",
    accessorKey: "productName",
    header: () => <span title="Tên sản phẩm">Tên SP</span>,
    cell: ({ row }) => (
      <p className="line-clamp-1" title={row.getValue("productName")}>
        {row.getValue("productName")}
      </p>
    ),
  },
];

const ProductList = () => {
  const { products, isLoadingDelay } = useProduct();

  return (
    <div className="w-full flex flex-col overflow-hidden flex-1 overflow-y-hidden h-full">
      <DataTable
        columns={COLUMNS}
        data={products}
        className="w-full h-full overflow-auto border-r"
        enablePaging={false}
        enableColumnFilter={true}
        enableScrollTo={false}
      />
      <div
        className={cn(
          "w-full bg-gray-200 rounded h-1.5 overflow-hidden",
          isLoadingDelay ? "block" : "hidden",
        )}
      >
        <div className="bg-blue-500 h-full animate-pulse"></div>
      </div>
    </div>
  );
};

export default ProductList;
