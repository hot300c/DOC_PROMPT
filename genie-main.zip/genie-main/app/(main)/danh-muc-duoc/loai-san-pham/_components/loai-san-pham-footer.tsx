"use client";

import { ELoadingMessages } from "@/app/lib/enums";
import { useFeedbackDialog } from "@/app/lib/feedback-dialog-provider";
import { notifySuccess } from "@/app/lib/utils";
import useLoading from "@/components/loading";
import { Button } from "@/components/ui/button";

import { getErrorMessage } from "@/app/lib/utils/errorUtils";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { ProductTypeRESP } from "../_utils/definitions/loai-san-pham.resp";
import {
  productTypeDelete,
  productTypeSave,
} from "../_utils/services/loai-san-pham.api";

export type LoaiSanPhamFooterProps = {
  selectedLoaiSanPham: ProductTypeRESP | undefined;
  setSelectedLoaiSanPham: (value: ProductTypeRESP | undefined) => void;
};

export const LoaiSanPhamFooter = ({
  selectedLoaiSanPham,
  setSelectedLoaiSanPham,
}: LoaiSanPhamFooterProps) => {
  const { alert, confirm } = useFeedbackDialog();
  const { showLoading, hideLoading } = useLoading();
  const router = useRouter();
  const [productTypeName, setProductTypeName] = useState<string | undefined>(
    undefined,
  );

  useEffect(() => {
    setProductTypeName(selectedLoaiSanPham?.name);
  }, [selectedLoaiSanPham?.name]);

  const validateSaveData = async (): Promise<boolean> => {
    if (!productTypeName) {
      await alert({
        title: "Cảnh báo",
        content: "Vui lòng nhập tên loại!",
      });
      return false;
    }
    if (
      selectedLoaiSanPham?.productTypeID !== 0 &&
      !!selectedLoaiSanPham?.productTypeID
    ) {
      const isReplaceDate = await confirm({
        title: "Cảnh báo",
        content:
          "Bạn đang ghi đè lên dữ liệu cũ. Bạn có đồng ý thực hiện không?",
      });
      if (!isReplaceDate) return false;
    }
    return true;
  };

  const validateDeleteData = async (): Promise<boolean> => {
    if (
      selectedLoaiSanPham?.productTypeID === 0 &&
      !selectedLoaiSanPham?.productTypeID
    ) {
      await alert({
        title: "Cảnh báo",
        content: "Vui lòng chọn dữ liệu xóa!",
      });
      return false;
    } else {
      const isConfirmDelete = await confirm({
        title: "Cảnh báo",
        content: "Bạn có chắc muốn xóa " + productTypeName + " ?",
      });
      if (!isConfirmDelete) return false;
    }
    return true;
  };

  const onHandleSave = async () => {
    const loadingId = showLoading(ELoadingMessages.WAITING);
    try {
      const isValid = await validateSaveData();
      if (!isValid) return;

      const response = await productTypeSave({
        id: selectedLoaiSanPham?.productTypeID ?? 0,
        name: productTypeName!,
      });
      if (response.result !== "Ok") {
        await alert({
          title: "Cảnh báo",
          content: response.result,
        });
        return;
      }
      notifySuccess("Lưu loại sản phẩm  thành công.");
      router.refresh();
    } catch (error) {
      await alert({
        title: "Cảnh báo",
        content:
          "Lưu loại sản phẩm không thành công: " + getErrorMessage(error),
      });
    } finally {
      hideLoading(loadingId);
    }
  };

  const onHandleDelete = async () => {
    const loadingId = showLoading(ELoadingMessages.WAITING);
    try {
      const isValid = await validateDeleteData();
      if (!isValid) return;

      const response = await productTypeDelete({
        id: selectedLoaiSanPham?.productTypeID ?? 0,
      });
      if (response.result !== "Ok") {
        await alert({
          title: "Cảnh báo",
          content: response.result,
        });
        return;
      }
      notifySuccess("Xóa loại sản phẩm  thành công.");
      router.refresh();
    } catch (error) {
      await alert({
        title: "Cảnh báo",
        content:
          "Lưu loại sản phẩm không thành công: " + getErrorMessage(error),
      });
    } finally {
      hideLoading(loadingId);
    }
  };

  return (
    <div className="flex-row w-full">
      <div className="flex items-center mt-1">
        <Label className="whitespace-nowrap mr-4">Tên loại</Label>
        <Input
          className="w-80"
          value={productTypeName}
          onChange={(e) => setProductTypeName(e.target.value)}
        />
      </div>
      <div className="flex flex-row justify-end py-2 gap-2 mr-2">
        <Button
          type="button"
          onClick={() => {
            setProductTypeName("");
            setSelectedLoaiSanPham(undefined);
          }}
        >
          Thêm mới
        </Button>
        <Button type="button" onClick={() => onHandleSave()}>
          Lưu
        </Button>
        <Button type="button" onClick={() => onHandleDelete()}>
          Xóa
        </Button>
      </div>
    </div>
  );
};
