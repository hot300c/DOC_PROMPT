"use client";
import {
  DataTable,
  DataTableColumnHeaderSort,
} from "@/components/ui/dataTable";
import { ColumnDef } from "@tanstack/react-table";
import { useMemo } from "react";
import { ProductTypeRESP } from "../_utils/definitions/loai-san-pham.resp";

export type LoaiSanPhamTableProps = {
  data: ProductTypeRESP[];
  onRowClick: (row: ProductTypeRESP) => void;
  productTypeID: string;
};
const LoaiSanPhamTable = ({
  data,
  onRowClick,
  productTypeID,
}: LoaiSanPhamTableProps) => {
  const columns = useMemo(() => {
    const result: ColumnDef<ProductTypeRESP>[] = [
      {
        id: "name",
        accessorKey: "name",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Tên loại SP" />
        ),
        meta: {
          className: "text-left truncate",
        },
        cell: ({ row }) => (
          <div title={row.original.name}>{row.original.name}</div>
        ),
      },
    ];
    return result;
  }, []);

  const indexScrollTo = useMemo(
    () =>
      productTypeID
        ? data.findIndex((row) => row.productTypeID.toString() == productTypeID)
        : 0,
    [data, productTypeID],
  );

  return (
    <DataTable
      className="w-full overflow-y-auto border flex-1"
      tHeadClass="z-40"
      tRowClass="cursor-pointer"
      columns={columns}
      data={data}
      enableColumnFilter={true}
      enablePaging={false}
      enableGlobalFilter={true}
      placeholderSearch="Nhập để tìm kiếm..."
      enableFooter
      onRowClick={onRowClick}
      indexScrollTo={indexScrollTo}
    ></DataTable>
  );
};

export default LoaiSanPhamTable;
