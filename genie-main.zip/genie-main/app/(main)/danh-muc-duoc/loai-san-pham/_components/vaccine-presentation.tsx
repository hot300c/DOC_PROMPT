"use client";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { useEffect, useState } from "react";
import { ProductTypeRESP } from "../_utils/definitions/loai-san-pham.resp";
import LoaiSanPhamTable from "./loai-san-pham-datatable";
import { LoaiSanPhamFooter } from "./loai-san-pham-footer";

export type LoaiSanPhamPresentationProps = {
  data: ProductTypeRESP[];
};
const LoaiSanPhamPresentation = ({ data }: LoaiSanPhamPresentationProps) => {
  const searchParams = useSearchParams();
  const productTypeID = searchParams.get("productTypeID");
  const router = useRouter();
  const pathname = usePathname();

  const [selectedLoaiSanPham, setSelectedLoaiSanPham] = useState<
    ProductTypeRESP | undefined
  >(undefined);

  useEffect(() => {
    if (!!selectedLoaiSanPham) return;
    if (!productTypeID) {
      setSelectedLoaiSanPham(data[0]);
      return;
    }
    setSelectedLoaiSanPham(
      data.find((item) => item.productTypeID.toString() === productTypeID),
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [data, productTypeID]);

  const onRowClick = (row: ProductTypeRESP) => {
    setSelectedLoaiSanPham(row);
    const query = new URLSearchParams(window.location.search);
    query.set("productTypeID", row.productTypeID.toString());
    router.push(pathname + "?" + query.toString());
  };

  return (
    <div className="flex flex-col flex-1 overflow-y-hidden">
      <LoaiSanPhamTable
        data={data}
        onRowClick={onRowClick}
        productTypeID={productTypeID ?? "0"}
      />
      <div className=" flex overflow-hidden min-h-0">
        <LoaiSanPhamFooter
          selectedLoaiSanPham={selectedLoaiSanPham}
          setSelectedLoaiSanPham={setSelectedLoaiSanPham}
        ></LoaiSanPhamFooter>
      </div>
    </div>
  );
};

export default LoaiSanPhamPresentation;
