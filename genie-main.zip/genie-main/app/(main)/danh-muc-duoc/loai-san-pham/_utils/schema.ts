export type LoaiSanPhamParams = {
  productTypeID: string;
};
