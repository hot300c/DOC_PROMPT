import { getUserSession } from "@/actions/get-user-session";
import * as httpService from "@/app/lib/network/http";
import { ProductTypeRESP } from "../definitions/loai-san-pham.resp";

export async function getProductTypeList(): Promise<ProductTypeRESP[]> {
  try {
    const currentUser = await getUserSession();
    const response = await httpService.post("/DataAccess", [
      {
        category: "QAHosGenericDB",
        command: "ws_L_ProductType_List",
        parameters: {
          FacID: currentUser.facId,
        },
      },
    ]);
    return response.data.table || [];
  } catch (error) {
    return [];
  }
}

export async function productTypeSave({
  id,
  name,
}: {
  id: number;
  name: string;
}): Promise<{ result: string }> {
  const currentUser = await getUserSession();
  const response = await httpService.post("/DataAccess", [
    {
      category: "QAHosGenericDB",
      command: "ws_L_ProductType_Save",
      parameters: {
        ID: id,
        Name: name,
        FacID: currentUser.facId,
      },
    },
  ]);
  return response.data.table[0];
}

export async function productTypeDelete({
  id,
}: {
  id: number;
}): Promise<{ result: string }> {
  const currentUser = await getUserSession();
  const response = await httpService.post("/DataAccess", [
    {
      category: "QAHosGenericDB",
      command: "ws_L_ProductType_Delete",
      parameters: {
        ID: id,
        FacID: currentUser.facId,
      },
    },
  ]);

  return response.data.table[0];
}
