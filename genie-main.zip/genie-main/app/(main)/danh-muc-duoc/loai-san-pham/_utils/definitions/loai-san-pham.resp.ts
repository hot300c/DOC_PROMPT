export type ProductTypeRESP = {
  name: string;
  productTypeID: number;
};
