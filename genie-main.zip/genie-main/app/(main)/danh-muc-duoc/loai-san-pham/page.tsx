import { Suspense } from "react";
import { Loading } from "../../duoc/(base_components)/loading";
import VaccineHeader from "./_components/vaccine-header";
import { getProductTypeList } from "./_utils/services/loai-san-pham.api";
import LoaiSanPhamPresentation from "./_components/vaccine-presentation";

export default async function Page(props: {}) {
  const data = await getProductTypeList();
  return (
    <div className="flex flex-col w-full h-full space-y-2">
      <VaccineHeader />
      <Suspense fallback={<Loading />}>
        <LoaiSanPhamPresentation data={data} />
      </Suspense>
    </div>
  );
}
