import { ModalPrintProvider } from "@/app/lib/modal-print-provider";
import { Suspense } from "react";
import { Loading } from "../../duoc/(base_components)/loading";
import VaccineContainer from "./_components/vaccine-container";
import VaccineHeader from "./_components/vaccine-header";
import { VaccineData } from "./_utils/definitions/vaccine.resp";
import { VaccineFilterParams } from "./_utils/schema/schema";
import { fetchDataVaccine } from "./_utils/services/vaccine.api";

export default async function Page(props: {
  searchParams?: Promise<VaccineFilterParams>;
}) {
  const searchParams = await props.searchParams;
  const vaccineData: VaccineData = await fetchDataVaccine(
    Number(searchParams?.productID) ?? 0,
  );
  return (
    <ModalPrintProvider>
      <div className="flex flex-col w-full h-full space-y-2">
        <VaccineHeader />
        <Suspense fallback={<Loading />}>
          <VaccineContainer vaccineData={vaccineData} />
        </Suspense>
      </div>
    </ModalPrintProvider>
  );
}
