import { VaccineData, VaccineRESP } from "../_utils/definitions/vaccine.resp";
import VaccinePresentation from "./vaccine-presentation";

export type VaccineContainerProps = {
  vaccineData: VaccineData;
};
const VaccineContainer = async ({ vaccineData }: VaccineContainerProps) => {
  const data: VaccineRESP[] = vaccineData.data;
  return (
    <VaccinePresentation
      data={data}
      vaccineData={vaccineData}
    ></VaccinePresentation>
  );
};

export default VaccineContainer;
