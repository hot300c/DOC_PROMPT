"use client";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { useEffect, useState } from "react";
import { VaccineData, VaccineRESP } from "../_utils/definitions/vaccine.resp";
import { VaccineGiaTab } from "./tab/gia/vaccince-gia-tab";
import { VaccineSanPhamTab } from "./tab/san-pham/vaccince-san-pham-tab";
import VaccineTable from "./vaccine-datatable";

export type VaccinePresentationProps = {
  data: VaccineRESP[];
  vaccineData: VaccineData;
};
const VaccinePresentation = ({
  data,
  vaccineData,
}: VaccinePresentationProps) => {
  const searchParams = useSearchParams();
  const productID = searchParams.get("productID");
  const router = useRouter();
  const pathname = usePathname();
  const [selectedVaccine, setSelectedVaccine] = useState<
    VaccineRESP | undefined
  >(undefined);
  useEffect(() => {
    if (!!selectedVaccine) return;
    if (!productID) {
      setSelectedVaccine(data[0]);
      return;
    }
    setSelectedVaccine(
      data.find((item) => item.productID.toString() === productID),
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [data, productID]);

  const onRowClick = (row: VaccineRESP) => {
    setSelectedVaccine(row);
    const query = new URLSearchParams(window.location.search);
    query.set("productID", row.productID.toString());
    router.push(pathname + "?" + query.toString());
  };

  return (
    <div className="flex flex-col flex-1 w-full h-full overflow-hidden">
      <div className="flex-[2] flex overflow-hidden">
        <VaccineTable
          data={data}
          onRowClick={onRowClick}
          productID={productID}
        />
      </div>
      <div className="flex-[1] flex overflow-hidden min-h-0">
        <Tabs
          defaultValue="san-pham"
          className="flex flex-col items-start overflow-hidden w-full h-full"
        >
          <TabsList>
            <TabsTrigger value="san-pham">Sản phẩm</TabsTrigger>
            <TabsTrigger value="gia">Giá</TabsTrigger>
          </TabsList>
          <div className="flex-1 min-h-0 w-full overflow-hidden">
            <TabsContent value="san-pham" className="h-full">
              <VaccineSanPhamTab
                vaccineData={vaccineData}
                selectedVaccine={selectedVaccine}
                setSelectedVaccine={setSelectedVaccine}
                data={data}
              ></VaccineSanPhamTab>
            </TabsContent>
            <TabsContent value="gia" className="h-full">
              <VaccineGiaTab selectedVaccine={selectedVaccine}></VaccineGiaTab>
            </TabsContent>
          </div>
        </Tabs>
      </div>
    </div>
  );
};

export default VaccinePresentation;
