"use client";

import { DATE_FORMAT, ELoadingMessages } from "@/app/lib/enums";
import { useFeedbackDialog } from "@/app/lib/feedback-dialog-provider";
import { notifySuccess } from "@/app/lib/utils";
import { exportToExcel, TableConfig } from "@/app/lib/utils/exportToExcel ";
import useLoading from "@/components/loading";
import { Button } from "@/components/ui/button";
import { format } from "date-fns";
import {
  ProductPriceListRESP,
  VaccineRESP,
} from "../../../_utils/definitions/vaccine.resp";
import { VaccineGiaFormData } from "../../../_utils/schema/vaccine-gia-chema";
import { productPriceSave } from "../../../_utils/services/vaccine.api";

export type VaccineGiaFooterProps = {
  selectedVaccine: VaccineRESP | undefined;
  handleFetchDataGiaVaccine: (productID: number) => Promise<void>;
  formData: VaccineGiaFormData | undefined;
  onHandleAddNew: () => void;
  productPriceList: ProductPriceListRESP[];
};

export const VaccineGiaFooter = ({
  selectedVaccine,
  handleFetchDataGiaVaccine,
  formData,
  onHandleAddNew,
  productPriceList,
}: VaccineGiaFooterProps) => {
  const { alert } = useFeedbackDialog();
  const { showLoading, hideLoading } = useLoading();

  const validateData = async (
    formData: VaccineGiaFormData | undefined,
  ): Promise<boolean> => {
    if (!formData) return false;
    if (!selectedVaccine?.productID) {
      await alert({
        title: "Cảnh báo",
        content: "Vui lòng nhập thông tin sản phẩm!",
      });
      return false;
    }
    if (!formData.hospitalPrice) {
      await alert({
        title: "Cảnh báo",
        content: "Chưa nhập giá",
      });
      return false;
    }
    if (!formData.effFrom) {
      await alert({
        title: "Cảnh báo",
        content: "Chọn ngày bắt đầu áp dụng giá",
      });
      return false;
    }
    if ((formData.medicarePrice ?? 0).toString().length > 14) {
      await alert({
        title: "Cảnh báo",
        content:
          "Giá kê khai đã vượt số lượng tối đa là 14, vui lòng kiểm tra lại!",
      });
      return false;
    }
    return true;
  };

  const onSubmit = async (formData: VaccineGiaFormData | undefined) => {
    const loadingId = showLoading(ELoadingMessages.WAITING);
    try {
      const isValid = await validateData(formData);
      if (!isValid) return;

      await productPriceSave({
        params: formData!,
        productID: selectedVaccine?.productID!,
      });

      notifySuccess("Lưu sản phẩm vaccine thành công.");
      await handleFetchDataGiaVaccine(selectedVaccine?.productID ?? 0);
    } catch (error) {
    } finally {
      hideLoading(loadingId);
    }
  };

  const onExportData = async () => {
    const tableConfig: TableConfig = {
      columns: {
        STT: { width: 5, alignment: "center" },
        "Đơn giá": { width: 15, alignment: "center" },
        "Giá kê khai": { width: 15, alignment: "center" },
        "Từ ngày": { width: 20, alignment: "left" },
        "Đến ngày": { width: 20, alignment: "center" },
      },
      data:
        !!productPriceList && productPriceList.length > 0
          ? productPriceList.map((row, index) => [
              index + 1,
              Number(row.hospitalPrice),
              Number(row.medicarePrice),
              format(row.effFrom, DATE_FORMAT.MMDDYYYY),
              !!row.effThru ? format(row.effThru, DATE_FORMAT.MMDDYYYY) : "",
            ])
          : [],
      sheetName: "Vaccine Giá",
      fileName: `VaccineGia.xlsx`,
    };
    await exportToExcel(tableConfig);
  };

  return (
    <div className="flex flex-row justify-between py-2">
      <div>
        <Button type="button" onClick={onExportData}>
          Xuất excel
        </Button>
      </div>
      <div className="flex flex-row gap-2 mr-2">
        <Button type="button" onClick={onHandleAddNew}>
          Thêm mới
        </Button>
        <Button type="button" onClick={() => onSubmit(formData)}>
          Lưu
        </Button>
      </div>
    </div>
  );
};
