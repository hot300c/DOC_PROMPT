"use client";

import { ELoadingMessages } from "@/app/lib/enums";
import { useFeedbackDialog } from "@/app/lib/feedback-dialog-provider";
import { notifySuccess } from "@/app/lib/utils";
import { getErrorMessage } from "@/app/lib/utils/errorUtils";
import useLoading from "@/components/loading";
import { MultiSelect } from "@/components/select/multi-select";
import { Select } from "@/components/select/select";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { selectBaseSetting } from "@/redux/selectors";
import { useAppSelector } from "@/redux/store";
import { zodResolver } from "@hookform/resolvers/zod";
import { useRouter } from "next/navigation";
import { useEffect, useMemo, useState } from "react";
import { useForm } from "react-hook-form";
import { CommonRESP } from "../../../../shared/_utils/definitions/response";
import {
  DinhNghiaLieuDungRESP,
  MaDungChungRESP,
  NuocSanXuatRESP,
  VaccineData,
  VaccineRESP,
  VendorRESP,
} from "../../../_utils/definitions/vaccine.resp";
import {
  VaccineSanPhamFormData,
  VaccineSanPhamSchema,
} from "../../../_utils/schema/vaccine-san-pham-chema";
import { productDelete } from "../../../_utils/services/vaccine.api";
import HangSanXuatComboBox from "../../combobox/hang-san-xuat-combobox";
import LieuDungComboBox from "../../combobox/lieu-dung-combobox";
import MaDungChungComboBox from "../../combobox/ma-dung-chung-combobox";
import NhaCungCapComboBox from "../../combobox/nha-cung-cap-combobox";
import NuocSanXuatComboBox from "../../combobox/nuoc-san-xuat-combobox";
import { PrdoductVaccineFooter } from "./product-vaccine-footer";

export type VaccineSanPhamTabModalProps = {
  vaccineData: VaccineData;
  selectedVaccine: VaccineRESP | undefined;
  setSelectedVaccine: (vaccine: VaccineRESP | undefined) => void;
  data: VaccineRESP[];
};

export const VaccineSanPhamTab = ({
  vaccineData,
  selectedVaccine,
  setSelectedVaccine,
  data,
}: VaccineSanPhamTabModalProps) => {
  const { alert, confirm } = useFeedbackDialog();
  const { showLoading, hideLoading } = useLoading();
  const router = useRouter();
  const baseSetting = useAppSelector(selectBaseSetting);

  const coQuanLyGiaTheoKho =
    baseSetting.find((item) => item.name === "CoQuanLyGiaTheoKho")?.value ===
    "Y";
  const [countrySelect, setCountrySelect] = useState<
    NuocSanXuatRESP | undefined
  >(undefined);

  const [hangSanXuatSelect, setHangSanXuatSelect] = useState<
    CommonRESP | undefined
  >(undefined);

  const [maDungChungSelect, setMaDungChungSelect] = useState<
    MaDungChungRESP | undefined
  >(undefined);

  const [nhaCungCapSelect, setNhaCungCapSelect] = useState<
    VendorRESP | undefined
  >(undefined);

  const [lieuDungSelect, setLieuDungSelect] = useState<
    DinhNghiaLieuDungRESP | undefined
  >(undefined);

  const defaultFormData: VaccineSanPhamFormData = {
    productID: undefined,
    hospitalCode: "",
    hospitalName: "",
    formula: undefined,
    content: "",
    usage: "",
    displayPackage: "",
    unitID: "0",
    isThuocHiem: "0",
    isUsing: "0",
    nuocSanXuat: undefined,
    hangSanXuat: undefined,
    duongDung: "0",
    isBaoMat: "0",
    nhomBenhID: undefined,
    maChung: "",
    isGuiTinNhanVaccine: false,
    isVaccineHiem: "0",
    maDuocQG: "",
    nccID: undefined,
    idDinhNghiaLieuDung: undefined,
    idLoaiSanPham: undefined,
    productTypeID: undefined,
  };

  const mapVaccineToFormData = (
    vaccine: VaccineRESP | undefined,
  ): VaccineSanPhamFormData => {
    if (!vaccine) return {} as VaccineSanPhamFormData;
    return Object.fromEntries(
      Object.keys(defaultFormData).map((key) => {
        let value =
          vaccine[key as keyof VaccineRESP] ??
          defaultFormData[key as keyof VaccineSanPhamFormData];

        // xử lý các field đặc biệt cần convert
        if (
          key === "isThuocHiem" ||
          key === "isUsing" ||
          key === "isBaoMat" ||
          key === "isVaccineHiem"
        ) {
          value = vaccine[key as keyof VaccineRESP] ? "1" : "0";
        }
        return [key, value];
      }),
    ) as VaccineSanPhamFormData;
  };

  const optionsLoaiSanPham = useMemo(() => {
    return vaccineData.dugs.map((item) => ({
      label: item.name,
      value: item.id.toString(),
    }));
  }, [vaccineData.dugs]);

  const productTypes = useMemo(() => {
    return vaccineData.productTypes.map((item) => ({
      label: item.name,
      value: item.productTypeID.toString(),
    }));
  }, [vaccineData.productTypes]);

  const nhomBenhs = useMemo(() => {
    return vaccineData.nhomBenhVaccines.map((item) => ({
      label: item.tenNhomBenh,
      value: item.id.toString(),
    }));
  }, [vaccineData.nhomBenhVaccines]);

  const fomulars = useMemo(() => {
    return vaccineData.formulas.map((item) => ({
      label: item.ten,
      value: item.ma.toString(),
    }));
  }, [vaccineData.formulas]);

  const donViTinh = useMemo(() => {
    return vaccineData.donViDungs.map((item) => ({
      label: item.unitName,
      value: item.unitID.toString(),
    }));
  }, [vaccineData.donViDungs]);

  const duongDungs = useMemo(() => {
    return vaccineData.cachDungThuocs.map((item) => ({
      label: item.comboValue ?? "",
      value: (item.comboValue ?? 0).toString(),
    }));
  }, [vaccineData.cachDungThuocs]);

  useEffect(() => {
    if (!!selectedVaccine?.nuocSanXuat) {
      const country = vaccineData.nuocSanXuats.find(
        (item) => item.countryID === selectedVaccine.nuocSanXuat,
      );
      handleNuocSanXuatSelect(country);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedVaccine?.nuocSanXuat, vaccineData.nuocSanXuats]);

  const handleNuocSanXuatSelect = (country?: NuocSanXuatRESP) => {
    setCountrySelect(country);
    form.setValue("nuocSanXuat", country?.countryID);
  };

  useEffect(() => {
    if (!!selectedVaccine?.hangSanXuat) {
      const hangSanXuat = vaccineData.hangSanXuats.find(
        (item) => item.id === selectedVaccine.hangSanXuat,
      );
      handleHangSanXuatSelect(hangSanXuat);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedVaccine?.hangSanXuat, vaccineData.hangSanXuats]);

  const handleHangSanXuatSelect = (country?: CommonRESP) => {
    setHangSanXuatSelect(country);
    form.setValue("hangSanXuat", country?.id);
  };

  useEffect(() => {
    if (!!selectedVaccine?.maChung) {
      const maChung = vaccineData.maDungChungs.find(
        (item) => item.maChung === selectedVaccine.maChung,
      );
      setMaDungChungSelect(maChung);
    }
  }, [selectedVaccine?.maChung, vaccineData.maDungChungs]);

  const handleMaDungChungSelect = (maDungChung?: MaDungChungRESP) => {
    setMaDungChungSelect(maDungChung);
    form.setValue("maChung", maDungChung?.maChung);
  };

  useEffect(() => {
    if (!!selectedVaccine?.iD_NCC) {
      const nhaCungCap = vaccineData.vendors.find(
        (item) => item.id === selectedVaccine.iD_NCC,
      );
      setNhaCungCapSelect(nhaCungCap);
    }
  }, [selectedVaccine?.iD_NCC, vaccineData.vendors]);

  const handleNhaCungCapSelect = (nhaCungCap?: VendorRESP) => {
    setNhaCungCapSelect(nhaCungCap);
    form.setValue("nccID", nhaCungCap?.id);
  };

  useEffect(() => {
    if (!!selectedVaccine?.idDinhNghiaLieuDung) {
      const nhaCungCap = vaccineData.dinhNghiaLieuDungs.find(
        (item) => item.id === selectedVaccine.idDinhNghiaLieuDung,
      );
      setLieuDungSelect(nhaCungCap);
    }
  }, [selectedVaccine?.idDinhNghiaLieuDung, vaccineData.dinhNghiaLieuDungs]);

  const handleLieuDungSelect = (lieDung?: DinhNghiaLieuDungRESP) => {
    setLieuDungSelect(lieDung);
    form.setValue("idDinhNghiaLieuDung", lieDung?.id);
  };

  const form = useForm<VaccineSanPhamFormData>({
    resolver: zodResolver(VaccineSanPhamSchema),
    defaultValues: mapVaccineToFormData(selectedVaccine),
  });

  // Cập nhật form khi selectedVaccine thay đổi
  useEffect(() => {
    form.reset(mapVaccineToFormData(selectedVaccine));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedVaccine]);

  const onHandleAddNew = () => {
    form.reset(defaultFormData);
    setCountrySelect(undefined);
    setHangSanXuatSelect(undefined);
    setMaDungChungSelect(undefined);
    setNhaCungCapSelect(undefined);
    setLieuDungSelect(undefined);
    setSelectedVaccine(undefined);
  };

  const onHandleDelete = async () => {
    if (!selectedVaccine) return;
    const isConfirmDelete = await confirm({
      title: "Xác nhận",
      content:
        "Bạn có chắc chắn muốn xóa sản phẩm " +
        selectedVaccine.hospitalName +
        "này không?",
    });
    if (!isConfirmDelete) return;
    const loadingId = showLoading(ELoadingMessages.WAITING);

    try {
      await productDelete(selectedVaccine.productID, coQuanLyGiaTheoKho);
      notifySuccess("Xóa sản phẩm vaccine thành công.");
      form.reset(defaultFormData);
      router.refresh();
    } catch (error) {
      await alert({
        title: "Lỗi",
        content: "Xóa sản phẩm thất bại: " + getErrorMessage(error),
      });
      return;
    } finally {
      hideLoading(loadingId);
    }
  };

  return (
    <div className="px-4">
      <Form {...form}>
        <form className="flex flex-col w-full">
          <div className="flex-1 flex min-h-0 gap-2">
            <div className="w-1/3">
              <div className="flex items-center">
                <Label className="whitespace-nowrap w-44 ">Mã</Label>
                <FormField
                  disabled={
                    form.getValues("productID") === undefined ||
                    form.getValues("productID") === 0
                  }
                  control={form.control}
                  name="hospitalCode"
                  render={({ field }) => (
                    <FormItem className="flex items-center gap-2 w-full">
                      <FormControl className="flex-1">
                        <Input
                          {...field}
                          onFocus={(e) => {
                            e.target.select();
                          }}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <div className="flex items-center mt-1">
                <Label className="whitespace-nowrap w-44">Tên</Label>
                <FormField
                  control={form.control}
                  name="hospitalName"
                  render={({ field }) => (
                    <FormItem className="flex items-center gap-2 w-full">
                      <FormControl className="w-full">
                        <Input
                          {...field}
                          onFocus={(e) => {
                            e.target.select();
                          }}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <div className="flex items-center mt-1">
                <Label className="whitespace-nowrap w-44 ">Loại sản phẩm</Label>
                <FormField
                  control={form.control}
                  name="idLoaiSanPham"
                  render={({ field }) => (
                    <Select
                      placeholder="Chọn loại sản phẩm"
                      className="w-full"
                      disabled={true}
                      classNameSelectList="max-h-96"
                      value={field.value?.toString() || "1"}
                      classNamePopover="w-full"
                      onChange={(value) => {
                        field.onChange(value);
                      }}
                      options={optionsLoaiSanPham}
                    />
                  )}
                />
              </div>
              <div className="flex items-center mt-1">
                <Label className="whitespace-nowrap w-44">Nước sản xuất</Label>
                <NuocSanXuatComboBox
                  nuocSanXuats={vaccineData.nuocSanXuats}
                  selectedCountryID={countrySelect?.countryID.toString()}
                  handleCountrySelect={(country) => {
                    handleNuocSanXuatSelect(country);
                  }}
                />
              </div>
              <div className="flex items-center mt-1">
                <Label className="whitespace-nowrap w-44">Nhà sản xuất</Label>
                <HangSanXuatComboBox
                  hangSanXuats={vaccineData.hangSanXuats}
                  selectedHangSanXuatID={hangSanXuatSelect?.id.toString()}
                  handleHangSanXuatSelect={(hangSanXuat) => {
                    handleHangSanXuatSelect(hangSanXuat || undefined);
                  }}
                />
              </div>
              <div className="flex items-center mt-1">
                <Label className="whitespace-nowrap w-44">ĐVT</Label>
                <FormField
                  control={form.control}
                  name="unitID"
                  render={({ field }) => (
                    <Select
                      placeholder="--Chọn đơn vị tính--"
                      className="w-full"
                      classNameSelectList="max-h-96"
                      value={field.value?.toString()}
                      classNamePopover="w-full"
                      onChange={(value) => {
                        field.onChange(value);
                      }}
                      options={donViTinh}
                    />
                  )}
                />
              </div>
            </div>
            <div className="w-1/3">
              <div className="flex items-center">
                <Label className="whitespace-nowrap mr-12 ">
                  Loại danh mục
                </Label>
                <FormField
                  control={form.control}
                  name="productTypeID"
                  render={({ field }) => (
                    <Select
                      placeholder="Chọn loại sản phẩm"
                      className="w-full"
                      disabled={true}
                      classNameSelectList="max-h-96"
                      value={field.value?.toString() || "17"}
                      classNamePopover="w-full"
                      onChange={(value) => {
                        field.onChange(value);
                      }}
                      options={productTypes}
                    />
                  )}
                />
              </div>
              <div className="flex items-center mt-1">
                <Label className="whitespace-nowrap mr-16 ">Nhóm bệnh</Label>
                <FormField
                  control={form.control}
                  name="nhomBenhID"
                  render={({ field }) => (
                    <MultiSelect
                      value={field.value?.toString().split(",") ?? []}
                      className="w-full"
                      classNamePopover="w-90"
                      options={nhomBenhs}
                      onChange={(values) => {
                        field.onChange(values.join(","));
                      }}
                    />
                  )}
                />
              </div>
              <div className="flex justify-between">
                <FormField
                  control={form.control}
                  name="dosageForm"
                  render={({ field }) => (
                    <FormItem className="flex items-center gap-2 mr-2">
                      <FormLabel className="whitespace-nowrap mr-11">
                        Dạng bào chế
                      </FormLabel>
                      <FormControl className="flex-1">
                        <Input
                          {...field}
                          onFocus={(e) => {
                            e.target.select();
                          }}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="usage"
                  render={({ field }) => (
                    <FormItem className="flex items-center gap-2">
                      <FormLabel className="whitespace-nowrap mr-5">
                        Cách dùng
                      </FormLabel>
                      <FormControl className="flex-1">
                        <Input
                          {...field}
                          onFocus={(e) => {
                            e.target.select();
                          }}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="content"
                render={({ field }) => (
                  <FormItem className="flex items-center gap-2">
                    <FormLabel className="whitespace-nowrap w-32">
                      Hàm lượng
                    </FormLabel>
                    <FormControl className="flex-1">
                      <Input
                        {...field}
                        onFocus={(e) => {
                          e.target.select();
                        }}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="flex items-center mt-1">
                <Label className="whitespace-nowrap mr-11 ">
                  Mã dùng chung
                </Label>
                <div className="w-1/2 mr-2">
                  <MaDungChungComboBox
                    maDungChungs={vaccineData.maDungChungs}
                    selectedMaDungChungID={maDungChungSelect?.maChung.toString()}
                    handleMaDungChungSelect={(maDungChung) => {
                      handleMaDungChungSelect(maDungChung || undefined);
                    }}
                  />
                </div>
                <FormField
                  control={form.control}
                  name="maChung"
                  render={({ field }) => (
                    <FormItem className="flex items-center gap-2">
                      <FormControl className="flex-1">
                        <Input
                          {...field}
                          onFocus={(e) => {
                            e.target.select();
                          }}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <div className="flex items-center mt-1">
                <Label className="whitespace-nowrap mr-11 ">
                  Nhà nhập khẩu
                </Label>
                <NhaCungCapComboBox
                  vendors={vaccineData.vendors}
                  selectedNhaCungCapID={nhaCungCapSelect?.id.toString()}
                  handleNhaCungCapSelect={(nhaCungCap) => {
                    handleNhaCungCapSelect(nhaCungCap || undefined);
                  }}
                />
              </div>
            </div>
            <div className="w-1/3">
              <div className="flex items-center">
                <div className="flex items-center w-1/2 mr-2">
                  <FormField
                    control={form.control}
                    name="maDuocQG"
                    render={({ field }) => (
                      <FormItem className="flex items-center gap-2">
                        <FormLabel className="whitespace-nowrap mr-3">
                          Mã dược QG
                        </FormLabel>
                        <FormControl className="flex-1">
                          <Input
                            {...field}
                            onFocus={(e) => {
                              e.target.select();
                            }}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                <div className="flex items-center w-1/2 ">
                  <FormField
                    control={form.control}
                    name="displayPackage"
                    render={({ field }) => (
                      <FormItem className="flex items-center gap-2">
                        <FormLabel className="whitespace-nowrap mr-8">
                          Quy cách đ/gói
                        </FormLabel>
                        <FormControl className="flex-1">
                          <Input
                            {...field}
                            onFocus={(e) => {
                              e.target.select();
                            }}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </div>
              <div className="flex items-center mt-1">
                <Label className="whitespace-nowrap mr-9">Hoạt chất</Label>
                <FormField
                  control={form.control}
                  name="formula"
                  render={({ field }) => (
                    <MultiSelect
                      value={!!field.value ? field.value?.split(",") : []}
                      className="w-full"
                      classNamePopover="w-90"
                      options={fomulars}
                      onChange={(values) => {
                        field.onChange(values.join(","));
                      }}
                    />
                  )}
                />
              </div>
              <div className="flex items-center  mt-1">
                <Label className="whitespace-nowrap mr-6">Đường dùng</Label>
                <FormField
                  control={form.control}
                  name="duongDung"
                  render={({ field }) => (
                    <Select
                      placeholder="--Chọn đường dùng --"
                      className="w-full"
                      classNameSelectList="max-h-96"
                      value={field.value?.toString() || "0"}
                      classNamePopover="w-full"
                      onChange={(value) => {
                        field.onChange(value);
                      }}
                      options={duongDungs}
                    />
                  )}
                />
              </div>
              <div className="mt-1 flex justify-between">
                <FormField
                  control={form.control}
                  name="isThuocHiem"
                  render={({ field }) => (
                    <FormItem className="inline-flex items-center space-y-0">
                      <FormControl>
                        <div className="flex items-center gap-2">
                          <FormLabel className="whitespace-nowrap mr-6 ">
                            Thuốc hiếm
                          </FormLabel>
                          <Checkbox
                            checked={field.value === "1"}
                            onCheckedChange={(checked) =>
                              field.onChange(checked ? "1" : "0")
                            }
                          />
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                ></FormField>
                <FormField
                  control={form.control}
                  name="isBaoMat"
                  render={({ field }) => (
                    <FormItem className="inline-flex items-center space-y-0">
                      <FormControl>
                        <div className="flex items-center gap-2">
                          <FormLabel className="whitespace-nowrap mr-6 ">
                            Bảo mật
                          </FormLabel>
                          <Checkbox
                            checked={field.value === "1"}
                            onCheckedChange={(checked) =>
                              field.onChange(checked ? "1" : "0")
                            }
                          />
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                ></FormField>
                <FormField
                  control={form.control}
                  name="isVaccineHiem"
                  render={({ field }) => (
                    <FormItem className="inline-flex items-center space-y-0">
                      <FormControl>
                        <div className="flex items-center gap-2">
                          <FormLabel className="whitespace-nowrap mr-6 ">
                            Vaccine Hiếm
                          </FormLabel>
                          <Checkbox
                            checked={field.value === "1"}
                            onCheckedChange={(checked) =>
                              field.onChange(checked ? "1" : "0")
                            }
                          />
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                ></FormField>
              </div>
              <div className="mt-1 flex justify-between">
                <FormField
                  control={form.control}
                  name="isGuiTinNhanVaccine"
                  render={({ field }) => (
                    <FormItem className="inline-flex items-center space-y-0">
                      <FormControl>
                        <div className="flex items-center gap-2">
                          <FormLabel className="whitespace-nowrap mr-1 ">
                            Không nhắn tin
                          </FormLabel>
                          <Checkbox
                            checked={field.value ?? false}
                            onCheckedChange={(checked) =>
                              field.onChange(checked)
                            }
                          />
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                ></FormField>
                <FormField
                  control={form.control}
                  name="isUsing"
                  render={({ field }) => (
                    <FormItem className="inline-flex items-center space-y-0">
                      <FormControl>
                        <div className="flex items-center gap-2">
                          <FormLabel className="whitespace-nowrap mr-6 ">
                            Sử dụng
                          </FormLabel>
                          <Checkbox
                            checked={field.value === "1"}
                            onCheckedChange={(checked) =>
                              field.onChange(checked ? "1" : "0")
                            }
                          />
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                ></FormField>
              </div>
              <div className="flex items-center mt-1">
                <Label className="whitespace-nowrap mr-10 ">Liều dùng</Label>
                <LieuDungComboBox
                  dinhNghiaLieuDungs={vaccineData.dinhNghiaLieuDungs}
                  selectedLieuDungID={lieuDungSelect?.id.toString()}
                  handleLieuDungSelect={(lieuDung) => {
                    handleLieuDungSelect(lieuDung || undefined);
                  }}
                />
              </div>
            </div>
          </div>
          <PrdoductVaccineFooter
            onHandleAddNew={onHandleAddNew}
            formData={form.getValues()}
            onHandleDelete={onHandleDelete}
            data={data}
          ></PrdoductVaccineFooter>
        </form>
      </Form>
    </div>
  );
};
