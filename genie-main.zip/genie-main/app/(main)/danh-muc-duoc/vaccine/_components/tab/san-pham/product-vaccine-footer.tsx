"use client";

import { ELoadingMessages } from "@/app/lib/enums";
import { useFeedbackDialog } from "@/app/lib/feedback-dialog-provider";
import { notifySuccess } from "@/app/lib/utils";
import { getErrorMessage } from "@/app/lib/utils/errorUtils";
import { exportToExcel, TableConfig } from "@/app/lib/utils/exportToExcel ";
import useLoading from "@/components/loading";
import { Button } from "@/components/ui/button";
import { useRouter } from "next/navigation";
import { VaccineRESP } from "../../../_utils/definitions/vaccine.resp";
import { VaccineSanPhamFormData } from "../../../_utils/schema/vaccine-san-pham-chema";
import {
  nhomBenhVaccineDeleteQuyen,
  productNhomBenhVaccineSaveQuyen,
  productVaccineSave,
} from "../../../_utils/services/vaccine.api";

export type PrdoductVaccineFooterProps = {
  formData: VaccineSanPhamFormData;
  onHandleAddNew: () => void;
  onHandleDelete: () => Promise<void>;
  data: VaccineRESP[];
};

export const PrdoductVaccineFooter = ({
  formData,
  onHandleAddNew,
  onHandleDelete,
  data,
}: PrdoductVaccineFooterProps) => {
  const { alert, confirm } = useFeedbackDialog();
  const { showLoading, hideLoading } = useLoading();
  const router = useRouter();

  const validateData = async (
    formData: VaccineSanPhamFormData,
  ): Promise<boolean> => {
    if (!formData.nhomBenhID) {
      await alert({
        title: "Cảnh báo",
        content: "Chưa chọn nhóm bệnh.",
      });
      return false;
    }
    if (!formData.hospitalName) {
      await alert({
        title: "Cảnh báo",
        content: "Chưa nhập tên thuốc.",
      });
      return false;
    }
    if (!formData.duongDung) {
      await alert({
        title: "Cảnh báo",
        content: "Chưa nhập đường dùng.",
      });
      return false;
    }
    if (!formData.unitID) {
      await alert({
        title: "Cảnh báo",
        content: "Chưa nhập đơn vị tính.",
      });
      return false;
    }
    if (!formData.maChung) {
      await alert({
        title: "Cảnh báo",
        content: "Chưa nhập mã chung.",
      });
      return false;
    }
    if (formData.productID != 0 && !!formData.productID) {
      const isConfirmReplaceProduct = await confirm({
        title: "Cảnh báo",
        content:
          "Bạn đang ghi đè lên dữ liệu cũ. Bạn có đồng ý thực hiện không?",
      });
      if (!isConfirmReplaceProduct) return false;
    }
    return true;
  };

  const onSubmit = async (formData: VaccineSanPhamFormData) => {
    const loadingId = showLoading(ELoadingMessages.WAITING);
    try {
      const isValid = await validateData(formData);
      if (!isValid) return;
      const isPrdoductVaccineFooter =
        await handlePrdoductVaccineFooter(formData);
      if (!isPrdoductVaccineFooter) return;

      const isNhomBenhVaccineDeleteQuyen =
        await handleNhomBenhVaccineDeleteQuyen(formData);
      if (!isNhomBenhVaccineDeleteQuyen) return;

      const isProductNhomBenhVaccineSaveQuyen =
        await handleProductNhomBenhVaccineSaveQuyen(formData);
      if (!isProductNhomBenhVaccineSaveQuyen) return;

      notifySuccess("Lưu sản phẩm vaccine thành công.");
      router.refresh();
    } catch (error) {
    } finally {
      hideLoading(loadingId);
    }
  };

  const handlePrdoductVaccineFooter = async (
    formData: VaccineSanPhamFormData,
  ): Promise<boolean> => {
    try {
      await productVaccineSave(formData);
      return true;
    } catch (error) {
      await alert({
        title: "Lỗi",
        content: "Lưu sản phẩm vaccine thất bại.",
      });
      return false;
    }
  };

  const handleNhomBenhVaccineDeleteQuyen = async (
    formData: VaccineSanPhamFormData,
  ): Promise<boolean> => {
    try {
      await nhomBenhVaccineDeleteQuyen(formData.maChung!);
      return true;
    } catch (error) {
      await alert({
        title: "Lỗi",
        content: "Xóa nhóm bệnh vaccine thất bại: " + getErrorMessage(error),
      });
      return false;
    }
  };

  const handleProductNhomBenhVaccineSaveQuyen = async (
    formData: VaccineSanPhamFormData,
  ): Promise<boolean> => {
    try {
      await productNhomBenhVaccineSaveQuyen(
        formData.maChung!,
        formData.nhomBenhID?.toString().split(","),
      );
      return true;
    } catch (error) {
      await alert({
        title: "Lỗi",
        content:
          "Lưu sản phẩm nhóm bệnh vaccine thất bại: " + getErrorMessage(error),
      });
      return false;
    }
  };
  const exportData = async (data: VaccineRESP[]) => {
    const tableConfig: TableConfig = {
      columns: {
        "Mã chung": { width: 10, alignment: "left" },
        "Mã SP": { width: 20, alignment: "left" },
        "Tên SP": { width: 30, alignment: "left" },
        "Hàm lượng": { width: 15, alignment: "left" },
        "Hoạt chất": { width: 15, alignment: "left" },
        ĐVT: { width: 10, alignment: "left" },
        "Đường dùng": { width: 20, alignment: "left" },
        "Nước SX": { width: 15, alignment: "left" },
        "Hãng SX": { width: 15, alignment: "left" },
        "Nhóm bệnh": { width: 25, alignment: "left" },
        "Thuốc hiếm": { width: 15, alignment: "left" },
        "Bảo mật": { width: 15, alignment: "left" },
        "Sử dụng": { width: 15, alignment: "left" },
        "Thay đổi gầm nhất": { width: 30, alignment: "left" },
        "Vaccine hiếm": { width: 15, alignment: "left" },
      },
      data:
        data && data.length > 0
          ? data.map((row) => [
              row.maChung,
              row.hospitalCode,
              row.hospitalName,
              row.content,
              row.formula,
              row.unitName,
              row.duongDung,
              row.countryName,
              row.hangsanxuat1,
              row.tenNhomBenh,
              row.isThuocHiem ? "Checked" : "Unchecked",
              row.isBaoMat ? "Checked" : "Unchecked",
              row.isUsing ? "Checked" : "Unchecked",
              row.modifiedByUser,
              row.isVaccineHiem ? "Checked" : "Unchecked",
            ])
          : [],
      sheetName: "Vaccine Sản phẩm",
      fileName: "vaccine-san-pham.xlsx",
    };

    await exportToExcel(tableConfig);
  };

  return (
    <div className="flex-none flex flex-row  justify-between">
      <div>
        <Button type="button" onClick={() => exportData(data)}>
          Xuất excel
        </Button>
      </div>
      <div className="flex flex-row gap-2">
        <Button type="button" onClick={onHandleAddNew}>
          Thêm mới
        </Button>
        <Button type="button" onClick={() => onSubmit(formData)}>
          Lưu
        </Button>
        <Button type="button" onClick={onHandleDelete}>
          Xóa
        </Button>
      </div>
    </div>
  );
};
