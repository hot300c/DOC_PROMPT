"use client";

import InputAvailableQty from "@/app/(main)/duoc/duyet-du-tru/_components/input-available-qty";
import { DATE_FORMAT } from "@/app/lib/enums";
import { InputDatePicker } from "@/components/input-date-picker";
import { Form, FormControl, FormField, FormItem } from "@/components/ui/form";
import { Label } from "@/components/ui/label";
import { zodResolver } from "@hookform/resolvers/zod";
import { format } from "date-fns/format";
import { useEffect } from "react";
import { useForm } from "react-hook-form";
import {
  ProductPriceGetGiaGanNhattRESP,
  ProductPriceListRESP,
} from "../../../_utils/definitions/vaccine.resp";
import { VaccineGiaFormData } from "../../../_utils/schema/vaccine-gia-chema";
import { VaccineSanPhamSchema } from "../../../_utils/schema/vaccine-san-pham-chema";

export type VaccineGiaFormProps = {
  productPrice: ProductPriceListRESP | undefined;
  productPriceGetGiaGanNhat: ProductPriceGetGiaGanNhattRESP | undefined;
  setFormData: (form: VaccineGiaFormData | undefined) => void;
};

export const VaccineGiaForm = ({
  productPrice,
  productPriceGetGiaGanNhat,
  setFormData,
}: VaccineGiaFormProps) => {
  const defaultFormData: VaccineGiaFormData = {
    hospitalPrice: 0,
    medicarePrice: 0,
    effFrom: null,
    effThru: null,
    giaNhapGanNhat: 0,
    tiLePhanTram: 0,
    ngayNhapGanNhat: null,
  };

  const mapVaccineToFormData = (
    vaccine: VaccineGiaFormData | undefined,
  ): VaccineGiaFormData => {
    if (!vaccine) return {} as VaccineGiaFormData;
    return Object.fromEntries(
      Object.keys(defaultFormData).map((key) => {
        let value =
          vaccine[key as keyof VaccineGiaFormData] ??
          defaultFormData[key as keyof VaccineGiaFormData];
        return [key, value];
      }),
    ) as VaccineGiaFormData;
  };

  const form = useForm<VaccineGiaFormData>({
    resolver: zodResolver(VaccineSanPhamSchema),
    defaultValues: mapVaccineToFormData(undefined),
  });

  useEffect(() => {
    form.reset(
      mapVaccineToFormData({
        hospitalPrice: productPrice?.hospitalPrice ?? 0,
        medicarePrice: productPrice?.medicarePrice ?? 0,
        effFrom: productPrice?.effFrom,
        effThru: productPrice?.effThru,
        giaNhapGanNhat: productPriceGetGiaGanNhat?.giaNhapGanNhat ?? 0,
        tiLePhanTram: productPriceGetGiaGanNhat?.tiLePhanTram ?? 0,
        ngayNhapGanNhat: productPriceGetGiaGanNhat?.ngayNhapGanNhat,
      }),
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    productPrice?.effFrom,
    productPrice?.effThru,
    productPrice?.hospitalPrice,
    productPrice?.medicarePrice,
    productPriceGetGiaGanNhat?.giaNhapGanNhat,
    productPriceGetGiaGanNhat?.ngayNhapGanNhat,
    productPriceGetGiaGanNhat?.tiLePhanTram,
  ]);

  useEffect(() => {
    const subscription = form.watch((values, { name }) => {
      if (["hospitalPrice", "medicarePrice", "effFrom"].includes(name || "")) {
        setFormData(form.getValues());
      }
    });
    return () => subscription.unsubscribe();
  }, [form, setFormData]);

  return (
    <Form {...form}>
      <form className="w-full">
        <div className="flex justify-between gap-1">
          <div>
            <Label className="whitespace-nowrap mr-2">Đơn giá bán</Label>
            <div>
              <FormField
                control={form.control}
                name="hospitalPrice"
                render={({ field }) => (
                  <FormItem className="flex items-center gap-4 w-full">
                    <FormControl>
                      <InputAvailableQty
                        className="max-w-48"
                        id="hospitalPrice"
                        availableQty={Number(field.value ?? 0)}
                        onChange={async (value) => {
                          form.setValue("hospitalPrice", value);
                        }}
                      />
                    </FormControl>
                  </FormItem>
                )}
              />
            </div>
          </div>

          <div>
            <Label className="whitespace-nowrap mr-2">Từ ngày</Label>
            <FormField
              control={form.control}
              name="effFrom"
              render={({ field }) => (
                <FormItem className="flex items-center w-full sm:w-auto">
                  <FormControl className="flex-1">
                    <div className="relative">
                      <InputDatePicker
                        value={field.value ? new Date(field.value) : undefined}
                        onChange={async (date) => {
                          date &&
                            field.onChange(format(date, DATE_FORMAT.MMDDYYYY));
                        }}
                      />
                    </div>
                  </FormControl>
                </FormItem>
              )}
            />
          </div>
          <div>
            <Label className="whitespace-nowrap mr-2">Đến ngày</Label>
            <FormField
              control={form.control}
              name="effThru"
              render={({ field }) => (
                <FormItem className="flex items-center w-full sm:w-auto">
                  <FormControl className="flex-1">
                    <div className="relative">
                      <InputDatePicker
                        disabled={true}
                        value={field.value ? new Date(field.value) : undefined}
                        onChange={async (date) => {
                          date &&
                            field.onChange(format(date, DATE_FORMAT.MMDDYYYY));
                        }}
                      />
                    </div>
                  </FormControl>
                </FormItem>
              )}
            />
          </div>
          <div>
            <Label className="whitespace-nowrap mr-2">Giá kê khai</Label>
            <FormField
              control={form.control}
              name="medicarePrice"
              render={({ field }) => (
                <FormItem className="flex items-center gap-4">
                  <FormControl>
                    <InputAvailableQty
                      id="medicarePrice"
                      className="max-w-48"
                      availableQty={Number(field.value ?? 0)}
                      onChange={async (value) => {
                        form.setValue("medicarePrice", value);
                      }}
                    />
                  </FormControl>
                </FormItem>
              )}
            />
          </div>
          <div>
            <Label className="whitespace-nowrap mr-2">
              Giá nhập vào gần nhất
            </Label>
            <FormField
              control={form.control}
              name="giaNhapGanNhat"
              render={({ field }) => (
                <FormItem className="flex items-center gap-4">
                  <FormControl>
                    <InputAvailableQty
                      className="max-w-48"
                      id="giaNhapGanNhat"
                      disabled={true}
                      availableQty={Number(field.value ?? 0)}
                      onChange={async (value) => {
                        form.setValue("giaNhapGanNhat", value);
                      }}
                    />
                  </FormControl>
                </FormItem>
              )}
            />
          </div>
          <div>
            <Label className="whitespace-nowrap mr-2">
              Tỉ lệ % giá bán so với giá nhập nhập gần nhất
            </Label>
            <FormField
              control={form.control}
              name="tiLePhanTram"
              render={({ field }) => (
                <FormItem className="flex items-center gap-4">
                  <FormControl>
                    <InputAvailableQty
                      id="tiLePhanTram"
                      className="max-w-48"
                      disabled={true}
                      availableQty={Number(field.value ?? 0)}
                      onChange={async (value) => {
                        form.setValue("tiLePhanTram", value);
                      }}
                    />
                  </FormControl>
                </FormItem>
              )}
            />
          </div>
          <div>
            <Label className="whitespace-nowrap mr-2">Ngày nhập gần nhất</Label>
            <FormField
              control={form.control}
              name="ngayNhapGanNhat"
              render={({ field }) => (
                <FormItem className="flex items-center w-full sm:w-auto">
                  <FormControl className="flex-1">
                    <div className="relative">
                      <InputDatePicker
                        value={field.value ? new Date(field.value) : undefined}
                        disabled={true}
                        onChange={async (date) => {
                          date &&
                            field.onChange(format(date, DATE_FORMAT.MMDDYYYY));
                        }}
                      />
                    </div>
                  </FormControl>
                </FormItem>
              )}
            />
          </div>
        </div>
      </form>
    </Form>
  );
};
