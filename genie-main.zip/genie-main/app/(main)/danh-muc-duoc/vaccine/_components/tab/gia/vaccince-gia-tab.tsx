"use client";

import { ELoadingMessages } from "@/app/lib/enums";
import { useFeedbackDialog } from "@/app/lib/feedback-dialog-provider";
import { getErrorMessage } from "@/app/lib/utils/errorUtils";
import useLoading from "@/components/loading";
import { useCallback, useEffect, useState } from "react";
import {
  ProductPriceGetGiaGanNhattRESP,
  ProductPriceListRESP,
  VaccineGiaData,
  VaccineRESP,
} from "../../../_utils/definitions/vaccine.resp";
import { VaccineGiaFormData } from "../../../_utils/schema/vaccine-gia-chema";
import { fetchDataGiaVaccine } from "../../../_utils/services/vaccine.api";
import { VaccineGiaFooter } from "./vaccince-gia-footer";
import { VaccineGiaForm } from "./vaccince-gia-form";
import VaccineGiaTable from "./vaccine-gia-datatable";

export type VaccineGiaTabProps = {
  selectedVaccine: VaccineRESP | undefined;
};

export const VaccineGiaTab = ({ selectedVaccine }: VaccineGiaTabProps) => {
  const { alert } = useFeedbackDialog();
  const { showLoading, hideLoading } = useLoading();
  const [formData, setFormData] = useState<VaccineGiaFormData | undefined>(
    undefined,
  );
  const [productPrice, setProductPrice] = useState<
    ProductPriceListRESP | undefined
  >(undefined);

  const [productPriceGetGiaGanNhat, setProductPriceGetGiaGanNhat] = useState<
    ProductPriceGetGiaGanNhattRESP | undefined
  >(undefined);

  const [vaccineGiaData, setVaccineGiaData] = useState<
    VaccineGiaData | undefined
  >(undefined);

  const onHandleAddNew = () => {
    setProductPrice(undefined);
    setProductPriceGetGiaGanNhat(undefined);
  };

  const handleFetchDataGiaVaccine = useCallback(async (productID: number) => {
    const loadingId = showLoading(ELoadingMessages.WAITING);
    try {
      var response = await fetchDataGiaVaccine(productID ?? 0);
      setVaccineGiaData(response);
      setProductPrice(response?.productPriceList[0]);
      setProductPriceGetGiaGanNhat(response?.productPriceGetGiaGanNhat[0]);
    } catch (err) {
      await alert({
        title: "Lỗi",
        content: getErrorMessage(err),
      });
    } finally {
      hideLoading(loadingId);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const onRowCick = (row: ProductPriceListRESP) => {
    setProductPrice(row);
  };

  useEffect(() => {
    void handleFetchDataGiaVaccine(selectedVaccine?.productID ?? 0);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedVaccine?.productID]);

  return (
    <div className="flex h-full flex-col overflow-hidden px-4">
      <VaccineGiaForm
        setFormData={setFormData}
        productPrice={productPrice}
        productPriceGetGiaGanNhat={productPriceGetGiaGanNhat}
      ></VaccineGiaForm>
      <div className="flex-1 min-h-0 overflow-auto">
        <VaccineGiaTable
          data={vaccineGiaData?.productPriceList ?? []}
          onRowClick={onRowCick}
        />
      </div>
      <VaccineGiaFooter
        onHandleAddNew={onHandleAddNew}
        selectedVaccine={selectedVaccine}
        formData={formData}
        handleFetchDataGiaVaccine={handleFetchDataGiaVaccine}
        productPriceList={vaccineGiaData?.productPriceList ?? []}
      ></VaccineGiaFooter>
    </div>
  );
};
