"use client";
import { DATE_FORMAT } from "@/app/lib/enums";
import {
  DataTable,
  DataTableColumnHeaderSort,
} from "@/components/ui/dataTable";
import { ColumnDef } from "@tanstack/react-table";
import { format } from "date-fns/format";
import { useMemo } from "react";
import { NumericFormat } from "react-number-format";
import { ProductPriceListRESP } from "../../../_utils/definitions/vaccine.resp";

export type VaccineGiaTableProps = {
  data: ProductPriceListRESP[];
  onRowClick: (row: ProductPriceListRESP) => void;
};
const VaccineGiaTable = ({ data, onRowClick }: VaccineGiaTableProps) => {
  const columns = useMemo(() => {
    const result: ColumnDef<ProductPriceListRESP>[] = [
      {
        id: "hospitalPrice",
        accessorKey: "hospitalPrice",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Đơn giá" />
        ),
        meta: {
          className: "text-overflow-ellipsis truncate text-right",
        },
        cell: ({ row }) => (
          <NumericFormat
            className="flex-1"
            value={row.original.hospitalPrice}
            thousandSeparator="."
            decimalSeparator=","
            decimalScale={2}
            fixedDecimalScale
            displayType="text"
          />
        ),
      },
      {
        id: "effFrom",
        accessorKey: "effFrom",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Từ ngày"
            className="justify-start"
          />
        ),
        size: 100,
        cell: ({ row }) => (
          <div className="min-w-12">
            {format(row.original.effFrom, DATE_FORMAT.DD_MM_YYYY_VI)}
          </div>
        ),
      },
      {
        id: "effThru",
        accessorKey: "effThru",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Đến ngày"
            className="justify-start"
          />
        ),
        size: 100,
        cell: ({ row }) => (
          <div className="min-w-12">
            {!!row.original.effThru
              ? format(row.original.effThru, DATE_FORMAT.DD_MM_YYYY_VI)
              : ""}
          </div>
        ),
      },
    ];
    return result;
  }, []);

  return (
    <div className="flex-1 flex flex-col h-full w-full">
      <DataTable
        className="w-full overflow-y-auto border"
        tableClassName="border"
        tHeadClass="z-40"
        columns={columns}
        data={data}
        enableColumnFilter={false}
        enablePaging={false}
        enableGlobalFilter={false}
        placeholderSearch="Nhập để tìm kiếm..."
        enableFooter
        onRowClick={onRowClick}
      ></DataTable>
    </div>
  );
};

export default VaccineGiaTable;
