"use client";
import { Checkbox } from "@/components/ui/checkbox";
import {
  DataTable,
  DataTableColumnHeaderSort,
} from "@/components/ui/dataTable";
import { ColumnDef } from "@tanstack/react-table";
import { useMemo } from "react";
import { VaccineRESP } from "../_utils/definitions/vaccine.resp";

export type VaccineTableProps = {
  data: VaccineRESP[];
  onRowClick: (row: VaccineRESP) => void;
  productID: string | null;
};
const VaccineTable = ({ data, onRowClick, productID }: VaccineTableProps) => {
  const columns = useMemo(() => {
    const result: ColumnDef<VaccineRESP>[] = [
      {
        id: "maChung",
        accessorKey: "maChung",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Mã chung" />
        ),
        meta: {
          className: "text-left truncate",
        },
        cell: ({ row }) => (
          <div title={row.original.maChung}>{row.original.maChung}</div>
        ),
      },
      {
        id: "hospitalCode",
        accessorKey: "hospitalCode",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Mã SP" />
        ),
        cell: ({ row }) => (
          <div title={row.original.hospitalCode}>
            {row.original.hospitalCode}
          </div>
        ),
      },
      {
        id: "hospitalName",
        accessorKey: "hospitalName",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Tên SP" />
        ),
        cell: ({ row }) => (
          <div className="min-w-40">
            <span title={row.original.hospitalName}>
              {row.original.hospitalName}
            </span>
          </div>
        ),
      },
      {
        id: "content",
        accessorKey: "content",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Hàm lượng" />
        ),
        meta: {
          className: "text-left",
        },
      },
      {
        id: "formula",
        accessorKey: "formula",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Hoạt chất" />
        ),
        meta: {
          className: "text-left",
        },
      },
      {
        id: "unitName",
        accessorKey: "unitName",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="ĐVT" />
        ),
        meta: {
          className: "text-left",
        },
      },
      {
        id: "duongDung",
        accessorKey: "duongDung",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Đường dùng" />
        ),
        meta: {
          className: "text-left",
        },
      },
      {
        id: "countryName",
        accessorKey: "countryName",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Nước SX" />
        ),
        meta: {
          className: "text-left",
        },
      },
      {
        id: "hangsanxuat1",
        accessorKey: "hangsanxuat1",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Hãng SX" />
        ),
        meta: {
          className: "text-left",
        },
      },
      {
        id: "tenNhomBenh",
        accessorKey: "tenNhomBenh",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Nhóm bệnh" />
        ),
        meta: {
          className: "text-left",
        },
      },
      {
        id: "isThuocHiem",
        accessorKey: "isThuocHiem",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title={
              <span className="w-full block text-center">
                Thuốc <br></br>hiếm
              </span>
            }
          />
        ),
        meta: {
          className: "pl-1 text-center",
        },
        cell: ({ row }) => <Checkbox checked={row.original.isThuocHiem} />,
        filterFn: "isBoolean",
      },

      {
        id: "isBaoMat",
        accessorKey: "isBaoMat",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title={
              <span className="w-full block text-center">
                Bảo <br></br>mật
              </span>
            }
          />
        ),
        meta: {
          className: "pl-1 text-center",
        },
        cell: ({ row }) => <Checkbox checked={row.original.isBaoMat} />,
        filterFn: "isBoolean",
      },

      {
        id: "isUsing",
        accessorKey: "isUsing",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title={
              <span className="w-full block text-center">
                Sử <br></br>dụng
              </span>
            }
          />
        ),
        meta: {
          className: "pl-1 text-center",
        },
        cell: ({ row }) => <Checkbox checked={row.original.isUsing} />,
        filterFn: "isBoolean",
      },

      {
        id: "modifiedByUser",
        accessorKey: "modifiedByUser",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Thay đổi gần nhất"
          />
        ),
        meta: {
          className: "text-left",
        },
      },

      {
        id: "isVaccineHiem",
        accessorKey: "isVaccineHiem",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title={
              <span className="w-full text-center">
                Vaccine <br></br>hiếm
              </span>
            }
          />
        ),
        meta: {
          className: "pl-1 text-center",
        },
        cell: ({ row }) => <Checkbox checked={row.original.isVaccineHiem} />,
        filterFn: "isBoolean",
      },
    ];
    return result;
  }, []);

  const indexScrollTo = useMemo(
    () =>
      productID
        ? data.findIndex((row) => row.productID.toString() == productID)
        : 0,
    [data, productID],
  );

  return (
    <div className="flex flex-col h-full w-full">
      <DataTable
        className="w-full h-full overflow-y-auto border"
        tableClassName="border"
        tHeadClass="z-40"
        columns={columns}
        data={data}
        enableColumnFilter={true}
        enablePaging={false}
        enableGlobalFilter={true}
        placeholderSearch="Nhập để tìm kiếm..."
        enableFooter
        onRowClick={onRowClick}
        indexScrollTo={indexScrollTo}
      ></DataTable>
    </div>
  );
};

export default VaccineTable;
