"use client";

import { TableSelect } from "@/components/select/table-select";
import { DataTableColumnHeaderSort } from "@/components/ui/dataTable";
import { ColumnDef } from "@tanstack/react-table";
import { useMemo } from "react";
import { VendorRESP } from "../../_utils/definitions/vaccine.resp";

export default function NhaCungCapComboBox({
  vendors = [],
  selectedNhaCungCapID,
  handleNhaCungCapSelect,
}: {
  vendors?: VendorRESP[];
  selectedNhaCungCapID?: string;
  handleNhaCungCapSelect: (x: VendorRESP | undefined) => void;
}) {
  const nhaCungCapID = useMemo(() => {
    return vendors.find((sp) => sp.id.toString() === selectedNhaCungCapID);
  }, [selectedNhaCungCapID, vendors]);

  const NHA_CUNG_CAP_COLUMN_COMBOBOX = useMemo(() => {
    const result: ColumnDef<VendorRESP>[] = [
      {
        id: "name",
        accessorKey: "name",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Hãng sản xuất"
            className="justify-start"
          />
        ),
        enableSorting: true,
      },
    ];
    return result;
  }, []);
  return (
    <div className="flex flex-row col-span-2 items-center gap-3 h-lg:gap-4 w-full">
      <TableSelect
        columns={NHA_CUNG_CAP_COLUMN_COMBOBOX}
        data={vendors}
        labelKey="name"
        valueKey="id"
        placeholderSearch="Tìm kiếm..."
        placeholder="--Chọn nhà cung cấp --"
        data-cy="chon-nha-cung-cap"
        value={nhaCungCapID}
        className="w-full"
        classNameTable="max-h-[40vh] max-w-[1000px]"
        classNamePopover="w-auto min-w-60"
        onChange={handleNhaCungCapSelect}
      />
    </div>
  );
}
