"use client";

import { TableSelect } from "@/components/select/table-select";
import { DataTableColumnHeaderSort } from "@/components/ui/dataTable";
import { ColumnDef } from "@tanstack/react-table";
import { useMemo } from "react";
import { MaDungChungRESP } from "../../_utils/definitions/vaccine.resp";

export default function MaDungChungComboBox({
  maDungChungs = [],
  selectedMaDungChungID,
  handleMaDungChungSelect,
}: {
  maDungChungs?: MaDungChungRESP[];
  selectedMaDungChungID?: string;
  handleMaDungChungSelect: (x: MaDungChungRESP | undefined) => void;
}) {
  const countryID = useMemo(() => {
    return maDungChungs.find(
      (sp) => sp.maChung.toString() === selectedMaDungChungID,
    );
  }, [selectedMaDungChungID, maDungChungs]);

  const NUOC_SAN_XUAT_COLUMN_COMBOBOX = useMemo(() => {
    const result: ColumnDef<MaDungChungRESP>[] = [
      {
        id: "hospitalCode",
        accessorKey: "hospitalCode",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Mã SP"
            className="justify-start"
          />
        ),
        enableSorting: true,
      },
      {
        id: "hospitalName",
        accessorKey: "hospitalName",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Tên SP"
            className="justify-start"
          />
        ),
        cell: ({ row }) => <div>{row.original.hospitalName}</div>,
        enableSorting: true,
      },
      {
        id: "aliasName",
        accessorKey: "aliasName",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Mã chung"
            className="justify-start"
          />
        ),
        cell: ({ row }) => (
          <div className="min-w-32">{row.original.maChung}</div>
        ),
        enableSorting: true,
      },
    ];
    return result;
  }, []);
  return (
    <div className="flex flex-row col-span-2 items-center gap-3 h-lg:gap-4 w-full">
      <TableSelect
        columns={NUOC_SAN_XUAT_COLUMN_COMBOBOX}
        data={maDungChungs}
        labelKey="hospitalName"
        valueKey="maChung"
        placeholderSearch="Tìm kiếm..."
        placeholder="--Chọn mã dùng chung --"
        data-cy="chon-ma-dung-chung"
        value={countryID}
        className="w-full"
        classNameTable="max-h-[40vh] max-w-[1000px]"
        classNamePopover="w-auto min-w-60"
        onChange={handleMaDungChungSelect}
      />
    </div>
  );
}
