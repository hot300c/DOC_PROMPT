"use client";

import { TableSelect } from "@/components/select/table-select";
import { DataTableColumnHeaderSort } from "@/components/ui/dataTable";
import { ColumnDef } from "@tanstack/react-table";
import { useMemo } from "react";
import { NuocSanXuatRESP } from "../../_utils/definitions/vaccine.resp";

export default function NuocSanXuatComboBox({
  nuocSanXuats = [],
  selectedCountryID,
  handleCountrySelect,
}: {
  nuocSanXuats?: NuocSanXuatRESP[];
  selectedCountryID?: string;
  handleCountrySelect: (x: NuocSanXuatRESP | undefined) => void;
}) {
  const countryID = useMemo(() => {
    return nuocSanXuats.find(
      (sp) => sp.countryID.toString() === selectedCountryID,
    );
  }, [selectedCountryID, nuocSanXuats]);

  const NUOC_SAN_XUAT_COLUMN_COMBOBOX = useMemo(() => {
    const result: ColumnDef<NuocSanXuatRESP>[] = [
      {
        id: "countryID",
        accessorKey: "countryID",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Country ID"
            className="justify-start"
          />
        ),
        enableSorting: true,
      },
      {
        id: "countryName",
        accessorKey: "countryName",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Country Name"
            className="justify-start"
          />
        ),
        cell: ({ row }) => <div>{row.original.countryName}</div>,
        enableSorting: true,
      },
      {
        id: "aliasName",
        accessorKey: "aliasName",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Alias Name"
            className="justify-start"
          />
        ),
        cell: ({ row }) => (
          <div className="min-w-32">{row.original.aliasName}</div>
        ),
        enableSorting: true,
      },
    ];
    return result;
  }, []);
  return (
    <div className="flex flex-row col-span-2 items-center gap-3 h-lg:gap-4 w-full">
      <TableSelect
        columns={NUOC_SAN_XUAT_COLUMN_COMBOBOX}
        data={nuocSanXuats}
        labelKey="countryName"
        valueKey="countryID"
        placeholderSearch="Tìm kiếm..."
        placeholder="--Chọn nước sản xuất --"
        data-cy="chon-nuoc-san-xuat"
        value={countryID}
        className="w-full"
        classNameTable="max-h-[40vh] max-w-[1000px]"
        classNamePopover="w-auto min-w-60"
        onChange={handleCountrySelect}
      />
    </div>
  );
}
