"use client";

import { TableSelect } from "@/components/select/table-select";
import { DataTableColumnHeaderSort } from "@/components/ui/dataTable";
import { ColumnDef } from "@tanstack/react-table";
import { useMemo } from "react";
import { DinhNghiaLieuDungRESP } from "../../_utils/definitions/vaccine.resp";

export default function LieuDungComboBox({
  dinhNghiaLieuDungs = [],
  selectedLieuDungID,
  handleLieuDungSelect,
}: {
  dinhNghiaLieuDungs?: DinhNghiaLieuDungRESP[];
  selectedLieuDungID?: string;
  handleLieuDungSelect: (x: DinhNghiaLieuDungRESP | undefined) => void;
}) {
  const hangSanXuatID = useMemo(() => {
    return dinhNghiaLieuDungs.find(
      (sp) => sp.id.toString() === selectedLieuDungID,
    );
  }, [selectedLieuDungID, dinhNghiaLieuDungs]);

  const LIEU_DUNG_COLUMN_COMBOBOX = useMemo(() => {
    const result: ColumnDef<DinhNghiaLieuDungRESP>[] = [
      {
        id: "tenLieuDung",
        accessorKey: "tenLieuDung",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Tên liều dùng"
            className="justify-start"
          />
        ),
        enableSorting: true,
      },
      {
        id: "soLuong",
        accessorKey: "soLuong",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Số lượng"
            className="justify-start"
          />
        ),
        enableSorting: true,
      },
      {
        id: "unitNameDinhNghia",
        accessorKey: "unitNameDinhNghia",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Đơn vị"
            className="justify-start"
          />
        ),
        enableSorting: true,
      },
    ];
    return result;
  }, []);
  return (
    <div className="flex flex-row col-span-2 items-center gap-3 h-lg:gap-4 w-full">
      <TableSelect
        columns={LIEU_DUNG_COLUMN_COMBOBOX}
        data={dinhNghiaLieuDungs}
        labelKey="tenLieuDung"
        valueKey="id"
        placeholderSearch="Tìm kiếm..."
        placeholder="--Chọn liều dùng --"
        data-cy="chon-lieu-dung"
        value={hangSanXuatID}
        className="w-full"
        classNameTable="max-h-[40vh] max-w-[1000px]"
        classNamePopover="w-auto min-w-60"
        onChange={handleLieuDungSelect}
      />
    </div>
  );
}
