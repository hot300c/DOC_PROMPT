"use client";

import { TableSelect } from "@/components/select/table-select";
import { DataTableColumnHeaderSort } from "@/components/ui/dataTable";
import { ColumnDef } from "@tanstack/react-table";
import { useMemo } from "react";
import { CommonRESP } from "../../../shared/_utils/definitions/response";

export default function HangSanXuatComboBox({
  hangSanXuats = [],
  selectedHangSanXuatID,
  handleHangSanXuatSelect,
}: {
  hangSanXuats?: CommonRESP[];
  selectedHangSanXuatID?: string;
  handleHangSanXuatSelect: (x: CommonRESP | undefined) => void;
}) {
  const hangSanXuatID = useMemo(() => {
    return hangSanXuats.find(
      (sp) => sp.id.toString() === selectedHangSanXuatID,
    );
  }, [selectedHangSanXuatID, hangSanXuats]);

  const NUOC_SAN_XUAT_COLUMN_COMBOBOX = useMemo(() => {
    const result: ColumnDef<CommonRESP>[] = [
      {
        id: "name",
        accessorKey: "name",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Hãng sản xuất"
            className="justify-start"
          />
        ),
        enableSorting: true,
      },
    ];
    return result;
  }, []);
  return (
    <div className="flex flex-row col-span-2 items-center gap-3 h-lg:gap-4 w-full">
      <TableSelect
        columns={NUOC_SAN_XUAT_COLUMN_COMBOBOX}
        data={hangSanXuats}
        labelKey="name"
        valueKey="id"
        placeholderSearch="Tìm kiếm..."
        placeholder="--Chọn hãng sản xuất --"
        data-cy="chon-hang-san-xuat"
        value={hangSanXuatID}
        className="w-full"
        classNameTable="max-h-[40vh] max-w-[1000px]"
        classNamePopover="w-auto min-w-60"
        onChange={handleHangSanXuatSelect}
      />
    </div>
  );
}
