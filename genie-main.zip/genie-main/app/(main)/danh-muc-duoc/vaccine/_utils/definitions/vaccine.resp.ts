import {
  ComboValuesListCachDungThuocV2RESP,
  CommonRESP,
  InventoryStockRESP,
  ProductTypeRESP,
  UoMRESP,
} from "../../../shared/_utils/definitions/response";

export interface VaccineRESP {
  hangSanXuat: number;
  content: string;
  displayPackage: string;
  donViSuDung: string;
  donvidung: string | null;
  duongDung: string;
  modifiedByUser: string;
  countryName: string;
  formula: string;
  hangsanxuat1: string;
  hospitalCode: string;
  hospitalName: string;
  iD_NCC: number;
  idDinhNghiaLieuDung: number;
  isActive: boolean;
  isBaoMat: boolean;
  isGuiTinNhanVaccine: boolean;
  isHalfVol: boolean;
  isThuocHiem: boolean;
  isUsing: boolean;
  isVaccineHiem: boolean;
  maChung: string;
  maDuocQG: string;
  nhomBenhID: string;
  nuocSanXuat: number;
  productID: number;
  tenNhomBenh: string;
  unitID: number;
  unitName: string;
  usage: string;
  vendorID: number;
}

//Table 1
export type FormulaRESP = {
  ma: string;
  ten: string;
};

//Table 2
export type NuocSanXuatRESP = {
  countryID: number;
  countryName: string;
  aliasName: string;
  countryMacdinh?: number;
};

//Table 7
export type NhomBenhVaccineRESP = {
  id: number;
  maNhomBenh: string;
  tenNhomBenh: string;
};

//Table 8
export type MaDungChungRESP = {
  productID: number;
  hospitalCode: string;
  hospitalName: string;
  maChung: string;
};

//Table 10
export type VendorRESP = {
  id: number;
  vendorNo: string;
  name: string;
};

//Table 11
export type DinhNghiaLieuDungRESP = {
  id: number;
  idUnit: number | null;
  idUnitDinhNghia: number | null;
  idUnitDinhNghiaQuyDoi: number | null;
  slQuyDoi: number | null;
  soLuong: number;
  tenLieuDung: string | null;
  unitName: string | null;
  unitNameDinhNghia: string | null;
};

export type VaccineData = {
  dugs: CommonRESP[];
  formulas: FormulaRESP[];
  nuocSanXuats: NuocSanXuatRESP[];
  productTypes: ProductTypeRESP[];
  cachDungThuocs: ComboValuesListCachDungThuocV2RESP[];
  hangSanXuats: CommonRESP[];
  donViDungs: UoMRESP[];
  nhomBenhVaccines: NhomBenhVaccineRESP[];
  maDungChungs: MaDungChungRESP[];
  inventoryStocks: InventoryStockRESP[];
  vendors: VendorRESP[];
  dinhNghiaLieuDungs: DinhNghiaLieuDungRESP[];
  data: VaccineRESP[];
};

export type VaccineGiaData = {
  nhomBenhVaccineByProductID: NhomBenhVaccineByProductIDRESP[];
  productPriceList: ProductPriceListRESP[];
  productPriceGetGiaGanNhat: ProductPriceGetGiaGanNhattRESP[];
};

export type NhomBenhVaccineByProductIDRESP = {
  createdBy: string;
  createdOn: string;
  facID_Deleted?: string;
  id: number;
  maChung: string;
  modifiedBy: string;
  modifiedOn: string;
  nhomBenhID: number;
  productID: number;
  tenNhomBenh: string;
};

export type ProductPriceListRESP = {
  armyPrice?: number;
  effFrom: string;
  effThru?: string;
  giaDichVu: number;
  giaDiemThuong?: number;
  hospitalPrice: number;
  medicarePrice?: number;
};

export type ProductPriceGetGiaGanNhattRESP = {
  giaNhapGanNhat: number;
  ngayNhapGanNhat?: string;
  tiLePhanTram: number;
};
