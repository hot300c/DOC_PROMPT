import { getUserSession } from "@/actions/get-user-session";
import { SequenceRequest } from "@/app/lib/definitions/setting";
import * as httpService from "@/app/lib/network/http";
import * as SystemService from "@/app/lib/services/system";
import {
  VaccineData,
  VaccineGiaData,
  VaccineRESP,
} from "../definitions/vaccine.resp";
import { VaccineSanPhamFormData } from "../schema/vaccine-san-pham-chema";
import { VaccineGiaFormData } from "../schema/vaccine-gia-chema";
import { format } from "date-fns";
import { DATE_FORMAT } from "@/app/lib/enums";
import { InventoryStockRESP } from "../../../shared/_utils/definitions/response";

export async function getProductBaseUserIDList(): Promise<VaccineRESP[]> {
  try {
    const currentUser = await getUserSession();
    const response = await httpService.post("/DataAccess", [
      {
        category: "QAHosGenericDB",
        command: "ws_LoadProductBaseUserID_List",
        parameters: {
          ActionType: 6,
          FacID: currentUser.facId,
        },
      },
    ]);

    return response.data.table || [];
  } catch (error) {
    return [];
  }
}

export async function fetchDataVaccine(productID: number): Promise<any> {
  try {
    const currentUser = await getUserSession();
    const requests: SequenceRequest[] = [
      {
        category: "QAHosGenericDB",
        command: "ws_DugType_List",
        parameters: {
          FacID: currentUser.facId,
        },
      },
      {
        category: "QAHosGenericDB",
        command: "ws_L_Formula_List",
        parameters: {},
      },
      {
        category: "QAHosGenericDB",
        command: "ws_L_Nuocsanxuat_List",
        parameters: {
          FacID: currentUser.facId,
        },
      },
      {
        category: "QAHosGenericDB",
        command: "ws_L_ProductType_List",
        parameters: {
          FacID: currentUser.facId,
        },
      },
      {
        category: "QAHosGenericDB",
        command: "ws_DOC_ComboValues_List_CachDungThuocV2",
        parameters: {
          FacID: currentUser.facId,
        },
      },
      {
        category: "QAHosGenericDB",
        command: "ws_L_HangSanXuat_List",
        parameters: {
          FacID: currentUser.facId,
        },
      },
      {
        category: "QAHosGenericDB",
        command: "ws_L_UoM_List",
        parameters: {},
      },
      {
        category: "QAHosGenericDB",
        command: "ws_L_NhomBenhVaccine_List",
        parameters: {
          FacID: currentUser.facId,
          Action: 1,
        },
      },
      {
        category: "QAHosGenericDB",
        command: "ws_L_Product_MaDungChung_List",
        parameters: {
          FacID: currentUser.facId,
        },
      },
      {
        category: "QAHosGenericDB",
        command: "ws_L_InventoryStock_List",
        parameters: {
          FacID: currentUser.facId,
          ActionType: 10,
        },
      },
      {
        category: "QAHosGenericDB",
        command: "ws_L_Vendor_GetList",
        parameters: {
          FacID: currentUser.facId,
        },
      },
      {
        category: "QAHosGenericDB",
        command: "ws_L_DinhNghiaLieuDung_Get_All",
        parameters: {},
      },
      {
        category: "QAHosGenericDB",
        command: "ws_LoadProductBaseUserID_List",
        parameters: {
          ActionType: 6,
          FacID: currentUser.facId,
        },
      },
    ];
    const response = await SystemService.executeTransaction({
      request: requests,
    });
    const vaccineData: VaccineData = {
      dugs: response.table || [],
      formulas: response.table1 || [],
      nuocSanXuats: response.table2 || [],
      productTypes: response.table3 || [],
      cachDungThuocs: response.table4 || [],
      hangSanXuats: response.table5 || [],
      donViDungs: response.table6 || [],
      nhomBenhVaccines: response.table7 || [],
      maDungChungs: response.table8 || [],
      inventoryStocks: response.table9 || [],
      vendors: response.table10 || [],
      dinhNghiaLieuDungs: response.table11 || [],
      data: response.table12 || [],
    };
    return vaccineData;
  } catch (error) {
    return [];
  }
}

export async function productVaccineSave(
  params: VaccineSanPhamFormData,
): Promise<{ success: boolean }> {
  const { facId } = await getUserSession();
  const response = await httpService.post("/DataAccess", [
    {
      category: "QAHosGenericDB",
      command: "ws_L_Product_Vaccine_Save",
      parameters: {
        FacID: facId,
        ProductID: Number(params.productID ?? 0),
        HospitalCode: params.hospitalCode,
        HospitalName: params.hospitalName,
        Formula: params.formula,
        Content: params.content,
        Usage: params.usage,
        DisplayPackage: params.displayPackage,
        UnitID: params.unitID,
        IsThuocHiem: params.isThuocHiem,
        IsUsing: params.isUsing,
        NuocSanXuat: params.nuocSanXuat,
        HangSanXuat: params.hangSanXuat,
        DuongDung: params.duongDung,
        DonViDung: 0,
        IsBaoMat: params.isBaoMat,
        NhomBenhID: Number(params.nhomBenhID),
        MaChung: params.maChung,
        DosageForm: params.dosageForm,
        IsHalfVol: false,
        IsGuiTinNhanVaccine: params.isGuiTinNhanVaccine,
        IsVaccineHiem: params.isVaccineHiem,
        MaDuocQG: params.maDuocQG,
        NCCID: params.nccID,
        IDDinhNghiaLieuDung: params.idDinhNghiaLieuDung,
      },
    },
  ]);
  return response.data;
}

export async function getInventoryStockList(
  danhMucThuocChungToanBenhVien: boolean,
): Promise<InventoryStockRESP[]> {
  const currentUser = await getUserSession();
  const response = await httpService.post("/DataAccess", [
    {
      category: "QAHosGenericDB",
      command: "ws_L_InventoryStock_List",
      parameters: {
        FacID: currentUser.facId,
        ActionType: danhMucThuocChungToanBenhVien ? 16 : 10,
      },
    },
  ]);

  return response.data.table || [];
}

export async function nhomBenhVaccineDeleteQuyen(
  maChung: string,
): Promise<{ success: boolean }> {
  const currentUser = await getUserSession();
  const response = await httpService.post("/DataAccess", [
    {
      category: "QAHosGenericDB",
      command: "ws_L_Product_NhomBenhVaccine_DeleteQuyen",
      parameters: {
        MaChung: maChung,
        FacID: currentUser.facId,
      },
    },
  ]);

  return response.data.table;
}

export async function productNhomBenhVaccineSaveQuyen(
  maChung: string,
  nhomBenhIDs: string[] = [],
): Promise<{ success: boolean }> {
  const currentUser = await getUserSession();
  const requests: SequenceRequest[] = [];

  nhomBenhIDs.forEach((nhomBenhID) => {
    requests.push({
      category: "QAHosGenericDB",
      command: "ws_L_Product_NhomBenhVaccine_SaveQuyen",
      parameters: {
        MaChung: maChung,
        NhomBenhID: nhomBenhID,
        FacID: currentUser.facId,
      },
    });
  });

  const response = await SystemService.executeTransaction({
    request: requests,
  });
  return response.data;
}

export async function productDelete(
  productID: number,
  coQuanLyGiaTheoKho: boolean = false,
): Promise<{ success: boolean }> {
  const currentUser = await getUserSession();
  const requests: SequenceRequest[] = [];
  requests.push({
    category: "QAHosGenericDB",
    command: "ws_L_Product_Delete",
    parameters: {
      ID: productID,
      FacID: currentUser.facId,
    },
  });
  if (coQuanLyGiaTheoKho) {
    requests.push({
      category: "QAHosGenericDB",
      command: "ws_L_ProductPrice_DeleteByProduct",
      parameters: {
        ProductID: productID,
        FacID: currentUser.facId,
      },
    });
  }
  const response = await SystemService.executeTransaction({
    request: requests,
  });
  return response.data;
}

export async function fetchDataGiaVaccine(
  productID: number,
): Promise<VaccineGiaData> {
  const currentUser = await getUserSession();
  const requests: SequenceRequest[] = [
    {
      category: "QAHosGenericDB",
      command: "ws_L_Product_NhomBenhVaccine_GetByProductID",
      parameters: {
        ProductID: productID,
        FacID: currentUser.facId,
      },
    },
    {
      category: "QAHosGenericDB",
      command: "ws_L_ProductPrice_List",
      parameters: {
        ProductID: productID,
        FacID: currentUser.facId,
      },
    },
    {
      category: "QAHosGenericDB",
      command: "ws_L_ProductPrice_GetGiaGanNhat_TiLePhanTramGiaBan",
      parameters: {
        ProductID: productID,
        FacID: currentUser.facId,
      },
    },
  ];
  const response = await SystemService.executeTransaction({
    request: requests,
  });
  const vaccineData: VaccineGiaData = {
    nhomBenhVaccineByProductID: response.table || [],
    productPriceList: response.table1 || [],
    productPriceGetGiaGanNhat: response.table2 || [],
  };
  return vaccineData;
}

export async function productPriceSave({
  params,
  productID,
}: {
  params: VaccineGiaFormData;
  productID: number;
}): Promise<{ success: boolean }> {
  const currentUser = await getUserSession();
  const response = await httpService.post("/DataAccess", [
    {
      category: "QAHosGenericDB",
      command: "ws_L_ProductPrice_Save",
      parameters: {
        ProductID: productID,
        EffFrom: format(params.effFrom!, DATE_FORMAT.YYYYMMDD_AS_INT),
        EffThru: "29990101",
        HospitalPrice: (params.hospitalPrice ?? 0).toString(),
        MedicarePrice: 0,
        FacID: currentUser.facId,
        STTMaHoaTheoKQDT: "",
        SoQDPheDuyet: "",
        TenDonViDauThau: "",
        SoQDMuaSamTrucTiep: "",
        GiaKeKhai: (params.medicarePrice ?? 0).toString(),
      },
    },
  ]);

  return response.data.table;
}
