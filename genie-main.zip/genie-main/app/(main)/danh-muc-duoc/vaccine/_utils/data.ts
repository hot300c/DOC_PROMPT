import { CommonRESP } from "../../shared/_utils/definitions/response";

export const loaiThaus: CommonRESP[] = [
  { id: 1, name: "Thầu tập trung" },
  { id: 2, name: "Thầu riêng tại BV" },
];
