export type VaccineFilterParams = {
  productID: string;
};
