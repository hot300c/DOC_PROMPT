"use client";
import { z } from "zod";

export const VaccineSanPhamSchema = z.object({
  productID: z.union([z.string(), z.number()]).optional(),
  hospitalCode: z.string().optional(),
  hospitalName: z.string().optional(),
  formula: z.string().optional(),
  content: z.string().optional(),
  usage: z.string().optional(),
  displayPackage: z.string().optional(),
  unitID: z.union([z.string(), z.number()]).optional(),
  isThuocHiem: z.string().optional(),
  isUsing: z.string().optional(),
  nuocSanXuat: z.union([z.string(), z.number()]).optional(),
  hangSanXuat: z.union([z.string(), z.number()]).optional(),
  duongDung: z.union([z.string(), z.number()]).optional(),
  isBaoMat: z.string().optional(),
  nhomBenhID: z.union([z.string(), z.number()]).optional(),
  maChung: z.string().optional(),
  dosageForm: z.string().optional(),
  isGuiTinNhanVaccine: z.boolean().optional(),
  isVaccineHiem: z.string().optional(),
  maDuocQG: z.string().optional(),
  nccID: z.number().optional(),
  idDinhNghiaLieuDung: z.union([z.string(), z.number()]).optional(),
  idLoaiSanPham: z.union([z.string(), z.number()]).optional(),
  productTypeID: z.union([z.string(), z.number()]).optional(),
});
export type VaccineSanPhamFormData = z.infer<typeof VaccineSanPhamSchema>;
