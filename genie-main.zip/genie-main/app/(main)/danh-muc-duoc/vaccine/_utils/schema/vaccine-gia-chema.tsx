"use client";
import { z } from "zod";

export const VaccineGiaSchema = z.object({
  hospitalPrice: z.number().optional(),
  effFrom: z.string().nullable().optional(),
  effThru: z.string().nullable().optional(),
  medicarePrice: z.number().optional(),
  giaNhapGanNhat: z.number().optional(),
  tiLePhanTram: z.number().optional(),
  ngayNhapGanNhat: z.string().nullable().optional(),
});
export type VaccineGiaFormData = z.infer<typeof VaccineGiaSchema>;
