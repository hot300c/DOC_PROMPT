export default async function Page(props: {}) {
  return <div className="flex flex-col h-full">Wellcome nuoc-san-xuat</div>;
}
