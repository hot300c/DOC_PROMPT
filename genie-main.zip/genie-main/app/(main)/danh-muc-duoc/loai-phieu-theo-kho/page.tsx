import {
  ResizableHandle,
  ResizablePanel,
  ResizablePanelGroup,
} from "@/components/ui/resizable";
import { Suspense } from "react";
import { Loading } from "../../duoc/(base_components)/loading";
import LoaiPhieuTheoKhoContainer from "./_components/loai-phieu-theo-kho-container";
import LoaiPhieuTheoKhoFilter from "./_components/loai-phieu-theo-kho-filter";
import LoaiPhieuTheoKhoHeader from "./_components/loai-phieu-theo-kho-header";
import { FilterFormValues } from "./_utils/schema";
import { ws_L_InventoryStock_List } from "./_utils/services/loai-phieu-theo-kho.api";

export default async function Page(props: {
  searchParams?: Promise<FilterFormValues>;
}) {
  const searchParams = await props.searchParams;
  const stocks = await ws_L_InventoryStock_List();
  return (
    <div className="flex flex-col w-full h-full overflow-hidden">
      <LoaiPhieuTheoKhoHeader />
      <ResizablePanelGroup direction="horizontal">
        <ResizablePanel defaultSize={33.33} minSize={10}>
          <LoaiPhieuTheoKhoFilter data={stocks} />
        </ResizablePanel>
        <ResizableHandle withHandle />
        <ResizablePanel defaultSize={66.67}>
          <Suspense key={`${searchParams?.stockID}`} fallback={<Loading />}>
            <LoaiPhieuTheoKhoContainer searchParams={searchParams} />
          </Suspense>
        </ResizablePanel>
      </ResizablePanelGroup>
    </div>
  );
}
