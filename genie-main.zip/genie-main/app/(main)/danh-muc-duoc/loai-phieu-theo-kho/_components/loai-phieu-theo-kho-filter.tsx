"use client";
import { InventoryStockRESP } from "@/app/(main)/duoc/shared/_utils/definitions/response";
import {
  DataTable,
  DataTableColumnHeaderSort,
} from "@/components/ui/dataTable";
import { ColumnDef } from "@tanstack/react-table";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { useMemo } from "react";

export interface LoaiPhieuTheoKhoFilterProps {
  data: InventoryStockRESP[];
}
const columns: ColumnDef<InventoryStockRESP>[] = [
  {
    id: "name",
    accessorKey: "name",
    header: ({ column }) => (
      <DataTableColumnHeaderSort
        column={column}
        title="Kho"
        className="justify-start"
      />
    ),
    enableSorting: true,
  },
];

const LoaiPhieuTheoKhoFilter: React.FC<LoaiPhieuTheoKhoFilterProps> = ({
  data,
}) => {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const stockID = searchParams.get("stockID");

  const handleRowClick = (rowData: InventoryStockRESP) => {
    const query = new URLSearchParams(searchParams);
    query.set("stockID", rowData.stockID.toString());
    router.push(pathname + "?" + query);
  };
  const indexScrollTo = useMemo(
    () =>
      stockID ? data.findIndex((row) => row.stockID?.toString() == stockID) : 0,
    [stockID, data],
  );

  return (
    <div className="flex-1 flex flex-col h-full w-full">
      <DataTable
        className="w-full overflow-y-auto border"
        columns={columns}
        data={data}
        columnVisibilityInit={{ search: false }}
        enableColumnFilter={true}
        enablePaging={true}
        enableFooter={true}
        isSelectRowWhenUseArrowKey
        indexScrollTo={indexScrollTo > 0 ? indexScrollTo : 0}
        onRowClick={handleRowClick}
      />
    </div>
  );
};

export default LoaiPhieuTheoKhoFilter;
