"use client";

import FacilityInfo from "@/components/facilityInfo";

const LoaiPhieuTheoKhoHeader = () => {
  return <FacilityInfo page={"DANH MỤC - DƯỢC | LOẠI PHIẾU THEO KHO"} />;
};

export default LoaiPhieuTheoKhoHeader;
