"use client";
import {
  DataTable,
  DataTableColumnHeaderSort,
} from "@/components/ui/dataTable";
import { ColumnDef } from "@tanstack/react-table";
import { useMemo } from "react";
import { ProductType } from "../_utils/definitions/loai-phieu-theo-kho.dto";

export interface LoaiPhieuTheoKhoDataTableProps {
  data: ProductType[];
  selectedProductTypeID: string;
  setSelectedProductTypeID: (id: string) => void;
}

const columns: ColumnDef<ProductType>[] = [
  {
    id: "name",
    accessorKey: "name",
    header: ({ column }) => (
      <DataTableColumnHeaderSort
        column={column}
        title="Loại phiếu"
        className="justify-start"
      />
    ),
    enableSorting: true,
  },
];

const LoaiPhieuTheoKhoDataTable: React.FC<LoaiPhieuTheoKhoDataTableProps> = ({
  data,
  setSelectedProductTypeID,
  selectedProductTypeID,
}) => {
  const indexScrollTo = useMemo(
    () =>
      selectedProductTypeID
        ? data.findIndex(
            (row) => row.productTypeId?.toString() == selectedProductTypeID,
          )
        : 0,
    [selectedProductTypeID, data],
  );
  return (
    <div className="flex-1 flex flex-col h-full w-full">
      <DataTable
        className="w-full overflow-y-auto border"
        columns={columns}
        data={data}
        columnVisibilityInit={{ search: false }}
        enableColumnFilter={true}
        enablePaging={false}
        isSelectRowWhenUseArrowKey
        onRowClick={(row) => {
          setSelectedProductTypeID(row.productTypeId);
        }}
        indexScrollTo={indexScrollTo}
      />
    </div>
  );
};

export default LoaiPhieuTheoKhoDataTable;
