"use client";

import { useState } from "react";
import { ProductType } from "../_utils/definitions/loai-phieu-theo-kho.dto";
import LoaiPhieuTheoKhoDataTable from "./loai-phieu-theo-kho-datatable";
import { LoaiPhieuTheoKhoFooter } from "./loai-phieu-theo-kho-footer";

type LoaiPhieuTheoKhoPresentationProps = {
  data: ProductType[];
};
const LoaiPhieuTheoKhoPresentation = ({
  data,
}: LoaiPhieuTheoKhoPresentationProps) => {
  const [selectedProductTypeID, setSelectedProductTypeID] = useState<string>(
    data[0]?.productTypeId || "",
  );
  return (
    <div className="flex flex-col h-full">
      <LoaiPhieuTheoKhoDataTable
        data={data}
        selectedProductTypeID={selectedProductTypeID}
        setSelectedProductTypeID={setSelectedProductTypeID}
      />
      <LoaiPhieuTheoKhoFooter
        dataProductType={data}
        selectedProductTypeID={selectedProductTypeID}
        setSelectedProductTypeID={setSelectedProductTypeID}
      />
    </div>
  );
};
export default LoaiPhieuTheoKhoPresentation;
