import { ProductType } from "../_utils/definitions/loai-phieu-theo-kho.dto";
import { FilterFormValues } from "../_utils/schema";
import { ws_LoadLoaiPhieu_List } from "../_utils/services/loai-phieu-theo-kho.api";
import LoaiPhieuTheoKhoPresentation from "./loai-phieu-theo-kho-presentation";
export type LoaiPhieuTheoKhoContainerProps = {
  searchParams?: FilterFormValues;
};
const LoaiPhieuTheoKhoContainer = async ({
  searchParams,
}: LoaiPhieuTheoKhoContainerProps) => {
  let data: ProductType[] = [];
  if (searchParams?.stockID) {
    data = await ws_LoadLoaiPhieu_List(searchParams.stockID);
  }
  return <LoaiPhieuTheoKhoPresentation data={data} />;
};

export default LoaiPhieuTheoKhoContainer;
