"use client";
import { useFeedbackDialog } from "@/app/lib/feedback-dialog-provider";
import { notifySuccess } from "@/app/lib/utils";
import { getErrorMessage } from "@/app/lib/utils/errorUtils";
import { Select } from "@/components/select/select";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { useRouter, useSearchParams } from "next/navigation";
import { useState } from "react";
import { ProductType } from "../_utils/definitions/loai-phieu-theo-kho.dto";
import {
  ws_INV_ProductTypeInStock_Delete,
  ws_INV_ProductTypeInStock_Save,
  ws_LoadLoaiPhieu_List,
} from "../_utils/services/loai-phieu-theo-kho.api";
export interface LoaiPhieuTheoKhoFooterProps {
  dataProductType: ProductType[];
  selectedProductTypeID: string;
  setSelectedProductTypeID: (id: string) => void;
}

export function LoaiPhieuTheoKhoFooter({
  dataProductType,
  selectedProductTypeID,
  setSelectedProductTypeID,
}: LoaiPhieuTheoKhoFooterProps) {
  const searchParams = useSearchParams();
  const router = useRouter();

  const stockID = searchParams.get("stockID");

  const [productTypeList, setProductTypeList] = useState<ProductType[]>(
    dataProductType || [],
  );
  const [isAdd, setIsAdd] = useState<boolean>(false);
  const { alert } = useFeedbackDialog();
  const fetchData = async () => {
    try {
      if (stockID) {
        const data = await ws_LoadLoaiPhieu_List(stockID, 2);
        setProductTypeList(data);
      }
    } catch (error) {
      setProductTypeList([]);
      setSelectedProductTypeID("");
    }
  };

  const handleSave = async () => {
    try {
      if (stockID) {
        await ws_INV_ProductTypeInStock_Save(stockID, selectedProductTypeID);
        notifySuccess("Lưu thành công");
        router.refresh();
      }
    } catch (error) {
      await alert({
        title: "Lỗi",
        content: getErrorMessage(error),
      });
    } finally {
      setIsAdd(false);
      setProductTypeList(dataProductType);
    }
  };

  const handleDelete = async () => {
    try {
      if (stockID) {
        await ws_INV_ProductTypeInStock_Delete(stockID, selectedProductTypeID);
        notifySuccess("Xóa thành công");
        router.refresh();
      }
    } catch (error) {
      await alert({
        title: "Lỗi",
        content: getErrorMessage(error),
      });
    } finally {
      setIsAdd(false);
      setProductTypeList(dataProductType);
    }
  };

  const handleAdd = async () => {
    setIsAdd(true);
    await fetchData();
  };

  return (
    <div className="flex items-center justify-between bg-muted p-2 w-full">
      <div className="space-x-2">
        <Label>Loại phiếu</Label>
        <Select
          className="w-70"
          classNamePopover="w-full"
          classNameSelectList="max-h-96 w-70"
          placeholder="Chọn loại phiếu"
          value={selectedProductTypeID}
          onChange={(value) => {
            setSelectedProductTypeID(value);
          }}
          options={productTypeList?.map((item) => ({
            label: item.name,
            value: item.productTypeId,
          }))}
        />
      </div>

      <div className="flex gap-2">
        <Button variant="default" onClick={handleAdd}>
          Thêm
        </Button>
        <Button variant="default" onClick={handleDelete}>
          Xóa
        </Button>
        {isAdd && (
          <Button variant="default" onClick={handleSave}>
            Lưu
          </Button>
        )}
      </div>
    </div>
  );
}
