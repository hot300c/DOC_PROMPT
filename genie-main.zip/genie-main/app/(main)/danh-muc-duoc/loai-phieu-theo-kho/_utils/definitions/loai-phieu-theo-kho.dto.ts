export type ProductType = {
  productTypeId: string;
  name: string;
};
