import { getUserSession } from "@/actions/get-user-session";
import { InventoryStockRESP } from "@/app/(main)/duoc/shared/_utils/definitions/response";
import * as httpService from "@/app/lib/network/http";
import { ProductType } from "../definitions/loai-phieu-theo-kho.dto";

export const ws_L_InventoryStock_List = async (): Promise<
  InventoryStockRESP[]
> => {
  try {
    const { facId } = await getUserSession();
    const response = await httpService.post("/DataAccess", [
      {
        category: "QAHosGenericDB",
        command: "ws_L_InventoryStock_List",
        parameters: {
          FacID: facId,
          ActionType: 1,
        },
      },
    ]);
    return response.data.table;
  } catch (err) {
    return [];
  }
};
export const ws_LoadLoaiPhieu_List = async (
  stockID: string,
  actionType: number = 1,
): Promise<ProductType[]> => {
  try {
    const { facId } = await getUserSession();
    const response = await httpService.post("/DataAccess", [
      {
        category: "QAHosGenericDB",
        command: "ws_LoadLoaiPhieu_List",
        parameters: {
          StockID: stockID,
          FacID: facId,
          ActionType: actionType,
        },
      },
    ]);
    return response.data.table;
  } catch (error) {
    return [];
  }
};

export const ws_INV_ProductTypeInStock_Delete = async (
  stockID: string,
  productTypeId: string,
) => {
  const response = await httpService.post("/DataAccess", [
    {
      category: "QAHosGenericDB",
      command: "ws_INV_ProductTypeInStock_Delete",
      parameters: {
        StockID: stockID,
        ProductTypeId: productTypeId,
      },
    },
  ]);
  return response.data.table;
};

export const ws_INV_ProductTypeInStock_Save = async (
  stockID: string,
  productTypeId: string,
) => {
  const { facId } = await getUserSession();
  const response = await httpService.post("/DataAccess", [
    {
      category: "QAHosGenericDB",
      command: "ws_INV_ProductTypeInStock_Save",
      parameters: {
        FacID: facId,
        StockID: stockID,
        ProductTypeId: productTypeId,
      },
    },
  ]);
  return response.data.table;
};
