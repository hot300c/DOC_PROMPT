import { z } from "zod";

export const LoaiPhieuTheoKhoFormSchema = z
  .object({
    stockID: z.string().min(1),
    productTypeID: z.string().optional(),
  })
  .strict();

export type FilterFormValues = z.infer<typeof LoaiPhieuTheoKhoFormSchema>;
