import {
  ResizableHandle,
  ResizablePanel,
  ResizablePanelGroup,
} from "@/components/ui/resizable";
import { Suspense } from "react";
import NhomKhoDetailContainer from "./_components/detail/nhom-kho-detail-container";
import NhomKhoContainer from "./_components/nhom-kho-container";
import NhomKhoHeader from "./_components/nhom-kho-header";
import { NhomKhoFilterSchema } from "./_utils/schema";
import Loading from "./loading";

export default async function Page(props: {
  searchParams?: Promise<NhomKhoFilterSchema>;
}) {
  const searchParams = await props.searchParams;
  return (
    <div className="flex flex-col w-full h-full overflow-hidden">
      <NhomKhoHeader />
      <ResizablePanelGroup direction="vertical">
        <ResizablePanel defaultSize={33.33} minSize={10}>
          <NhomKhoContainer />
        </ResizablePanel>
        <ResizableHandle className="m-1" withHandle />
        <ResizablePanel defaultSize={66.67}>
          <Suspense key={`${searchParams?.groupID}`} fallback={<Loading />}>
            <NhomKhoDetailContainer searchParams={searchParams} />
          </Suspense>
        </ResizablePanel>
      </ResizablePanelGroup>
    </div>
  );
}
