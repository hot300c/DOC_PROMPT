"use client";

import FacilityInfo from "@/components/facilityInfo";

const NhomKhoHeader = () => {
  return <FacilityInfo page={"DANH MỤC - DƯỢC | NHÓM KHO"} />;
};

export default NhomKhoHeader;
