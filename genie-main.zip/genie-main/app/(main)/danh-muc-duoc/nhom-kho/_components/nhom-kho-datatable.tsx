"use client";
import {
  DataTable,
  DataTableColumnHeaderSort,
} from "@/components/ui/dataTable";
import { ColumnDef } from "@tanstack/react-table";
import { Ellipsis, X } from "lucide-react";
import { useSearchParams } from "next/navigation";
import { useMemo } from "react";
import { StockGroup } from "../_utils/definitions/nhom-kho.dto";

export interface NhomKhoDataTableProps {
  data: StockGroup[];
  onRowClick: (rowData: StockGroup) => void;
  onEdit: (rowData: StockGroup) => void;
  onDelete: (rowData: StockGroup) => void;
}

const NhomKhoDataTable: React.FC<NhomKhoDataTableProps> = ({
  data,
  onRowClick,
  onEdit,
  onDelete,
}) => {
  const searchParams = useSearchParams();
  const groupID = searchParams.get("groupID");
  const indexScrollTo = useMemo(
    () =>
      groupID ? data.findIndex((row) => row.groupID?.toString() == groupID) : 0,
    [groupID, data],
  );
  const columns: ColumnDef<StockGroup>[] = useMemo(
    () => [
      {
        id: "name",
        accessorKey: "name",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Tên nhóm kho"
            className="justify-start"
          />
        ),
        enableSorting: true,
      },
      {
        id: "edit",
        accessorKey: "edit",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Sửa"
            className="justify-start"
          />
        ),
        cell: ({ row }) => (
          <Ellipsis
            className="text-gray-500 cursor-pointer"
            onClick={() => {
              onEdit(row.original);
            }}
          />
        ),
      },
      {
        id: "delete",
        accessorKey: "delete",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Xóa"
            className="justify-start"
          />
        ),
        cell: ({ row }) => (
          <X
            className="text-gray-500 cursor-pointer"
            onClick={() => {
              onDelete(row.original);
            }}
          />
        ),
      },
    ],
    [onEdit, onDelete],
  );

  return (
    <div className="flex-1 flex flex-col h-full w-full">
      <DataTable
        className="w-full overflow-y-auto border"
        columns={columns}
        data={data}
        columnVisibilityInit={{ search: false }}
        enableColumnFilter={true}
        enablePaging={false}
        isSelectRowWhenUseArrowKey
        onRowClick={onRowClick}
        indexScrollTo={indexScrollTo}
      />
    </div>
  );
};

export default NhomKhoDataTable;
