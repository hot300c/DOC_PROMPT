import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

import { useFeedbackDialog } from "@/app/lib/feedback-dialog-provider";
import { notifySuccess } from "@/app/lib/utils";
import { getErrorMessage } from "@/app/lib/utils/errorUtils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useRouter } from "next/navigation";
import { useRef } from "react";
import { StockGroup } from "../_utils/definitions/nhom-kho.dto";
import { ws_L_INV_StockGroup_Save } from "../_utils/services/nhom-kho.api";

export type NhomKhoModalProps = {
  isOpen: boolean;
  onClosed: () => void;
  selectedRow: StockGroup;
};

const NhomKhoModal = ({ isOpen, onClosed, selectedRow }: NhomKhoModalProps) => {
  const inputRef = useRef<HTMLInputElement>(null);
  const router = useRouter();
  const { alert } = useFeedbackDialog();

  const onSave = async () => {
    if (inputRef.current?.value === "") {
      await alert({
        title: "Cảnh báo",
        content: "Tên nhóm kho không được để trống",
      });
      return;
    }
    try {
      await ws_L_INV_StockGroup_Save(
        selectedRow.groupID,
        inputRef.current?.value!,
      );
      notifySuccess("Lưu nhóm kho thành công");
      router.refresh();
      onClosed();
    } catch (error) {
      await alert({
        title: "Lỗi",
        content: getErrorMessage(error),
      });
    }
  };
  return (
    <Dialog open={isOpen} onOpenChange={onClosed}>
      <DialogContent className="bg-white min-w-[20%] flex flex-col h-[20vh]">
        <DialogHeader className="w-full">
          <DialogTitle>Thêm mới nhóm kho</DialogTitle>
        </DialogHeader>
        <div className="flex-1 flex flex-col gap-4 p-4">
          <div className="flex flex-row gap-2">
            <Label className="w-20">Nhóm kho: </Label>
            <Input ref={inputRef} defaultValue={selectedRow.name}></Input>
          </div>
          <Button className="self-end" variant="outline" onClick={onSave}>
            Lưu
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default NhomKhoModal;
