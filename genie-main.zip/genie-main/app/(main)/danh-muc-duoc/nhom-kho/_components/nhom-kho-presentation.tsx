"use client";

import { useFeedbackDialog } from "@/app/lib/feedback-dialog-provider";
import { notifySuccess } from "@/app/lib/utils";
import { getErrorMessage } from "@/app/lib/utils/errorUtils";
import { Button } from "@/components/ui/button";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { useEffect, useState } from "react";
import { StockGroup } from "../_utils/definitions/nhom-kho.dto";
import { ws_L_INV_StockGroup_Delete } from "../_utils/services/nhom-kho.api";
import NhomKhoDataTable from "./nhom-kho-datatable";
import NhomKhoModal from "./nhom-kho-modal";

type NhomKhoPresentationProps = {
  data: StockGroup[];
};
const NhomKhoPresentation = ({ data }: NhomKhoPresentationProps) => {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const { alert } = useFeedbackDialog();
  const [selectedStockGroup, setSelectedStockGroup] = useState<
    StockGroup | undefined
  >(data[0]);
  const [isOpenDetail, setOpenDetail] = useState<boolean>(false);

  const handleRowClick = (rowData: StockGroup) => {
    setSelectedStockGroup(rowData);
    const filteredValues = {
      ...Object.fromEntries(searchParams.entries()),
      groupID: rowData.groupID,
    };
    const query = new URLSearchParams(filteredValues).toString();
    router.push(pathname + "?" + query);
  };

  useEffect(() => {
    if (data && data[0]) {
      handleRowClick(data[0]);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleEdit = (rowData: StockGroup) => {
    setSelectedStockGroup(rowData);
    setOpenDetail(true);
  };

  const handleDelete = async (rowData: StockGroup) => {
    try {
      await ws_L_INV_StockGroup_Delete(rowData.groupID);
      notifySuccess("Xóa nhóm kho thành công");
      router.refresh();
    } catch (error) {
      await alert({
        title: "Lỗi",
        content: getErrorMessage(error),
      });
    }
  };

  const handleAddNew = () => {
    setSelectedStockGroup({
      groupID: "0",
      name: "",
    });
    setOpenDetail(true);
  };

  return (
    <div className="flex flex-col h-full">
      <div className="flex-1 overflow-auto">
        <NhomKhoDataTable
          data={data}
          onRowClick={handleRowClick}
          onDelete={handleDelete}
          onEdit={handleEdit}
        />
      </div>

      <div className="flex items-start justify-end m-1">
        <Button onClick={handleAddNew}>Thêm nhóm</Button>
      </div>
      {isOpenDetail && selectedStockGroup && (
        <NhomKhoModal
          isOpen={isOpenDetail}
          onClosed={() => {
            setOpenDetail(false);
          }}
          selectedRow={selectedStockGroup}
        />
      )}
    </div>
  );
};
export default NhomKhoPresentation;
