"use client";
import {
  DataTable,
  DataTableColumnHeaderSort,
} from "@/components/ui/dataTable";
import { ColumnDef } from "@tanstack/react-table";
import { Ellipsis, X } from "lucide-react";
import { useMemo } from "react";
import { StockGroupShipment } from "../../_utils/definitions/nhom-kho.dto";

export interface NhomKhoDetailDataTableProps {
  data: StockGroupShipment[];
  onEdit: (rowData: StockGroupShipment) => void;
  onDelete: (rowData: StockGroupShipment) => void;
}

const NhomKhoDetailDataTable: React.FC<NhomKhoDetailDataTableProps> = ({
  data,
  onEdit,
  onDelete,
}) => {
  const columns = useMemo<ColumnDef<StockGroupShipment>[]>(
    () => [
      {
        id: "type",
        accessorKey: "type",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Loại"
            className="justify-start"
          />
        ),
        enableSorting: true,
      },
      {
        id: "inTypeName",
        accessorKey: "inTypeName",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Loại nhập"
            className="justify-start"
          />
        ),
        enableSorting: true,
      },
      {
        id: "outTypeName",
        accessorKey: "outTypeName",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Loại xuất"
            className="justify-start"
          />
        ),
      },
      {
        id: "edit",
        accessorKey: "edit",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Sửa"
            className="justify-start"
          />
        ),
        cell: ({ row }) => (
          <Ellipsis
            className="text-gray-500 cursor-pointer"
            onClick={() => {
              onEdit(row.original);
            }}
          />
        ),
      },
      {
        id: "delete",
        accessorKey: "delete",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Xóa"
            className="justify-start"
          />
        ),
        cell: ({ row }) => (
          <X
            className="text-gray-500 cursor-pointer"
            onClick={() => {
              onDelete(row.original);
            }}
          />
        ),
      },
    ],
    [onEdit, onDelete],
  );
  return (
    <div className="flex-1 flex flex-col h-full w-full">
      <DataTable
        className="w-full overflow-y-auto border"
        columns={columns}
        data={data}
        columnVisibilityInit={{ search: false }}
        enableColumnFilter={true}
        enablePaging={false}
        isSelectRowWhenUseArrowKey
      />
    </div>
  );
};

export default NhomKhoDetailDataTable;
