import { INVInTypeListAllByCustomerRESP } from "@/app/(main)/duoc/lien-ket-kho/_utils/definitions/lien-ket-kho.response";
import { TableSelect } from "@/components/select/table-select";
import { DataTableColumnHeaderSort } from "@/components/ui/dataTable";
import { ColumnDef } from "@tanstack/react-table";
import React, { useMemo } from "react";

type Props = {
  list: INVInTypeListAllByCustomerRESP[];
  value: string | undefined;
  onChange: (value: string) => void;
};

const INTYPE_COLUMN_COMBOBOX: ColumnDef<INVInTypeListAllByCustomerRESP>[] = [
  {
    id: "inTypeName",
    accessorKey: "inTypeName",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Loại nhập" />
    ),
  },
  {
    id: "inTypeNameCaption",
    accessorKey: "inTypeNameCaption",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Đối tượng" />
    ),
  },
];

const SelectInType: React.FC<Props> = ({ list, value, onChange }) => {
  const selectedItem = useMemo(
    () => list.find((v) => v.inType == value),
    [value, list],
  );

  return (
    <TableSelect
      placeholderSearch="Chọn loại nhập"
      placeholder="Chọn loại nhập"
      className="w-full"
      classNamePopover="w-auto min-w-64"
      data={list}
      value={selectedItem}
      labelKey="inTypeName"
      valueKey="inType"
      onChange={(value) => onChange(value.inType)}
      columns={INTYPE_COLUMN_COMBOBOX}
    />
  );
};

export default SelectInType;
