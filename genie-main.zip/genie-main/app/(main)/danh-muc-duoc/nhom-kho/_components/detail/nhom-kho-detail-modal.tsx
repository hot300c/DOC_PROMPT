import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

import {
  INVInTypeListAllByCustomerRESP,
  INVOutTypeListAllByCustomerRESP,
} from "@/app/(main)/duoc/lien-ket-kho/_utils/definitions/lien-ket-kho.response";
import {
  ws_L_INVInType_ListAllByCustomer,
  ws_L_INVOutType_ListAllByCustomer,
} from "@/app/(main)/duoc/lien-ket-kho/_utils/services/lien-ket-kho.api";
import { useFeedbackDialog } from "@/app/lib/feedback-dialog-provider";
import { notifySuccess } from "@/app/lib/utils";
import { getErrorMessage } from "@/app/lib/utils/errorUtils";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import {
  StockGroup,
  StockGroupShipment,
} from "../../_utils/definitions/nhom-kho.dto";
import {
  ws_L_INV_StockGroup_List,
  ws_L_INV_StockGroupShipment_Save,
} from "../../_utils/services/nhom-kho.api";
import NhomKhoDetailModalForm from "./nhom-kho-detail-modal-form";

export type NhomKhoDetailModalProps = {
  isOpen: boolean;
  onClosed: () => void;
  selectedRow: StockGroupShipment;
};

const NhomKhoDetailModal = ({
  isOpen,
  onClosed,
  selectedRow,
}: NhomKhoDetailModalProps) => {
  const { alert } = useFeedbackDialog();
  const router = useRouter();
  const [outTypeList, setOutTypeList] = useState<
    INVOutTypeListAllByCustomerRESP[]
  >([]);
  const [inTypeList, setInTypeList] = useState<
    INVInTypeListAllByCustomerRESP[]
  >([]);
  const [stockGroupList, setStockGroupList] = useState<StockGroup[]>([]);
  const loadData = async () => {
    try {
      const [outTypeList, inTypeList, stockGroupList] = await Promise.all([
        ws_L_INVOutType_ListAllByCustomer(),
        ws_L_INVInType_ListAllByCustomer(),
        ws_L_INV_StockGroup_List(),
      ]);
      setOutTypeList(outTypeList);
      setInTypeList(inTypeList);
      setStockGroupList(stockGroupList);
    } catch (error) {
      console.error("Failed to fetch vaccine data", error);
    }
  };

  useEffect(() => {
    void loadData();
  }, []);

  const onSave = async (data: StockGroupShipment) => {
    try {
      await ws_L_INV_StockGroupShipment_Save({
        groupID: data.groupID,
        inTypeID: data.inTypeID,
        outTypeID: data.outTypeID,
        type: data.type,
        groupShipmentID: data.id,
      });
      notifySuccess("Lưu nhóm kho thành công");
      router.refresh();
      onClosed();
    } catch (error) {
      await alert({
        title: "Lỗi",
        content: getErrorMessage(error),
      });
    }
  };
  return (
    <Dialog open={isOpen} onOpenChange={onClosed}>
      <DialogContent className="bg-white min-w-[15%] flex flex-col h-[35vh]">
        <DialogHeader className="w-full">
          <DialogTitle>Thêm mới loại nhóm kho</DialogTitle>
        </DialogHeader>

        <NhomKhoDetailModalForm
          inTypeList={inTypeList}
          stockGroupList={stockGroupList}
          outTypeList={outTypeList}
          selectedRow={selectedRow}
          onSave={onSave}
        />
      </DialogContent>
    </Dialog>
  );
};

export default NhomKhoDetailModal;
