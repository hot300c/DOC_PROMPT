"use client";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
} from "@/components/ui/form";
import { useForm } from "react-hook-form";

import {
  INVInTypeListAllByCustomerRESP,
  INVOutTypeListAllByCustomerRESP,
} from "@/app/(main)/duoc/lien-ket-kho/_utils/definitions/lien-ket-kho.response";
import { Select } from "@/components/select/select";
import { Button } from "@/components/ui/button";
import { Types } from "../../_utils/constant";
import {
  StockGroup,
  StockGroupShipment,
} from "../../_utils/definitions/nhom-kho.dto";
import SelectInType from "./select-loai-nhap";
import SelectOutType from "./select-loai-xuat";

type NhomKhoDetailModalFormFilterProps = {
  stockGroupList: StockGroup[];
  inTypeList: INVInTypeListAllByCustomerRESP[];
  outTypeList: INVOutTypeListAllByCustomerRESP[];
  selectedRow: StockGroupShipment;
  onSave: (data: StockGroupShipment) => void;
};

const NhomKhoDetailModalForm = ({
  stockGroupList,
  inTypeList,
  outTypeList,
  selectedRow,
  onSave,
}: NhomKhoDetailModalFormFilterProps) => {
  const form = useForm<StockGroupShipment>({
    defaultValues: selectedRow,
  });

  const onSubmit = (data: StockGroupShipment) => {
    onSave(data);
  };

  return (
    <Form {...form}>
      <form
        onSubmit={form.handleSubmit(onSubmit)}
        className="flex flex-col gap-1 items-center h-full"
      >
        <FormField
          control={form.control}
          name="groupID"
          render={({ field }) => (
            <FormItem className="w-full flex flex-row">
              <FormLabel className="text-sm pr-1 font-medium mt-2 w-30">
                Nhóm kho
              </FormLabel>
              <FormControl>
                <Select
                  disabled={selectedRow.id == "0"}
                  className="w-full"
                  classNamePopover="w-full"
                  classNameSelectList="max-h-96"
                  placeholder="Chọn kho"
                  value={field.value}
                  onChange={(value) => {
                    field.onChange(value);
                  }}
                  options={stockGroupList.map((item) => ({
                    label: item.name,
                    value: item.groupID,
                  }))}
                />
              </FormControl>
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="type"
          render={({ field }) => (
            <FormItem className="w-full flex flex-row">
              <FormLabel className="text-sm pr-1 font-medium mt-2 w-30">
                Loại
              </FormLabel>
              <FormControl className="flex-2">
                <Select
                  className="w-full"
                  classNamePopover="w-full"
                  classNameSelectList="max-h-96 w-70"
                  placeholder="Chọn loại"
                  value={field.value}
                  onChange={(value) => {
                    field.onChange(value);
                  }}
                  options={Types}
                />
              </FormControl>
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="outTypeID"
          render={({ field }) => (
            <FormItem className="w-full flex flex-row">
              <FormLabel className="text-sm pr-1 font-medium mt-2 w-30">
                Loại xuất
              </FormLabel>
              <FormControl>
                <SelectOutType
                  list={outTypeList}
                  onChange={(value) => field.onChange(value)}
                  value={field.value}
                />
              </FormControl>
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="inTypeID"
          render={({ field }) => (
            <FormItem className="w-full flex flex-row">
              <FormLabel className="text-sm pr-1 font-medium mt-2 w-30">
                Loại nhận
              </FormLabel>
              <FormControl>
                <SelectInType
                  list={inTypeList}
                  onChange={(value) => field.onChange(value)}
                  value={field.value}
                />
              </FormControl>
            </FormItem>
          )}
        />
        <Button className="self-end mt-2" type="submit">
          Lưu
        </Button>
      </form>
    </Form>
  );
};

export default NhomKhoDetailModalForm;
