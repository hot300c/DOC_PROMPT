import { INVOutTypeListAllByCustomerRESP } from "@/app/(main)/duoc/lien-ket-kho/_utils/definitions/lien-ket-kho.response";
import { TableSelect } from "@/components/select/table-select";
import { DataTableColumnHeaderSort } from "@/components/ui/dataTable";
import { ColumnDef } from "@tanstack/react-table";
import React, { useMemo } from "react";

type Props = {
  list: INVOutTypeListAllByCustomerRESP[];
  value: string | undefined;
  onChange: (value: string) => void;
};

const OUTTYPE_COLUMN_COMBOBOX: ColumnDef<INVOutTypeListAllByCustomerRESP>[] = [
  {
    id: "outTypeName",
    accessorKey: "outTypeName",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Loại xuất" />
    ),
  },
  {
    id: "outTypeCaption",
    accessorKey: "outTypeCaption",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Đối tượng" />
    ),
  },
];

const SelectOutType: React.FC<Props> = ({ list, value, onChange }) => {
  const selectedItem = useMemo(
    () => list.find((v) => v.outType == value),
    [value, list],
  );

  return (
    <TableSelect
      placeholderSearch="Chọn loại xuất"
      placeholder="Chọn loại xuất"
      className="w-full"
      classNamePopover="w-auto min-w-64"
      data={list}
      value={selectedItem}
      labelKey="outTypeName"
      valueKey="outType"
      onChange={(value) => onChange(value.outType)}
      columns={OUTTYPE_COLUMN_COMBOBOX}
    />
  );
};

export default SelectOutType;
