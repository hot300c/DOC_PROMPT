"use client";

import { useFeedbackDialog } from "@/app/lib/feedback-dialog-provider";
import { notifySuccess } from "@/app/lib/utils";
import { getErrorMessage } from "@/app/lib/utils/errorUtils";
import { Button } from "@/components/ui/button";
import { useRouter, useSearchParams } from "next/navigation";
import { useState } from "react";
import { StockGroupShipment } from "../../_utils/definitions/nhom-kho.dto";
import { ws_L_INV_StockGroupShipment_Delete } from "../../_utils/services/nhom-kho.api";
import NhomKhoDetailDataTable from "./nhom-kho-detail-datatable";
import NhomKhoDetailModal from "./nhom-kho-detail-modal";

type NhomKhoDetailPresentationProps = {
  data: StockGroupShipment[];
};
const NhomKhoDetailPresentation = ({
  data,
}: NhomKhoDetailPresentationProps) => {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { alert } = useFeedbackDialog();
  const groupID = searchParams.get("groupID") || "";
  const [isOpenDetail, setOpenDetail] = useState<boolean>(false);
  const [selectedStockGroupShipment, setSelectedStockGroupShipment] = useState<
    StockGroupShipment | undefined
  >(data[0]);

  const handleEdit = (rowData: StockGroupShipment) => {
    setSelectedStockGroupShipment(rowData);
    setOpenDetail(true);
  };

  const handleDelete = async (rowData: StockGroupShipment) => {
    try {
      await ws_L_INV_StockGroupShipment_Delete(rowData.id);
      notifySuccess("Xóa loại nhóm thành công");
      router.refresh();
    } catch (error) {
      await alert({
        title: "Lỗi",
        content: getErrorMessage(error),
      });
    }
  };

  const handleAddNew = () => {
    setSelectedStockGroupShipment({
      id: "0",
      facID: "",
      groupID: groupID,
      inTypeID: "",
      outTypeID: "",
      type: "",
      groupName: "",
      inTypeName: "",
      outTypeName: "",
      name: "",
      description: "",
    } as StockGroupShipment);
    setOpenDetail(true);
  };

  return (
    <div className="flex flex-col h-full">
      <div className="flex-1 overflow-auto">
        <NhomKhoDetailDataTable
          data={data}
          onDelete={handleDelete}
          onEdit={handleEdit}
        />
      </div>
      <div className="flex items-start justify-end m-2">
        <Button onClick={handleAddNew}>Thêm loại nhóm</Button>
      </div>
      {isOpenDetail && selectedStockGroupShipment && (
        <NhomKhoDetailModal
          isOpen={isOpenDetail}
          onClosed={() => {
            setOpenDetail(false);
          }}
          selectedRow={selectedStockGroupShipment}
        />
      )}
    </div>
  );
};
export default NhomKhoDetailPresentation;
