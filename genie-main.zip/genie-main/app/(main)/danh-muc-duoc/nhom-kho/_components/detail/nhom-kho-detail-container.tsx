import { StockGroupShipment } from "../../_utils/definitions/nhom-kho.dto";
import { NhomKhoFilterSchema } from "../../_utils/schema";
import { ws_L_INV_StockGroupShipment_ListByGroupID } from "../../_utils/services/nhom-kho.api";
import NhomKhoDetailPresentation from "./nhom-kho-detail-presentation";
export type NhomKhoDetailContainerProps = {
  searchParams?: NhomKhoFilterSchema;
};
const NhomKhoDetailContainer = async ({
  searchParams,
}: NhomKhoDetailContainerProps) => {
  let data: StockGroupShipment[] = [];
  if (searchParams?.groupID) {
    data = await ws_L_INV_StockGroupShipment_ListByGroupID(
      searchParams.groupID,
    );
  }
  return <NhomKhoDetailPresentation data={data} />;
};

export default NhomKhoDetailContainer;
