import { ws_L_INV_StockGroup_List } from "../_utils/services/nhom-kho.api";
import NhomKhoPresentation from "./nhom-kho-presentation";

const NhomKhoContainer = async () => {
  const data = await ws_L_INV_StockGroup_List();
  return <NhomKhoPresentation data={data} />;
};

export default NhomKhoContainer;
