export const Types = [
  { label: "Peer", value: "Peer" },
  { label: "Parent", value: "Parent" },
  { label: "Child", value: "Child" },
  { label: "Sibling", value: "Sibling" },
  { label: "Tenant", value: "Tenant" },
  { label: "Other", value: "Other" },
];
