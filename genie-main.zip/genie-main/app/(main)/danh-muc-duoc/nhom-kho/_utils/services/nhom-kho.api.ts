import { getUserSession } from "@/actions/get-user-session";
import * as httpService from "@/app/lib/network/http";
import { StockGroup, StockGroupShipment } from "../definitions/nhom-kho.dto";

export const ws_L_INV_StockGroup_List = async (): Promise<StockGroup[]> => {
  try {
    const { facId } = await getUserSession();
    const response = await httpService.post("/DataAccess", [
      {
        category: "QAHosGenericDB",
        command: "ws_L_INV_StockGroup_List",
        parameters: {
          FacID: facId,
        },
      },
    ]);
    return response.data.table;
  } catch (err) {
    return [];
  }
};

export const ws_L_INV_StockGroupShipment_ListByGroupID = async (
  groupID: string,
): Promise<StockGroupShipment[]> => {
  try {
    const { facId } = await getUserSession();
    const response = await httpService.post("/DataAccess", [
      {
        category: "QAHosGenericDB",
        command: "ws_L_INV_StockGroupShipment_ListByGroupID",
        parameters: {
          FacID: facId,
          GroupID: groupID,
        },
      },
    ]);
    return response.data.table;
  } catch (err) {
    return [];
  }
};

export const ws_L_INV_StockGroup_Save = async (
  groupID: string,
  name: string,
) => {
  const { facId } = await getUserSession();
  await httpService.post("/DataAccess", [
    {
      category: "QAHosGenericDB",
      command: "ws_L_INV_StockGroup_Save",
      parameters: {
        FacID: facId,
        GroupID: groupID,
        NAME: name,
      },
    },
  ]);
};

export const ws_L_INV_StockGroup_Delete = async (groupID: string) => {
  const { facId } = await getUserSession();
  await httpService.post("/DataAccess", [
    {
      category: "QAHosGenericDB",
      command: "ws_L_INV_StockGroup_Delete",
      parameters: {
        FacID: facId,
        GroupID: groupID,
      },
    },
  ]);
};

export const ws_L_INV_StockGroupShipment_Delete = async (
  groupShipmentID: string,
) => {
  const { facId } = await getUserSession();
  await httpService.post("/DataAccess", [
    {
      category: "QAHosGenericDB",
      command: "ws_L_INV_StockGroupShipment_Delete",
      parameters: {
        FacID: facId,
        GroupShipmentID: groupShipmentID,
      },
    },
  ]);
};

export const ws_L_INV_StockGroupShipment_List = async (): Promise<
  StockGroupShipment[]
> => {
  try {
    const { facId } = await getUserSession();
    const response = await httpService.post("/DataAccess", [
      {
        category: "QAHosGenericDB",
        command: "ws_L_INV_StockGroupShipment_List",
        parameters: {
          FacID: facId,
        },
      },
    ]);
    return response.data.table;
  } catch (err) {
    return [];
  }
};

type StockGroupShipmentSaveREQ = {
  inTypeID: string;
  outTypeID: string;
  type: string;
  groupShipmentID: string;
  groupID: string;
};

export const ws_L_INV_StockGroupShipment_Save = async (
  req: StockGroupShipmentSaveREQ,
) => {
  const { facId } = await getUserSession();
  await httpService.post("/DataAccess", [
    {
      category: "QAHosGenericDB",
      command: "ws_L_INV_StockGroupShipment_Save",
      parameters: {
        FacID: facId,
        GroupID: req.groupID,
        GroupShipmentID: req.groupShipmentID,
        Type: req.type,
        InTypeID: req.inTypeID,
        OutTypeID: req.outTypeID,
      },
    },
  ]);
};
