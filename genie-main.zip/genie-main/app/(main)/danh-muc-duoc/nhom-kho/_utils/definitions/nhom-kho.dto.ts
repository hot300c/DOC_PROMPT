export type StockGroup = {
  groupID: string;
  name: string;
};

export type StockGroupShipment = {
  id: string;
  facID: string;
  groupID: string;
  inTypeID: string;
  outTypeID: string;
  type: string;
  groupName: string;
  inTypeName: string;
  outTypeName: string;
};
