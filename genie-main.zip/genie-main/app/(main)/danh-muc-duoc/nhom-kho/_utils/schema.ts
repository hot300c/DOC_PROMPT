"use client";
import { z } from "zod";

export const NhomKhoSchema = z.object({
  groupID: z.string(),
  typeId: z.string(),
});
export type NhomKhoFilterSchema = z.infer<typeof NhomKhoSchema>;
