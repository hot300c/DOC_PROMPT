"use client";
import { Checkbox } from "@/components/ui/checkbox";
import {
  DataTable,
  DataTableColumnHeaderSort,
} from "@/components/ui/dataTable";
import { ColumnDef } from "@tanstack/react-table";
import { useMemo } from "react";
import { VatTuRESP } from "../_utils/definitions/vat-tu.resp";

export type VatTuTableProps = {
  data: VatTuRESP[];
  onRowClick: (row: VatTuRESP) => void;
  productID: string | null;
};
const VatTuTable = ({ data, onRowClick, productID }: VatTuTableProps) => {
  const columns = useMemo(() => {
    const result: ColumnDef<VatTuRESP>[] = [
      {
        accessorKey: "index",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="STT"
            className="justify-start"
          />
        ),
        cell: ({ row }) => <div className="min-w-5">{row.index + 1}</div>,
        enableSorting: false,
      },
      {
        id: "productID",
        accessorKey: "productID",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title={
              <span>
                Mã <br></br> phần mềm
              </span>
            }
          />
        ),
        meta: {
          className: "text-left truncate",
        },
      },
      {
        id: "sttTheoDMI",
        accessorKey: "sttTheoDMI",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title={
              <span>
                Mã số theo <br></br> danh mục
              </span>
            }
          />
        ),
        meta: {
          className: "text-left truncate",
        },
      },
      {
        id: "maDungChung",
        accessorKey: "maDungChung",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title={
              <span>
                Mã <br></br> dùng chung
              </span>
            }
          />
        ),
        cell: ({ row }) => (
          <div title={row.original.maDungChung}>{row.original.maDungChung}</div>
        ),
      },
      {
        id: "maHieu",
        accessorKey: "maHieu",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Mã hiệu" />
        ),
      },
      {
        id: "hospitalCode",
        accessorKey: "hospitalCode",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Mã SP" />
        ),
        cell: ({ row }) => (
          <div className="min-w-24">
            <span title={row.original.hospitalCode}>
              {row.original.hospitalCode}
            </span>
          </div>
        ),
      },
      {
        id: "hospitalName",
        accessorKey: "hospitalName",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Tên SP" />
        ),
        cell: ({ row }) => (
          <div className="min-w-60">
            <span title={row.original.hospitalName}>
              {row.original.hospitalName}
            </span>
          </div>
        ),
      },
      {
        id: "medicareName",
        accessorKey: "medicareName",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title={
              <span>
                Tên <br></br>thương mại
              </span>
            }
          />
        ),
        cell: ({ row }) => (
          <div>
            <span title={row.original.medicareName}>
              {row.original.medicareName}
            </span>
          </div>
        ),
      },
      {
        id: "unitName",
        accessorKey: "unitName",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="ĐVT" />
        ),
      },
      {
        id: "quyCach",
        accessorKey: "quyCach",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title={
              <span>
                Qui <br></br>cách
              </span>
            }
          />
        ),
      },
      {
        id: "productType",
        accessorKey: "productType",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title={
              <span>
                Loại <br></br>danh mục
              </span>
            }
          />
        ),
        meta: {
          className: "text-left",
        },
      },
      {
        id: "productNganh",
        accessorKey: "productNganh",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Ngành" />
        ),
        meta: {
          className: "text-left",
        },
      },
      {
        id: "productNhom",
        accessorKey: "productNhom",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Nhóm" />
        ),
        meta: {
          className: "text-left min-w-60",
        },
      },
      {
        id: "productLoai",
        accessorKey: "productLoai",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Loại" />
        ),
        meta: {
          className: "text-left",
        },
      },
      {
        id: "countryName",
        accessorKey: "countryName",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title={
              <span>
                Nước <br></br>sản xuất
              </span>
            }
          />
        ),
        meta: {
          className: "text-left",
        },
      },
      {
        id: "hangsanxuat1",
        accessorKey: "hangsanxuat1",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title={
              <span>
                Hãng <br></br>sản xuất
              </span>
            }
          />
        ),
        meta: {
          className: "text-left",
        },
      },
      {
        id: "dinhMucHoacSoLanSuDung",
        accessorKey: "dinhMucHoacSoLanSuDung",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title={
              <span>
                Định mức <br></br>số lần sử dụng
              </span>
            }
          />
        ),
        meta: {
          className: "text-left",
        },
      },
      {
        id: "isMedicare",
        accessorKey: "isMedicare",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title={
              <span className="w-full block text-center">
                Thanh toán <br></br>riêng
              </span>
            }
          />
        ),
        meta: {
          className: "pl-1 text-center",
        },
        cell: ({ row }) => <Checkbox checked={row.original.isThuocHiem} />,
        filterFn: "isBoolean",
      },
      {
        id: "isUsing",
        accessorKey: "isUsing",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title={
              <span className="w-full block text-center">
                Đang <br></br>sử dụng
              </span>
            }
          />
        ),
        meta: {
          className: "pl-1 text-center",
        },
        cell: ({ row }) => <Checkbox checked={row.original.isThuocHiem} />,
        filterFn: "isBoolean",
      },
      {
        id: "modifiedByUser",
        accessorKey: "modifiedByUser",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Thay đổi gần nhất"
          />
        ),
        meta: {
          className: "text-left",
        },
      },
    ];
    return result;
  }, []);

  const indexScrollTo = useMemo(
    () =>
      productID
        ? data.findIndex((row) => row.productID.toString() == productID)
        : 0,
    [data, productID],
  );

  return (
    <div className="flex flex-col h-full w-full">
      <DataTable
        className="w-full h-full overflow-y-auto border"
        tableClassName="border"
        tHeadClass="z-40"
        columns={columns}
        data={data}
        enableColumnFilter={true}
        enablePaging={true}
        enableGlobalFilter={true}
        placeholderSearch="Nhập để tìm kiếm..."
        enableFooter
        onRowClick={onRowClick}
        indexScrollTo={indexScrollTo}
      ></DataTable>
    </div>
  );
};

export default VatTuTable;
