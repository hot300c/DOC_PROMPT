"use client";

import FacilityInfo from "@/components/facilityInfo";

export default function VatTuHeader() {
  return <FacilityInfo page={"DANH MỤC - DƯỢC | VẬT TƯ"} />;
}
