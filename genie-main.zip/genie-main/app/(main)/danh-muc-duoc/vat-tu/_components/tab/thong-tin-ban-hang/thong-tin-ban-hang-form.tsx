"use client";

import { PermissionEnum } from "@/app/lib/enums";
import { useAppPermissions } from "@/components/app-permissions/app-permissions";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { zodResolver } from "@hookform/resolvers/zod";
import { useEffect } from "react";
import { useForm } from "react-hook-form";
import { ThongTinBanHangRESP } from "../../../_utils/definitions/vat-tu.resp";
import {
  ThongTinBanHangFormData,
  ThongTinBanHangSchema,
} from "../../../_utils/schema/vat-tu-thong-tin-ban-hang-chema";

export type ThongTinBanHangFormProps = {
  thongTinBanHangData: ThongTinBanHangRESP | undefined;
  setFormData: (form: ThongTinBanHangFormData | undefined) => void;
};

export const ThongTinBanHangForm = ({
  thongTinBanHangData,
  setFormData,
}: ThongTinBanHangFormProps) => {
  const hasPermission = useAppPermissions();
  const isHasCaiDatApiKhiBan = hasPermission.hasPermission(
    PermissionEnum.DANH_MUC_DUOC_VAT_TU_CAI_DAT_API_KHI_BAN,
  );

  const defaultFormData: ThongTinBanHangFormData = {
    isBanTrongShop: thongTinBanHangData?.isBanTrongShop,
    isHienThiTungDong: thongTinBanHangData?.isHienThiTungDong,
    moTaSP: thongTinBanHangData?.moTaSP,
    apiKetThuc: thongTinBanHangData?.apiKetThuc,
    apiHuy: thongTinBanHangData?.apiHuy,
  };

  const mapVatTuToFormData = (
    vaccine: ThongTinBanHangFormData | undefined,
  ): ThongTinBanHangFormData => {
    if (!vaccine) return {} as ThongTinBanHangFormData;
    return Object.fromEntries(
      Object.keys(defaultFormData).map((key) => {
        let value =
          vaccine[key as keyof ThongTinBanHangFormData] ??
          defaultFormData[key as keyof ThongTinBanHangFormData];
        return [key, value];
      }),
    ) as ThongTinBanHangFormData;
  };

  const form = useForm<ThongTinBanHangFormData>({
    resolver: zodResolver(ThongTinBanHangSchema),
    defaultValues: mapVatTuToFormData(undefined),
  });

  useEffect(() => {
    form.reset(
      mapVatTuToFormData({
        isBanTrongShop: thongTinBanHangData?.isBanTrongShop,
        isHienThiTungDong: thongTinBanHangData?.isHienThiTungDong,
        moTaSP: thongTinBanHangData?.moTaSP,
        apiKetThuc: thongTinBanHangData?.apiKetThuc,
        apiHuy: thongTinBanHangData?.apiHuy,
      }),
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    thongTinBanHangData?.apiHuy,
    thongTinBanHangData?.apiKetThuc,
    thongTinBanHangData?.isBanTrongShop,
    thongTinBanHangData?.isHienThiTungDong,
    thongTinBanHangData?.moTaSP,
  ]);

  useEffect(() => {
    const subscription = form.watch((values, { name }) => {
      setFormData(form.getValues());
    });
    return () => subscription.unsubscribe();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [form]);

  return (
    <Form {...form}>
      <form className="w-full">
        <div>
          <div className="flex justify-between gap-1">
            <FormField
              control={form.control}
              name="isBanTrongShop"
              render={({ field }) => (
                <FormItem className="inline-flex items-center space-y-0">
                  <FormControl>
                    <div className="flex items-center gap-2">
                      <FormLabel className="whitespace-nowrap mr-6 ">
                        Cho phép bán trong shop
                      </FormLabel>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={(checked) => field.onChange(checked)}
                      />
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            ></FormField>
            <FormField
              control={form.control}
              name="isHienThiTungDong"
              render={({ field }) => (
                <FormItem className="inline-flex items-center space-y-0">
                  <FormControl>
                    <div className="flex items-center gap-2">
                      <FormLabel className="whitespace-nowrap mr-6 ">
                        Hiển thị thành từng dòng
                      </FormLabel>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={(checked) => field.onChange(checked)}
                      />
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            ></FormField>
          </div>
          <div className="mt-1">
            <Label className="whitespace-nowrap mr-[164px]">
              Mô tả sản phẩm
            </Label>
            <FormField
              control={form.control}
              name="moTaSP"
              render={({ field }) => (
                <FormItem className="flex items-center gap-2 w-full">
                  <FormControl className="w-full">
                    <Textarea
                      {...field}
                      onFocus={(e) => {
                        e.target.select();
                      }}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
          <div className="flex items-center mt-1">
            <Label className="whitespace-nowrap w-48">API khi kết thúc:</Label>
            <FormField
              control={form.control}
              disabled={!isHasCaiDatApiKhiBan}
              name="apiKetThuc"
              render={({ field }) => (
                <FormItem className="flex items-center gap-2 w-full">
                  <FormControl className="w-full">
                    <Input
                      {...field}
                      onFocus={(e) => {
                        e.target.select();
                      }}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
          <div className="flex items-center mt-1">
            <Label className="whitespace-nowrap w-48">API hủy:</Label>
            <FormField
              control={form.control}
              disabled={!isHasCaiDatApiKhiBan}
              name="apiHuy"
              render={({ field }) => (
                <FormItem className="flex items-center gap-2 w-full">
                  <FormControl className="w-full">
                    <Input
                      {...field}
                      onFocus={(e) => {
                        e.target.select();
                      }}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
        </div>
      </form>
    </Form>
  );
};
