"use client";

import { ELoadingMessages } from "@/app/lib/enums";
import { useFeedbackDialog } from "@/app/lib/feedback-dialog-provider";
import { getErrorMessage } from "@/app/lib/utils/errorUtils";
import useLoading from "@/components/loading";
import { Label } from "@/components/ui/label";
import { useCallback, useEffect, useState } from "react";
import {
  VatTuRESP,
  VatTuTuongDuongRESP,
} from "../../../_utils/definitions/vat-tu.resp";
import { getProductListThuocTuongDuong } from "../../../_utils/services/vat-tu.api";
import SanPhamComboBox from "../../combobox/vat-tu-tuong-duong-combobox";
import VatTuTuongDuongTable from "./vat-tu-tuong-duong-datatable";
import { VatTuTuongDuongFooter } from "./vat-tu-tuong-duong-footer";

export type VatTuTuongDuongTabProps = {
  selectedVatTu: VatTuRESP | undefined;
  exportData: () => void;
  vatTuData: VatTuRESP[];
};

export const VatTuTuongDuongTab = ({
  selectedVatTu,
  exportData,
  vatTuData,
}: VatTuTuongDuongTabProps) => {
  const { alert } = useFeedbackDialog();
  const { showLoading, hideLoading } = useLoading();

  const [sanPhamSelected, setSanPhamSelected] = useState<VatTuRESP | undefined>(
    undefined,
  );

  const [vatTuTuongDuonData, setVatTuTuongDuonData] = useState<
    VatTuTuongDuongRESP[]
  >([]);

  const onHandleAddNew = () => {
    setSanPhamSelected(undefined);
  };

  const handleFetchDataVatTuTuongDuong = useCallback(
    async (productID: number) => {
      const loadingId = showLoading(ELoadingMessages.WAITING);
      try {
        var response = await getProductListThuocTuongDuong(productID ?? 0);
        setVatTuTuongDuonData(response);
      } catch (err) {
        await alert({
          title: "Lỗi",
          content: getErrorMessage(err),
        });
      } finally {
        hideLoading(loadingId);
      }
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [],
  );

  const onRowCick = (row: VatTuTuongDuongRESP) => {
    const sanPham = vatTuData.find(
      (q) => q.productID === Number(row.productID ?? 0),
    );
    setSanPhamSelected(sanPham);
  };

  useEffect(() => {
    void handleFetchDataVatTuTuongDuong(selectedVatTu?.productID ?? 0);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedVatTu?.productID]);

  return (
    <div className="flex h-full flex-col overflow-hidden px-4">
      <div className="flex items-center mt-1 mb-1">
        <Label className="whitespace-nowrap mr-4">Sản phẩm</Label>
        <SanPhamComboBox
          sanPhams={vatTuData}
          selectedSanPhamID={sanPhamSelected?.productID.toString()}
          handleSanPhamSelect={(sp) => {
            setSanPhamSelected(sp);
          }}
        />
      </div>
      <div className="flex-1 min-h-0 overflow-auto">
        <VatTuTuongDuongTable
          vatTuTuongDuonData={vatTuTuongDuonData}
          onRowClick={onRowCick}
        />
      </div>
      <VatTuTuongDuongFooter
        onHandleAddNew={onHandleAddNew}
        selectedVatTu={selectedVatTu}
        handleFetchDataVatTuTuongDuong={handleFetchDataVatTuTuongDuong}
        exportData={exportData}
        sanPhamSelected={sanPhamSelected}
      ></VatTuTuongDuongFooter>
    </div>
  );
};
