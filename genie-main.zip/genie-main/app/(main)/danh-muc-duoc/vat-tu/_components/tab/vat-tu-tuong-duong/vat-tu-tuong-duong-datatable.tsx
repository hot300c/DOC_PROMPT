"use client";
import {
  DataTable,
  DataTableColumnHeaderSort,
} from "@/components/ui/dataTable";
import { ColumnDef } from "@tanstack/react-table";
import { useMemo } from "react";
import { VatTuTuongDuongRESP } from "../../../_utils/definitions/vat-tu.resp";

export type VatTuTuongDuongTableProps = {
  vatTuTuongDuonData: VatTuTuongDuongRESP[];
  onRowClick: (row: VatTuTuongDuongRESP) => void;
};
const VatTuTuongDuongTable = ({
  vatTuTuongDuonData,
  onRowClick,
}: VatTuTuongDuongTableProps) => {
  const columns = useMemo(() => {
    const result: ColumnDef<VatTuTuongDuongRESP>[] = [
      {
        id: "productID",
        accessorKey: "productID",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Mã phần mềm" />
        ),
        meta: {
          className: "text-overflow-ellipsis truncate",
        },
      },
      {
        id: "hospitalCode",
        accessorKey: "hospitalCode",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Mã sản phẩm" />
        ),
        meta: {
          className: "text-overflow-ellipsis truncate",
        },
      },
      {
        id: "hospitalName",
        accessorKey: "hospitalName",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Tên vật tư" />
        ),
        meta: {
          className: "text-overflow-ellipsis truncate",
        },
      },
      {
        id: "unitName",
        accessorKey: "unitName",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Đơn vị tính" />
        ),
        meta: {
          className: "text-overflow-ellipsis truncate",
        },
      },
      {
        id: "productNganh",
        accessorKey: "productNganh",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Ngành" />
        ),
        meta: {
          className: "text-overflow-ellipsis truncate",
        },
      },
      {
        id: "productNhom",
        accessorKey: "productNhom",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Nhóm" />
        ),
        meta: {
          className: "text-overflow-ellipsis truncate",
        },
      },
      {
        id: "productLoai",
        accessorKey: "productLoai",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Loại" />
        ),
        meta: {
          className: "text-overflow-ellipsis truncate",
        },
      },
    ];
    return result;
  }, []);

  return (
    <div className="flex-1 flex flex-col h-full w-full">
      <DataTable
        className="w-full overflow-y-auto border"
        tableClassName="border"
        tHeadClass="z-40"
        columns={columns}
        data={vatTuTuongDuonData}
        enableColumnFilter={false}
        enablePaging={false}
        enableGlobalFilter={false}
        placeholderSearch="Nhập để tìm kiếm..."
        enableFooter
        onRowClick={onRowClick}
      ></DataTable>
    </div>
  );
};

export default VatTuTuongDuongTable;
