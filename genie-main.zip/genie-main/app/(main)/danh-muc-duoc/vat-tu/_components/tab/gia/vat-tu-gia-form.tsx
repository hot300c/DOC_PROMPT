"use client";

import { ProductPriceListRESP } from "@/app/(main)/danh-muc-duoc/vaccine/_utils/definitions/vaccine.resp";
import InputAvailableQty from "@/app/(main)/duoc/duyet-du-tru/_components/input-available-qty";
import { DATE_FORMAT } from "@/app/lib/enums";
import { InputDatePicker } from "@/components/input-date-picker";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { zodResolver } from "@hookform/resolvers/zod";
import { format } from "date-fns/format";
import { useEffect } from "react";
import { useForm } from "react-hook-form";
import { VatTuRESP } from "../../../_utils/definitions/vat-tu.resp";
import { VatTuGiaFormData } from "../../../_utils/schema/vat-tu-gia-chema";
import { VatTuSanPhamSchema } from "../../../_utils/schema/vat-tu-san-pham-chema";

export type VatTuGiaFormProps = {
  productPrice: ProductPriceListRESP | undefined;
  setFormData: (form: VatTuGiaFormData | undefined) => void;
  selectedVatTu: VatTuRESP | undefined;
};

export const VatTuGiaForm = ({
  productPrice,
  setFormData,
  selectedVatTu,
}: VatTuGiaFormProps) => {
  const defaultFormData: VatTuGiaFormData = {
    hospitalPrice: 0,
    medicarePrice: 0,
    effFrom: null,
    effThru: null,
    armyPrice: 0,
    giaDichVu: 0,
    giaDiemThuong: 0,
    sttkqdt: "",
    tenDonViSYT: "",
    soQDPheDuyet: "",
    soQDMuaSamTrucTiep: "",
    ngayHieuLuc: "",
  };

  const mapVatTuToFormData = (
    vaccine: VatTuGiaFormData | undefined,
  ): VatTuGiaFormData => {
    if (!vaccine) return {} as VatTuGiaFormData;
    return Object.fromEntries(
      Object.keys(defaultFormData).map((key) => {
        let value =
          vaccine[key as keyof VatTuGiaFormData] ??
          defaultFormData[key as keyof VatTuGiaFormData];
        return [key, value];
      }),
    ) as VatTuGiaFormData;
  };

  const form = useForm<VatTuGiaFormData>({
    resolver: zodResolver(VatTuSanPhamSchema),
    defaultValues: mapVatTuToFormData(undefined),
  });

  useEffect(() => {
    form.reset(
      mapVatTuToFormData({
        hospitalPrice: productPrice?.hospitalPrice ?? 0,
        medicarePrice: productPrice?.medicarePrice ?? 0,
        effFrom: productPrice?.effFrom,
        effThru: productPrice?.effThru,
        giaDiemThuong: productPrice?.giaDiemThuong ?? 0,
        armyPrice: productPrice?.armyPrice ?? 0,
        giaDichVu: productPrice?.giaDichVu ?? 0,
        sttkqdt: selectedVatTu?.sttkqdt,
        tenDonViSYT: selectedVatTu?.tenDonViSYT,
        soQDPheDuyet: selectedVatTu?.soQDPheDuyet ?? "",
        soQDMuaSamTrucTiep: selectedVatTu?.soQDMuaSamTrucTiep ?? "",
        ngayHieuLuc: selectedVatTu?.ngayHieuLuc ?? "2999-01-01",
      }),
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    productPrice?.armyPrice,
    productPrice?.effFrom,
    productPrice?.effThru,
    productPrice?.giaDichVu,
    productPrice?.giaDiemThuong,
    productPrice?.hospitalPrice,
    productPrice?.medicarePrice,
    selectedVatTu?.ngayHieuLuc,
    selectedVatTu?.soQDMuaSamTrucTiep,
    selectedVatTu?.soQDPheDuyet,
    selectedVatTu?.sttkqdt,
    selectedVatTu?.tenDonViSYT,
  ]);

  useEffect(() => {
    const subscription = form.watch((values, { name }) => {
      setFormData(form.getValues());
    });
    return () => subscription.unsubscribe();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [form]);

  return (
    <Form {...form}>
      <form className="w-full">
        <div className="flex  gap-1">
          <div className="flex items-center">
            <Label className="whitespace-nowrap mr-2">Giá thu phí</Label>
            <div>
              <FormField
                control={form.control}
                name="hospitalPrice"
                render={({ field }) => (
                  <FormItem className="flex items-center gap-4 w-full">
                    <FormControl>
                      <InputAvailableQty
                        className="max-w-20"
                        id="hospitalPrice"
                        availableQty={Number(field.value ?? 0)}
                        onChange={async (value) => {
                          form.setValue("hospitalPrice", value);
                        }}
                      />
                    </FormControl>
                  </FormItem>
                )}
              />
            </div>
          </div>
          <div className="flex items-center">
            <Label className="whitespace-nowrap mr-2">Giá bảo hiểm</Label>
            <FormField
              control={form.control}
              name="medicarePrice"
              render={({ field }) => (
                <FormItem className="flex items-center gap-4">
                  <FormControl>
                    <InputAvailableQty
                      id="medicarePrice"
                      className="max-w-20"
                      availableQty={Number(field.value ?? 0)}
                      onChange={async (value) => {
                        form.setValue("medicarePrice", value);
                      }}
                    />
                  </FormControl>
                </FormItem>
              )}
            />
          </div>
          <div className="flex items-center">
            <Label className="whitespace-nowrap mr-2">Giá dịch vụ</Label>
            <FormField
              control={form.control}
              name="giaDichVu"
              render={({ field }) => (
                <FormItem className="flex items-center gap-4">
                  <FormControl>
                    <InputAvailableQty
                      id="giaDichVu"
                      className="max-w-20"
                      availableQty={Number(field.value ?? 0)}
                      onChange={async (value) => {
                        form.setValue("giaDichVu", value);
                      }}
                    />
                  </FormControl>
                </FormItem>
              )}
            />
          </div>

          <div className="flex items-center">
            <Label className="whitespace-nowrap mr-2">Điểm thưởng</Label>
            <FormField
              control={form.control}
              name="giaDiemThuong"
              render={({ field }) => (
                <FormItem className="flex items-center gap-4">
                  <FormControl>
                    <InputAvailableQty
                      id="giaDiemThuong"
                      className="max-w-20"
                      availableQty={Number(field.value ?? 0)}
                      onChange={async (value) => {
                        form.setValue("giaDiemThuong", value);
                      }}
                    />
                  </FormControl>
                </FormItem>
              )}
            />
          </div>

          <div className="flex items-center">
            <Label className="whitespace-nowrap mr-2">Ngày hiệu lực</Label>
            <FormField
              control={form.control}
              name="effFrom"
              render={({ field }) => (
                <FormItem className="flex items-center w-full sm:w-auto">
                  <FormControl className="flex-1">
                    <div className="relative">
                      <InputDatePicker
                        value={field.value ? new Date(field.value) : undefined}
                        onChange={async (date) => {
                          date &&
                            field.onChange(format(date, DATE_FORMAT.MMDDYYYY));
                        }}
                      />
                    </div>
                  </FormControl>
                </FormItem>
              )}
            />
          </div>
          <div className="flex items-center">
            <Label className="whitespace-nowrap mr-2">Đến ngày</Label>
            <FormField
              control={form.control}
              name="effThru"
              render={({ field }) => (
                <FormItem className="flex items-center w-full sm:w-auto">
                  <FormControl className="flex-1">
                    <div className="relative">
                      <InputDatePicker
                        disabled={true}
                        value={field.value ? new Date(field.value) : undefined}
                        onChange={async (date) => {
                          date &&
                            field.onChange(format(date, DATE_FORMAT.MMDDYYYY));
                        }}
                      />
                    </div>
                  </FormControl>
                </FormItem>
              )}
            />
          </div>
        </div>
        <div className="text-sm font-semibold mt-1">
          Thống kê kết quả trúng thầu
        </div>
        <div className="flex  gap-1">
          <div className="flex items-center mt-1 w-1/5">
            <Label className="whitespace-nowrap mr-4 ">
              STT mã hóa theo KQĐT
            </Label>
            <FormField
              control={form.control}
              name="sttkqdt"
              render={({ field }) => (
                <FormItem className="flex items-center gap-2 w-full">
                  <FormControl className="flex-1">
                    <Input
                      {...field}
                      onFocus={(e) => {
                        e.target.select();
                      }}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
          <div className="flex items-center mt-1  w-1/5">
            <Label className="whitespace-nowrap mr-4 ">
              Tên đơn vị (SYT/BV)
            </Label>
            <FormField
              control={form.control}
              name="tenDonViSYT"
              render={({ field }) => (
                <FormItem className="flex items-center gap-2 w-full">
                  <FormControl className="flex-1">
                    <Input
                      {...field}
                      onFocus={(e) => {
                        e.target.select();
                      }}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
          <div className="flex items-center mt-1  w-1/5">
            <Label className="whitespace-nowrap mr-4 ">
              Số QĐ phê duyệt kết quả đấu thầu
            </Label>
            <FormField
              control={form.control}
              name="soQDPheDuyet"
              render={({ field }) => (
                <FormItem className="flex items-center gap-2 w-full">
                  <FormControl className="flex-1">
                    <Input
                      {...field}
                      onFocus={(e) => {
                        e.target.select();
                      }}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
          <div className="flex items-center mt-1  w-1/5">
            <Label className="whitespace-nowrap mr-4 ">
              Số mua sắm trực tiếp
            </Label>
            <FormField
              control={form.control}
              name="soQDMuaSamTrucTiep"
              render={({ field }) => (
                <FormItem className="flex items-center gap-2 w-full">
                  <FormControl className="flex-1">
                    <Input
                      {...field}
                      onFocus={(e) => {
                        e.target.select();
                      }}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
          <div className="flex items-center w-1/5">
            <Label className="whitespace-nowrap mr-2">Đến ngày</Label>
            <FormField
              control={form.control}
              name="ngayHieuLuc"
              render={({ field }) => (
                <FormItem className="flex items-center w-full sm:w-auto">
                  <FormControl className="flex-1">
                    <div className="relative">
                      <InputDatePicker
                        value={field.value ? new Date(field.value) : undefined}
                        onChange={async (date) => {
                          date &&
                            field.onChange(format(date, DATE_FORMAT.MMDDYYYY));
                        }}
                      />
                    </div>
                  </FormControl>
                </FormItem>
              )}
            />
          </div>
        </div>
      </form>
    </Form>
  );
};
