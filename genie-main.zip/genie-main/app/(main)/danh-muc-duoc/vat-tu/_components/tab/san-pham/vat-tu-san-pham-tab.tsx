"use client";

import HangSanXuatComboBox from "@/app/(main)/danh-muc-duoc/vaccine/_components/combobox/hang-san-xuat-combobox";
import NuocSanXuatComboBox from "@/app/(main)/danh-muc-duoc/vaccine/_components/combobox/nuoc-san-xuat-combobox";
import { loaiThaus } from "@/app/(main)/danh-muc-duoc/vaccine/_utils/data";
import { NuocSanXuatRESP } from "@/app/(main)/danh-muc-duoc/vaccine/_utils/definitions/vaccine.resp";
import InputAvailableQty from "@/app/(main)/duoc/duyet-du-tru/_components/input-available-qty";
import { MultiSelect } from "@/components/select/multi-select";
import { Select } from "@/components/select/select";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { zodResolver } from "@hookform/resolvers/zod";
import { useEffect, useMemo, useState } from "react";
import { useForm } from "react-hook-form";
import { CommonRESP } from "../../../../shared/_utils/definitions/response";
import { useVatTu } from "../../../_context/vat-tu-context";
import { VatTuData, VatTuRESP } from "../../../_utils/definitions/vat-tu.resp";
import {
  VatTuSanPhamFormData,
  VatTuSanPhamSchema,
} from "../../../_utils/schema/vat-tu-san-pham-chema";
import LoaiThauComboBox from "../../combobox/loai-thau-combobox";
import { VatTuSanPhamFooter } from "./vat-tu-san-pham-footer";

export type VaccineSanPhamTabProps = {
  vatTuData: VatTuData;
  selectedVatTu: VatTuRESP | undefined;
  setSelectedVatTu: (vatTu: VatTuRESP | undefined) => void;
  data: VatTuRESP[];
  exportData: () => void;
  mapVatTuToFormData: (vatTu: VatTuRESP | undefined) => VatTuSanPhamFormData;
  defaultFormData: VatTuSanPhamFormData;
};

export const VatTuSanPhamTab = ({
  vatTuData,
  selectedVatTu,
  setSelectedVatTu,
  exportData,
  data,
  mapVatTuToFormData,
  defaultFormData,
}: VaccineSanPhamTabProps) => {
  const { setFormVatTuSamPhamData } = useVatTu();
  const [loaiThauSelect, setLoaiThauSelect] = useState<CommonRESP | undefined>(
    undefined,
  );

  const [countrySelect, setCountrySelect] = useState<
    NuocSanXuatRESP | undefined
  >(undefined);

  const [hangSanXuatSelect, setHangSanXuatSelect] = useState<
    CommonRESP | undefined
  >(undefined);

  const productTypes = useMemo(() => {
    return vatTuData.productTypes.map((item) => ({
      label: item.name,
      value: item.productTypeID.toString(),
    }));
  }, [vatTuData.productTypes]);

  const productNganhs = useMemo(() => {
    return vatTuData.productNganhs.map((item) => ({
      label: item.name,
      value: item.id.toString(),
    }));
  }, [vatTuData.productNganhs]);

  const productNhoms = useMemo(() => {
    return vatTuData.productNhoms.map((item) => ({
      label: item.name,
      value: item.id.toString(),
    }));
  }, [vatTuData.productNhoms]);

  const productLoais = useMemo(() => {
    return vatTuData.productLoais.map((item) => ({
      label: item.name,
      value: item.id.toString(),
    }));
  }, [vatTuData.productLoais]);

  const donViTinh = useMemo(() => {
    return vatTuData.uoms.map((item) => ({
      label: item.unitName,
      value: item.unitID.toString(),
    }));
  }, [vatTuData.uoms]);

  const duongDungs = useMemo(() => {
    return vatTuData.cachDungThuocs.map((item) => ({
      label: item.comboValue ?? "",
      value: (item.comboValue ?? 0).toString(),
    }));
  }, [vatTuData.cachDungThuocs]);

  const inventoryStocks = useMemo(() => {
    return vatTuData.inventoryStocks.map((item) => ({
      label: item.name ?? "",
      value: (item.stockID ?? 0).toString(),
    }));
  }, [vatTuData.inventoryStocks]);

  useEffect(() => {
    if (!!selectedVatTu?.nuocSanXuat) {
      const country = vatTuData.countrys.find(
        (item) => item.countryID === selectedVatTu.nuocSanXuat,
      );
      handleNuocSanXuatSelect(country);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedVatTu?.nuocSanXuat, vatTuData.countrys]);

  const handleNuocSanXuatSelect = (country?: NuocSanXuatRESP) => {
    setCountrySelect(country);
    form.setValue("nuocSanXuat", country?.countryID);
  };

  useEffect(() => {
    if (!!selectedVatTu?.hangSanXuat) {
      const hangSanXuat = vatTuData.hangSanXuats.find(
        (item) => item.id === selectedVatTu.hangSanXuat,
      );
      handleHangSanXuatSelect(hangSanXuat);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedVatTu?.hangSanXuat, vatTuData.hangSanXuats]);

  const handleHangSanXuatSelect = (country?: CommonRESP) => {
    setHangSanXuatSelect(country);
    form.setValue("hangSanXuat", country?.id);
  };

  useEffect(() => {
    if (!!selectedVatTu?.loaiThau) {
      const loaiThau = loaiThaus.find(
        (item) => item.id === selectedVatTu.loaiThau,
      );
      handleLoaiThauSelect(loaiThau);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedVatTu?.loaiThau, loaiThaus]);

  const handleLoaiThauSelect = (loaiThau?: CommonRESP) => {
    setLoaiThauSelect(loaiThau);
    form.setValue("loaiThau", loaiThau?.id);
  };

  const form = useForm<VatTuSanPhamFormData>({
    resolver: zodResolver(VatTuSanPhamSchema),
    defaultValues: mapVatTuToFormData(selectedVatTu),
  });

  // Cập nhật form khi selectedVatTu thay đổi
  useEffect(() => {
    form.reset(mapVatTuToFormData(selectedVatTu));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedVatTu]);

  const onHandleAddNew = () => {
    form.reset(defaultFormData);
    setCountrySelect(undefined);
    setHangSanXuatSelect(undefined);
    setSelectedVatTu(undefined);
    setLoaiThauSelect(undefined);
  };

  useEffect(() => {
    const subscription = form.watch((values, { name }) => {
      setFormVatTuSamPhamData(form.getValues());
    });
    return () => subscription.unsubscribe();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [form]);

  return (
    <div className="px-4">
      <Form {...form}>
        <form className="flex flex-col w-full">
          <div className="flex-1 flex min-h-0 gap-2">
            <div className="w-1/4">
              <div className="flex items-center">
                <Label className="whitespace-nowrap w-48 ">
                  Mã số theo danh mục
                </Label>
                <FormField
                  control={form.control}
                  name="sttTheoDMI"
                  render={({ field }) => (
                    <FormItem className="flex items-center gap-2 w-full">
                      <FormControl className="flex-1">
                        <Input
                          {...field}
                          onFocus={(e) => {
                            e.target.select();
                          }}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <div className="flex items-center mt-1">
                <Label className="whitespace-nowrap w-48 ">Mã dùng chung</Label>
                <FormField
                  control={form.control}
                  name="maDungChung"
                  render={({ field }) => (
                    <FormItem className="flex items-center gap-2 w-full">
                      <FormControl className="flex-1">
                        <Input
                          {...field}
                          onFocus={(e) => {
                            e.target.select();
                          }}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <div className="flex items-center  mt-1">
                <Label className="whitespace-nowrap w-48 ">Mã hiệu</Label>
                <FormField
                  control={form.control}
                  name="maHieu"
                  render={({ field }) => (
                    <FormItem className="flex items-center gap-2 w-full">
                      <FormControl className="flex-1">
                        <Input
                          {...field}
                          onFocus={(e) => {
                            e.target.select();
                          }}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <div className="flex items-center mt-1">
                <Label className="whitespace-nowrap w-48">Mã sản phẩm</Label>
                <FormField
                  control={form.control}
                  name="hospitalCode"
                  render={({ field }) => (
                    <FormItem className="flex items-center gap-2 w-full">
                      <FormControl className="w-full">
                        <Input
                          {...field}
                          onFocus={(e) => {
                            e.target.select();
                          }}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <div className="flex items-center mt-1">
                <Label className="whitespace-nowrap w-48">Tên sản phẩm</Label>
                <FormField
                  control={form.control}
                  name="productName"
                  render={({ field }) => (
                    <FormItem className="flex items-center gap-2 w-full">
                      <FormControl className="w-full">
                        <Input
                          {...field}
                          onFocus={(e) => {
                            e.target.select();
                          }}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <div className="flex items-center mt-1">
                <Label className="whitespace-nowrap w-48">Tên thương mại</Label>
                <FormField
                  control={form.control}
                  name="medicareName"
                  render={({ field }) => (
                    <FormItem className="flex items-center gap-2 w-full">
                      <FormControl className="w-full">
                        <Input
                          {...field}
                          onFocus={(e) => {
                            e.target.select();
                          }}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <div className="flex items-center mt-1">
                <Label className="whitespace-nowrap w-48">ĐVT</Label>
                <FormField
                  control={form.control}
                  name="unitID"
                  render={({ field }) => (
                    <Select
                      placeholder="--Chọn đơn vị tính--"
                      className="w-full"
                      classNameSelectList="max-h-96"
                      value={field.value?.toString()}
                      classNamePopover="w-full"
                      onChange={(value) => {
                        field.onChange(value);
                      }}
                      options={donViTinh}
                    />
                  )}
                />
              </div>
            </div>
            <div className="w-1/4">
              <div className="flex items-center">
                <Label className="whitespace-nowrap w-48">Loại danh mục</Label>
                <FormField
                  control={form.control}
                  name="productTypeID"
                  render={({ field }) => (
                    <Select
                      placeholder="--Chọn loại danh mục--"
                      className="w-full"
                      classNameSelectList="max-h-96"
                      value={field.value?.toString()}
                      classNamePopover="w-full"
                      onChange={(value) => {
                        field.onChange(value);
                      }}
                      options={productTypes}
                    />
                  )}
                />
              </div>
              <div className="flex items-center mt-1">
                <Label className="whitespace-nowrap w-48">Ngành</Label>
                <FormField
                  control={form.control}
                  name="productNganhID"
                  render={({ field }) => (
                    <Select
                      placeholder="--Chọn ngành--"
                      className="w-full"
                      classNameSelectList="max-h-96"
                      value={field.value?.toString()}
                      classNamePopover="w-full"
                      onChange={(value) => {
                        field.onChange(value);
                      }}
                      options={productNganhs}
                    />
                  )}
                />
              </div>
              <div className="flex items-center mt-1">
                <Label className="whitespace-nowrap w-48">Nhóm</Label>
                <FormField
                  control={form.control}
                  name="productNhomID"
                  render={({ field }) => (
                    <Select
                      placeholder="--Chọn nhóm--"
                      className="w-full"
                      classNameSelectList="max-h-96"
                      value={field.value?.toString()}
                      classNamePopover="w-full"
                      onChange={(value) => {
                        field.onChange(value);
                      }}
                      options={productNhoms}
                    />
                  )}
                />
              </div>
              <div className="flex items-center mt-1">
                <Label className="whitespace-nowrap w-48">Loại</Label>
                <FormField
                  control={form.control}
                  name="productLoaiID"
                  render={({ field }) => (
                    <Select
                      placeholder="--Chọn loại--"
                      className="w-full"
                      classNameSelectList="max-h-96"
                      value={field.value?.toString()}
                      classNamePopover="w-full"
                      onChange={(value) => {
                        field.onChange(value);
                      }}
                      options={productLoais}
                    />
                  )}
                />
              </div>
              <div className="flex items-center mt-1">
                <Label className="whitespace-nowrap w-48">Nước sản xuất</Label>
                <NuocSanXuatComboBox
                  nuocSanXuats={vatTuData.countrys}
                  selectedCountryID={countrySelect?.countryID.toString()}
                  handleCountrySelect={(country) => {
                    handleNuocSanXuatSelect(country);
                  }}
                />
              </div>
              <div className="flex items-center mt-1">
                <Label className="whitespace-nowrap w-48">Hãng sản xuất</Label>
                <HangSanXuatComboBox
                  hangSanXuats={vatTuData.hangSanXuats}
                  selectedHangSanXuatID={hangSanXuatSelect?.id.toString()}
                  handleHangSanXuatSelect={(hangSanXuat) => {
                    handleHangSanXuatSelect(hangSanXuat || undefined);
                  }}
                />
              </div>
              <div className="flex items-center mt-1">
                <Label className="whitespace-nowrap w-48">Qui cách</Label>
                <FormField
                  control={form.control}
                  name="quyCach"
                  render={({ field }) => (
                    <FormItem className="flex items-center gap-2 w-full">
                      <FormControl className="w-full">
                        <Input
                          {...field}
                          onFocus={(e) => {
                            e.target.select();
                          }}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </div>
            <div className="w-1/4">
              <div className="flex items-center mt-1">
                <Label className="whitespace-nowrap w-48">Loại thầu</Label>
                <LoaiThauComboBox
                  loaiThaus={loaiThaus}
                  selectedLoaiThauID={loaiThauSelect?.id.toString()}
                  handleLoaiThauSelect={(loaiThau) => {
                    handleLoaiThauSelect(loaiThau || undefined);
                  }}
                />
              </div>

              <div className="flex items-center mt-1">
                <Label className="whitespace-nowrap w-48">Kho</Label>
                <FormField
                  control={form.control}
                  name="stockID"
                  render={({ field }) => (
                    <MultiSelect
                      value={
                        !!field.value
                          ? field.value?.split(",")
                          : !!selectedVatTu?.productID &&
                              selectedVatTu?.productID !== 0
                            ? inventoryStocks.map((q) => q.value)
                            : []
                      }
                      className="w-full"
                      classNamePopover="w-90"
                      options={inventoryStocks}
                      onChange={(values) => {
                        field.onChange(values.join(","));
                      }}
                    />
                  )}
                />
              </div>
              <div className="flex items-center  mt-1">
                <Label className="whitespace-nowrap w-48">Đường dùng</Label>
                <FormField
                  control={form.control}
                  name="maDuongDUng"
                  render={({ field }) => (
                    <Select
                      placeholder="--Chọn đường dùng --"
                      className="w-full"
                      classNameSelectList="max-h-96"
                      value={field.value?.toString() || "0"}
                      classNamePopover="w-full"
                      onChange={(value) => {
                        field.onChange(value);
                      }}
                      options={duongDungs}
                    />
                  )}
                />
              </div>
              <div className="flex flex-row items-baseline mt-1">
                <div className="flex-1">
                  <FormField
                    control={form.control}
                    name="vtytThanhToanRieng"
                    render={({ field }) => (
                      <FormItem>
                        <RadioGroup
                          value={field.value ? "true" : "false"}
                          onValueChange={(value) =>
                            field.onChange(value === "true")
                          }
                          className="flex flex-row space-x-4 border rounded px-2"
                        >
                          <div className="flex flex-row items-center">
                            <RadioGroupItem value="true" id="tt-rieng" />
                            <label htmlFor="tt-rieng" className="pl-2 text-sm">
                              Thanh toán riêng
                            </label>
                          </div>
                          <div className="flex flex-row items-center">
                            <RadioGroupItem value="false" id="tt-khong-rieng" />
                            <label
                              htmlFor="tt-khong-rieng"
                              className="pl-2 text-sm"
                            >
                              Không thanh toán riêng
                            </label>
                          </div>
                        </RadioGroup>
                      </FormItem>
                    )}
                  />
                </div>
              </div>
              <div className="flex flex-row items-baseline mt-1">
                <div className="flex-1">
                  <FormField
                    control={form.control}
                    name="isDvktCao"
                    render={({ field }) => (
                      <FormItem>
                        <RadioGroup
                          value={field.value ? "true" : "false"}
                          onValueChange={(value) =>
                            field.onChange(value === "true")
                          }
                          className="flex flex-row space-x-4 border rounded px-2 "
                        >
                          <div className="flex flex-row items-center">
                            <RadioGroupItem value="true" id="no-dvktcao-true" />
                            <label
                              htmlFor="no-dvktcao-true"
                              className="pl-2 text-sm"
                            >
                              Có ĐVKTCao
                            </label>
                          </div>
                          <div className="flex flex-row items-center">
                            <RadioGroupItem
                              value="false"
                              id="no-dvktcao-false"
                            />
                            <label
                              htmlFor="no-dvktcao-false"
                              className="pl-2 text-sm"
                            >
                              Không có ĐVKTCao
                            </label>
                          </div>
                        </RadioGroup>
                      </FormItem>
                    )}
                  />
                </div>
              </div>
              <div className="flex items-center mt-1">
                <Label className="whitespace-nowrap w-48">Diot</Label>
                <FormField
                  control={form.control}
                  name="content"
                  render={({ field }) => (
                    <FormItem className="flex items-center gap-2 w-full">
                      <FormControl className="w-full">
                        <Input
                          {...field}
                          onFocus={(e) => {
                            e.target.select();
                          }}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </div>
            <div className="w-1/4">
              <div className="flex items-center mt-1">
                <Label className="whitespace-nowrap mr-[164px]">
                  Mã dược QG
                </Label>
                <FormField
                  control={form.control}
                  name="maDuocQG"
                  render={({ field }) => (
                    <FormItem className="flex items-center gap-2 w-full">
                      <FormControl className="w-full">
                        <Input
                          {...field}
                          onFocus={(e) => {
                            e.target.select();
                          }}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <div className="flex items-center mt-1 ">
                <Label className="whitespace-nowrap w-60">
                  Định mức số lần sử dụng
                </Label>
                <div className="flex-1">
                  <FormField
                    control={form.control}
                    name="dinhMucHoacSoLanSuDung"
                    render={({ field }) => (
                      <FormItem className="flex items-center gap-4 w-full">
                        <FormControl>
                          <InputAvailableQty
                            className="w-full max-w-full !important"
                            id="dinhMucHoacSoLanSuDung"
                            availableQty={Number(field.value ?? 0)}
                            onChange={async (value) => {
                              form.setValue("dinhMucHoacSoLanSuDung", value);
                            }}
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                </div>
              </div>
              <div className="flex items-center mt-1">
                <Label className="whitespace-nowrap mr-[76px]">
                  VTYT có dán tem (&gt; 2 triệu)
                </Label>
                <FormField
                  control={form.control}
                  name="dvytCoDanTemTren2Tr"
                  render={({ field }) => (
                    <FormItem className="flex items-center gap-2 w-full">
                      <FormControl className="w-full">
                        <Input
                          {...field}
                          onFocus={(e) => {
                            e.target.select();
                          }}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <div className="flex items-center mt-1 ">
                <Label className="whitespace-nowrap w-60">
                  Tiền BH thanh toán
                </Label>
                <div className="flex-1">
                  <FormField
                    control={form.control}
                    name="soTienThanhToanBHYT"
                    render={({ field }) => (
                      <FormItem className="flex items-center gap-4 w-full">
                        <FormControl>
                          <InputAvailableQty
                            className="w-full max-w-full !important"
                            id="soTienThanhToanBHYT"
                            availableQty={Number(field.value ?? 0)}
                            onChange={async (value) => {
                              form.setValue("soTienThanhToanBHYT", value);
                            }}
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                </div>
              </div>
              <div className="flex items-center mt-1 ">
                <Label className="whitespace-nowrap w-60">
                  % thành phẩm bảo hiểm thanh toán
                </Label>
                <div className="flex-1">
                  <FormField
                    control={form.control}
                    name="phanTramThanhToanBHYT"
                    render={({ field }) => (
                      <FormItem className="flex items-center gap-4 w-full">
                        <FormControl>
                          <InputAvailableQty
                            className="w-full max-w-full !important"
                            id="phanTramThanhToanBHYT"
                            availableQty={Number(field.value ?? 0)}
                            onChange={async (value) => {
                              form.setValue("phanTramThanhToanBHYT", value);
                            }}
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                </div>
              </div>
              <FormField
                control={form.control}
                name="chkIsUsing"
                render={({ field }) => (
                  <FormItem className="inline-flex items-center space-y-0">
                    <FormControl>
                      <div className="flex items-center gap-2">
                        <FormLabel className="whitespace-nowrap mr-6 ">
                          Không còn sử dụng
                        </FormLabel>
                        <Checkbox
                          checked={field.value}
                          onCheckedChange={(checked) => field.onChange(checked)}
                        />
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              ></FormField>
            </div>
          </div>
          <VatTuSanPhamFooter
            onHandleAddNew={onHandleAddNew}
            formData={form.getValues()}
            form={form}
            defaultFormData={defaultFormData}
            selectedVatTu={selectedVatTu}
            exportData={exportData}
          ></VatTuSanPhamFooter>
        </form>
      </Form>
    </div>
  );
};
