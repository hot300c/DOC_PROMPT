"use client";

import { ELoadingMessages } from "@/app/lib/enums";
import { useFeedbackDialog } from "@/app/lib/feedback-dialog-provider";
import { notifySuccess } from "@/app/lib/utils";
import { getErrorMessage } from "@/app/lib/utils/errorUtils";
import useLoading from "@/components/loading";
import { Button } from "@/components/ui/button";
import { useRouter } from "next/navigation";
import { useVatTu } from "../../../_context/vat-tu-context";
import {
  VatTuCustomFieldRESP,
  VatTuRESP,
} from "../../../_utils/definitions/vat-tu.resp";
import { ThongTinBanHangFormData } from "../../../_utils/schema/vat-tu-thong-tin-ban-hang-chema";
import { thongTinBanHangSave } from "../../../_utils/services/vat-tu.api";
import { validateDataVatTu } from "../../../_utils/validate-data";

export type ThongTinBanHangFooterProps = {
  selectedVatTu: VatTuRESP | undefined;
  handleFetchDataThongTinBanHang: (productID: number) => Promise<void>;
  formData: ThongTinBanHangFormData | undefined;
  vatTuCustomField: VatTuCustomFieldRESP[];
  exportData: () => void;
};

export const ThongTinBanHangFooter = ({
  selectedVatTu,
  handleFetchDataThongTinBanHang,
  formData,
  vatTuCustomField,
  exportData,
}: ThongTinBanHangFooterProps) => {
  const { alert } = useFeedbackDialog();
  const { showLoading, hideLoading } = useLoading();
  const { formVatTuSamPhamData } = useVatTu();
  const router = useRouter();
  const validateData = async (
    formData: ThongTinBanHangFormData | undefined,
  ): Promise<boolean> => {
    if (!formData) return false;
    const isValidateDataVatTu = await validateDataVatTu({
      formData: formVatTuSamPhamData ?? undefined,
      tabSelected: "ThongTinBanHang",
      alert: async (options) => {
        return Promise.resolve(alert(options)).then(() => {});
      },
    });
    if (!isValidateDataVatTu) return false;
    if (!selectedVatTu?.productID) {
      await alert({
        title: "Cảnh báo",
        content: "Vui lòng nhập thông tin sản phẩm!",
      });
      return false;
    }
    return true;
  };

  const onSubmit = async (formData: ThongTinBanHangFormData | undefined) => {
    const loadingId = showLoading(ELoadingMessages.WAITING);

    try {
      const isValid = await validateData(formData);
      if (!isValid) return;

      await thongTinBanHangSave({
        params: formData,
        productID: selectedVatTu?.productID!,
        vatTuCustomField: vatTuCustomField,
      });

      notifySuccess("Lưu thông tin bán hàng vật tư thành công.");
      await handleFetchDataThongTinBanHang(selectedVatTu?.productID ?? 0);
      router.refresh();
    } catch (error) {
      await alert({
        title: "Lỗi",
        content: getErrorMessage(error),
      });
    } finally {
      hideLoading(loadingId);
    }
  };

  return (
    <div className="flex flex-row justify-between py-2">
      <div>
        <Button type="button" onClick={exportData}>
          Xuất excel
        </Button>
      </div>
      <div className="flex flex-row gap-2 mr-2">
        <Button type="button" onClick={() => onSubmit(formData)}>
          Lưu
        </Button>
      </div>
    </div>
  );
};
