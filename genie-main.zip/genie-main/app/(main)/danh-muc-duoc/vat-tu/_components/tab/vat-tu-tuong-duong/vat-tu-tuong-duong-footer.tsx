"use client";

import { ELoadingMessages } from "@/app/lib/enums";
import { useFeedbackDialog } from "@/app/lib/feedback-dialog-provider";
import { notifySuccess } from "@/app/lib/utils";
import { getErrorMessage } from "@/app/lib/utils/errorUtils";
import useLoading from "@/components/loading";
import { Button } from "@/components/ui/button";
import { useRouter } from "next/navigation";
import { useVatTu } from "../../../_context/vat-tu-context";
import { VatTuRESP } from "../../../_utils/definitions/vat-tu.resp";
import { productLinkSave } from "../../../_utils/services/vat-tu.api";
import { validateDataVatTu } from "../../../_utils/validate-data";

export type VatTuTuongDuongFooterProps = {
  selectedVatTu: VatTuRESP | undefined;
  handleFetchDataVatTuTuongDuong: (productID: number) => Promise<void>;
  onHandleAddNew: () => void;
  exportData: () => void;
  sanPhamSelected: VatTuRESP | undefined;
};

export const VatTuTuongDuongFooter = ({
  selectedVatTu,
  handleFetchDataVatTuTuongDuong,
  onHandleAddNew,
  exportData,
  sanPhamSelected,
}: VatTuTuongDuongFooterProps) => {
  const { alert } = useFeedbackDialog();
  const { showLoading, hideLoading } = useLoading();
  const { formVatTuSamPhamData } = useVatTu();
  const router = useRouter();
  const validateData = async (): Promise<boolean> => {
    const isValidateDataVatTu = await validateDataVatTu({
      formData: formVatTuSamPhamData ?? undefined,
      tabSelected: "ThuocTuongDuong",
      alert: async (options) => {
        return Promise.resolve(alert(options)).then(() => {});
      },
    });
    if (!isValidateDataVatTu) return false;
    if (!sanPhamSelected) {
      await alert({
        title: "Cảnh báo",
        content: "Vui lòng chọn sản phẩm!",
      });
      return false;
    }
    if (selectedVatTu?.productID === sanPhamSelected.productID) {
      await alert({
        title: "Cảnh báo",
        content: "Trùng sản phẩm thuốc tương đương.",
      });
      return false;
    }
    return true;
  };

  const onSubmit = async () => {
    const loadingId = showLoading(ELoadingMessages.WAITING);

    try {
      const isValid = await validateData();
      if (!isValid) return;

      await productLinkSave(
        selectedVatTu?.productID!,
        sanPhamSelected?.productID!,
      );
      notifySuccess("Lưu vật tư tương đương thành công.");
      await handleFetchDataVatTuTuongDuong(selectedVatTu?.productID ?? 0);
      router.refresh();
    } catch (error) {
      await alert({
        title: "Lỗi",
        content: getErrorMessage(error),
      });
    } finally {
      hideLoading(loadingId);
    }
  };

  return (
    <div className="flex flex-row justify-between py-2">
      <div>
        <Button type="button" onClick={exportData}>
          Xuất excel
        </Button>
      </div>
      <div className="flex flex-row gap-2 mr-2">
        <Button type="button" onClick={onHandleAddNew}>
          Thêm mới
        </Button>
        <Button type="button" onClick={() => onSubmit()}>
          Lưu
        </Button>
      </div>
    </div>
  );
};
