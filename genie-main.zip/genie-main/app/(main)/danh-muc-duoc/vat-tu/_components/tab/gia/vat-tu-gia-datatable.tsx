"use client";
import { ProductPriceListRESP } from "@/app/(main)/danh-muc-duoc/vaccine/_utils/definitions/vaccine.resp";
import { DATE_FORMAT } from "@/app/lib/enums";
import {
  DataTable,
  DataTableColumnHeaderSort,
} from "@/components/ui/dataTable";
import { ColumnDef } from "@tanstack/react-table";
import { format } from "date-fns/format";
import { useMemo } from "react";
import { NumericFormat } from "react-number-format";

export type VatTuGiaTableProps = {
  data: ProductPriceListRESP[];
  onRowClick: (row: ProductPriceListRESP) => void;
};
const VatTuGiaTable = ({ data, onRowClick }: VatTuGiaTableProps) => {
  const columns = useMemo(() => {
    const result: ColumnDef<ProductPriceListRESP>[] = [
      {
        id: "hospitalPrice",
        accessorKey: "hospitalPrice",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Giá BV" />
        ),
        meta: {
          className: "text-overflow-ellipsis truncate text-right",
        },
        cell: ({ row }) => (
          <NumericFormat
            className="flex-1"
            value={row.original.hospitalPrice}
            thousandSeparator="."
            decimalSeparator=","
            decimalScale={2}
            fixedDecimalScale
            displayType="text"
          />
        ),
      },
      {
        id: "giaDichVu",
        accessorKey: "giaDichVu",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Giá DV" />
        ),
        meta: {
          className: "text-overflow-ellipsis truncate text-right",
        },
        cell: ({ row }) => (
          <NumericFormat
            className="flex-1"
            value={row.original.giaDichVu}
            thousandSeparator="."
            decimalSeparator=","
            decimalScale={2}
            fixedDecimalScale
            displayType="text"
          />
        ),
      },
      {
        id: "armyPrice",
        accessorKey: "armyPrice",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Giá Quân" />
        ),
        meta: {
          className: "text-overflow-ellipsis truncate text-right",
        },
        cell: ({ row }) => (
          <NumericFormat
            className="flex-1"
            value={row.original.armyPrice}
            thousandSeparator="."
            decimalSeparator=","
            decimalScale={2}
            fixedDecimalScale
            displayType="text"
          />
        ),
      },
      {
        id: "medicarePrice",
        accessorKey: "medicarePrice",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Giá BH" />
        ),
        meta: {
          className: "text-overflow-ellipsis truncate text-right",
        },
        cell: ({ row }) => (
          <NumericFormat
            className="flex-1"
            value={row.original.medicarePrice}
            thousandSeparator="."
            decimalSeparator=","
            decimalScale={2}
            fixedDecimalScale
            displayType="text"
          />
        ),
      },
      {
        id: "giaDiemThuong",
        accessorKey: "giaDiemThuong",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Điểm thường" />
        ),
        meta: {
          className: "text-overflow-ellipsis truncate text-right",
        },
        cell: ({ row }) => (
          <NumericFormat
            className="flex-1"
            value={row.original.giaDiemThuong}
            thousandSeparator="."
            decimalSeparator=","
            decimalScale={2}
            fixedDecimalScale
            displayType="text"
          />
        ),
      },
      {
        id: "effFrom",
        accessorKey: "effFrom",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Từ ngày"
            className="justify-start"
          />
        ),
        size: 100,
        cell: ({ row }) => (
          <div className="min-w-12">
            {format(row.original.effFrom, DATE_FORMAT.DD_MM_YYYY_VI)}
          </div>
        ),
      },
      {
        id: "effThru",
        accessorKey: "effThru",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Đến ngày"
            className="justify-start"
          />
        ),
        size: 100,
        cell: ({ row }) => (
          <div className="min-w-12">
            {!!row.original.effThru
              ? format(row.original.effThru, DATE_FORMAT.DD_MM_YYYY_VI)
              : ""}
          </div>
        ),
      },
    ];
    return result;
  }, []);

  return (
    <div className="flex-1 flex flex-col h-full w-full">
      <DataTable
        className="w-full overflow-y-auto border"
        tableClassName="border"
        tHeadClass="z-40"
        columns={columns}
        data={data}
        enableColumnFilter={false}
        enablePaging={false}
        enableGlobalFilter={false}
        placeholderSearch="Nhập để tìm kiếm..."
        enableFooter
        onRowClick={onRowClick}
      ></DataTable>
    </div>
  );
};

export default VatTuGiaTable;
