"use client";

import { ELoadingMessages } from "@/app/lib/enums";
import { useFeedbackDialog } from "@/app/lib/feedback-dialog-provider";
import { getErrorMessage } from "@/app/lib/utils/errorUtils";
import useLoading from "@/components/loading";
import { useCallback, useEffect, useState } from "react";

import { Button } from "@/components/ui/button";
import {
  ThongTinBanHangRESP,
  VatTuCustomFieldRESP,
  VatTuRESP,
} from "../../../_utils/definitions/vat-tu.resp";
import { ThongTinBanHangFormData } from "../../../_utils/schema/vat-tu-thong-tin-ban-hang-chema";
import { getProductThongTinBanHang } from "../../../_utils/services/vat-tu.api";
import ThongTinBanHangTable from "./thong-tin-ban-hang-datatable";
import { ThongTinBanHangFooter } from "./thong-tin-ban-hang-footer";
import { ThongTinBanHangForm } from "./thong-tin-ban-hang-form";

export type ThongTinBanHangTabProps = {
  selectedVatTu: VatTuRESP | undefined;
  exportData: () => void;
};

export const ThongTinBanHangTab = ({
  selectedVatTu,
  exportData,
}: ThongTinBanHangTabProps) => {
  const { alert } = useFeedbackDialog();
  const { showLoading, hideLoading } = useLoading();

  const [formData, setFormData] = useState<ThongTinBanHangFormData | undefined>(
    undefined,
  );
  const [thongTinBanHangData, setThongTinBanHangData] = useState<
    ThongTinBanHangRESP | undefined
  >(undefined);

  const [vatTuCustomField, setVatTuCustomField] = useState<
    VatTuCustomFieldRESP[]
  >([]);

  const handleFetchDataThongTinBanHang = useCallback(
    async (productID: number) => {
      const loadingId = showLoading(ELoadingMessages.WAITING);
      try {
        var response = await getProductThongTinBanHang(productID ?? 0);
        setThongTinBanHangData(response?.thongTinBanHang ?? undefined);
        setVatTuCustomField(response?.vatTuCustomField ?? []);
      } catch (err) {
        await alert({
          title: "Lỗi",
          content: getErrorMessage(err),
        });
      } finally {
        hideLoading(loadingId);
      }
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [],
  );

  useEffect(() => {
    void handleFetchDataThongTinBanHang(selectedVatTu?.productID ?? 0);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedVatTu?.productID]);

  const handleAddCustomField = () => {
    setVatTuCustomField((preData) => [
      ...preData,
      {
        id: 0, // placeholder, server sẽ thay bằng id thật
        custom_LoaiDuLieu: "",
        custom_MaTruong: "",
        custom_TenTruong: "",
        productID: selectedVatTu?.productID ?? 0,
      },
    ]);
  };

  return (
    <div className="flex h-full flex-col overflow-hidden px-4">
      <div className="flex-1 min-h-0 overflow-auto">
        <div className="flex gap-4">
          <div className="w-1/2">
            <ThongTinBanHangForm
              setFormData={setFormData}
              thongTinBanHangData={thongTinBanHangData}
            ></ThongTinBanHangForm>
          </div>

          <div className="flex-1 min-h-0  w-1/2">
            <div>
              <div className="flex justify-between w-full">
                <p className="mb-0 text-sm">Trường custom</p>
                <Button onClick={handleAddCustomField}>Thêm</Button>
              </div>

              <ThongTinBanHangTable
                data={vatTuCustomField}
                setVatTuCustomField={setVatTuCustomField}
              />
            </div>
          </div>
        </div>
      </div>
      <ThongTinBanHangFooter
        selectedVatTu={selectedVatTu}
        handleFetchDataThongTinBanHang={handleFetchDataThongTinBanHang}
        exportData={exportData}
        vatTuCustomField={vatTuCustomField}
        formData={formData}
      ></ThongTinBanHangFooter>
    </div>
  );
};
