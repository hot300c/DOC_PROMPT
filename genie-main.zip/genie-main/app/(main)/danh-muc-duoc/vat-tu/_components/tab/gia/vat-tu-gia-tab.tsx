"use client";

import { ProductPriceListRESP } from "@/app/(main)/danh-muc-duoc/vaccine/_utils/definitions/vaccine.resp";
import { ELoadingMessages } from "@/app/lib/enums";
import { useFeedbackDialog } from "@/app/lib/feedback-dialog-provider";
import { getErrorMessage } from "@/app/lib/utils/errorUtils";
import useLoading from "@/components/loading";
import { useCallback, useEffect, useState } from "react";
import { VatTuRESP } from "../../../_utils/definitions/vat-tu.resp";
import { VatTuGiaFormData } from "../../../_utils/schema/vat-tu-gia-chema";
import { getProductPriceList } from "../../../_utils/services/vat-tu.api";
import VatTuGiaTable from "./vat-tu-gia-datatable";
import { VatTuGiaFooter } from "./vat-tu-gia-footer";
import { VatTuGiaForm } from "./vat-tu-gia-form";

export type VatTuGiaTabProps = {
  selectedVatTu: VatTuRESP | undefined;
  exportData: () => void;
};

export const VatTuGiaTab = ({
  selectedVatTu,
  exportData,
}: VatTuGiaTabProps) => {
  const { alert } = useFeedbackDialog();
  const { showLoading, hideLoading } = useLoading();
  const [formData, setFormData] = useState<VatTuGiaFormData | undefined>(
    undefined,
  );
  const [productPrice, setProductPrice] = useState<
    ProductPriceListRESP | undefined
  >(undefined);

  const [data, setData] = useState<ProductPriceListRESP[]>([]);

  const onHandleAddNew = () => {
    setProductPrice(undefined);
  };

  const handleFetchDataGiaVatTu = useCallback(async (productID: number) => {
    const loadingId = showLoading(ELoadingMessages.WAITING);
    try {
      var response = await getProductPriceList(productID ?? 0);
      setData(response);
      setProductPrice(response[0] ?? undefined);
    } catch (err) {
      await alert({
        title: "Lỗi",
        content: getErrorMessage(err),
      });
    } finally {
      hideLoading(loadingId);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const onRowCick = (row: ProductPriceListRESP) => {
    setProductPrice(row);
  };

  useEffect(() => {
    void handleFetchDataGiaVatTu(selectedVatTu?.productID ?? 0);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedVatTu?.productID]);

  return (
    <div className="flex h-full flex-col overflow-hidden px-4">
      <VatTuGiaForm
        setFormData={setFormData}
        productPrice={productPrice}
        selectedVatTu={selectedVatTu}
      ></VatTuGiaForm>
      <div className="flex-1 min-h-0 overflow-auto">
        <VatTuGiaTable data={data} onRowClick={onRowCick} />
      </div>
      <VatTuGiaFooter
        onHandleAddNew={onHandleAddNew}
        selectedVatTu={selectedVatTu}
        formData={formData}
        handleFetchDataGiaVatTu={handleFetchDataGiaVatTu}
        exportData={exportData}
      ></VatTuGiaFooter>
    </div>
  );
};
