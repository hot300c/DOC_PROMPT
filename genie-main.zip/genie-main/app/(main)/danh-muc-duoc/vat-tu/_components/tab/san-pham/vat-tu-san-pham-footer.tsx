"use client";

import { ELoadingMessages } from "@/app/lib/enums";
import { useFeedbackDialog } from "@/app/lib/feedback-dialog-provider";
import { notifySuccess } from "@/app/lib/utils";
import { getErrorMessage } from "@/app/lib/utils/errorUtils";
import useLoading from "@/components/loading";
import { Button } from "@/components/ui/button";
import { useRouter } from "next/navigation";
import { VatTuRESP } from "../../../_utils/definitions/vat-tu.resp";
import { VatTuSanPhamFormData } from "../../../_utils/schema/vat-tu-san-pham-chema";
import {
  productVatTuDelete,
  productVatTuSave,
  stockProductPermissonsDelete,
} from "../../../_utils/services/vat-tu.api";
import { validateDataVatTu } from "../../../_utils/validate-data";
import { UseFormReturn } from "react-hook-form";

export type VatTuSanPhamFooterProps = {
  formData: VatTuSanPhamFormData;
  onHandleAddNew: () => void;
  exportData: () => void;
  defaultFormData: VatTuSanPhamFormData;
  selectedVatTu: VatTuRESP | undefined;
  form: UseFormReturn<VatTuSanPhamFormData>;
};

export const VatTuSanPhamFooter = ({
  formData,
  onHandleAddNew,
  exportData,
  defaultFormData,
  selectedVatTu,
  form,
}: VatTuSanPhamFooterProps) => {
  const { alert, confirm } = useFeedbackDialog();
  const { showLoading, hideLoading } = useLoading();
  const router = useRouter();

  const validateData = async (
    formData: VatTuSanPhamFormData,
  ): Promise<boolean> => {
    const isValidateDataVatTu = await validateDataVatTu({
      formData,
      tabSelected: "VatTu",
      alert: async (options) => {
        return Promise.resolve(alert(options)).then(() => {});
      },
    });
    if (!isValidateDataVatTu) return false;
    if (!formData.stockID) {
      await alert({
        title: "Cảnh báo",
        content: "Chưa chọn kho sử dụng sản phẩm",
      });
      return false;
    }
    if (formData.productID != 0 && !!formData.productID) {
      const isConfirmReplaceProduct = await confirm({
        title: "Cảnh báo",
        content:
          "Bạn đang ghi đè lên dữ liệu cũ. Bạn có đồng ý thực hiện không?",
      });
      if (!isConfirmReplaceProduct) return false;
    }
    return true;
  };

  const onSubmit = async (formData: VatTuSanPhamFormData) => {
    const loadingId = showLoading(ELoadingMessages.WAITING);
    try {
      const isValid = await validateData(formData);
      if (!isValid) return;
      const isVatTuSanPhamSave = await handleVatTuSanPhamSave({
        ...formData,
        isUsing: !(
          (formData.productID ?? 0).toString() === "0" && !formData.chkIsUsing
        ),
        isActive: !(
          (formData.productID ?? 0).toString() === "0" && !formData.chkIsUsing
        ),
      });
      if (!isVatTuSanPhamSave) return;
      const isNhomBenhVatTuDeleteQuyen =
        await handleNhomBenhVatTuDeleteQuyen(formData);
      if (!isNhomBenhVatTuDeleteQuyen) return;
      notifySuccess("Lưu sản phẩm vật tư thành công.");
      router.refresh();
    } catch (error) {
    } finally {
      hideLoading(loadingId);
    }
  };

  const handleVatTuSanPhamSave = async (
    formData: VatTuSanPhamFormData,
  ): Promise<boolean> => {
    try {
      await productVatTuSave(formData);
      return true;
    } catch (error) {
      await alert({
        title: "Lỗi",
        content: "Lưu sản phẩm vật tư thất bại.",
      });
      return false;
    }
  };

  const handleNhomBenhVatTuDeleteQuyen = async (
    formData: VatTuSanPhamFormData,
  ): Promise<boolean> => {
    try {
      await stockProductPermissonsDelete(
        (formData.productID ?? 0).toString(),
        formData.stockID?.split(","),
      );
      return true;
    } catch (error) {
      await alert({
        title: "Lỗi",
        content: "Xóa nhóm bệnh vật tư thất bại: " + getErrorMessage(error),
      });
      return false;
    }
  };

  const onHandleDelete = async () => {
    if (!selectedVatTu) return;
    const isConfirmDelete = await confirm({
      title: "Xác nhận",
      content:
        "Bạn có chắc chắn muốn xóa sản phẩm " +
        selectedVatTu.hospitalName +
        "này không?",
    });
    if (!isConfirmDelete) return;
    const loadingId = showLoading(ELoadingMessages.WAITING);

    try {
      const response = await productVatTuDelete(selectedVatTu.productID);
      if (response.statusText.toLowerCase() !== "ok") {
        await alert({
          title: "Cảnh báo",
          content: response.statusText,
        });
        return;
      }
      notifySuccess("Xóa sản phẩm vật tư thành công.");
      form.reset(defaultFormData);
      router.refresh();
    } catch (error) {
      await alert({
        title: "Lỗi",
        content: "Xóa sản phẩm thất bại: " + getErrorMessage(error),
      });
      return;
    } finally {
      hideLoading(loadingId);
    }
  };

  return (
    <div className="flex-none flex flex-row  justify-between">
      <div>
        <Button type="button" onClick={() => exportData()}>
          Xuất excel
        </Button>
      </div>
      <div className="flex flex-row gap-2">
        <Button type="button" onClick={onHandleAddNew}>
          Thêm mới
        </Button>
        <Button type="button" onClick={() => onSubmit(formData)}>
          Lưu
        </Button>
        <Button type="button" onClick={onHandleDelete}>
          Xóa
        </Button>
      </div>
    </div>
  );
};
