"use client";
import {
  DataTable,
  DataTableColumnHeaderSort,
} from "@/components/ui/dataTable";
import { Input } from "@/components/ui/input";
import { ColumnDef } from "@tanstack/react-table";
import { useMemo } from "react";
import { VatTuCustomFieldRESP } from "../../../_utils/definitions/vat-tu.resp";

export type ThongTinBanHangTableProps = {
  data: VatTuCustomFieldRESP[];
  setVatTuCustomField: (data: VatTuCustomFieldRESP[]) => void;
};
const ThongTinBanHangTable = ({
  data,
  setVatTuCustomField,
}: ThongTinBanHangTableProps) => {
  const columns = useMemo(() => {
    const result: ColumnDef<VatTuCustomFieldRESP>[] = [
      {
        id: "custom_MaTruong",
        accessorKey: "custom_MaTruong",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Mã trường" />
        ),
        meta: {
          className: "text-overflow-ellipsis truncate",
        },
        cell: ({ row, table }) => (
          <Input
            value={row.original.custom_MaTruong}
            onChange={(e) => {
              table.options.meta?.updateData(
                row.index,
                "custom_MaTruong",
                e.target.value,
              );
            }}
          />
        ),
      },
      {
        id: "custom_TenTruong",
        accessorKey: "custom_TenTruong",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Tên trường" />
        ),
        meta: {
          className: "text-overflow-ellipsis truncate",
        },
        cell: ({ row, table }) => (
          <Input
            value={row.original.custom_TenTruong}
            onChange={(e) => {
              table.options.meta?.updateData(
                row.index,
                "custom_TenTruong",
                e.target.value,
              );
            }}
          />
        ),
      },
      {
        id: "custom_LoaiDuLieu",
        accessorKey: "custom_LoaiDuLieu",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Loại dữ liệu" />
        ),
        meta: {
          className: "text-overflow-ellipsis truncate",
        },
        cell: ({ row, table }) => (
          <Input
            value={row.original.custom_LoaiDuLieu}
            onChange={(e) => {
              table.options.meta?.updateData(
                row.index,
                "custom_LoaiDuLieu",
                e.target.value,
              );
            }}
          />
        ),
      },
    ];
    return result;
  }, []);

  return (
    <div className="flex-1 flex flex-col h-full w-full">
      <DataTable
        className="w-full overflow-y-auto border"
        tableClassName="border"
        tHeadClass="z-40"
        columns={columns}
        data={data}
        enableColumnFilter={false}
        enablePaging={false}
        enableGlobalFilter={false}
        placeholderSearch="Nhập để tìm kiếm..."
        enableFooter
        onChange={setVatTuCustomField}
      ></DataTable>
    </div>
  );
};

export default ThongTinBanHangTable;
