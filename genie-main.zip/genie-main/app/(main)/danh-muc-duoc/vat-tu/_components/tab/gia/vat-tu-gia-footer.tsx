"use client";

import { ELoadingMessages } from "@/app/lib/enums";
import { useFeedbackDialog } from "@/app/lib/feedback-dialog-provider";
import { notifySuccess } from "@/app/lib/utils";
import { getErrorMessage } from "@/app/lib/utils/errorUtils";
import useLoading from "@/components/loading";
import { Button } from "@/components/ui/button";
import { useRouter } from "next/navigation";
import { useVatTu } from "../../../_context/vat-tu-context";
import { VatTuRESP } from "../../../_utils/definitions/vat-tu.resp";
import { VatTuGiaFormData } from "../../../_utils/schema/vat-tu-gia-chema";
import {
  productVatTuSave,
  vatTuPriceSave,
} from "../../../_utils/services/vat-tu.api";
import { validateDataVatTu } from "../../../_utils/validate-data";

export type VatTuGiaFooterProps = {
  selectedVatTu: VatTuRESP | undefined;
  handleFetchDataGiaVatTu: (productID: number) => Promise<void>;
  formData: VatTuGiaFormData | undefined;
  onHandleAddNew: () => void;
  exportData: () => void;
};

export const VatTuGiaFooter = ({
  selectedVatTu,
  handleFetchDataGiaVatTu,
  formData,
  onHandleAddNew,
  exportData,
}: VatTuGiaFooterProps) => {
  const { alert } = useFeedbackDialog();
  const { showLoading, hideLoading } = useLoading();
  const { formVatTuSamPhamData } = useVatTu();
  const router = useRouter();
  const validateData = async (
    formData: VatTuGiaFormData | undefined,
  ): Promise<boolean> => {
    if (!formData) return false;
    const isValidateDataVatTu = await validateDataVatTu({
      formData: formVatTuSamPhamData ?? undefined,
      tabSelected: "Gia",
      alert: async (options) => {
        return Promise.resolve(alert(options)).then(() => {});
      },
    });
    if (!isValidateDataVatTu) return false;
    if (!selectedVatTu?.productID) {
      await alert({
        title: "Cảnh báo",
        content: "Vui lòng nhập thông tin sản phẩm!",
      });
      return false;
    }
    if (!formData.hospitalPrice) {
      await alert({
        title: "Cảnh báo",
        content: "Chưa nhập giá",
      });
      return false;
    }
    if (!formData.effFrom) {
      await alert({
        title: "Cảnh báo",
        content: "Chọn ngày bắt đầu áp dụng giá",
      });
      return false;
    }
    if ((formData.medicarePrice ?? 0).toString().length > 14) {
      await alert({
        title: "Cảnh báo",
        content:
          "Giá kê khai đã vượt số lượng tối đa là 14, vui lòng kiểm tra lại!",
      });
      return false;
    }
    return true;
  };

  const onSubmit = async (formData: VatTuGiaFormData | undefined) => {
    const loadingId = showLoading(ELoadingMessages.WAITING);

    try {
      const isValid = await validateData(formData);
      if (!isValid) return;

      await vatTuPriceSave({
        params: formData!,
        productID: selectedVatTu?.productID!,
      });

      await productVatTuSave({
        ...formVatTuSamPhamData,
        isActive: true,
        isUsing: true,
        sttKQDT: formData?.sttkqdt,
        tenDonViSYT: formData?.tenDonViSYT,
        soQDPheDuyet: formData?.soQDPheDuyet,
        soQDMuaSamTrucTiep: formData?.soQDMuaSamTrucTiep,
        ngayHieuLuc: formData?.ngayHieuLuc,
      });
      notifySuccess("Lưu giá vật tư thành công.");
      await handleFetchDataGiaVatTu(selectedVatTu?.productID ?? 0);
      router.refresh();
    } catch (error) {
      await alert({
        title: "Lỗi",
        content: getErrorMessage(error),
      });
    } finally {
      hideLoading(loadingId);
    }
  };

  return (
    <div className="flex flex-row justify-between py-2">
      <div>
        <Button type="button" onClick={exportData}>
          Xuất excel
        </Button>
      </div>
      <div className="flex flex-row gap-2 mr-2">
        <Button type="button" onClick={onHandleAddNew}>
          Thêm mới
        </Button>
        <Button type="button" onClick={() => onSubmit(formData)}>
          Lưu
        </Button>
      </div>
    </div>
  );
};
