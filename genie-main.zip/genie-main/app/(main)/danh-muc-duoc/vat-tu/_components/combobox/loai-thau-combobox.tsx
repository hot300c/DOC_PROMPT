"use client";

import { TableSelect } from "@/components/select/table-select";
import { DataTableColumnHeaderSort } from "@/components/ui/dataTable";
import { ColumnDef } from "@tanstack/react-table";
import { useMemo } from "react";
import { CommonRESP } from "../../../shared/_utils/definitions/response";

export default function LoaiThauComboBox({
  loaiThaus = [],
  selectedLoaiThauID,
  handleLoaiThauSelect,
}: {
  loaiThaus?: CommonRESP[];
  selectedLoaiThauID?: string;
  handleLoaiThauSelect: (x: CommonRESP | undefined) => void;
}) {
  const nhaCungCapID = useMemo(() => {
    return loaiThaus.find((sp) => sp.id.toString() === selectedLoaiThauID);
  }, [selectedLoaiThauID, loaiThaus]);

  const LOAI_THAU_COLUMN_COMBOBOX = useMemo(() => {
    const result: ColumnDef<CommonRESP>[] = [
      {
        id: "id",
        accessorKey: "id",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="ID"
            className="justify-start"
          />
        ),
        enableSorting: true,
      },
      {
        id: "name",
        accessorKey: "name",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Name"
            className="justify-start"
          />
        ),
        enableSorting: true,
      },
    ];
    return result;
  }, []);
  return (
    <div className="flex flex-row col-span-2 items-center gap-3 h-lg:gap-4 w-full">
      <TableSelect
        columns={LOAI_THAU_COLUMN_COMBOBOX}
        data={loaiThaus}
        labelKey="name"
        valueKey="id"
        placeholderSearch="Tìm kiếm..."
        placeholder="--Chọn loại thầu --"
        data-cy="chon-loai-thau"
        value={nhaCungCapID}
        className="w-full"
        classNameTable="max-h-[40vh] max-w-[1000px]"
        classNamePopover="w-auto min-w-60"
        onChange={handleLoaiThauSelect}
      />
    </div>
  );
}
