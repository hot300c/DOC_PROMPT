"use client";

import { TableSelect } from "@/components/select/table-select";
import { DataTableColumnHeaderSort } from "@/components/ui/dataTable";
import { ColumnDef } from "@tanstack/react-table";
import { useMemo } from "react";
import { VatTuRESP } from "../../_utils/definitions/vat-tu.resp";

export default function SanPhamComboBox({
  sanPhams = [],
  selectedSanPhamID,
  handleSanPhamSelect,
}: {
  sanPhams?: VatTuRESP[];
  selectedSanPhamID?: string;
  handleSanPhamSelect: (x: VatTuRESP | undefined) => void;
}) {
  const nhaCungCapID = useMemo(() => {
    return sanPhams.find((sp) => sp.productID.toString() === selectedSanPhamID);
  }, [selectedSanPhamID, sanPhams]);

  const VAT_TU_TUONG_DUONG_COLUMN_COMBOBOX = useMemo(() => {
    const result: ColumnDef<VatTuRESP>[] = [
      {
        id: "productID",
        accessorKey: "productID",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Mã phần mềm" />
        ),
        meta: {
          className: "text-left truncate",
        },
      },
      {
        id: "hospitalCode",
        accessorKey: "hospitalCode",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Mã SP" />
        ),
        cell: ({ row }) => (
          <div className="min-w-24">
            <span title={row.original.hospitalCode}>
              {row.original.hospitalCode}
            </span>
          </div>
        ),
      },
      {
        id: "hospitalName",
        accessorKey: "hospitalName",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Tên SP" />
        ),
        cell: ({ row }) => (
          <div className="min-w-60">
            <span title={row.original.hospitalName}>
              {row.original.hospitalName}
            </span>
          </div>
        ),
      },
      {
        id: "unitName",
        accessorKey: "unitName",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="ĐVT" />
        ),
      },
      {
        id: "formula",
        accessorKey: "formula",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Hoạt chất" />
        ),
      },
    ];
    return result;
  }, []);
  return (
    <div className="flex flex-row col-span-2 items-center gap-3 h-lg:gap-4 w-96">
      <TableSelect
        columns={VAT_TU_TUONG_DUONG_COLUMN_COMBOBOX}
        data={sanPhams}
        labelKey="hospitalName"
        valueKey="productID"
        placeholderSearch="Tìm kiếm..."
        placeholder="--Chọn sản phẩm--"
        data-cy="chon-loai-thau"
        value={nhaCungCapID}
        className="w-full"
        classNameTable="max-h-[40vh] max-w-[1000px]"
        classNamePopover="w-auto min-w-60"
        onChange={handleSanPhamSelect}
      />
    </div>
  );
}
