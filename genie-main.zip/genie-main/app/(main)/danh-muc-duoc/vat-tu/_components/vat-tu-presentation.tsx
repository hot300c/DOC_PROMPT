"use client";
import { exportToExcel, TableConfig } from "@/app/lib/utils/exportToExcel ";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { useEffect, useState } from "react";
import { useVatTu } from "../_context/vat-tu-context";
import { VatTuData, VatTuRESP } from "../_utils/definitions/vat-tu.resp";
import { VatTuSanPhamFormData } from "../_utils/schema/vat-tu-san-pham-chema";
import { VatTuGiaTab } from "./tab/gia/vat-tu-gia-tab";
import { VatTuSanPhamTab } from "./tab/san-pham/vat-tu-san-pham-tab";
import { ThongTinBanHangTab } from "./tab/thong-tin-ban-hang/thong-tin-ban-hang-tab";
import { VatTuTuongDuongTab } from "./tab/vat-tu-tuong-duong/vat-tu-tuong-duong-tab";
import VatTuTable from "./vat-tu-datatable";

export type VatTuPresentationProps = {
  data: VatTuRESP[];
  vatTuData: VatTuData;
};
const VatTuPresentation = ({ data, vatTuData }: VatTuPresentationProps) => {
  const searchParams = useSearchParams();
  const productID = searchParams.get("productID");
  const router = useRouter();
  const pathname = usePathname();
  const { setFormVatTuSamPhamData } = useVatTu();
  const [selectedVatTu, setSelectedVatTu] = useState<VatTuRESP | undefined>(
    undefined,
  );

  const defaultFormData: VatTuSanPhamFormData = {
    productID: undefined,
    facID: "",
    productName: "",
    unitID: "0",
    sttKQDT: "",
    tenDonViSYT: "",
    soQDPheDuyet: "",
    soQDMuaSamTrucTiep: "",
    sttTheoDMI: "",
    nuocSanXuat: undefined,
    hangSanXuat: undefined,
    maSoTheoNhom: "",
    quyCach: "",
    isDvktCao: false,
    dvytCoDanTemTren2Tr: "",
    dinhMucHoacSoLanSuDung: null,
    vtytThanhToanRieng: false,
    soTienThanhToanBHYT: undefined,
    productNganhID: undefined,
    productNhomID: undefined,
    productLoaiID: undefined,
    isUsing: true, // mặc định đang sử dụng
    chkIsUsing: undefined,
    isActive: true, // mặc định active
    productTypeID: undefined,
    content: "",
    medicareName: "",
    maDungChung: "",
    ngayHieuLuc: "", // có thể format yyyyMMdd trước khi submit
    maHieu: "",
    hospitalCode: "",
    loaiThau: undefined,
    maDuongDUng: "",
    phanTramThanhToanBHYT: undefined,
    giaTuThien: "0",
    maDuocQG: "",
    stockID:
      !!selectedVatTu?.productID && selectedVatTu?.productID !== 0
        ? vatTuData.inventoryStocks.map((q) => q.stockID).join(",")
        : undefined,
    dvktCao: "",
  };

  const mapVatTuToFormData = (
    vatTu: VatTuRESP | undefined,
  ): VatTuSanPhamFormData => {
    if (!vatTu) return {} as VatTuSanPhamFormData;
    return Object.fromEntries(
      Object.keys(defaultFormData).map((key) => {
        let value =
          vatTu[key as keyof VatTuRESP] ??
          defaultFormData[key as keyof VatTuSanPhamFormData];
        if (key === "chkIsUsing") {
          value = !(vatTu.isUsing ?? defaultFormData.isUsing);
        }
        if (key === "isDvktCao") {
          value = !!vatTu.dvktCao;
        }
        return [key, value];
      }),
    ) as VatTuSanPhamFormData;
  };

  useEffect(() => {
    if (!!selectedVatTu) return;
    if (!productID) {
      setSelectedVatTu(data[0]);
      return;
    }
    setSelectedVatTu(
      data.find((item) => item.productID.toString() === productID),
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [data, productID]);

  const onRowClick = (row: VatTuRESP) => {
    setSelectedVatTu(row);
    setFormVatTuSamPhamData(mapVatTuToFormData(row));
    const query = new URLSearchParams(window.location.search);
    query.set("productID", row.productID.toString());
    router.push(pathname + "?" + query.toString());
  };

  const exportData = async () => {
    const tableConfig: TableConfig = {
      columns: {
        "Mã phần mềm": { width: 10, alignment: "left" },
        "Mã số theo danh mục": { width: 20, alignment: "left" },
        "Mã dùng chung": { width: 10, alignment: "left" },
        "Mã hiệu": { width: 20, alignment: "left" },
        "Mã SP": { width: 20, alignment: "left" },
        "Tên SP": { width: 30, alignment: "left" },
        "Tên thương mại": { width: 20, alignment: "left" },
        ĐVT: { width: 10, alignment: "left" },
        "Qui cách": { width: 10, alignment: "left" },
        "Loại danh mục": { width: 20, alignment: "left" },
        Ngành: { width: 20, alignment: "left" },
        Nhóm: { width: 20, alignment: "left" },
        Loại: { width: 20, alignment: "left" },
        "Nước SX": { width: 15, alignment: "left" },
        "Hãng SX": { width: 15, alignment: "left" },
        "Định mức số lần sử dụng": { width: 10, alignment: "left" },
        "Thanh toán riêng": { width: 15, alignment: "left" },
        "Đang sử dụng": { width: 15, alignment: "left" },
        "Thay đổi gầm nhất": { width: 30, alignment: "left" },
      },
      data:
        data && data.length > 0
          ? data.map((row) => [
              row.productID,
              row.sttTheoDMI,
              row.maDungChung,
              row.maHieu,
              row.hospitalCode,
              row.hospitalName,
              row.medicareName,
              row.unitName,
              row.quyCach,
              row.productType,
              row.productNganh,
              row.productNhom,
              row.productLoai,
              row.countryName,
              row.hangsanxuat1,
              Number(row.dinhMucHoacSoLanSuDung),
              row.isMedicare ? "Checked" : "Unchecked",
              row.isUsing ? "Checked" : "Unchecked",
              row.modifiedByUser,
            ])
          : [],
      sheetName: "VatTu Sản phẩm",
      fileName: "vật tư-san-pham.xlsx",
    };
    await exportToExcel(tableConfig);
  };

  return (
    <div className="flex flex-col flex-1 w-full h-full overflow-hidden">
      <div className="flex-[2] flex overflow-hidden">
        <VatTuTable data={data} onRowClick={onRowClick} productID={productID} />
      </div>
      <div className="flex-[1] flex overflow-hidden min-h-0">
        <Tabs
          defaultValue="san-pham"
          className="flex flex-col items-start overflow-hidden w-full h-full"
        >
          <TabsList>
            <TabsTrigger value="san-pham">Sản phẩm</TabsTrigger>
            <TabsTrigger value="gia">Giá</TabsTrigger>
            <TabsTrigger value="vat-tu-tuong-duong">
              Vật tư tương đương
            </TabsTrigger>
            <TabsTrigger value="thong-tin-ban-hang">
              Thông tin bán hàng
            </TabsTrigger>
          </TabsList>
          <div className="flex-1 min-h-0 w-full overflow-hidden">
            <TabsContent value="san-pham" className="h-full">
              <VatTuSanPhamTab
                vatTuData={vatTuData}
                selectedVatTu={selectedVatTu}
                setSelectedVatTu={setSelectedVatTu}
                data={data}
                exportData={exportData}
                mapVatTuToFormData={mapVatTuToFormData}
                defaultFormData={defaultFormData}
              ></VatTuSanPhamTab>
            </TabsContent>
            <TabsContent value="gia" className="h-full">
              <VatTuGiaTab
                selectedVatTu={selectedVatTu}
                exportData={exportData}
              ></VatTuGiaTab>
            </TabsContent>
            <TabsContent value="vat-tu-tuong-duong" className="h-full">
              <VatTuTuongDuongTab
                selectedVatTu={selectedVatTu}
                exportData={exportData}
                vatTuData={data}
              ></VatTuTuongDuongTab>
            </TabsContent>
            <TabsContent value="thong-tin-ban-hang" className="h-full">
              <ThongTinBanHangTab
                selectedVatTu={selectedVatTu}
                exportData={exportData}
              ></ThongTinBanHangTab>
            </TabsContent>
          </div>
        </Tabs>
      </div>
    </div>
  );
};

export default VatTuPresentation;
