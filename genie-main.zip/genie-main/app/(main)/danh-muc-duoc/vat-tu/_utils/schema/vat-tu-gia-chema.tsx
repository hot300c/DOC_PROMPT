"use client";
import { z } from "zod";

export const VatTuGiaSchema = z.object({
  armyPrice: z.number().optional(),
  effFrom: z.string().nullable().optional(),
  effThru: z.string().nullable().optional(),
  giaDichVu: z.number().optional(),
  giaDiemThuong: z.number().optional(),
  hospitalPrice: z.number().optional(),
  medicarePrice: z.number().optional(),
  sttkqdt: z.string().optional(),
  tenDonViSYT: z.string().optional(),
  soQDPheDuyet: z.string().optional(),
  soQDMuaSamTrucTiep: z.string().optional(),
  ngayHieuLuc: z.string().optional(),
});
export type VatTuGiaFormData = z.infer<typeof VatTuGiaSchema>;
