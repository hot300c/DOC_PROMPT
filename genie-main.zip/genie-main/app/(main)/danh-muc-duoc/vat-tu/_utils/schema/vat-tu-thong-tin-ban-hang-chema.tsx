"use client";
import { z } from "zod";

export const ThongTinBanHangSchema = z.object({
  isBanTrongShop: z.boolean().optional(),
  isHienThiTungDong: z.boolean().optional(),
  moTaSP: z.string().optional(),
  apiKetThuc: z.string().optional(),
  apiHuy: z.string().optional(),
});
export type ThongTinBanHangFormData = z.infer<typeof ThongTinBanHangSchema>;
