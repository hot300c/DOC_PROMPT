import { getUserSession } from "@/actions/get-user-session";
import { SequenceRequest } from "@/app/lib/definitions/setting";
import { DATE_FORMAT } from "@/app/lib/enums";
import * as httpService from "@/app/lib/network/http";
import * as SystemService from "@/app/lib/services/system";
import { format } from "date-fns";
import { ProductPriceListRESP } from "../../../vaccine/_utils/definitions/vaccine.resp";
import {
  ThongTinBanHangData,
  VatTuCustomFieldRESP,
  VatTuTuongDuongRESP,
} from "../definitions/vat-tu.resp";
import { VatTuGiaFormData } from "../schema/vat-tu-gia-chema";
import { VatTuSanPhamFormData } from "../schema/vat-tu-san-pham-chema";
import { ThongTinBanHangFormData } from "../schema/vat-tu-thong-tin-ban-hang-chema";

export async function fetchDataVatTu(): Promise<any> {
  try {
    const currentUser = await getUserSession();
    const requests: SequenceRequest[] = [
      {
        category: "QAHosGenericDB",
        command: "ws_LoadProductBaseUserID_List",
        parameters: {
          FacID: currentUser.facId,
          ActionType: 7,
        },
      },
      {
        category: "QAHosGenericDB",
        command: "ws_L_UoM_List",
        parameters: {},
      },
      {
        category: "QAHosGenericDB",
        command: "ws_L_Country_List",
        parameters: {
          FacID: currentUser.facId,
        },
      },
      {
        category: "QAHosGenericDB",
        command: "ws_L_HangSanXuat_List",
        parameters: {
          FacID: currentUser.facId,
        },
      },
      {
        category: "QAHosGenericDB",
        command: "ws_L_InventoryStock_List",
        parameters: {
          FacID: currentUser.facId,
          ActionType: 4,
        },
      },
      {
        category: "QAHosGenericDB",
        command: "ws_L_ProductNganh_List",
        parameters: {
          FacID: currentUser.facId,
        },
      },
      {
        category: "QAHosGenericDB",
        command: "ws_L_ProductNhom_List",
        parameters: {
          FacID: currentUser.facId,
        },
      },
      {
        category: "QAHosGenericDB",
        command: "ws_L_ProductLoai_List",
        parameters: {
          FacID: currentUser.facId,
        },
      },
      {
        category: "QAHosGenericDB",
        command: "ws_L_ProductType_List",
        parameters: {
          FacID: currentUser.facId,
        },
      },
      {
        category: "QAHosGenericDB",
        command: "ws_DOC_ComboValues_List_CachDungThuocV2",
        parameters: {
          FacID: currentUser.facId,
        },
      },
    ];
    const response = await SystemService.executeTransaction({
      request: requests,
    });
    const vaccineData: any = {
      data: response.table || [],
      uoms: response.table1 || [],
      countrys: response.table2 || [],
      hangSanXuats: response.table3 || [],
      inventoryStocks: response.table4 || [],
      productNganhs: response.table5 || [],
      productNhoms: response.table6 || [],
      productLoais: response.table7 || [],
      productTypes: response.table8 || [],
      cachDungThuocs: response.table9 || [],
    };
    return vaccineData;
  } catch (error) {
    return undefined;
  }
}

export async function productVatTuDelete(
  productID: number,
): Promise<{ statusText: string }> {
  const { facId } = await getUserSession();
  const response = await httpService.post("/DataAccess", [
    {
      category: "QAHosGenericDB",
      command: "ws_L_Product_Delete",
      parameters: {
        ID: productID,
        FacId: facId,
      },
    },
  ]);
  return response.data;
}

export async function productVatTuSave(
  params: VatTuSanPhamFormData,
): Promise<{ result: boolean }> {
  const { facId } = await getUserSession();
  const paramsObject = {
    FacID: facId,
    ProductID: params.productID ?? 0,
    ProductName: params.productName,
    UnitID: Number(params.unitID ?? 0),
    STTKQDT: params.sttKQDT,
    TenDonViSYT: params.tenDonViSYT,
    SoQDPheDuyet: params.soQDPheDuyet,
    SoQDMuaSamTrucTiep: params.soQDMuaSamTrucTiep,
    SttTheoDMI: params.sttTheoDMI,
    NuocSanXuat: params.nuocSanXuat ?? 0,
    HangSanXuat: params.hangSanXuat ?? 0,
    MaSoTheoNhom: params.maSoTheoNhom,
    QuyCach: params.quyCach,
    DvktCao: params.isDvktCao ? params.maDungChung : "",
    NoDVKTCao: !params.isDvktCao ? params.maDungChung : "",
    DvytCoDanTemTren2Tr: params.dvytCoDanTemTren2Tr,
    DinhMucHoacSoLanSuDung: params.dinhMucHoacSoLanSuDung,
    VtytThanhToanRieng: params.vtytThanhToanRieng ? 1 : 0,
    BHThanhToan: params.soTienThanhToanBHYT ?? 0,
    ProductNganhID: Number(params.productNganhID),
    ProductNhomID: Number(params.productNhomID),
    ProductLoaiID: Number(params.productLoaiID),
    IsUsing: params.isUsing,
    IsActive: params.isActive,
    ProductTypeID: Number(params.productTypeID),
    Content: params.content,
    MedicareName: params.medicareName,
    MaDungChung: params.maDungChung,
    NgayHieuLuc: !!params.ngayHieuLuc
      ? format(params.ngayHieuLuc, DATE_FORMAT.YYYYMMDD_AS_INT)
      : null,
    MaHieu: params.maHieu,
    HospitalCode: params.hospitalCode,
    LoaiThau: params.loaiThau,
    MaDuongDUng: params.maDuongDUng,
    PhanTramThanhToanBHYT: params.phanTramThanhToanBHYT ?? 0,
    GiaTuThien: Number(params.giaTuThien),
    MaDuocQG: params.maDuocQG,
  };

  const response = await httpService.post("/DataAccess", [
    {
      category: "QAHosGenericDB",
      command: "ws_L_ProductVatTu_Save",
      parameters: paramsObject,
    },
  ]);
  return response.data;
}

export async function stockProductPermissonsDelete(
  productID?: string,
  stockIDs: string[] = [],
): Promise<{ result: boolean }> {
  const currentUser = await getUserSession();
  const requests: SequenceRequest[] = [];

  stockIDs.forEach((stockID) => {
    requests.push({
      category: "Security",
      command: "ws_StockProductPermissons_Delete",
      parameters: {
        ProductID: productID,
        StockID: stockID,
        FacID: currentUser.facId,
      },
    });
    requests.push({
      category: "Security",
      command: "ws_StockProductPermissons_Save",
      parameters: {
        ProductID: productID,
        StockID: stockID,
        FacID: currentUser.facId,
      },
    });
  });

  const response = await SystemService.executeTransaction({
    request: requests,
  });
  return response.data;
}

export async function getProductPriceList(
  productID: number,
): Promise<ProductPriceListRESP[]> {
  const { facId } = await getUserSession();
  const response = await httpService.post("/DataAccess", [
    {
      category: "QAHosGenericDB",
      command: "ws_L_ProductPrice_List",
      parameters: {
        ProductID: productID,
        FacId: facId,
      },
    },
  ]);
  return response.data.table ?? [];
}

export async function vatTuPriceSave({
  params,
  productID,
}: {
  params: VatTuGiaFormData;
  productID: number;
}): Promise<{ success: boolean }> {
  const currentUser = await getUserSession();
  const response = await httpService.post("/DataAccess", [
    {
      category: "QAHosGenericDB",
      command: "ws_L_ProductPrice_Mainten_Save",
      parameters: {
        ProductID: productID,
        EffFrom: format(params.effFrom!, DATE_FORMAT.YYYYMMDD_AS_INT),
        EffThru: "29990101",
        FacID: currentUser.facId,
        HospitalPrice: (params.hospitalPrice ?? 0).toString(),
        MedicarePrice: (params.medicarePrice ?? 0).toString(),
        ArmyPrice: (params.armyPrice ?? 0).toString(),
        GiaDichVu: (params.giaDichVu ?? 0).toString(),
        GiaDiemThuong: (params.giaDiemThuong ?? 0).toString(),
        SoLuongDC: "0",
        SLPhanBo: "0",
      },
    },
  ]);

  return response.data.table;
}

export async function getProductListThuocTuongDuong(
  productID: number,
): Promise<VatTuTuongDuongRESP[]> {
  const { facId } = await getUserSession();
  const response = await httpService.post("/DataAccess", [
    {
      category: "QAHosGenericDB",
      command: "ws_L_Product_ListThuocTuongDuong",
      parameters: {
        ProductID: productID,
        FacId: facId,
      },
    },
  ]);
  return response.data.table ?? [];
}

export async function productLinkSave(
  productID: number,
  productLinkID: number,
): Promise<{ success: boolean }> {
  const { facId } = await getUserSession();
  const response = await httpService.post("/DataAccess", [
    {
      category: "QAHosGenericDB",
      command: "ws_L_ProductLink_Save",
      parameters: {
        ProductID: productID,
        FacId: facId,
        ProductLinkID: productLinkID,
      },
    },
  ]);
  return response.data.table;
}

export async function getProductThongTinBanHang(
  productID: number,
): Promise<ThongTinBanHangData> {
  const { facId } = await getUserSession();
  const response = await httpService.post("/DataAccess", [
    {
      category: "QAHosGenericDB",
      command: "ws_L_Product_ThongTinBanHang_GET",
      parameters: {
        ProductID: productID,
        FacId: facId,
      },
    },
  ]);

  return {
    thongTinBanHang: response.data.table[0] ?? undefined,
    vatTuCustomField: response.data.table1 ?? [],
  };
}

export async function thongTinBanHangSave({
  vatTuCustomField,
  productID,
  params,
}: {
  vatTuCustomField: VatTuCustomFieldRESP[];
  productID: number;
  params: ThongTinBanHangFormData | undefined;
}): Promise<{ result: boolean }> {
  const requests: SequenceRequest[] = [];
  requests.push({
    category: "QAHosGenericDB",
    command: "ws_L_Product_ThongTinBanHang_Save",
    parameters: {
      ProductID: productID,
      IsBanTrongShop: params?.isBanTrongShop,
      IsHienThiTungDong: params?.isHienThiTungDong,
      MoTaSP: (params?.moTaSP ?? "").trim(),
      APIKetThuc: params?.apiKetThuc,
      APIHuy: params?.apiHuy,
    },
  });
  vatTuCustomField.forEach((customField) => {
    requests.push({
      category: "QAHosGenericDB",
      command: "ws_L_Product_ThongTinBanHang_Custom_Save",
      parameters: {
        ProductID: productID,
        ID: customField.id,
        Custom_MaTruong: customField.custom_MaTruong,
        Custom_TenTruong: customField.custom_TenTruong,
        Custom_LoaiDuLieu: customField.custom_LoaiDuLieu,
      },
    });
  });

  const response = await SystemService.executeTransaction({
    request: requests,
  });
  return response.data;
}
