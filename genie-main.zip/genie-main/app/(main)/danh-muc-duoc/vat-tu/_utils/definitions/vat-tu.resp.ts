import {
  ComboValuesListCachDungThuocV2RESP,
  CommonRESP,
  InventoryStockRESP,
  ProductTypeRESP,
  UoMRESP,
} from "../../../shared/_utils/definitions/response";
import { NuocSanXuatRESP } from "../../../vaccine/_utils/definitions/vaccine.resp";

export interface VatTuRESP {
  aliasName: string;
  atc: string;
  biddingNumber: string;
  boPhanSuDung: string;
  buyingNumber: string;
  chiPhikhac: number;
  chuY: string | null;
  congDung: string;
  content: string;
  countryName: string;
  createdBy: string | null;
  createdOn: string;
  cskcb: string | null;
  customerID: number;
  dinhMucHoacSoLanSuDung: string | null;
  displayPackage: string;
  donViSuDung: string;
  donvidung: string | null;
  dosageForm: string;
  drugType: number;
  duongDung: string;
  dvktCao: string | null;
  dvytCoDanTemTren2Tr: string | null;
  facID: string;
  facID_CheckSum: number;
  formula: string;
  ghiChu: string;
  gia: number;
  giaKeKhai: number | null;
  giaTuThien: number | null;
  gioiHanKe: number;
  guidkey: string;
  hangSanXuat: number;
  hangsanxuat1: string;
  hdsd: string;
  hospitalCode: string;
  hospitalName: string;
  hospitalNameNoUnicode: string;
  iD_NCC: number;
  idDinhNghiaLieuDung: number;
  isActive: boolean;
  isBaoMat: boolean;
  isGuiTinNhanVaccine: boolean;
  isHalfVol: boolean;
  isHighTech: boolean | null;
  isMedicare: boolean;
  isNhaThuoc: boolean | null;
  isRetail: boolean | null;
  isThuocHiem: boolean;
  isUsing: boolean;
  isVaccineHiem: boolean;
  loai: string;
  loaiSanPhamBaoHiem: number;
  loaiThau: number;
  loaiThuocBHID: number;
  loaiVEN: number;
  loaithuocbhyt: string | null;
  maChung: string;
  maChung_CheckSum: number;
  maDauThau: string;
  maDungChung: string;
  maDuocQG: string;
  maDuongDUng: string;
  maHieu: string | null;
  maSoTheoNhom: string | null;
  maThau: string;
  medicareCode: string;
  medicareName: string;
  modifiedBy: string;
  modifiedByUser: string;
  modifiedOn: string;
  name: string | null;
  nganh: string;
  ngayHieuLuc: string;
  nguonGocSanXuat: number;
  nhacungcap: string | null;
  nhom: string;
  nhomBenhID: string;
  nhomthuocbhyt: string | null;
  nodvktCao: string | null;
  note: string;
  nuocSanXuat: number;
  orderIndexPhieuLinh: number | null;
  percentPriceAvg: number | null;
  percentforDoctor: number | null;
  percentforPharcy: number | null;
  phanTramThanhToanBHYT: number;
  preservationDamaging: number;
  processDamaging: number;
  productID: number;
  productLoai: string;
  productLoaiChiTietID: number;
  productLoaiID: number;
  productName: string;
  productNganh: string;
  productNganhID: number;
  productNhom: string;
  productNhomBHYTID: number;
  productNhomID: number;
  productSpecialCodes: string | null;
  productType: string;
  productTypeID: number;
  qtyOfYear: number | null;
  quyCach: string | null;
  registryCode: string;
  slPhanBo: number | null;
  soQDMuaSamTrucTiep: string | null;
  soQDPheDuyet: string | null;
  soTienThanhToanBHYT: number;
  sttTheoDMI: string;
  sttkqdt: string;
  tcktGroup: string;
  tenDonViSYT: string;
  tenHangSanXuat: string;
  tenKhoaHoc: string;
  tenKhoaHocThanhPhan: string;
  tenNhomBenh: string;
  tinhTrangduocLieuNhap: number;
  tinhTrangduocLieuSuDung: number;
  ttBietDuoc: string;
  ttHoatChat: string;
  unitID: number;
  unitName: string;
  usage: string;
  vendorID: number;
  vtytThanhToanRieng: string | null;
}

export type ProductNganhRESP = {
  createdBy: string;
  createdOn: string; // ISO date string
  facID: string;
  id: number;
  isDuocLieu?: boolean;
  isThanhPham: boolean;
  modifiedBy: string;
  modifiedOn: string; // ISO date string
  name: string;
  nameNoUnicode: string;
  productTypeID?: number;
};

export type ProductNhomsRESP = {
  codeNhom: string;
  createdBy?: string;
  createdOn: string;
  facID: string;
  id: number;
  inTypeIDExportForInPatient?: number;
  inTypeIDPhieuDuTruLuanChuyen?: number;
  modifiedBy?: string;
  modifiedOn: string;
  name: string;
  nameNoUnicode: string;
  outTypeIDExportForInPatient?: number;
  productNganh: string;
  productNganhID: number;
};

export type productLoaiRESP = {
  createdBy?: string;
  createdOn?: string;
  facID: string;
  id: number;
  modifiedBy?: string;
  modifiedOn?: string;
  name: string;
  nameNoUnicode: string;
  productNganh: string;
  productNhom: string;
  productNhomId: number;
};

export type VatTuData = {
  data: VatTuRESP[];
  uoms: UoMRESP[];
  countrys: NuocSanXuatRESP[];
  hangSanXuats: CommonRESP[];
  inventoryStocks: InventoryStockRESP[];
  productNganhs: ProductNganhRESP[];
  productNhoms: ProductNhomsRESP[];
  productLoais: productLoaiRESP[];
  productTypes: ProductTypeRESP[];
  cachDungThuocs: ComboValuesListCachDungThuocV2RESP[];
};

export interface VatTuTuongDuongRESP {
  productID: number;
  hospitalCode: string;
  hospitalName: string;
  unitName: string;
  productNganh: string;
  productNhom: string;
  productLoai?: string;
}

export interface ThongTinBanHangRESP {
  apiHuy?: string;
  apiKetThuc?: string;
  isBanTrongShop?: boolean;
  isHienThiTungDong?: boolean;
  moTaSP?: string;
  productID: number;
}
export interface VatTuCustomFieldRESP {
  custom_LoaiDuLieu?: string;
  custom_MaTruong?: string;
  custom_TenTruong?: string;
  id: number;
  productID: number;
}

export interface ThongTinBanHangData {
  thongTinBanHang?: ThongTinBanHangRESP;
  vatTuCustomField?: VatTuCustomFieldRESP[];
}
