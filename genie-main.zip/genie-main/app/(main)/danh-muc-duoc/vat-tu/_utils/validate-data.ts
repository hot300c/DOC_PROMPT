import { VatTuSanPhamFormData } from "./schema/vat-tu-san-pham-chema";

interface ValidateKeDonParams {
  formData: VatTuSanPhamFormData | undefined;
  tabSelected: string;
  alert: (options: { title: string; content: string }) => Promise<void>;
}

export async function validateDataVatTu({
  formData,
  tabSelected,
  alert,
}: ValidateKeDonParams): Promise<boolean> {
  if (!formData?.stockID && tabSelected === "VatTu") {
    await alert({ title: "Cảnh báo", content: "Chưa nhập kho" });
    return false;
  }

  if (tabSelected === "VatTu" && !formData?.productTypeID) {
    await alert({ title: "Cảnh báo", content: "Chưa nhập loại danh mục" });
    return false;
  }

  if ((formData?.phanTramThanhToanBHYT ?? 0) > 100) {
    await alert({
      title: "Cảnh báo",
      content: "Mức thành phần thanh toán đã vượt quá qui định",
    });
    return false;
  }

  if (!formData?.productName) {
    await alert({
      title: "Cảnh báo",
      content: "Chưa nhập Tên VTYT",
    });
    return false;
  }

  if (Number(formData?.unitID) === 0) {
    await alert({ title: "Cảnh báo", content: "Chưa Chọn đơn vị tính" });
    return false;
  }
  return true;
}
