import { Suspense } from "react";
import { Loading } from "../../duoc/(base_components)/loading";
import VatTuHeader from "./_components/vat-tu-header";
import { fetchDataVatTu } from "./_utils/services/vat-tu.api";
import VatTuPresentation from "./_components/vat-tu-presentation";
import { VatTuData } from "./_utils/definitions/vat-tu.resp";
import { VatTuProvider } from "./_context/vat-tu-context";

export default async function Page(props: {}) {
  const vatTuData: VatTuData = await fetchDataVatTu();
  return (
    <VatTuProvider>
      <div className="flex flex-col w-full h-full space-y-2">
        <VatTuHeader />
        <Suspense fallback={<Loading />}>
          <VatTuPresentation data={vatTuData.data} vatTuData={vatTuData} />
        </Suspense>
      </div>
    </VatTuProvider>
  );
}
