"use client";
import { createContext, ReactNode, useContext, useState } from "react";
import { VatTuSanPhamFormData } from "../_utils/schema/vat-tu-san-pham-chema";

interface VatTuContextType {
  formVatTuSamPhamData: VatTuSanPhamFormData | undefined;
  setFormVatTuSamPhamData: (values: VatTuSanPhamFormData | undefined) => void;
}

const VatTuContext = createContext<VatTuContextType | undefined>(undefined);

export function VatTuProvider({ children }: { children: ReactNode }) {
  const [formVatTuSamPhamData, setFormVatTuSamPhamData] = useState<VatTuSanPhamFormData | undefined>(
    undefined,
  );

  return (
    <VatTuContext.Provider
      value={{
        formVatTuSamPhamData,
        setFormVatTuSamPhamData,
      }}
    >
      {children}
    </VatTuContext.Provider>
  );
}

export function useVatTu() {
  const context = useContext(VatTuContext);
  if (context === undefined) {
    throw new Error("useVatTu must be used within a VatTuProvider");
  }
  return context;
}
