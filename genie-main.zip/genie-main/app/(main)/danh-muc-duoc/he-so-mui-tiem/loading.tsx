import { Loading as BaseLoading } from "../../duoc/(base_components)/loading";
export default function Loading() {
  return <BaseLoading />;
}
