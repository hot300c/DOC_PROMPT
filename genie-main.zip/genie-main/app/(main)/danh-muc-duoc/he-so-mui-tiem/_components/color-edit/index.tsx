"use client";

import { cn } from "@/app/lib/utils";
import { Button } from "@/components/ui/button";
import {
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useState } from "react";
import { CustomColorTab, SystemColorTab, WebColorTab } from "./color-tabs";
import { getBackgroundStyle, rgbToHex } from "./color-utils";
import { useColorPicker } from "./use-color-picker";

export type ColorEditProps = {
  value?: string;
  onChange?: (color: string) => void;
  label?: string;
  placeholder?: string;
  disabled?: boolean;
  className?: string;
};

export const ColorEdit = ({
  value = "255, 255, 255",
  onChange,
  label,
  placeholder = "Chọn màu sắc",
  disabled = false,
  className,
}: ColorEditProps) => {
  const [isOpen, setIsOpen] = useState(false);

  const { currentColor, internalColor, handleColorChange, handleInputBlur } =
    useColorPicker(value, onChange);

  return (
    <div className={cn("space-y-2", className)}>
      <Popover open={isOpen} onOpenChange={setIsOpen}>
        <PopoverTrigger asChild>
          <Button
            id="color-picker"
            variant="outline"
            className={cn(
              "w-full justify-start text-left font-normal h-6",
              !currentColor && "text-muted-foreground",
            )}
            disabled={disabled}
          >
            <div
              className="mr-5 h-3 w-10 border border-gray-300 flex-shrink-0"
              style={getBackgroundStyle(
                currentColor === "transparent"
                  ? "transparent"
                  : currentColor.startsWith("#")
                    ? currentColor
                    : rgbToHex(currentColor),
              )}
            />
            <span className="flex-1 text-sm">
              {currentColor ? currentColor : placeholder}
            </span>
          </Button>
        </PopoverTrigger>

        <PopoverContent className="w-80 p-3" align="start">
          <Tabs defaultValue="web" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="custom">Custom</TabsTrigger>
              <TabsTrigger value="web">Web</TabsTrigger>
              <TabsTrigger value="system">System</TabsTrigger>
            </TabsList>

            <TabsContent value="custom">
              <CustomColorTab
                internalColor={internalColor}
                onColorChange={handleColorChange}
                onInputBlur={handleInputBlur}
              />
            </TabsContent>

            <TabsContent value="web">
              <WebColorTab
                internalColor={internalColor}
                onColorChange={handleColorChange}
              />
            </TabsContent>

            <TabsContent value="system">
              <SystemColorTab
                internalColor={internalColor}
                onColorChange={handleColorChange}
              />
            </TabsContent>

            <div className="flex justify-end space-x-2 pt-3 border-t mt-3">
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => setIsOpen(false)}
              >
                Đóng
              </Button>
            </div>
          </Tabs>
        </PopoverContent>
      </Popover>
    </div>
  );
};

export type ColorEditFormProps = {
  name: string;
  label?: string;
  placeholder?: string;
  disabled?: boolean;
  className?: string;
  form: any;
};

export const ColorEditForm = ({
  name,
  label = "Màu sắc",
  placeholder = "Chọn màu sắc",
  disabled = false,
  className,
  form,
}: ColorEditFormProps) => {
  return (
    <FormField
      control={form.control}
      name={name}
      render={({ field }) => (
        <FormItem className={className}>
          <FormLabel>{label}</FormLabel>
          <FormControl>
            <ColorEdit
              value={field.value}
              onChange={field.onChange}
              placeholder={placeholder}
              disabled={disabled}
            />
          </FormControl>
          <FormMessage />
        </FormItem>
      )}
    />
  );
};
