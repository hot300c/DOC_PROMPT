"use client";

import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import {
  hexToRgbCommaSeparated,
  isValidHexColor,
  isValidRgb,
} from "./color-utils";

type ColorFormValues = {
  color: string;
};

export const useColorPicker = (
  initialValue: string,
  onChange?: (color: string) => void,
) => {
  const [currentColor, setCurrentColor] = useState(initialValue);
  const [internalColor, setInternalColor] = useState(initialValue);

  const form = useForm<ColorFormValues>({
    defaultValues: {
      color: initialValue,
    },
  });

  useEffect(() => {
    setCurrentColor(initialValue);
    setInternalColor(initialValue);
    form.setValue("color", initialValue);
  }, [initialValue, form]);

  const handleColorChange = (color: string, shouldNotify = true) => {
    const rgbColor = color.startsWith("#")
      ? hexToRgbCommaSeparated(color)
      : color;

    setInternalColor(rgbColor);
    form.setValue("color", rgbColor);

    if (shouldNotify) {
      setCurrentColor(rgbColor);
      onChange?.(rgbColor);
    }
  };

  const handleInputChange = (inputValue: string, shouldNotify = false) => {
    setInternalColor(inputValue);
    form.setValue("color", inputValue);

    if (isValidRgb(inputValue)) {
      if (shouldNotify) {
        setCurrentColor(inputValue);
        onChange?.(inputValue);
      }
    } else {
      let colorValue = inputValue;
      if (!colorValue.startsWith("#")) {
        colorValue = "#" + colorValue;
      }
      if (isValidHexColor(colorValue)) {
        const rgbColor = hexToRgbCommaSeparated(colorValue);
        if (shouldNotify) {
          setCurrentColor(rgbColor);
          onChange?.(rgbColor);
        }
      }
    }
  };

  const handleInputBlur = () => {
    if (isValidRgb(internalColor)) {
      setCurrentColor(internalColor);
      onChange?.(internalColor);
    } else {
      let colorValue = internalColor;
      if (!colorValue.startsWith("#")) {
        colorValue = "#" + colorValue;
      }
      if (isValidHexColor(colorValue)) {
        const rgbColor = hexToRgbCommaSeparated(colorValue);
        setCurrentColor(rgbColor);
        setInternalColor(rgbColor);
        form.setValue("color", rgbColor);
        onChange?.(rgbColor);
      } else {
        setInternalColor(currentColor);
        form.setValue("color", currentColor);
      }
    }
  };

  return {
    currentColor,
    internalColor,
    form,
    handleColorChange,
    handleInputChange,
    handleInputBlur,
  };
};
