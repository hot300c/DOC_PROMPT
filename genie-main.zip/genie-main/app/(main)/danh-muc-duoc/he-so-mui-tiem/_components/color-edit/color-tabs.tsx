"use client";

import { customColors, systemColors, webColors } from "./color-data";
import { ColorGrid } from "./color-grid";
import { ColorInput, NativeColorPicker } from "./color-input";
import { ColorList } from "./color-list";

export type ColorTabProps = {
  internalColor: string;
  onColorChange: (color: string, shouldNotify?: boolean) => void;
  onInputBlur: () => void;
};

export const CustomColorTab = ({
  internalColor,
  onColorChange,
  onInputBlur,
}: ColorTabProps) => {
  return (
    <div className="space-y-3 mt-3">
      <ColorInput
        value={internalColor}
        onChange={onColorChange}
        onBlur={onInputBlur}
      />

      <NativeColorPicker
        value={internalColor}
        onChange={(color) => onColorChange(color, true)}
      />

      <div className="max-h-40 overflow-y-auto">
        <ColorGrid
          colors={customColors}
          selectedColor={internalColor}
          onColorSelect={(color) => onColorChange(color, true)}
          title="Bảng màu tùy chỉnh"
          gridCols={8}
        />
      </div>
    </div>
  );
};

export const WebColorTab = ({
  internalColor,
  onColorChange,
}: Omit<ColorTabProps, "onInputBlur">) => {
  return (
    <div className="space-y-3 mt-3">
      <div className="max-h-48 overflow-y-auto">
        <ColorGrid
          colors={webColors.map((item) => item.color)}
          selectedColor={internalColor}
          onColorSelect={(color) => onColorChange(color, true)}
          title="Màu Web chuẩn"
          gridCols={8}
        />
      </div>
    </div>
  );
};

export const SystemColorTab = ({
  internalColor,
  onColorChange,
}: Omit<ColorTabProps, "onInputBlur">) => {
  return (
    <div className="space-y-3 mt-3">
      <ColorList
        colors={systemColors}
        selectedColor={internalColor}
        onColorSelect={(color) => onColorChange(color, true)}
        title="Màu hệ thống"
      />
    </div>
  );
};
