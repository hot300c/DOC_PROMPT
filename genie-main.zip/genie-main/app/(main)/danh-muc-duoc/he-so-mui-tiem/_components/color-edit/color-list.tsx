"use client";

import { cn } from "@/app/lib/utils";
import { Label } from "@/components/ui/label";
import { ColorItem } from "./color-data";
import { getBackgroundStyle, hexToRgbCommaSeparated } from "./color-utils";

export type ColorListProps = {
  colors: ColorItem[];
  selectedColor: string;
  onColorSelect: (color: string) => void;
  title: string;
  containerClassName?: string;
};

export const ColorList = ({
  colors,
  selectedColor,
  onColorSelect,
  title,
  containerClassName = "max-h-48",
}: ColorListProps) => {
  return (
    <div className="space-y-2">
      <Label className="text-sm font-medium">{title}</Label>
      <div className={cn("space-y-1 overflow-y-auto", containerClassName)}>
        {colors.map((item, index) => (
          <button
            key={`${title.toLowerCase().replace(/\s/g, "-")}-${index}`}
            type="button"
            className={cn(
              "w-full flex items-center gap-2 p-2 rounded hover:bg-gray-100 transition-colors text-left",
              (selectedColor === hexToRgbCommaSeparated(item.color) ||
                selectedColor === item.color) &&
                "bg-blue-50",
            )}
            onClick={() => onColorSelect(item.color)}
          >
            <div
              className="h-4 w-4 rounded border border-gray-300 flex-shrink-0"
              style={getBackgroundStyle(item.color)}
            />
            <div className="flex-1 min-w-0">
              <div className="text-sm font-medium truncate">{item.name}</div>
              <div className="text-xs text-gray-500 truncate">
                {hexToRgbCommaSeparated(item.color)}
              </div>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
};
