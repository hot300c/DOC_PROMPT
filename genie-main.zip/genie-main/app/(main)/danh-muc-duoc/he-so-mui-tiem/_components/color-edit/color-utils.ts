export const hexToRgbCommaSeparated = (hex: string): string => {
  if (hex === "transparent") {
    return "transparent";
  }

  const cleanHex = hex.replace("#", "");

  let fullHex = cleanHex;
  if (cleanHex.length === 3) {
    fullHex = cleanHex
      .split("")
      .map((char) => char + char)
      .join("");
  }

  if (fullHex.length !== 6) {
    return hex;
  }

  const r = parseInt(fullHex.substring(0, 2), 16);
  const g = parseInt(fullHex.substring(2, 4), 16);
  const b = parseInt(fullHex.substring(4, 6), 16);

  return `${r}, ${g}, ${b}`;
};

export const rgbToHex = (rgb: string): string => {
  if (rgb === "transparent") {
    return "transparent";
  }

  const commaSeparated = rgb.match(/(\d+),\s*(\d+),\s*(\d+)/);
  if (
    commaSeparated &&
    commaSeparated[1] &&
    commaSeparated[2] &&
    commaSeparated[3]
  ) {
    const r = parseInt(commaSeparated[1]);
    const g = parseInt(commaSeparated[2]);
    const b = parseInt(commaSeparated[3]);
    return `#${r.toString(16).padStart(2, "0")}${g.toString(16).padStart(2, "0")}${b.toString(16).padStart(2, "0")}`;
  }

  if (rgb.startsWith("#")) {
    return rgb;
  }

  return rgb;
};

export const isValidRgb = (rgb: string): boolean => {
  if (rgb === "transparent") return true;

  const commaSeparated = rgb.match(/^(\d+),\s*(\d+),\s*(\d+)$/);
  if (
    commaSeparated &&
    commaSeparated[1] &&
    commaSeparated[2] &&
    commaSeparated[3]
  ) {
    const [, r, g, b] = commaSeparated;
    return parseInt(r) <= 255 && parseInt(g) <= 255 && parseInt(b) <= 255;
  }
  return false;
};

export const isValidHexColor = (color: string): boolean => {
  return /^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/.test(color);
};

export const getBackgroundStyle = (color: string) => {
  if (color === "transparent") {
    return {
      backgroundColor: "#FFFFFF",
      backgroundImage:
        "linear-gradient(45deg, #ccc 25%, transparent 25%), linear-gradient(-45deg, #ccc 25%, transparent 25%), linear-gradient(45deg, transparent 75%, #ccc 75%), linear-gradient(-45deg, transparent 75%, #ccc 75%)",
      backgroundSize: "8px 8px",
      backgroundPosition: "0 0, 0 4px, 4px -4px, -4px 0px",
    };
  }

  return {
    backgroundColor: color.startsWith("#") ? color : rgbToHex(color),
  };
};
