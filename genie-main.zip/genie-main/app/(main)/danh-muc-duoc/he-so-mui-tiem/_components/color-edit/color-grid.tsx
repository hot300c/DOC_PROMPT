"use client";

import { Label } from "@/components/ui/label";
import { cva, type VariantProps } from "class-variance-authority";
import { getBackgroundStyle, hexToRgbCommaSeparated } from "./color-utils";

const gridVariants = cva("grid gap-1", {
  variants: {
    cols: {
      6: "grid-cols-6",
      7: "grid-cols-7",
      8: "grid-cols-8",
      9: "grid-cols-9",
      10: "grid-cols-10",
    },
  },
  defaultVariants: {
    cols: 8,
  },
});

const colorButtonVariants = cva(
  "h-6 w-6 rounded border border-gray-300 cursor-pointer hover:scale-110 transition-transform",
  {
    variants: {
      selected: {
        true: "ring-2 ring-primary ring-offset-1",
        false: "",
      },
    },
    defaultVariants: {
      selected: false,
    },
  },
);

export type ColorGridProps = {
  colors: string[];
  selectedColor: string;
  onColorSelect: (color: string) => void;
  title: string;
  gridCols?: VariantProps<typeof gridVariants>["cols"];
};

export const ColorGrid = ({
  colors,
  selectedColor,
  onColorSelect,
  title,
  gridCols = 8,
}: ColorGridProps) => {
  return (
    <div className="space-y-2">
      <Label className="text-sm font-medium">{title}</Label>
      <div className={gridVariants({ cols: gridCols })}>
        {colors.map((color, index) => {
          const isSelected =
            selectedColor === hexToRgbCommaSeparated(color) ||
            selectedColor === color;

          return (
            <button
              key={`${title.toLowerCase().replace(/\s/g, "-")}-${index}`}
              type="button"
              className={colorButtonVariants({ selected: isSelected })}
              style={getBackgroundStyle(color)}
              onClick={() => onColorSelect(color)}
              title={hexToRgbCommaSeparated(color)}
            />
          );
        })}
      </div>
    </div>
  );
};
