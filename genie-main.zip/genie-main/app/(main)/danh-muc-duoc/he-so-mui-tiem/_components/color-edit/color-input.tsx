"use client";

import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { rgbToHex } from "./color-utils";

export type ColorInputProps = {
  value: string;
  onChange: (value: string, shouldNotify?: boolean) => void;
  onBlur: () => void;
};

export const ColorInput = ({ value, onChange, onBlur }: ColorInputProps) => {
  return (
    <div className="space-y-2">
      <Label htmlFor="rgb-input" className="text-sm font-medium">
        Mã màu RGB
      </Label>
      <Input
        id="rgb-input"
        value={value}
        onChange={(e) => onChange(e.target.value, false)}
        onBlur={onBlur}
        placeholder="255, 255, 255 hoặc #FFFFFF"
        className="text-sm"
      />
      <div className="text-xs text-gray-500">
        HEX: {value.startsWith("#") ? value : rgbToHex(value)}
      </div>
    </div>
  );
};

export type NativeColorPickerProps = {
  value: string;
  onChange: (color: string) => void;
};

export const NativeColorPicker = ({
  value,
  onChange,
}: NativeColorPickerProps) => {
  return (
    <div className="space-y-2">
      <Label htmlFor="native-picker" className="text-sm font-medium">
        Chọn màu
      </Label>
      <input
        id="native-picker"
        type="color"
        value={value.startsWith("#") ? value : rgbToHex(value)}
        onChange={(e) => onChange(e.target.value)}
        className="h-10 w-full rounded border border-gray-300 cursor-pointer"
      />
    </div>
  );
};
