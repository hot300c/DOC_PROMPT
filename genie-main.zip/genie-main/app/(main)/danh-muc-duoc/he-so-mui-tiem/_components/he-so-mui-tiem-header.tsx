"use client";

import FacilityInfo from "@/components/facilityInfo";

export default function HeSoMuiTiemHeader() {
  return <FacilityInfo page={"DANH MỤC | HỆ SỐ MŨI TIÊM"} />;
}
