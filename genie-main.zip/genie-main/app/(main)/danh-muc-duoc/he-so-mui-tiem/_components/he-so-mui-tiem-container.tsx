import { HeSoMuiTiemFormValues } from "../_utils/schemas/he-so-mui-tiem-schema";
import { ws_L_HeSoTiem_Async } from "../_utils/services/he-so-mui-tiem.api";
import HeSoMuiTiemPresentation from "./he-so-mui-tiem-presentation";

export type HeSoMuiTiemContainerProps = {
  searchParams?: HeSoMuiTiemFormValues;
};

const HeSoMuiTiemContainer = async ({
  searchParams,
}: HeSoMuiTiemContainerProps) => {
  const hesoMuitiem = await ws_L_HeSoTiem_Async();
  return (
    <HeSoMuiTiemPresentation data={hesoMuitiem} searchParams={searchParams} />
  );
};

export default HeSoMuiTiemContainer;
