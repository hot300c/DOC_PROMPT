"use client";

import { DATE_FORMAT } from "@/app/lib/enums";
import { useFeedbackDialog } from "@/app/lib/feedback-dialog-provider";
import { InputDatePicker } from "@/components/input-date-picker";
import { TableSelect } from "@/components/select/table-select";
import { VirtualTableSelect } from "@/components/select/virtual-table-select/virtual-table-select";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import {
  DataTable,
  DataTableColumnHeaderSort,
} from "@/components/ui/dataTable";
import { Form, FormField } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { zodResolver } from "@hookform/resolvers/zod";
import { ColumnDef } from "@tanstack/react-table";
import { format } from "date-fns";
import { Plus, X } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { useForm } from "react-hook-form";
import {
  ws_Facility_GetAll,
  ws_L_HeSo_Get,
  ws_L_HeSoMuiTiem_Get,
  ws_L_Product_List_ByLoaiProduct,
} from "../_utils/definitions/he-so-mui-tiem.response";
import {
  HeSoMuiTiemFormSchema,
  HeSoMuiTiemFormValues,
} from "../_utils/schemas/he-so-mui-tiem-schema";
import {
  ws_L_HeSo_Delete_Async,
  ws_L_HeSo_Save_Async,
} from "../_utils/services/he-so-mui-tiem.api";
import { useHeSoMuiTiem } from "../context/he-so-mui-tiem-context";
import { ColorEdit } from "./color-edit";

const convertColorForColorEdit = (color: string | undefined): string => {
  if (!color) return "255, 255, 255";
  const argbMatch = color.match(/^(\d+),\s*(\d+),\s*(\d+),\s*(\d+)$/);
  if (argbMatch) {
    return `${argbMatch[2]}, ${argbMatch[3]}, ${argbMatch[4]}`;
  }

  const rgbMatch = color.match(/^(\d+),\s*(\d+),\s*(\d+)$/);
  if (rgbMatch) {
    return color;
  }

  if (color.startsWith("#")) {
    return color;
  }

  return "255, 255, 255";
};

export type HeSoMuiTiemTabProps = {
  ws_L_Product_List_ByLoaiProduct: ws_L_Product_List_ByLoaiProduct[];
  ws_L_HeSo_Get: ws_L_HeSo_Get[];
  ws_Facility_GetAll: ws_Facility_GetAll[];
  ws_L_HeSoMuiTiem_Get: ws_L_HeSoMuiTiem_Get[];
};

const COLUMN_DEFINITION_SP: ColumnDef<ws_L_Product_List_ByLoaiProduct>[] = [
  {
    id: "hospitalCode",
    accessorKey: "hospitalCode",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Mã Vaccine" />
    ),
  },
  {
    id: "hospitalName",
    accessorKey: "hospitalName",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Tên Vaccine" />
    ),
  },
  {
    id: "unitName",
    accessorKey: "unitName",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Unit" />
    ),
  },
  {
    id: "maChung",
    accessorKey: "maChung",
    header: ({ column }) => (
      <DataTableColumnHeaderSort column={column} title="Mã Chung" />
    ),
  },
];

export const HeSoMuiTiemTab = ({
  ws_L_Product_List_ByLoaiProduct,
  ws_L_HeSo_Get,
  ws_Facility_GetAll,
  ws_L_HeSoMuiTiem_Get,
}: HeSoMuiTiemTabProps) => {
  const { selectedRow, setResetForm } = useHeSoMuiTiem();
  const { confirm } = useFeedbackDialog();
  const form = useForm<HeSoMuiTiemFormValues>({
    resolver: zodResolver(HeSoMuiTiemFormSchema),
    defaultValues: {
      hospitalCode: "",
      hospitalName: "",
      heSo: "",
      fromDate: format(new Date(), DATE_FORMAT.YYYY_MM_DD),
      thruDate: format(
        new Date(new Date().setMonth(new Date().getMonth() + 1)),
        DATE_FORMAT.YYYY_MM_DD,
      ),
      color: "255, 255, 255",
      facID: "",
    },
  });

  const [isHeSoPopoverOpen, setIsHeSoPopoverOpen] = useState(false);
  const [selectedHeSo, setSelectedHeSo] = useState<ws_L_HeSo_Get | null>(null);
  const [newHeSoValue, setNewHeSoValue] = useState("");
  const [currentSelectedProduct, setCurrentSelectedProduct] =
    useState<ws_L_Product_List_ByLoaiProduct | null>(null);

  const selectedProduct = useMemo(
    () =>
      currentSelectedProduct ||
      ws_L_Product_List_ByLoaiProduct.find(
        (v) => v.productID === selectedRow?.productID,
      ),
    [ws_L_Product_List_ByLoaiProduct, selectedRow, currentSelectedProduct],
  );
  const selectedFacility = useMemo(
    () => ws_Facility_GetAll.find((v) => v.id === selectedRow?.facID),
    [ws_Facility_GetAll, selectedRow],
  );
  const selectedHeSoFromData = useMemo(
    () =>
      ws_L_HeSo_Get.find(
        (v) => v.heSo === selectedRow?.heSoTuongUng.toString(),
      ),
    [ws_L_HeSo_Get, selectedRow],
  );

  useEffect(() => {
    const resetFormFunction = () => {
      form.reset({
        hospitalCode: "",
        hospitalName: "",
        heSo: "",
        fromDate: format(new Date(), DATE_FORMAT.YYYY_MM_DD),
        thruDate: format(
          new Date(new Date().setMonth(new Date().getMonth() + 1)),
          DATE_FORMAT.YYYY_MM_DD,
        ),
        color: "255, 255, 255",
        facID: "",
      });
      setSelectedHeSo(null);
      setCurrentSelectedProduct(null);
      setNewHeSoValue("");
    };

    setResetForm(() => resetFormFunction);
  }, [form, setResetForm]);

  useEffect(() => {
    if (selectedRow) {
      const convertedColor = convertColorForColorEdit(selectedRow.color);

      form.reset({
        hospitalCode: selectedRow.hospitalCode,
        hospitalName: selectedRow.hospitalName,
        heSo: selectedRow.heSoTuongUng.toString(),
        fromDate: selectedRow.fromDate,
        thruDate: selectedRow.thruDate,
        color: convertedColor,
        facID: selectedRow.facID,
      });

      setSelectedHeSo(selectedHeSoFromData || null);
      setCurrentSelectedProduct(null);
    }
  }, [selectedRow, selectedHeSoFromData, form]);

  const COLUMN_DEFINITION_COEFFICIENT: ColumnDef<ws_L_HeSo_Get>[] = [
    {
      id: "heSo",
      accessorKey: "heSo",
      header: ({ column }) => (
        <DataTableColumnHeaderSort column={column} title="Hệ Số" />
      ),
    },
    {
      id: "delete",
      accessorKey: "delete",
      header: ({ column }) => (
        <DataTableColumnHeaderSort column={column} title="Xóa" />
      ),
      cell: ({ row }) => (
        <X
          className="text-gray-500 cursor-pointer hover:text-red-500"
          onClick={async (e) => {
            e.stopPropagation();
            await confirm({
              title: "Cảnh báo",
              content: "Xác nhận xóa các hệ số đã chọn?",
            });
            await ws_L_HeSo_Delete_Async(row.original.seq);
          }}
        />
      ),
    },
  ];

  const [facilitySetups, setFacilitySetups] = useState<string[]>([]);

  useEffect(() => {
    const setups = Array.from(
      new Set(
        ws_L_HeSoMuiTiem_Get
          .filter(
            (heSo) =>
              heSo.productID === selectedRow?.productID &&
              heSo.hospitalCode === selectedRow?.hospitalCode &&
              heSo.heSoTuongUng === selectedRow?.heSoTuongUng &&
              heSo.thoiGianApDung === selectedRow?.thoiGianApDung,
          )
          .map((heSo) => heSo.facID),
      ),
    );
    setFacilitySetups(setups);
  }, [selectedRow, ws_L_HeSoMuiTiem_Get]);

  const COLUMN_DEFINITION_FACILITY: ColumnDef<ws_Facility_GetAll>[] = [
    {
      id: "isCheck",
      accessorKey: "isCheck",
      enableColumnFilter: true,
      filterFn: (row, columnId, filterValue) => {
        const isChecked = facilitySetups.includes(row.original.id);

        if (!filterValue || filterValue === "") {
          return true;
        }

        const normalized = String(filterValue).toLowerCase();

        if (normalized === "checked" || normalized === "true") {
          return isChecked === true;
        }

        if (normalized === "unchecked" || normalized === "false") {
          return isChecked === false;
        }

        return false;
      },
      meta: {
        enableColumnFilterDropdown: true,
      },
      header: ({ column }) => (
        <DataTableColumnHeaderSort
          column={column}
          title=""
          className="justify-start"
        />
      ),
      cell: ({ row }) => {
        const isChecked = facilitySetups.includes(row.original.id);
        return (
          <Checkbox
            checked={isChecked}
            className="p-0"
            onCheckedChange={(value: boolean) =>
              console.log("Checkbox changed:", value)
            }
          />
        );
      },
      accessorFn: (row) =>
        facilitySetups.includes(row.id) ? "Checked" : "Unchecked",
    },
    {
      id: "id",
      accessorKey: "id",
      header: ({ column }) => (
        <DataTableColumnHeaderSort column={column} title="Mã cơ sở" />
      ),
    },
    {
      id: "facName",
      accessorKey: "facName",
      header: ({ column }) => (
        <DataTableColumnHeaderSort column={column} title="Tên cơ sở" />
      ),
    },
  ];

  const themHeSo = async (heSo: number) => {
    await ws_L_HeSo_Save_Async(heSo);
  };

  return (
    <div className="px-4">
      <Form {...form}>
        <form className="flex flex-col w-full">
          <div className="flex-1 flex min-h-0 gap-2">
            <div className="w-1/3">
              <div className="flex items-center">
                <Label className="whitespace-nowrap w-20 ">Mã SP</Label>
                <FormField
                  control={form.control}
                  name="hospitalCode"
                  disabled={true}
                  render={({ field }) => (
                    <Input
                      className="ml-3"
                      {...field}
                      onFocus={(e) => {
                        e.target.select();
                      }}
                    />
                  )}
                />
              </div>
              <div className="flex items-center mt-1">
                <Label className="whitespace-nowrap w-20">Tên SP</Label>
                <FormField
                  control={form.control}
                  name="hospitalName"
                  render={({ field }) => (
                    <VirtualTableSelect
                      placeholderSearch="Nhập Tên sản phẩm"
                      placeholder="--Chọn tên sản phẩm--"
                      className="flex-1"
                      classNamePopover={`min-w-[960px]`}
                      data={ws_L_Product_List_ByLoaiProduct}
                      value={selectedProduct}
                      labelKey="hospitalName"
                      valueKey="productID"
                      onChange={(value) => {
                        setCurrentSelectedProduct(value);
                        field.onChange(value?.hospitalName || "");
                        form.setValue(
                          "hospitalCode",
                          value?.hospitalCode || "",
                        );
                      }}
                      columns={COLUMN_DEFINITION_SP}
                      alignPopover="start"
                    />
                  )}
                />
              </div>
              <div className="flex items-start mt-1">
                <Label className="whitespace-nowrap w-20 ">Hệ Số</Label>
                <FormField
                  control={form.control}
                  name="heSo"
                  render={({ field }) => (
                    <Popover
                      open={isHeSoPopoverOpen}
                      onOpenChange={setIsHeSoPopoverOpen}
                    >
                      <PopoverTrigger asChild>
                        <Input
                          readOnly
                          placeholder="--Chọn hệ số--"
                          value={
                            selectedHeSo
                              ? selectedHeSo.heSo
                              : selectedRow
                                ? selectedRow.heSoTuongUng
                                : ""
                          }
                          className="flex-1 cursor-pointer"
                          onClick={() => setIsHeSoPopoverOpen(true)}
                        />
                      </PopoverTrigger>
                      <PopoverContent className="w-80 p-0" align="start">
                        <div className="p-2">
                          <div className="max-h-48 overflow-auto">
                            <DataTable
                              columns={COLUMN_DEFINITION_COEFFICIENT}
                              data={ws_L_HeSo_Get}
                              enablePaging={false}
                              enableColumnFilter={false}
                              onRowClick={(heSo) => {
                                setSelectedHeSo(heSo);
                                field.onChange(heSo.heSo);
                                setIsHeSoPopoverOpen(false);
                                console.log("Selected heSo:", heSo);
                              }}
                              className="border-0"
                            />
                          </div>
                          <div className="flex items-start gap-2 mt-2 pt-2 border-t">
                            <Input
                              placeholder="Hệ số"
                              value={newHeSoValue}
                              onChange={(e) => {
                                let value = e.target.value;
                                if (/^\d*\.?\d*$/.test(value)) {
                                  const match =
                                    value.match(/^(\d*)\.(\d{0,1})/);
                                  if (match) {
                                    value = `${match[1]}${match[2] ? "." + match[2] : ""}`;
                                  }
                                  setNewHeSoValue(value);
                                }
                              }}
                              className="flex-1 h-8"
                              inputMode="decimal"
                              pattern="^\d*\.?\d*$"
                            />
                            <Button
                              size="sm"
                              onClick={async () =>
                                await themHeSo(Number(newHeSoValue))
                              }
                              className="h-8"
                              disabled={
                                !newHeSoValue || isNaN(Number(newHeSoValue))
                              }
                            >
                              <Plus className="h-4 w-4 mr-1" />
                              Thêm mới
                            </Button>
                          </div>
                        </div>
                      </PopoverContent>
                    </Popover>
                  )}
                />
              </div>
            </div>
            <div className="w-1/3">
              <div className="flex items-center gap-2">
                <Label className="whitespace-nowrap">Áp dụng</Label>
                <Label className="whitespace-nowrap ml-14">Từ ngày</Label>
                <FormField
                  control={form.control}
                  name="fromDate"
                  render={({ field }) => (
                    <InputDatePicker
                      value={field.value ? new Date(field.value) : undefined}
                      onChange={(date) => {
                        field.onChange(date?.toISOString().split("T")[0] || "");
                      }}
                    />
                  )}
                />
                <Label className="whitespace-nowrap">Đến ngày</Label>
                <FormField
                  control={form.control}
                  name="thruDate"
                  render={({ field }) => (
                    <InputDatePicker
                      value={field.value ? new Date(field.value) : undefined}
                      onChange={(date) => {
                        field.onChange(date?.toISOString().split("T")[0] || "");
                      }}
                    />
                  )}
                />
              </div>
              <div className="flex items-center mt-1">
                <Label className="whitespace-nowrap mr-9">Màu áp dụng</Label>
                <FormField
                  control={form.control}
                  name="color"
                  render={({ field }) => {
                    return (
                      <ColorEdit
                        key={`color-${selectedRow?.seq}-${field.value}`}
                        value={field.value || "255, 255, 255"}
                        onChange={(value) => {
                          field.onChange(value);
                        }}
                        className="h-6 w-16"
                      />
                    );
                  }}
                />
              </div>
              <div className="flex items-center mt-1">
                <Label className="whitespace-nowrap mr-7 ">Cơ sở áp dụng</Label>
                <FormField
                  control={form.control}
                  name="facID"
                  render={({ field }) => (
                    <TableSelect
                      placeholderSearch="Nhập cơ sở"
                      placeholder="--Chọn cơ sở--"
                      className="flex-1"
                      classNamePopover="w-auto min-w-64"
                      data={ws_Facility_GetAll}
                      value={selectedFacility}
                      labelKey="facName"
                      valueKey="id"
                      onChange={(value) => {
                        field.onChange(value?.id);
                      }}
                      columns={COLUMN_DEFINITION_FACILITY}
                    />
                  )}
                />
              </div>
            </div>
          </div>
        </form>
      </Form>
    </div>
  );
};
