import { Skeleton } from "@/components/ui/skeleton";

export const XuatKhoV2Loading = () => {
  return (
    <div
      className={`fixed inset-0 flex items-center justify-center !pointer-events-auto`}
    >
      <div className="flex items-center justify-center space-x-2 w-[250px] h-[60px] text-black bg-slate-100 border-2 border-[#ffcc00] rounded-md">
        <div className="animate-spin w-5 h-5 border-4 color border-t-transparent border-slate-400 rounded-full"></div>
        <p className=" text-black flex items-center">
          Đang tải dữ liệu
          <span className="ml-1 flex">
            <span className="animate-pulse opacity-0 hover:opacity-100">.</span>
            <span className="animate-pulse opacity-0 delay-200 hover:opacity-100">
              .
            </span>
            <span className="animate-pulse opacity-0 delay-400 hover:opacity-100">
              .
            </span>
            <span className="animate-pulse opacity-0 delay-600 hover:opacity-100">
              .
            </span>
          </span>
        </p>
      </div>
    </div>
  );
};

export const XuatKhoV2FormFilterLoading = () => {
  return (
    <section className="flex flex-row gap-2 pl-4 pr-4 pt-2 pb-2 bg-blue-50">
      <Skeleton className="h-7 flex-1" />
      <Skeleton className="h-7 flex-1" />
      <div className="flex flex-row gap-2">
        <Skeleton className="h-7 w-[100px]" />
        <Skeleton className="h-7 w-[100px]" />
        <Skeleton className="h-7 w-[100px]" />
      </div>
      <Skeleton className="h-7 w-[120px]" />
    </section>
  );
};
