import { ELoadingMessages } from "@/app/lib/enums";
import { useFeedbackDialog } from "@/app/lib/feedback-dialog-provider";
import { notifyError, notifySuccess } from "@/app/lib/utils";
import { getErrorMessage } from "@/app/lib/utils/errorUtils";
import useLoading from "@/components/loading";
import { Button } from "@/components/ui/button";
import { useRouter } from "next/navigation";
import { ws_L_HeSoMuiTiem_Delete_Async } from "../_utils/services/he-so-mui-tiem.api";
import { useHeSoMuiTiem } from "../context/he-so-mui-tiem-context";
export type HeSoMuiTiemFooterProps = {};

const HeSoMuiTiemFooter = ({}: HeSoMuiTiemFooterProps) => {
  const { checkedItems, setSelectedRow, resetForm } = useHeSoMuiTiem();
  const { confirm } = useFeedbackDialog();
  const { showLoading, hideLoading } = useLoading();
  const router = useRouter();
  const xoaHeSo = async () => {
    try {
      const isDelete = await confirm({
        title: "Cảnh báo",
        content: "Xác nhận xóa các hệ số đã chọn?",
      });
      if (!isDelete) return;

      const seqs = checkedItems.map((item) => item.seq);
      const loadingId = showLoading(ELoadingMessages.LOADING_DATA);
      const result = await ws_L_HeSoMuiTiem_Delete_Async(seqs);

      if (result) {
        try {
          router.refresh();
          notifySuccess("Đã xóa các hệ số đã chọn.");
          resetForm();
          setSelectedRow(null);
        } finally {
          hideLoading(loadingId);
        }
      }
    } catch (error) {
      const message = getErrorMessage(error);
      notifyError(`Có lỗi xảy ra khi xóa: ${message}`);
    }
  };

  return (
    <div className="flex w-full p-2 bg-muted">
      <div className="flex items-end justify-end space-x-2 w-full">
        <div className="ml-auto flex space-x-2">
          <Button
            onClick={() => {
              resetForm();
              setSelectedRow(null);
            }}
          >
            Thêm mới
          </Button>
          <Button onClick={() => console.log("Lưu")}>Lưu</Button>
          <Button onClick={xoaHeSo}>Xóa</Button>
        </div>
      </div>
    </div>
  );
};

export default HeSoMuiTiemFooter;
