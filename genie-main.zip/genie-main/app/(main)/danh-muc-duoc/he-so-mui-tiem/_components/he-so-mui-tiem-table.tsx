"use client";
import { compareInclude } from "@/app/lib/utils";
import { Checkbox } from "@/components/ui/checkbox";
import {
  DataTable,
  DataTableColumnHeaderSort,
} from "@/components/ui/dataTable";
import { ColumnDef, Row } from "@tanstack/react-table";
import { useMemo, useState } from "react";
import { ws_L_HeSoMuiTiem_Get } from "../_utils/definitions/he-so-mui-tiem.response";
import { useHeSoMuiTiem } from "../context/he-so-mui-tiem-context";

const globalFilterFn = (
  row: Row<ws_L_HeSoMuiTiem_Get>,
  columnId: string,
  filterValue: string,
) => {
  if (
    columnId === "hospitalCode" ||
    columnId === "hospitalName" ||
    columnId === "maChung"
  ) {
    const originalValue = String(
      row.original[columnId as keyof ws_L_HeSoMuiTiem_Get],
    );
    return compareInclude(filterValue, originalValue);
  }
  return false;
};

export type HeSoMuiTiemTableProps = {
  data: ws_L_HeSoMuiTiem_Get[];
};
const HeSoMuiTiemTable = ({ data }: HeSoMuiTiemTableProps) => {
  const { checkedItems, setCheckedItems, setSelectedRow } = useHeSoMuiTiem();
  const [checkedRows, setCheckedRows] = useState<Record<number, boolean>>({});

  const columns = useMemo(() => {
    const result: ColumnDef<ws_L_HeSoMuiTiem_Get>[] = [
      {
        id: "isCheck",
        accessorKey: "isCheck",
        enableColumnFilter: true,
        filterFn: (row, columnId, filterValue) => {
          const isChecked =
            checkedRows[row.original.seq] ?? row.original.isCheck;

          if (!filterValue || filterValue === "") {
            return true;
          }

          const normalized = String(filterValue).toLowerCase();

          if (normalized === "checked" || normalized === "true") {
            return isChecked === true;
          }

          if (normalized === "unchecked" || normalized === "false") {
            return isChecked === false;
          }

          return false;
        },
        meta: {
          enableColumnFilterDropdown: true,
        },
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title=""
            className="justify-start"
          />
        ),
        cell: ({ row }) => {
          // const rowIndex = row.index;
          const isChecked =
            checkedRows[row.original.seq] ?? row.original.isCheck;

          return (
            <Checkbox
              checked={isChecked}
              className="p-0"
              onCheckedChange={(value: boolean) => {
                setCheckedRows((prev) => ({
                  ...prev,
                  [row.original.seq]: value,
                }));

                if (value && setCheckedItems) {
                  const currentArray = checkedItems || [];
                  setCheckedItems([
                    ...currentArray,
                    { checked: true, seq: String(row.original.seq) },
                  ]);
                }
              }}
            />
          );
        },
        accessorFn: (row, index) => {
          const isChecked = checkedRows[index] ?? row.isCheck;
          return isChecked ? "Checked" : "Unchecked";
        },
      },
      {
        id: "stt",
        accessorKey: "stt",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="STT"
            className="justify-start"
          />
        ),
        enableSorting: true,
      },
      {
        id: "maChung",
        accessorKey: "maChung",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Mã chung"
            className="justify-start"
          />
        ),
        meta: {
          enableColumnFilterDropdown: true,
        },
      },
      {
        id: "hospitalCode",
        accessorKey: "hospitalCode",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Mã SP"
            className="justify-start w-40"
          />
        ),
        enableSorting: true,
        meta: {
          enableColumnFilterDropdown: true,
        },
      },
      {
        id: "hospitalName",
        accessorKey: "hospitalName",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Tên SP"
            className="justify-start w-40"
          />
        ),
        meta: {
          enableColumnFilterDropdown: true,
        },
        enableSorting: true,
      },
      {
        id: "heSoTuongUng",
        accessorKey: "heSoTuongUng",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Hệ số tương ứng"
            className="justify-start"
          />
        ),
        enableSorting: true,
      },
      {
        id: "thoiGianApDung",
        accessorKey: "thoiGianApDung",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Thời gian áp dụng"
            className="justify-start"
          />
        ),
        enableSorting: true,
      },
      {
        id: "facName",
        accessorKey: "facName",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Cơ sở áp dụng"
            className="justify-start"
          />
        ),
        meta: {
          enableColumnFilterDropdown: true,
        },
        enableSorting: true,
      },
      {
        id: "modifiedBy",
        accessorKey: "modifiedBy",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Người thay đổi cuối"
            className="justify-start"
          />
        ),
        enableSorting: true,
      },
    ];
    return result;
  }, [checkedRows, setCheckedItems, checkedItems]);

  return (
    <div className="flex-1 flex flex-col w-full h-full">
      <DataTable
        className="w-full overflow-auto border"
        tHeadClass="z-40"
        tRowClass="cursor-pointer"
        data={data}
        columns={columns}
        enableFooter={true}
        enablePaging={true}
        enableColumnFilter={true}
        enableGlobalFilter={true}
        globalFilterFn={globalFilterFn}
        placeholderSearch="Nhập Mã SP để tìm kiếm..."
        onRowClick={(row) => {
          setSelectedRow(row);
        }}
      />
    </div>
  );
};

export default HeSoMuiTiemTable;
