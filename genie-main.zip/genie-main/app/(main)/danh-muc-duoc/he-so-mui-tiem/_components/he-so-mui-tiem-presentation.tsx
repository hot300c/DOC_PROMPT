"use client";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { HeSoMuiTiem } from "../_utils/definitions/he-so-mui-tiem.response";
import { HeSoMuiTiemFormValues } from "../_utils/schemas/he-so-mui-tiem-schema";
import { HeSoMuiTiemTab } from "./he-so-mui-tiem-cai-dat";
import HeSoMuiTiemFooter from "./he-so-mui-tiem-footer";
import HeSoMuiTiemTable from "./he-so-mui-tiem-table";
export type HeSoMuiTiemPresentationProps = {
  data: HeSoMuiTiem | undefined;
  searchParams?: HeSoMuiTiemFormValues;
};
const HeSoMuiTiemPresentation = ({
  data,
  searchParams,
}: HeSoMuiTiemPresentationProps) => {
  return (
    <div className="flex flex-col flex-1 w-full h-full overflow-y-hidden">
      <div className="flex-[3.5] overflow-hidden">
        <HeSoMuiTiemTable data={data?.ws_L_HeSoMuiTiem_Get ?? []} />
      </div>
      <div className="flex-[1] flex overflow-hidden min-h-0 bg-gray-100">
        <Tabs
          defaultValue="cai-dat"
          className="flex flex-col items-start border overflow-hidden w-full h-full"
        >
          <TabsList>
            <TabsTrigger value="cai-dat">Cài đặt</TabsTrigger>
          </TabsList>
          <div className="flex-1 min-h-0 w-full overflow-hidden">
            <TabsContent value="cai-dat" className="h-full">
              <HeSoMuiTiemTab
                ws_L_Product_List_ByLoaiProduct={
                  data?.ws_L_Product_List_ByLoaiProduct ?? []
                }
                ws_L_HeSo_Get={data?.ws_L_HeSo_Get ?? []}
                ws_Facility_GetAll={data?.ws_Facility_GetAll ?? []}
                ws_L_HeSoMuiTiem_Get={data?.ws_L_HeSoMuiTiem_Get ?? []}
              />
            </TabsContent>
          </div>
        </Tabs>
      </div>
      <HeSoMuiTiemFooter />
    </div>
  );
};

export default HeSoMuiTiemPresentation;
