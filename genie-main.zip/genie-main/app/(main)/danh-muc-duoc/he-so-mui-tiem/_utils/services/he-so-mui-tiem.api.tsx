import { getUserSession } from "@/actions/get-user-session";
import { SequenceRequest } from "@/app/lib/definitions/setting";
import * as httpService from "@/app/lib/network/http";
import { executeTransaction } from "@/app/lib/services/system";
import { getErrorMessage } from "@/app/lib/utils/errorUtils";
import {
  LAY_FAC_THEO_USER,
  PRODUCT_TYPE_VACCINE_ID,
  WS_FACILITY_TAT_CA,
} from "../constants/he-so-mui-tiem.constant";
import { HeSoMuiTiem } from "../definitions/he-so-mui-tiem.response";

export const ws_L_HeSoTiem_Async = async (): Promise<
  HeSoMuiTiem | undefined
> => {
  const requests = [] as SequenceRequest[];
  const currentUser = await getUserSession();
  try {
    const facId = currentUser.facId;

    requests.push({
      category: "QAHosGenericDB",
      command: "ws_L_HeSo_Get",
      parameters: {},
    });
    requests.push({
      category: "QAHosGenericDB",
      command: "ws_Facility_GetAll",
      parameters: {
        FacID: "",
        isTatCa: WS_FACILITY_TAT_CA,
        LayFacTheoUser: LAY_FAC_THEO_USER,
      },
    });
    requests.push({
      category: "QAHosGenericDB",
      command: "ws_L_Product_List_ByLoaiProduct",
      parameters: {
        FacID: facId,
        ProductTypeID: PRODUCT_TYPE_VACCINE_ID,
      },
    });
    requests.push({
      category: "QAHosGenericDB",
      command: "ws_L_HeSoMuiTiem_Get_V2",
      parameters: {
        FacID: facId,
      },
    });
    const result = await executeTransaction({
      request: requests,
    });
    return {
      ws_L_HeSo_Get: result.table,
      ws_Facility_GetAll: result.table2,
      ws_L_Product_List_ByLoaiProduct: result.table3,
      ws_L_HeSoMuiTiem_Get: result.table4,
    } as HeSoMuiTiem;
  } catch (error) {
    const message = getErrorMessage(error);
    console.error("Error in ws_L_HeSoTiem_Async:", message);
    return undefined;
  }
};

export const ws_L_HeSoMuiTiem_Delete_Async = async (
  ids: string[],
): Promise<boolean> => {
  try {
    const requests: SequenceRequest[] = [];
    for (const id of ids) {
      requests.push({
        category: "QAHosGenericDB",
        command: "ws_L_HeSoMuiTiem_Delete",
        parameters: {
          Seq: id,
        },
      });
    }
    await executeTransaction({
      request: requests,
    });
    return true;
  } catch (error) {
    const message = getErrorMessage(error);
    console.error("Error in ws_L_HeSoMuiTiem_Delete_Async:", message);
    return false;
  }
};

export async function ws_L_HeSo_Delete_Async(seq: number): Promise<boolean> {
  const response = await httpService.post("/DataAccess", [
    {
      category: "QAHosGenericDB",
      command: "ws_L_HeSo_Delete",
      parameters: {
        Seq: seq,
      },
    },
  ]);

  return response && response.status == 200;
}

export async function ws_L_HeSo_Save_Async(heSo: number): Promise<boolean> {
  const session = await getUserSession();
  const response = await httpService.post("/DataAccess", [
    {
      category: "QAHosGenericDB",
      command: "ws_L_HeSo_Save",
      parameters: {
        HeSo: heSo,
        FacID: session.facId,
      },
    },
  ]);

  return response && response.status == 200;
}
