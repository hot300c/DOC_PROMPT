export const WS_FACILITY_TAT_CA = 1;
export const LAY_FAC_THEO_USER = 0;
export const PRODUCT_TYPE_VACCINE_ID = 17;
