import { z } from "zod";

export const HeSoMuiTiemFormSchema = z.object({
  hospitalCode: z.string().optional(),
  hospitalName: z.string().optional(),
  heSo: z.string().optional(),
  fromDate: z.string().optional(),
  thruDate: z.string().optional(),
  color: z.string().optional(),
  facID: z.string().optional(),
});

export type HeSoMuiTiemFormValues = z.infer<typeof HeSoMuiTiemFormSchema>;
