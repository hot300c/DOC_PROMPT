export type ws_L_HeSo_Get = {
  seq: number;
  facID: string;
  heSo: string;
  createdOn: string;
  createdOnAsInt: string;
  createdBy: string;
  modifiedOn: string;
  modifiedBy: string;
};

export type ws_Facility_GetAll = {
  id: string;
  facName: string;
  orderi?: string;
  isCheck?: boolean;
};

export type ws_L_Product_List_ByLoaiProduct = {
  maChung: string;
  productID: number;
  hospitalCode: string;
  hospitalName: string;
  unitName: string;
  hospitalName1: string;
  formula: string;
  content: string;
  duongDung: string;
  isCheck: boolean;
  isProductMain: number;
};

export type ws_L_HeSoMuiTiem_Get = {
  isCheck: boolean;
  stt: number;
  seq: number;
  facID: string;
  maChung: string;
  productID: number;
  hospitalCode: string;
  hospitalName: string;
  heSoTuongUng: number;
  thoiGianApDung: string;
  facName: string;
  modifiedBy: string;
  fromDate: string;
  thruDate: string;
  color: string; // dạng "R, G, B, A"
  createdOn: string;
  createdOnAsInt: string;
  createdBy: string;
  modifiedOn: string;
};

export type HeSoMuiTiem = {
  ws_L_HeSo_Get: ws_L_HeSo_Get[];
  ws_Facility_GetAll: ws_Facility_GetAll[];
  ws_L_Product_List_ByLoaiProduct: ws_L_Product_List_ByLoaiProduct[];
  ws_L_HeSoMuiTiem_Get: ws_L_HeSoMuiTiem_Get[];
};
