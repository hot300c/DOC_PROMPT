export type ws_Facility_GetAll_Param = {
  isTatCa: number;
  layFacTheoUser: number;
};
