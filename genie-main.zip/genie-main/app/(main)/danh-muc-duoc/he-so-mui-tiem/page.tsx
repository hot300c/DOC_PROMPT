import HeSoMuiTiemContainer from "./_components/he-so-mui-tiem-container";
import HeSoMuiTiemHeader from "./_components/he-so-mui-tiem-header";
import { HeSoMuiTiemFormValues } from "./_utils/schemas/he-so-mui-tiem-schema";
import { HeSoMuiTiemProvider } from "./context/he-so-mui-tiem-context";

export default async function Page(props: {
  searchParams?: Promise<HeSoMuiTiemFormValues>;
}) {
  const searchParams = await props.searchParams;

  return (
    <HeSoMuiTiemProvider>
      <div className="flex flex-col overflow-y-hidden w-full h-full space-y-2">
        <HeSoMuiTiemHeader />
        <HeSoMuiTiemContainer searchParams={searchParams} />
      </div>
    </HeSoMuiTiemProvider>
  );
}
