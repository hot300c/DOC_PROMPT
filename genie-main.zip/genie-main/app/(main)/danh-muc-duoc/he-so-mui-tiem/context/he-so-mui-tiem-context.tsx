"use client";
import { createContext, useContext, useState } from "react";
import { ws_L_HeSoMuiTiem_Get } from "../_utils/definitions/he-so-mui-tiem.response";

type HeSoMuiTiemCheckedItem = {
  checked: boolean;
  seq: string;
};

type HeSoMuiTiemContextType = {
  checkedItems: HeSoMuiTiemCheckedItem[];
  setCheckedItems: (items: HeSoMuiTiemCheckedItem[]) => void;
  selectedRow: ws_L_HeSoMuiTiem_Get | null;
  setSelectedRow: (row: ws_L_HeSoMuiTiem_Get | null) => void;
  resetForm: () => void;
  setResetForm: (resetFn: () => void) => void;
};

const HeSoMuiTiemContext = createContext<HeSoMuiTiemContextType | undefined>(
  undefined,
);

export const useHeSoMuiTiem = () => {
  const context = useContext(HeSoMuiTiemContext);
  if (!context) {
    throw new Error("useHeSoMuiTiem must be used within a HeSoMuiTiemProvider");
  }
  return context;
};

export const HeSoMuiTiemProvider: React.FC<{
  children: React.ReactNode;
}> = ({ children }) => {
  const [checkedItems, setCheckedItems] = useState<HeSoMuiTiemCheckedItem[]>(
    [],
  );
  const [selectedRow, setSelectedRow] = useState<ws_L_HeSoMuiTiem_Get | null>(
    null,
  );
  const [resetForm, setResetForm] = useState<() => void>(() => () => {});

  return (
    <HeSoMuiTiemContext.Provider
      value={{
        checkedItems,
        setCheckedItems,
        selectedRow,
        setSelectedRow,
        resetForm,
        setResetForm,
      }}
    >
      {children}
    </HeSoMuiTiemContext.Provider>
  );
};
