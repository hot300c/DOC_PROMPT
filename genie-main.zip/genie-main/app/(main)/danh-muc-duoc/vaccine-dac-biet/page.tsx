import { ModalPrintProvider } from "@/app/lib/modal-print-provider";
import { Suspense } from "react";
import { Loading } from "../../duoc/(base_components)/loading";
import VaccineDacBietContainer from "./_components/vaccine-dac-biet-container";
import VaccineDacBietHeader from "./_components/vaccine-dac-biet-header";
import { VaccineDacBietData } from "./_utils/definitions/vaccine-dac-biet.resp";
import { VaccineDacBietFilterParams } from "./_utils/schema/schema";
import { fetchDataVaccineDacBiet } from "./_utils/services/vaccine-dac-biet.api";

export default async function Page(props: {
  searchParams?: Promise<VaccineDacBietFilterParams>;
}) {
  const searchParams = await props.searchParams;
  const vaccineDacBietData: VaccineDacBietData = await fetchDataVaccineDacBiet(
    Number(searchParams?.productID) ?? 0,
  );
  return (
    <ModalPrintProvider>
      <div className="flex flex-col w-full h-full space-y-2">
        <VaccineDacBietHeader />
        <Suspense fallback={<Loading />}>
          <VaccineDacBietContainer vaccineDacBietData={vaccineDacBietData} />
        </Suspense>
      </div>
    </ModalPrintProvider>
  );
}
