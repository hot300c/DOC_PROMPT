import { getUserSession } from "@/actions/get-user-session";
import { SequenceRequest } from "@/app/lib/definitions/setting";
import * as SystemService from "@/app/lib/services/system";
import {
  MaVaccineDacBietRESP,
  VaccineDacBietData,
} from "../definitions/vaccine-dac-biet.resp";
import * as httpService from "@/app/lib/network/http";
import { VaccineSpecialSaveParams } from "../definitions/vaccine-dac-biet.params";

export async function fetchDataVaccineDacBiet(productID: number): Promise<any> {
  try {
    const currentUser = await getUserSession();
    const requests: SequenceRequest[] = [
      {
        category: "QAHosGenericDB",
        command: "ws_LoadProductBaseUserID_List",
        parameters: {
          ActionType: 6,
          FacID: currentUser.facId,
        },
      },
      {
        category: "QAHosGenericDB",
        command: "ws_L_DinhNghiaLieuDung_Get_All",
        parameters: {},
      },
    ];
    const response = await SystemService.executeTransaction({
      request: requests,
    });
    const vaccineData: VaccineDacBietData = {
      data: response.table || [],
      dinhNghiaLieuDungs: response.table1 || [],
    };
    return vaccineData;
  } catch (error) {
    return [];
  }
}

export async function getVaccineSpecialByProductList(
  productID: number,
): Promise<MaVaccineDacBietRESP[]> {
  try {
    const response = await httpService.post("/DataAccess", [
      {
        category: "QAHosGenericDB",
        command: "ws_L_VaccineSpecial_ByProduct_List",
        parameters: {
          ProductID: productID,
        },
      },
    ]);

    return response.data.table || [];
  } catch (error) {
    return [];
  }
}

export async function vaccineSpecialListCheck(
  productSpecialCode: string,
): Promise<MaVaccineDacBietRESP[]> {
  try {
    const response = await httpService.post("/DataAccess", [
      {
        category: "QAHosGenericDB",
        command: "ws_L_VaccineSpecial_Check",
        parameters: {
          ProductSpecialCode: productSpecialCode,
        },
      },
    ]);

    return response.data.table || [];
  } catch (error) {
    return [];
  }
}

export async function vaccineDacBietSave(
  params: VaccineSpecialSaveParams,
): Promise<{ success: boolean }> {
  const response = await httpService.post("/DataAccess", [
    {
      category: "QAHosGenericDB",
      command: "ws_L_VaccineSpecial_Save",
      parameters: {
        ProductID: params.productID,
        MaChung: params.maChung,
        ProductSpecialCode: params.productSpecialCode,
        LieuDungID: params.lieuDungID,
        LieuDungName: params.lieuDungName,
        IsActive: true,
      },
    },
  ]);
  return response.data;
}

export async function vaccineDacBietDelete(
  vaccineSpecialID: number,
): Promise<{ success: boolean }> {
  const response = await httpService.post("/DataAccess", [
    {
      category: "QAHosGenericDB",
      command: "ws_L_VaccineSpecial_Delete",
      parameters: {
        VaccineSpecialID: vaccineSpecialID,
      },
    },
  ]);
  return response.data;
}
