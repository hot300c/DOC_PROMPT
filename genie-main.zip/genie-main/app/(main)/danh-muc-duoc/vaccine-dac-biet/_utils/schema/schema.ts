"use client";
import { z } from "zod";

export const MaVaccineDatBietSchema = z.object({
  productSpecialCode: z.string().optional(),
  lieuDungID: z.number().nullable().optional(),
  lieuDungName: z.string().nullable().optional(),
});
export type MaVaccineDatBietFormData = z.infer<typeof MaVaccineDatBietSchema>;

export type VaccineDacBietFilterParams = {
  productID: string;
};
