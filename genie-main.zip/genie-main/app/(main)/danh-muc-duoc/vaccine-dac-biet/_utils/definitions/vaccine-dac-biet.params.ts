export type VaccineSpecialSaveParams = {
  productID: number;
  maChung: string;
  productSpecialCode: string;
  lieuDungID: number;
  lieuDungName: string;
};
