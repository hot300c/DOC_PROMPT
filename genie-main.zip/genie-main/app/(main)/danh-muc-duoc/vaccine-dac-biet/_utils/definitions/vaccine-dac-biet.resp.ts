export interface VaccineDacBietRESP {
  content: string;
  countryName: string;
  donvidung: string | null;
  duongDung: string;
  formula: string;
  hangsanxuat1: string;
  hospitalCode: string;
  hospitalName: string;
  maChung: string;
  nuocSanXuat: number;
  productID: number;
  productSpecialCodes: string | null;
  tenNhomBenh: string;
  unitName: string;
}

export type DinhNghiaLieuDungRESP = {
  id: number;
  idUnit: number | null;
  idUnitDinhNghia: number | null;
  idUnitDinhNghiaQuyDoi: number | null;
  slQuyDoi: number | null;
  soLuong: number;
  tenLieuDung: string | null;
  unitName: string | null;
  unitNameDinhNghia: string | null;
};

export type VaccineDacBietData = {
  dinhNghiaLieuDungs: DinhNghiaLieuDungRESP[];
  data: VaccineDacBietRESP[];
};

export type MaVaccineDacBietRESP = {
  isActive: boolean;
  lieuDungID: number;
  lieuDungName: string;
  maChung: string;
  productID: number;
  productSpecialCode: string;
  vaccineSpecialID: number;
};
