"use client";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { useEffect, useState } from "react";
import {
  DinhNghiaLieuDungRESP,
  VaccineDacBietRESP,
} from "../_utils/definitions/vaccine-dac-biet.resp";
import { MaVaccineDacBietTab } from "./tab/ma-vaccine-dac-biet/ma-vaccine-dac-biet-tab";
import VaccineDacBietTable from "./vaccine-dac-biet-datatable";

export type VaccineDacBietPresentationProps = {
  data: VaccineDacBietRESP[];
  dinhNghiaLieuDungs: DinhNghiaLieuDungRESP[];
};
const VaccineDacBietPresentation = ({
  data,
  dinhNghiaLieuDungs,
}: VaccineDacBietPresentationProps) => {
  const searchParams = useSearchParams();
  const productID = searchParams.get("productID");
  const router = useRouter();
  const pathname = usePathname();

  const [selectedVaccineDacBiet, setSelectedVaccineDacBiet] = useState<
    VaccineDacBietRESP | undefined
  >(undefined);

  useEffect(() => {
    if (!!selectedVaccineDacBiet) return;
    if (!productID) {
      setSelectedVaccineDacBiet(data[0]);
      return;
    }
    setSelectedVaccineDacBiet(
      data.find((item) => item.productID.toString() === productID),
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [data, productID]);

  const onRowClick = (row: VaccineDacBietRESP) => {
    setSelectedVaccineDacBiet(row);
    const query = new URLSearchParams(window.location.search);
    query.set("productID", row.productID.toString());
    router.push(pathname + "?" + query.toString());
  };

  return (
    <div className="flex flex-col flex-1 w-full h-full overflow-hidden">
      <div className="flex-[2] flex overflow-hidden">
        <VaccineDacBietTable
          data={data}
          onRowClick={onRowClick}
          productID={productID}
        />
      </div>
      <div className="flex-[1] flex overflow-hidden min-h-0">
        <Tabs
          defaultValue="vaccine-dac-biet"
          className="flex flex-col items-start overflow-hidden w-full h-full"
        >
          <TabsList>
            <TabsTrigger value="vaccine-dac-biet">
              Mã vaccine đặc biệt
            </TabsTrigger>
          </TabsList>
          <div className="flex-1 min-h-0 w-full overflow-hidden">
            <TabsContent value="vaccine-dac-biet" className="h-full">
              <MaVaccineDacBietTab
                selectedVaccineDacBiet={selectedVaccineDacBiet}
                dinhNghiaLieuDungs={dinhNghiaLieuDungs}
                data={data}
              ></MaVaccineDacBietTab>
            </TabsContent>
          </div>
        </Tabs>
      </div>
    </div>
  );
};

export default VaccineDacBietPresentation;
