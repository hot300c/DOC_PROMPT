"use client";

import { TableSelect } from "@/components/select/table-select";
import { DataTableColumnHeaderSort } from "@/components/ui/dataTable";
import { Column, ColumnDef } from "@tanstack/react-table";
import { useMemo } from "react";
import { DinhNghiaLieuDungRESP } from "../../_utils/definitions/vaccine-dac-biet.resp";

export default function LieuDungComboBox({
  dinhNghiaLieuDungs = [],
  selectedLieuDungID,
  handleLieuDungSelect,
  isUseOnTable,
}: {
  dinhNghiaLieuDungs?: DinhNghiaLieuDungRESP[];
  selectedLieuDungID?: string;
  handleLieuDungSelect: (x: DinhNghiaLieuDungRESP | undefined) => void;
  isUseOnTable?: boolean;
}) {
  const hangSanXuatID = useMemo(() => {
    return dinhNghiaLieuDungs.find(
      (sp) => sp.id.toString() === selectedLieuDungID,
    );
  }, [selectedLieuDungID, dinhNghiaLieuDungs]);

  const LIEU_DUNG_COLUMN_COMBOBOX = useMemo(() => {
    const result: ColumnDef<DinhNghiaLieuDungRESP>[] = [
      ...(isUseOnTable
        ? [
            {
              id: "id",
              accessorKey: "id",
              header: ({
                column,
              }: {
                column: ColumnDef<DinhNghiaLieuDungRESP>;
              }) => (
                <DataTableColumnHeaderSort
                  column={column as Column<DinhNghiaLieuDungRESP>}
                  title="Đợt nhập"
                />
              ),
              cell: ({ row }: { row: { original: DinhNghiaLieuDungRESP } }) => (
                <div>{row.original.id}</div>
              ),
            },
          ]
        : []),
      {
        id: "tenLieuDung",
        accessorKey: "tenLieuDung",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Tên liều dùng"
            className="justify-start"
          />
        ),
        enableSorting: true,
      },
      ...(isUseOnTable
        ? [
            {
              id: "soLuong",
              accessorKey: "soLuong",
              header: ({
                column,
              }: {
                column: ColumnDef<DinhNghiaLieuDungRESP>;
              }) => (
                <DataTableColumnHeaderSort
                  column={column as Column<DinhNghiaLieuDungRESP>}
                  title="Số lượng"
                />
              ),
            },
            {
              id: "idUnit",
              accessorKey: "idUnit",
              header: ({
                column,
              }: {
                column: ColumnDef<DinhNghiaLieuDungRESP>;
              }) => (
                <DataTableColumnHeaderSort
                  column={column as Column<DinhNghiaLieuDungRESP>}
                  title="Đơn vị"
                />
              ),
            },
            {
              id: "unitName",
              accessorKey: "unitName",
              header: ({
                column,
              }: {
                column: ColumnDef<DinhNghiaLieuDungRESP>;
              }) => (
                <DataTableColumnHeaderSort
                  column={column as Column<DinhNghiaLieuDungRESP>}
                  title="Tên đơn vị"
                />
              ),
            },
            {
              id: "idUnitDinhNghia",
              accessorKey: "idUnitDinhNghia",
              header: ({
                column,
              }: {
                column: ColumnDef<DinhNghiaLieuDungRESP>;
              }) => (
                <DataTableColumnHeaderSort
                  column={column as Column<DinhNghiaLieuDungRESP>}
                  title="Đơn vị định nghĩa"
                />
              ),
            },
            {
              id: "unitNameDinhNghia",
              accessorKey: "unitNameDinhNghia",
              header: ({
                column,
              }: {
                column: ColumnDef<DinhNghiaLieuDungRESP>;
              }) => (
                <DataTableColumnHeaderSort
                  column={column as Column<DinhNghiaLieuDungRESP>}
                  title="Tên đơn vị định nghĩa"
                />
              ),
            },
            {
              id: "idUnitDinhNghiaQuyDoi",
              accessorKey: "idUnitDinhNghiaQuyDoi",
              header: ({
                column,
              }: {
                column: ColumnDef<DinhNghiaLieuDungRESP>;
              }) => (
                <DataTableColumnHeaderSort
                  column={column as Column<DinhNghiaLieuDungRESP>}
                  title="Đơn vị định nghĩa quy đổi"
                />
              ),
            },
            {
              id: "slQuyDoi",
              accessorKey: "slQuyDoi",
              header: ({
                column,
              }: {
                column: ColumnDef<DinhNghiaLieuDungRESP>;
              }) => (
                <DataTableColumnHeaderSort
                  column={column as Column<DinhNghiaLieuDungRESP>}
                  title="Số lượng quy đổi"
                />
              ),
            },
          ]
        : []),
    ];
    return result;
  }, [isUseOnTable]);
  return (
    <div className="flex flex-row col-span-2 items-center gap-3 h-lg:gap-4 w-full">
      <TableSelect
        columns={LIEU_DUNG_COLUMN_COMBOBOX}
        data={dinhNghiaLieuDungs}
        labelKey="tenLieuDung"
        valueKey="id"
        placeholderSearch="Tìm kiếm..."
        placeholder="--Chọn liều dùng --"
        data-cy="chon-hang-san-xuat"
        value={hangSanXuatID}
        className="w-full"
        classNameTable="max-h-[40vh] max-w-[1000px]"
        classNamePopover="w-auto min-w-60"
        onChange={handleLieuDungSelect}
      />
    </div>
  );
}
