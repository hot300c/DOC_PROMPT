"use client";
import {
  DataTable,
  DataTableColumnHeaderSort,
} from "@/components/ui/dataTable";
import { ColumnDef } from "@tanstack/react-table";
import { useMemo } from "react";
import { VaccineDacBietRESP } from "../_utils/definitions/vaccine-dac-biet.resp";

export type VaccineDacBietTableProps = {
  data: VaccineDacBietRESP[];
  onRowClick: (row: VaccineDacBietRESP) => void;
  productID: string | null;
};
const VaccineDacBietTable = ({
  data,
  onRowClick,
  productID,
}: VaccineDacBietTableProps) => {
  const columns = useMemo(() => {
    const result: ColumnDef<VaccineDacBietRESP>[] = [
      {
        id: "maChung",
        accessorKey: "maChung",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Mã chung" />
        ),
        meta: {
          className: "text-left truncate",
        },
        cell: ({ row }) => (
          <div title={row.original.maChung}>{row.original.maChung}</div>
        ),
      },
      {
        id: "hospitalCode",
        accessorKey: "hospitalCode",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Mã SP" />
        ),
        cell: ({ row }) => (
          <div title={row.original.hospitalCode}>
            {row.original.hospitalCode}
          </div>
        ),
      },
      {
        id: "hospitalName",
        accessorKey: "hospitalName",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Tên SP" />
        ),
        cell: ({ row }) => (
          <div className="min-w-40">
            <span title={row.original.hospitalName}>
              {row.original.hospitalName}
            </span>
          </div>
        ),
      },
      {
        id: "productSpecialCodes",
        accessorKey: "productSpecialCodes",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Vaccine đặc biệt" />
        ),
        cell: ({ row }) => (
          <div className="min-w-40">
            <span>{row.original.productSpecialCodes}</span>
          </div>
        ),
      },

      {
        id: "content",
        accessorKey: "content",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Hàm lượng" />
        ),
        meta: {
          className: "text-left",
        },
      },
      {
        id: "formula",
        accessorKey: "formula",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Hoạt chất" />
        ),
        meta: {
          className: "text-left",
        },
      },
      {
        id: "unitName",
        accessorKey: "unitName",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="ĐVT" />
        ),
        meta: {
          className: "text-left",
        },
      },
      {
        id: "duongDung",
        accessorKey: "duongDung",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Đường dùng" />
        ),
        meta: {
          className: "text-left",
        },
      },
      {
        id: "countryName",
        accessorKey: "countryName",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Nước SX" />
        ),
        meta: {
          className: "text-left",
        },
      },
      {
        id: "hangsanxuat1",
        accessorKey: "hangsanxuat1",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Hãng SX" />
        ),
        meta: {
          className: "text-left",
        },
      },
      {
        id: "tenNhomBenh",
        accessorKey: "tenNhomBenh",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Nhóm bệnh" />
        ),
        meta: {
          className: "text-left",
        },
      },
    ];
    return result;
  }, []);

  const indexScrollTo = useMemo(
    () =>
      productID
        ? data.findIndex((row) => row.productID.toString() == productID)
        : 0,
    [data, productID],
  );

  return (
    <div className="flex flex-col h-full w-full">
      <DataTable
        className="w-full h-full overflow-y-auto border"
        tableClassName="border"
        tHeadClass="z-40"
        columns={columns}
        data={data}
        enableColumnFilter={true}
        enablePaging={false}
        enableGlobalFilter={true}
        placeholderSearch="Nhập để tìm kiếm..."
        enableFooter
        onRowClick={onRowClick}
        indexScrollTo={indexScrollTo}
      ></DataTable>
    </div>
  );
};

export default VaccineDacBietTable;
