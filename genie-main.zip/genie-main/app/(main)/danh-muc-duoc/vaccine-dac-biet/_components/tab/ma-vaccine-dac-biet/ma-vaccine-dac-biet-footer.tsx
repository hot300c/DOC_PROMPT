"use client";

import { exportToExcel, TableConfig } from "@/app/lib/utils/exportToExcel ";
import { Button } from "@/components/ui/button";
import { VaccineDacBietRESP } from "../../../_utils/definitions/vaccine-dac-biet.resp";

export type MaVaccineDacBietFooterProps = {
  data: VaccineDacBietRESP[];
};

export const MaVaccineDacBietFooter = ({
  data,
}: MaVaccineDacBietFooterProps) => {
  const exportData = async (data: VaccineDacBietRESP[]) => {
    const tableConfig: TableConfig = {
      columns: {
        "Mã chung": { width: 10, alignment: "left" },
        "Mã SP": { width: 20, alignment: "left" },
        "Tên SP": { width: 30, alignment: "left" },
        "Vaccine đặc biệt": { width: 30, alignment: "left" },
        "Hàm lượng": { width: 15, alignment: "left" },
        "Hoạt chất": { width: 15, alignment: "left" },
        ĐVT: { width: 10, alignment: "left" },
        "Đường dùng": { width: 20, alignment: "left" },
        "Nước SX": { width: 15, alignment: "left" },
        "Hãng SX": { width: 15, alignment: "left" },
        "Nhóm bệnh": { width: 25, alignment: "left" },
      },
      data:
        data && data.length > 0
          ? data.map((row) => [
              row.maChung,
              row.hospitalCode,
              row.hospitalName,
              row.productSpecialCodes,
              row.content,
              row.formula,
              row.unitName,
              row.duongDung,
              row.countryName,
              row.hangsanxuat1,
              row.tenNhomBenh,
            ])
          : [],
      sheetName: "Vaccine đặc biệt",
      fileName: "vaccine-dac-biet.xlsx",
    };

    await exportToExcel(tableConfig);
  };

  return (
    <div className="flex-none flex flex-row mb-2">
      <Button type="button" onClick={() => exportData(data)}>
        Xuất excel
      </Button>
    </div>
  );
};
