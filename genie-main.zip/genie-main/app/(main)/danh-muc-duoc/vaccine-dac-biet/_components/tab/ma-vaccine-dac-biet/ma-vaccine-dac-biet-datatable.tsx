"use client";
import { ELoadingMessages } from "@/app/lib/enums";
import { useFeedbackDialog } from "@/app/lib/feedback-dialog-provider";
import { notifySuccess } from "@/app/lib/utils";
import { getErrorMessage } from "@/app/lib/utils/errorUtils";
import useLoading from "@/components/loading";
import { Checkbox } from "@/components/ui/checkbox";
import {
  DataTable,
  DataTableColumnHeaderSort,
} from "@/components/ui/dataTable";
import { ColumnDef } from "@tanstack/react-table";
import { X } from "lucide-react";
import { useMemo } from "react";
import {
  DinhNghiaLieuDungRESP,
  MaVaccineDacBietRESP,
} from "../../../_utils/definitions/vaccine-dac-biet.resp";
import { vaccineDacBietDelete } from "../../../_utils/services/vaccine-dac-biet.api";
import LieuDungComboBox from "../../combobox/lieu-dung-combobox";

export type MaVaccineDacBietTableProps = {
  data: MaVaccineDacBietRESP[];
  handleFetchDataGiaVaccine: (productID: number) => Promise<void>;
  dinhNghiaLieuDungs?: DinhNghiaLieuDungRESP[];
};
const MaVaccineDacBietTable = ({
  data,
  handleFetchDataGiaVaccine,
  dinhNghiaLieuDungs,
}: MaVaccineDacBietTableProps) => {
  const { alert, confirm } = useFeedbackDialog();
  const { showLoading, hideLoading } = useLoading();
  const handleDeteleMaVaccineDacBiet = async (row: MaVaccineDacBietRESP) => {
    const isConfirm = await confirm({
      title: "Cảnh báo",
      content: "Bạn có muốn xóa chi tiết phiếu này?",
    });
    if (!isConfirm) return;
    const loadingId = showLoading(ELoadingMessages.PROCESSING_DATA);

    try {
      await vaccineDacBietDelete(row.vaccineSpecialID);
      notifySuccess("Xóa thành công");
      await handleFetchDataGiaVaccine(row.productID);
    } catch (error) {
      const mess = getErrorMessage(error);
      await alert({
        title: "Cảnh báo",
        content: "Xóa không thành công: " + mess,
      });
    } finally {
      hideLoading(loadingId);
    }
  };

  const columns = useMemo(() => {
    const result: ColumnDef<MaVaccineDacBietRESP>[] = [
      {
        id: "productSpecialCode",
        accessorKey: "productSpecialCode",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Mã vaccine đặc biệt"
          />
        ),
        meta: {
          className: "text-overflow-ellipsis truncate ",
        },
      },
      {
        id: "lieuDungName",
        accessorKey: "lieuDungName",
        header: ({ column }) => (
          <DataTableColumnHeaderSort column={column} title="Liều dùng" />
        ),
        meta: {
          className: "text-overflow-ellipsis truncate text-right",
        },
        cell: ({ row }) => {
          const lieuDung = row.original;
          return (
            <LieuDungComboBox
              dinhNghiaLieuDungs={dinhNghiaLieuDungs}
              isUseOnTable={true}
              selectedLieuDungID={lieuDung.lieuDungID?.toString()}
              handleLieuDungSelect={(selected) => {}}
            />
          );
        },
      },
      {
        id: "isActive",
        accessorKey: "isActive",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title={<span className="w-full block text-center">Sử dụng</span>}
          />
        ),
        meta: {
          className: "pl-1 text-center",
        },
        cell: ({ row }) => <Checkbox checked={row.original.isActive} />,
        filterFn: "isBoolean",
      },
      {
        id: "deleteButton",
        accessorKey: "deleteButton",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Xóa"
            className="justify-start"
          />
        ),
        cell: ({ row }) => (
          <X
            onClick={async () => {
              await handleDeteleMaVaccineDacBiet(row.original);
            }}
            className="text-gray-500 cursor-pointer"
          />
        ),
        enableSorting: true,
      },
    ];
    return result;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [data]);

  return (
    <div className="flex-1 flex flex-col h-full w-full">
      <DataTable
        className="w-full overflow-y-auto border"
        tableClassName="border"
        tHeadClass="z-40"
        columns={columns}
        data={data}
        enableColumnFilter={false}
        enablePaging={false}
        enableGlobalFilter={false}
        placeholderSearch="Nhập để tìm kiếm..."
        enableFooter
      ></DataTable>
    </div>
  );
};

export default MaVaccineDacBietTable;
