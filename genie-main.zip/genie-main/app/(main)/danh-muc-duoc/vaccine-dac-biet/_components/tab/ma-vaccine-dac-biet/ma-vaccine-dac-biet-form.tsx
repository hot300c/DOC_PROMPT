"use client";

import { ELoadingMessages } from "@/app/lib/enums";
import { useFeedbackDialog } from "@/app/lib/feedback-dialog-provider";
import { notifySuccess } from "@/app/lib/utils";
import { getErrorMessage } from "@/app/lib/utils/errorUtils";
import useLoading from "@/components/loading";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { zodResolver } from "@hookform/resolvers/zod";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { VaccineSpecialSaveParams } from "../../../_utils/definitions/vaccine-dac-biet.params";
import {
  DinhNghiaLieuDungRESP,
  MaVaccineDacBietRESP,
  VaccineDacBietRESP,
} from "../../../_utils/definitions/vaccine-dac-biet.resp";
import {
  MaVaccineDatBietFormData,
  MaVaccineDatBietSchema,
} from "../../../_utils/schema/schema";
import {
  vaccineDacBietSave,
  vaccineSpecialListCheck,
} from "../../../_utils/services/vaccine-dac-biet.api";
import LieuDungComboBox from "../../combobox/lieu-dung-combobox";
export type MaVaccineDacBietFormProps = {
  dinhNghiaLieuDungs: DinhNghiaLieuDungRESP[];
  data: MaVaccineDacBietRESP[];
  selectedVaccineDacBiet: VaccineDacBietRESP | undefined;
  handleFetchDataGiaVaccine: (productID: number) => Promise<void>;
};

export const MaVaccineDacBietForm = ({
  dinhNghiaLieuDungs,
  data,
  selectedVaccineDacBiet,
  handleFetchDataGiaVaccine,
}: MaVaccineDacBietFormProps) => {
  const { alert } = useFeedbackDialog();

  const { showLoading, hideLoading } = useLoading();
  const [lieuDungSelect, setLieuDungSelect] = useState<
    DinhNghiaLieuDungRESP | undefined
  >(undefined);

  const defaultFormData: MaVaccineDatBietFormData = {
    productSpecialCode: "",
    lieuDungID: undefined,
    lieuDungName: undefined,
  };

  const mapVaccineToFormData = (
    vaccine: MaVaccineDatBietFormData | undefined,
  ): MaVaccineDatBietFormData => {
    if (!vaccine) return {} as MaVaccineDatBietFormData;
    return Object.fromEntries(
      Object.keys(defaultFormData).map((key) => {
        let value =
          vaccine[key as keyof MaVaccineDatBietFormData] ??
          defaultFormData[key as keyof MaVaccineDatBietFormData];
        return [key, value];
      }),
    ) as MaVaccineDatBietFormData;
  };

  const form = useForm<MaVaccineDatBietFormData>({
    resolver: zodResolver(MaVaccineDatBietSchema),
    defaultValues: mapVaccineToFormData(undefined),
  });

  const handleLieuDungSelect = (lieDung?: DinhNghiaLieuDungRESP) => {
    setLieuDungSelect(lieDung);
    form.setValue("lieuDungID", lieDung?.id);
    form.setValue("lieuDungName", lieDung?.tenLieuDung);
  };

  const validateData = async (
    formData: MaVaccineDatBietFormData,
  ): Promise<boolean> => {
    if (!formData.productSpecialCode) {
      await alert({
        title: "Cảnh báo",
        content: "Mã Vaccine không được để trống!",
      });
      return false;
    }
    if (!formData.lieuDungID) {
      await alert({
        title: "Cảnh báo",
        content: "Liều dùng không được để trống!",
      });
      return false;
    }
    var isExistedLieuDung = data.some(
      (q) => q.lieuDungID === formData.lieuDungID,
    );
    if (isExistedLieuDung) {
      await alert({
        title: "Cảnh báo",
        content: "Liều dùng không được trùng!",
      });
      return false;
    }
    var vaccineSpecialListValueCheck = await vaccineSpecialListCheck(
      formData.productSpecialCode,
    );
    if (
      vaccineSpecialListValueCheck.length > 0 &&
      selectedVaccineDacBiet?.maChung !==
        vaccineSpecialListValueCheck[0]?.maChung
    ) {
      await alert({
        title: "Cảnh báo",
        content:
          "Mã vaccine đặc biệt này đang thuộc vaccine: " +
          vaccineSpecialListValueCheck[0]?.maChung,
      });
      return false;
    }
    return true;
  };

  const onSubmit = async (formData: MaVaccineDatBietFormData) => {
    const loadingId = showLoading(ELoadingMessages.WAITING);
    try {
      const isValid = await validateData(formData);
      if (!isValid) return;
      const params: VaccineSpecialSaveParams = {
        productID: selectedVaccineDacBiet?.productID!,
        maChung: selectedVaccineDacBiet?.maChung!,
        lieuDungID: formData.lieuDungID!,
        lieuDungName: formData.lieuDungName!,
        productSpecialCode: formData.productSpecialCode!,
      };
      await vaccineDacBietSave(params);
      notifySuccess("Lưu mã vaccine đặc biệt thành công.");
      form.reset(defaultFormData);
      setLieuDungSelect(undefined);
      await handleFetchDataGiaVaccine(selectedVaccineDacBiet?.productID ?? 0);
    } catch (error) {
      await alert({
        title: "Lỗi",
        content: "Lưu mã vaccine đặc biệt thất bại: " + getErrorMessage(error),
      });
    } finally {
      hideLoading(loadingId);
    }
  };

  return (
    <Form {...form}>
      <form className="w-full" onSubmit={form.handleSubmit(onSubmit)}>
        <div className="flex gap-4">
          <div className="flex items-center mt-1">
            <Label className="whitespace-nowrap mr-12">
              Mã vaccine đặc biệt
            </Label>
            <FormField
              control={form.control}
              name="productSpecialCode"
              render={({ field }) => (
                <FormItem className="flex items-center gap-2 w-full">
                  <FormControl className="w-full">
                    <Input
                      {...field}
                      onFocus={(e) => {
                        e.target.select();
                      }}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
          <div className="flex items-center mt-1">
            <Label className="whitespace-nowrap mr-10 ">Liều dùng</Label>
            <LieuDungComboBox
              dinhNghiaLieuDungs={dinhNghiaLieuDungs}
              selectedLieuDungID={lieuDungSelect?.id.toString()}
              handleLieuDungSelect={(lieuDung) => {
                handleLieuDungSelect(lieuDung || undefined);
              }}
            />
          </div>
          <div className="flex items-center mt-1">
            <Button type="submit">Lưu</Button>
          </div>
        </div>
      </form>
    </Form>
  );
};
