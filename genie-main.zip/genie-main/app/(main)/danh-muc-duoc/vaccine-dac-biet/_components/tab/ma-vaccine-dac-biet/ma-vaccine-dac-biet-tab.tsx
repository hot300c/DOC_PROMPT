"use client";

import { ELoadingMessages } from "@/app/lib/enums";
import { useFeedbackDialog } from "@/app/lib/feedback-dialog-provider";
import { getErrorMessage } from "@/app/lib/utils/errorUtils";
import useLoading from "@/components/loading";
import { useCallback, useEffect, useState } from "react";
import {
  DinhNghiaLieuDungRESP,
  MaVaccineDacBietRESP,
  VaccineDacBietRESP,
} from "../../../_utils/definitions/vaccine-dac-biet.resp";

import { getVaccineSpecialByProductList } from "../../../_utils/services/vaccine-dac-biet.api";
import MaVaccineDacBietTable from "./ma-vaccine-dac-biet-datatable";
import { MaVaccineDacBietFooter } from "./ma-vaccine-dac-biet-footer";
import { MaVaccineDacBietForm } from "./ma-vaccine-dac-biet-form";

export type MaVaccineDacBietTabProps = {
  selectedVaccineDacBiet: VaccineDacBietRESP | undefined;
  dinhNghiaLieuDungs: DinhNghiaLieuDungRESP[];
  data: VaccineDacBietRESP[];
};

export const MaVaccineDacBietTab = ({
  selectedVaccineDacBiet,
  dinhNghiaLieuDungs,
  data,
}: MaVaccineDacBietTabProps) => {
  const { alert } = useFeedbackDialog();
  const { showLoading, hideLoading } = useLoading();

  const [maVaccineDacBietList, setMaVaccineDacBietList] = useState<
    MaVaccineDacBietRESP[]
  >([]);

  const handleFetchDataGiaVaccine = useCallback(async (productID: number) => {
    const loadingId = showLoading(ELoadingMessages.WAITING);
    try {
      var response = await getVaccineSpecialByProductList(productID ?? 0);
      setMaVaccineDacBietList(response);
    } catch (err) {
      await alert({
        title: "Lỗi",
        content: getErrorMessage(err),
      });
    } finally {
      hideLoading(loadingId);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    void handleFetchDataGiaVaccine(selectedVaccineDacBiet?.productID ?? 0);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedVaccineDacBiet?.productID]);

  return (
    <div className="flex h-full flex-col overflow-hidden px-4">
      <MaVaccineDacBietForm
        dinhNghiaLieuDungs={dinhNghiaLieuDungs}
        data={maVaccineDacBietList ?? []}
        selectedVaccineDacBiet={selectedVaccineDacBiet}
        handleFetchDataGiaVaccine={handleFetchDataGiaVaccine}
      ></MaVaccineDacBietForm>
      <div className="flex-1 min-h-0 overflow-auto mt-1">
        <MaVaccineDacBietTable
          handleFetchDataGiaVaccine={handleFetchDataGiaVaccine}
          data={maVaccineDacBietList ?? []}
          dinhNghiaLieuDungs={dinhNghiaLieuDungs}
        />
      </div>
      <MaVaccineDacBietFooter data={data}></MaVaccineDacBietFooter>
    </div>
  );
};
