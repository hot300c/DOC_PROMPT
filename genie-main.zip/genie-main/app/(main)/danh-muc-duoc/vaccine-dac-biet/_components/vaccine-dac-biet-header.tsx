"use client";

import FacilityInfo from "@/components/facilityInfo";

export default function VaccineDacBietHeader() {
  return <FacilityInfo page={"DANH MỤC - DƯỢC | VACCINE ĐẶC BIỆT"} />;
}
