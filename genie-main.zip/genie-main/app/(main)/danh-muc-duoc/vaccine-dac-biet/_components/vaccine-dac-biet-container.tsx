import { VaccineDacBietData } from "../_utils/definitions/vaccine-dac-biet.resp";
import VaccineDacBietPresentation from "./vaccine-dac-biet-presentation";

export type VaccineDacBietContainerProps = {
  vaccineDacBietData: VaccineDacBietData;
};
const VaccineDacBietContainer = async ({
  vaccineDacBietData,
}: VaccineDacBietContainerProps) => {
  return (
    <VaccineDacBietPresentation
      data={vaccineDacBietData.data}
      dinhNghiaLieuDungs={vaccineDacBietData.dinhNghiaLieuDungs}
    ></VaccineDacBietPresentation>
  );
};

export default VaccineDacBietContainer;
