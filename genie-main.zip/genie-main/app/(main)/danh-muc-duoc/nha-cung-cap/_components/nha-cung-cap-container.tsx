import { NhaCungCapFormValues } from "../_utils/schemas/nha-cung-cap-schema";
import { nhaCungCapAsync } from "../_utils/services/nha-cung-cap.api";
import NhaCungCapPresentation from "./nha-cung-cap-presentation";

export type NhaCungCapContainerProps = {
  searchParams?: NhaCungCapFormValues;
};

const NhaCungCapContainer = async ({
  searchParams,
}: NhaCungCapContainerProps) => {
  const nhaCungCaps = await nhaCungCapAsync();
  return (
    <NhaCungCapPresentation
      nhaCungcaps={nhaCungCaps}
      searchParams={searchParams}
    />
  );
};

export default NhaCungCapContainer;
