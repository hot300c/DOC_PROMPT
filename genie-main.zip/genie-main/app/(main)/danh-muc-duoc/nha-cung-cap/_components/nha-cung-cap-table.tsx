"use client";
import {
  DataTable,
  DataTableColumnHeaderSort,
} from "@/components/ui/dataTable";
import { ColumnDef, Row } from "@tanstack/react-table";
import { useEffect, useMemo, useRef } from "react";
import { L_Vendor } from "../_utils/definitions/nha-cung-cap.response";
import { useNhaCungCap } from "../context/nha-cung-cap-context";

export type NhaCungCapTableProps = {
  l_Vendor: L_Vendor[];
  onFilteredDataChange?: (filteredData: L_Vendor[]) => void;
};
const NhaCungCapTable = ({
  l_Vendor,
  onFilteredDataChange,
}: NhaCungCapTableProps) => {
  const { selectedRow, setSelectedRow } = useNhaCungCap();
  const hasInitialized = useRef(false);

  const handleFilteredRowsChange = (filteredRows: Row<L_Vendor>[]) => {
    const filteredVendors = filteredRows.map((row) => row.original);

    if (onFilteredDataChange) {
      onFilteredDataChange(filteredVendors);
    }
  };

  useEffect(() => {
    if (
      l_Vendor &&
      l_Vendor.length > 0 &&
      !selectedRow &&
      !hasInitialized.current
    ) {
      setSelectedRow(l_Vendor[0] ?? null);
      hasInitialized.current = true;
    }
  }, [l_Vendor, selectedRow, setSelectedRow]);

  const columns = useMemo(() => {
    const result: ColumnDef<L_Vendor>[] = [
      {
        id: "vendorNo",
        accessorKey: "vendorNo",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Mã"
            className="justify-start"
          />
        ),
        cell: ({ row }) => (
          <div className="text-no-wrap">{row.original.vendorNo}</div>
        ),
        filterFn: "includesString",
        enableSorting: true,
      },
      {
        id: "supplierName",
        accessorKey: "supplierName",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Tên"
            className="justify-start"
          />
        ),
        cell: ({ row }) => (
          <div className="text-no-wrap w-80">{row.original.supplierName}</div>
        ),
        filterFn: "includesString",
      },
      {
        id: "taxID",
        accessorKey: "taxID",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Mã số thuế"
            className="justify-start w-60"
          />
        ),
        filterFn: "includesString",
        enableSorting: true,
      },
      {
        id: "khoLienQuan",
        accessorKey: "khoLienQuan",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Kho liên quan"
            className="justify-start w-60"
          />
        ),
        cell: ({ row }) => (
          <div className="text-no-wrap w-100">{row.original.khoLienQuan}</div>
        ),
        enableSorting: true,
      },
      {
        id: "phone",
        accessorKey: "phone",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="SDT"
            className="justify-start"
          />
        ),
        filterFn: "includesString",
        enableSorting: true,
      },
      {
        id: "fullAddress",
        accessorKey: "fullAddress",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Địa chỉ"
            className="justify-start"
          />
        ),
        cell: ({ row }) => (
          // whitespace-nowrap
          <div className="w-60">{row.original.fullAddress}</div>
        ),
        filterFn: "includesString",
        enableSorting: true,
      },
      {
        id: "bankName",
        accessorKey: "bankName",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Ngân hàng"
            className="justify-start"
          />
        ),
        cell: ({ row }) => (
          // whitespace-nowrap
          <div className="w-50">{row.original.bankName}</div>
        ),
        enableSorting: true,
      },
      {
        id: "accountBank",
        accessorKey: "accountBank",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Số TK"
            className="justify-start"
          />
        ),
        filterFn: "includesString",
        enableSorting: true,
      },
      {
        id: "type",
        accessorKey: "type",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Loại"
            className="justify-start"
          />
        ),
        cell: ({ row }) => (
          // whitespace-nowrap
          <div className="w-60">{row.original.type}</div>
        ),
        enableColumnFilter: true,
        enableSorting: true,
      },
    ];
    return result;
  }, []);

  const indexScrollTo = useMemo(() => {
    return selectedRow
      ? l_Vendor.findIndex((vendor) => vendor.id === selectedRow.id)
      : 0;
  }, [selectedRow, l_Vendor]);

  return (
    <div className="flex-1 flex flex-col w-full h-full">
      <DataTable
        className="w-full overflow-auto border"
        tHeadClass="z-40"
        tRowClass="cursor-pointer"
        data={l_Vendor}
        columns={columns}
        enableFooter={true}
        enablePaging={true}
        enableColumnFilter={true}
        enableGlobalFilter={true}
        placeholderSearch="Nhập để tìm kiếm..."
        onRowClick={(row) => {
          setSelectedRow(row);
        }}
        indexScrollTo={indexScrollTo}
        onFilteredRowCountChange={handleFilteredRowsChange}
      />
    </div>
  );
};

export default NhaCungCapTable;
