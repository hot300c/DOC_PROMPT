"use client";

import { getSetting } from "@/app/lib/utils";
import { MultiSelect } from "@/components/select/multi-select";
import { Form, FormField } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { selectBaseSetting } from "@/redux/selectors";
import { useAppSelector } from "@/redux/store";
import { zodResolver } from "@hookform/resolvers/zod";
import { useCallback, useEffect, useMemo } from "react";
import { useForm } from "react-hook-form";
import { L_InventoryStock } from "../_utils/definitions/nha-cung-cap.response";
import {
  NhaCungCapFormSchema,
  NhaCungCapFormValues,
} from "../_utils/schemas/nha-cung-cap-schema";
import { nhaCungCapChiTietAsync } from "../_utils/services/nha-cung-cap.api";
import { useNhaCungCap } from "../context/nha-cung-cap-context";

export type NhaCungCapChiTietProps = {
  l_InventoryStock?: L_InventoryStock[];
};

export const NhaCungCapChiTiet = ({
  l_InventoryStock,
}: NhaCungCapChiTietProps) => {
  const { selectedRow, setFormValues } = useNhaCungCap();
  const baseSettings = useAppSelector(selectBaseSetting);
  const form = useForm<NhaCungCapFormValues>({
    resolver: zodResolver(NhaCungCapFormSchema),
    defaultValues: {
      vendorNo: "",
      taxID: "",
      name: "",
      phone: "",
      fullAddress: "",
      bankAdress: "",
      bankOfAddress: "",
      accountBank: "",
      bankName: "",
      khoLienQuan: "",
      bankAcountName: "",
    },
  });

  const updateFormValues = useCallback(
    (values: NhaCungCapFormValues) => {
      setFormValues(values);
    },
    [setFormValues],
  );

  useEffect(() => {
    const subscription = form.watch((value, { name, type }) => {
      if (type === "change") {
        updateFormValues(value as NhaCungCapFormValues);
      }
    });
    return () => subscription.unsubscribe();
  }, [form, updateFormValues]);

  useEffect(() => {
    const fetchAndPopulateData = async () => {
      if (selectedRow?.id) {
        try {
          const chiTietData = await nhaCungCapChiTietAsync(
            selectedRow.id.toString(),
          );

          if (chiTietData?.l_Vendor_By_ID?.[0]) {
            const vendorData = chiTietData.l_Vendor_By_ID[0];
            const stockIds =
              chiTietData.l_StockVendorPermissons_GetByVendorID
                ?.map((item) => item.stockID?.toString())
                .filter(Boolean) ?? [];

            form.reset({
              vendorNo: vendorData.vendorNo || "",
              taxID: vendorData.taxID || "",
              name: vendorData.name || "",
              phone: vendorData.phone || "",
              fullAddress: vendorData.fullAddress || "",
              bankAdress: vendorData.bankAdress || "",
              bankOfAddress: vendorData.bankOfAddress || "",
              accountBank: vendorData.accountBank || "",
              bankName: vendorData.bankName || "",
              khoLienQuan: stockIds.join(","),
              bankAcountName: vendorData.bankAcountName || "",
            });
          }
        } catch (error) {
          console.error("Error fetching vendor details:", error);
        }
      } else {
        form.reset({
          vendorNo: "",
          taxID: "",
          name: "",
          phone: "",
          fullAddress: "",
          bankAdress: "",
          bankOfAddress: "",
          accountBank: "",
          bankName: "",
          khoLienQuan: "",
          bankAcountName: "",
        });
      }
    };

    void fetchAndPopulateData();
  }, [selectedRow, form]);

  const khoLienQuanOptions = useMemo(
    () =>
      l_InventoryStock?.map((item) => ({
        value: item.stockID.toString(),
        label: item.name,
      })) ?? [],
    [l_InventoryStock],
  );

  const billBussinessPharmacySetting = getSetting(
    baseSettings,
    "BillBussiness",
    "Pharmacy",
  )?.value;

  return (
    <div className="px-4">
      <Form {...form}>
        <form className="flex flex-col w-full">
          <div className="flex-1 flex min-h-0 gap-6">
            {/* Cột trái */}
            <div className="w-1/2 space-y-3">
              <div className="flex items-center gap-2">
                <Label className="whitespace-nowrap w-32">
                  Mã nhà cung cấp
                </Label>
                <FormField
                  control={form.control}
                  name="vendorNo"
                  render={({ field }) => (
                    <Input {...field} className="flex-1" />
                  )}
                />
              </div>

              <div className="flex items-center gap-2">
                <Label className="whitespace-nowrap w-32">Mã số thuế</Label>
                <FormField
                  control={form.control}
                  name="taxID"
                  render={({ field }) => (
                    <Input {...field} className="flex-1" />
                  )}
                />
              </div>

              <div className="flex items-center gap-2">
                <Label className="whitespace-nowrap w-32">
                  Tên nhà cung cấp
                </Label>
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <Input {...field} className="flex-1" />
                  )}
                />
              </div>

              {billBussinessPharmacySetting === "N" ? (
                <div className="flex items-center gap-2">
                  <Label className="whitespace-nowrap w-32">
                    Đơn vị thụ hưởng
                  </Label>
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <Input {...field} className="flex-1" />
                    )}
                  />
                </div>
              ) : (
                <div className="h-4" />
              )}

              <div className="flex items-center gap-2 pt-1">
                <Label className="whitespace-nowrap w-32">Tại ngân hàng</Label>
                <FormField
                  control={form.control}
                  name="bankName"
                  render={({ field }) => (
                    <Input {...field} placeholder="" className="flex-1" />
                  )}
                />
              </div>

              <div className="flex items-center gap-2">
                <Label className="whitespace-nowrap w-32">Kho liên quan</Label>
                <FormField
                  control={form.control}
                  name="khoLienQuan"
                  render={({ field }) => (
                    <MultiSelect
                      options={khoLienQuanOptions}
                      onChange={(values) => field.onChange(values.join(","))}
                      value={field.value ? field.value.split(",") : []}
                      placeholder="-- Chọn kho tổng --"
                      className="flex-1"
                      classNamePopover={`min-w-[900px]`}
                    />
                  )}
                />
              </div>
            </div>

            {/* Cột phải */}
            <div className="w-1/2 space-y-3">
              <div className="flex items-center gap-2">
                <Label className="whitespace-nowrap w-32">Số điện thoại</Label>
                <FormField
                  control={form.control}
                  name="phone"
                  render={({ field }) => (
                    <Input {...field} className="flex-1" />
                  )}
                />
              </div>

              <div className="flex items-center gap-2">
                <Label className="whitespace-nowrap w-32">Địa chỉ</Label>
                <FormField
                  control={form.control}
                  name="fullAddress"
                  render={({ field }) => (
                    <Input {...field} className="flex-1" />
                  )}
                />
              </div>

              <div className="flex items-center gap-2">
                <Label className="whitespace-nowrap w-32">
                  Địa chỉ thụ hưởng
                </Label>
                <FormField
                  control={form.control}
                  name="bankAdress"
                  render={({ field }) => (
                    <Input {...field} placeholder="" className="flex-1" />
                  )}
                />
              </div>

              <div className="flex items-center gap-2">
                <Label className="whitespace-nowrap w-32">
                  Địa chỉ ngân hàng
                </Label>
                <FormField
                  control={form.control}
                  name="bankOfAddress"
                  render={({ field }) => (
                    <Input {...field} placeholder="" className="flex-1" />
                  )}
                />
              </div>

              <div className="flex items-center gap-2">
                <Label className="whitespace-nowrap w-32">Số tài khoản</Label>
                <FormField
                  control={form.control}
                  name="accountBank"
                  render={({ field }) => (
                    <Input {...field} placeholder="" className="flex-1" />
                  )}
                />
              </div>
            </div>
          </div>
        </form>
      </Form>
    </div>
  );
};
