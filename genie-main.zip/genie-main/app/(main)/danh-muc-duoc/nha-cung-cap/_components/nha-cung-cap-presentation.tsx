"use client";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useState } from "react";
import {
  L_Vendor,
  NhaCungCapResponse,
} from "../_utils/definitions/nha-cung-cap.response";
import { NhaCungCapFormValues } from "../_utils/schemas/nha-cung-cap-schema";
import { NhaCungCapChiTiet } from "./nha-cung-cap-chi-tiet";
import NhaCungCapFooter from "./nha-cung-cap-footer";
import NhaCungCapTable from "./nha-cung-cap-table";
export type NhaCungCapPresentationProps = {
  nhaCungcaps: NhaCungCapResponse | undefined;
  searchParams?: NhaCungCapFormValues;
};
const NhaCungCapPresentation = ({
  nhaCungcaps,
  searchParams,
}: NhaCungCapPresentationProps) => {
  const [filteredVendors, setFilteredVendors] = useState<L_Vendor[]>(
    nhaCungcaps?.l_Vendor ?? [],
  );

  const handleFilteredDataChange = (filteredData: L_Vendor[]) => {
    setFilteredVendors(filteredData);
  };

  return (
    <div className="flex flex-col flex-1 w-full h-full overflow-y-hidden">
      <div className="flex-[1.6] overflow-hidden">
        <NhaCungCapTable
          l_Vendor={nhaCungcaps?.l_Vendor ?? []}
          onFilteredDataChange={handleFilteredDataChange}
        />
      </div>
      <div className="flex-[1] flex overflow-hidden min-h-0 bg-gray-100">
        <Tabs
          defaultValue="nha-cung-cap"
          className="flex flex-col items-start border overflow-hidden w-full h-full"
        >
          <TabsList>
            <TabsTrigger value="nha-cung-cap">Nhà cung cấp</TabsTrigger>
          </TabsList>
          <div className="flex-1 min-h-0 w-full overflow-hidden">
            <TabsContent value="nha-cung-cap" className="h-full">
              <NhaCungCapChiTiet
                l_InventoryStock={nhaCungcaps?.l_InventoryStock ?? []}
              />
            </TabsContent>
          </div>
        </Tabs>
      </div>
      <NhaCungCapFooter filteredVendors={filteredVendors} />
    </div>
  );
};

export default NhaCungCapPresentation;
