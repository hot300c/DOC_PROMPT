"use client";

import FacilityInfo from "@/components/facilityInfo";

export default function NhaCungCapHeader() {
  return <FacilityInfo page={"DANH MỤC | NHÀ CUNG CẤP"} />;
}
