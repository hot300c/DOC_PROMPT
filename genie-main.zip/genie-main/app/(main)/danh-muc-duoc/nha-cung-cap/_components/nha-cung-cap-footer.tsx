import { useFeedbackDialog } from "@/app/lib/feedback-dialog-provider";
import { getSetting } from "@/app/lib/utils";
import useLoading from "@/components/loading";
import { Button } from "@/components/ui/button";
import { selectBaseSetting } from "@/redux/selectors";
import { useAppSelector } from "@/redux/store";
import { useRouter } from "next/navigation";
import { L_Vendor } from "../_utils/definitions/nha-cung-cap.response";
import { NhaCungCapFormValues } from "../_utils/schemas/nha-cung-cap-schema";
import { exportDetailData } from "../_utils/services/export-excel-detail";
import {
  ws_L_Vendor_Delete_Async,
  ws_L_Vendor_Save_Async,
  ws_StockVendorPermissons_Delete_Async,
  ws_StoctVendorPermissions_Save_Async,
} from "../_utils/services/nha-cung-cap.api";
import { useNhaCungCap } from "../context/nha-cung-cap-context";
export type NhaCungCapFooterProps = {
  filteredVendors?: L_Vendor[];
};

const NhaCungCapFooter = ({ filteredVendors }: NhaCungCapFooterProps) => {
  const { setSelectedRow, selectedRow, formValues } = useNhaCungCap();
  const { alert, confirm } = useFeedbackDialog();
  const { showLoading, hideLoading } = useLoading();
  const router = useRouter();
  const baseSettings = useAppSelector(selectBaseSetting);

  const validateForm = (formValues: NhaCungCapFormValues): string[] => {
    const validationErrors: string[] = [];

    if (!formValues.vendorNo || formValues.vendorNo.trim() === "") {
      validationErrors.push("Chưa nhập mã nhà cung cấp");
    }

    if (!formValues.taxID || formValues.taxID.trim() === "") {
      validationErrors.push("Chưa nhập mã số thuế");
    }

    if (!formValues.name || formValues.name.trim() === "") {
      validationErrors.push("Chưa nhập tên nhà cung cấp");
    }

    if (!formValues.phone || formValues.phone.trim() === "") {
      validationErrors.push("Chưa nhập số điện thoại");
    }

    if (!formValues.khoLienQuan || formValues.khoLienQuan.trim() === "") {
      validationErrors.push("Chưa chọn kho liên quan");
    }

    return validationErrors;
  };

  const handleSave = async () => {
    if (!formValues) {
      await alert({
        title: "Lỗi",
        content: "Không có dữ liệu để lưu!",
      });
      return;
    }

    const validationErrors = validateForm(formValues);
    if (validationErrors.length > 0) {
      await alert({
        title: "Lỗi xác thực",
        content: validationErrors.join("\n"),
      });
      return;
    }

    const loadingId = showLoading("Đang lưu...");
    try {
      const isAddNew = selectedRow === null;
      const vendorId = isAddNew ? "0" : selectedRow.id?.toString() || "0";

      if (!isAddNew) {
        const isAdd = await confirm({
          title: "Lưu ý",
          content:
            "Bạn đang ghi đè lên dữ liệu cũ.\n Bạn có đồng ý thực hiện không?",
        });
        if (!isAdd) return;
      }

      const vendorParams = {
        vendorId: vendorId,
        vendorNo: formValues.vendorNo || "",
        name: formValues.name || "",
        phone: formValues.phone || "",
        taxID: formValues.taxID || "",
        fullAddress: formValues.fullAddress || "",
        accountBank: formValues.accountBank || "",
        bankName: formValues.bankName || "",
        bankAdress: formValues.bankAdress || "",
        bankAcountName: formValues.bankAcountName || "",
        bankOfAddress: formValues.bankOfAddress || "",
      };

      const vendorResult = await ws_L_Vendor_Save_Async(vendorParams);

      if (vendorResult && vendorResult.length > 0 && vendorResult[0]) {
        const maintenanceSetting = getSetting(
          baseSettings,
          "VendorStocks",
          "Maintenance",
        )?.value;

        const savedVendorId = vendorResult[0].vendorID?.toString();

        if (maintenanceSetting === "Y") {
          const stockIds =
            formValues.khoLienQuan
              ?.split(",")
              .filter((id) => id.trim() !== "") ?? [];

          if (stockIds.length > 0) {
            await ws_StockVendorPermissons_Delete_Async(savedVendorId);

            await ws_StoctVendorPermissions_Save_Async({
              vendorId: savedVendorId,
              stockIDs: stockIds,
            });
          }
        }

        await alert({
          title: "Lưu",
          content: "Đã lưu",
        });

        const newVendor: L_Vendor = {
          id: vendorResult[0].vendorID,
          vendorNo: formValues.vendorNo || "",
          supplierName: formValues.name || "",
          phone: formValues.phone || "",
          taxID: formValues.taxID || "",
          bankName: formValues.bankName || "",
          fullAddress: formValues.fullAddress || "",
          accountBank: formValues.accountBank || "",
          bankAdress: formValues.bankAdress || "",
          bankAcountName: formValues.bankAcountName || "",
          khoLienQuan: formValues.khoLienQuan || "",
          stocksID: formValues.khoLienQuan || "",
          type: "",
        };
        router.refresh();
        setSelectedRow(newVendor);
      } else {
        await alert({
          title: "Lỗi",
          content: "Không thể lưu nhà cung cấp!",
        });
      }
    } catch (error) {
      await alert({
        title: "Lỗi",
        content: "Có lỗi xảy ra khi lưu!",
      });
    } finally {
      hideLoading(loadingId);
    }
  };

  const handleDeleteNcc = async () => {
    if (selectedRow?.type === "Danh mục hệ thống") {
      await alert({
        title: "Cảnh báo",
        content: "Không thể xóa Danh mục hệ thống",
      });
      return;
    }

    const confirmed = await confirm({
      title: "Cảnh báo",
      content: `Bạn muốn xóa 'Supplier ${selectedRow?.supplierName}'?\nBạn sẽ KHÔNG thể khôi phục lại dữ liệu đã xóa.`,
    });
    if (!confirmed) return;

    const loadingId = showLoading("Đang xóa...");
    try {
      const result = await ws_L_Vendor_Delete_Async(
        selectedRow?.id?.toString(),
      );
      await alert({
        title: "Cảnh báo",
        content: result === "Ok" ? "Đã xóa." : result,
      });
      if (result === "Ok") {
        setSelectedRow(null);
        router.refresh();
      }
    } finally {
      hideLoading(loadingId);
    }
  };

  const handleExportExcel = async () => {
    const dataToExport =
      filteredVendors && filteredVendors.length > 0 ? filteredVendors : [];
    await exportDetailData(dataToExport);
  };

  return (
    <div className="flex w-full p-2 bg-muted justify-between items-center">
      <div className="flex space-x-2 items-center">
        <Button onClick={handleExportExcel}>Excel</Button>
      </div>
      <div className="flex space-x-2">
        <Button onClick={() => setSelectedRow(null)}>Thêm mới</Button>
        <Button onClick={handleSave}>Lưu</Button>
        <Button onClick={handleDeleteNcc}>Xóa</Button>
      </div>
    </div>
  );
};

export default NhaCungCapFooter;
