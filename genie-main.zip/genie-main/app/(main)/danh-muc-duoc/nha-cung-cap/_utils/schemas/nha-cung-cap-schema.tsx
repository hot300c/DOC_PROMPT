import { z } from "zod";

export const NhaCungCapFormSchema = z.object({
  vendorNo: z.string().optional(), // Mã nhà cung cấp
  taxID: z.string().optional(), // Mã số thuế
  name: z.string().optional(), // Tên nhà cung cấp
  phone: z.string().optional(), // Số điện thoại
  fullAddress: z.string().optional(), // Địa chỉ
  bankAdress: z.string().optional(), // Địa chỉ thụ hưởng
  bankOfAddress: z.string().optional(), // Địa chỉ ngân hàng
  accountBank: z.string().optional(), // Số tài khoản
  bankName: z.string().optional(), // Tại ngân hàng
  khoLienQuan: z.string().optional(), // Kho liên quan
  bankAcountName: z.string().optional(), // Đơn vị thụ hưởng
});

export type NhaCungCapFormValues = z.infer<typeof NhaCungCapFormSchema>;
