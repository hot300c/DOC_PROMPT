export const ACTION_TYPE_NCC = 7; // Lấy danh sách kho cho màn hình bảng dữ liệu -> nhà cung cấp
