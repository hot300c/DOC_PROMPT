import { getUserSession } from "@/actions/get-user-session";
import { SequenceRequest } from "@/app/lib/definitions/setting";
import * as httpService from "@/app/lib/network/http";
import { executeTransaction } from "@/app/lib/services/system";
import { getErrorMessage } from "@/app/lib/utils/errorUtils";
import { ACTION_TYPE_NCC } from "../constants/nha-cung-cap.constant";
import {
  ws_L_Vendor_Save_Params,
  ws_StoctVendorPermissions_Save_Params,
} from "../definitions/nha-cung-cap.request";
import {
  NhaCungCapChiTiet,
  NhaCungCapResponse,
  ws_L_Vendor_Save,
} from "../definitions/nha-cung-cap.response";

export const nhaCungCapAsync = async (): Promise<
  NhaCungCapResponse | undefined
> => {
  const requests = [] as SequenceRequest[];
  const currentUser = await getUserSession();
  try {
    const facId = currentUser.facId;

    requests.push({
      category: "QAHosGenericDB",
      command: "ws_L_Vendor_List",
      parameters: {
        FacID: facId,
      },
    });
    requests.push({
      category: "QAHosGenericDB",
      command: "ws_L_InventoryStock_List",
      parameters: {
        FacID: facId,
        ActionType: ACTION_TYPE_NCC,
      },
    });

    const result = await executeTransaction({
      request: requests,
    });
    return {
      l_Vendor: result.table,
      l_InventoryStock: result.table1,
    } as NhaCungCapResponse;
  } catch (error) {
    const message = getErrorMessage(error);
    console.error("Error in nhaCungCapAsync:", message);
    return undefined;
  }
};

export const nhaCungCapChiTietAsync = async (
  vendorId: string,
): Promise<NhaCungCapChiTiet | undefined> => {
  const requests = [] as SequenceRequest[];
  const currentUser = await getUserSession();
  try {
    const facId = currentUser.facId;

    requests.push({
      category: "QAHosGenericDB",
      command: "ws_L_Vendor_Get",
      parameters: {
        FacID: facId,
        Id: vendorId,
      },
    });
    requests.push({
      category: "QAHosGenericDB",
      command: "ws_StockVendorPermissons_GetByVendorID",
      parameters: {
        FacID: facId,
        VendorID: vendorId,
      },
    });

    const result = await executeTransaction({
      request: requests,
    });
    return {
      l_Vendor_By_ID: result.table,
      l_StockVendorPermissons_GetByVendorID: result.table1,
    } as NhaCungCapChiTiet;
  } catch (error) {
    const message = getErrorMessage(error);
    console.error("Error in nhaCungCapChiTietAsync:", message);
    return undefined;
  }
};

export async function ws_StockVendorPermissons_Delete_Async(
  vendorId?: string,
): Promise<boolean> {
  try {
    const currentUser = await getUserSession();
    const response = await httpService.post("/DataAccess", [
      {
        category: "Security",
        command: "ws_StockVendorPermissons_Delete",
        parameters: {
          FacID: currentUser.facId,
          VendorID: vendorId,
        },
      },
    ]);

    return response && response.status == 200;
  } catch (error) {
    const message = getErrorMessage(error);
    console.error("Error in ws_StockVendorPermissons_Delete_Async:", message);
    return false;
  }
}

export async function ws_StoctVendorPermissions_Save_Async(
  params: ws_StoctVendorPermissions_Save_Params,
): Promise<boolean> {
  try {
    const currentUser = await getUserSession();
    const requests = [] as SequenceRequest[];
    for (const item of params.stockIDs) {
      requests.push({
        category: "Security",
        command: "ws_StoctVendorPermissions_Save",
        parameters: {
          FacID: currentUser.facId,
          StockID: item,
          VendorID: params.vendorId,
        },
      });
    }
    await executeTransaction({
      request: requests,
    });
    return true;
  } catch (error) {
    const message = getErrorMessage(error);
    console.error("Error in ws_StockVendorPermissons_Delete_Async:", message);
    return false;
  }
}

export async function ws_L_Vendor_Save_Async(
  params: ws_L_Vendor_Save_Params,
): Promise<ws_L_Vendor_Save[]> {
  try {
    const currentUser = await getUserSession();
    const response = await httpService.post("/DataAccess", [
      {
        category: "QAHosGenericDB",
        command: "ws_L_Vendor_Save",
        parameters: {
          FacID: currentUser.facId,
          ID: params.vendorId,
          VendorNo: params.vendorNo,
          Name: params.name,
          Phone: params.phone,
          TaxID: params.taxID,
          FullAddress: params.fullAddress,
          AccountBank: params.accountBank,
          BankName: params.bankName,
          BankAdress: params.bankAdress,
          BankAcountName: params.bankAcountName,
          BankOfAddress: params.bankOfAddress,
        },
      },
    ]);

    return response.data.table as ws_L_Vendor_Save[];
  } catch (error) {
    const message = getErrorMessage(error);
    console.error("Error in ws_L_Vendor_Save_Async:", message);
    return [];
  }
}

export async function ws_L_Vendor_Delete_Async(
  vendorId?: string,
): Promise<string> {
  try {
    const currentUser = await getUserSession();
    const response = await httpService.post("/DataAccess", [
      {
        category: "QAHosGenericDB",
        command: "ws_L_Vendor_Delete",
        parameters: {
          FacID: currentUser.facId,
          Id: vendorId,
        },
      },
    ]);

    return response.data.table[0].result.toString();
  } catch (error) {
    const message = getErrorMessage(error);
    console.error("Error in ws_L_Vendor_Delete_Async:", message);
    return message;
  }
}
