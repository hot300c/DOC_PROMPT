import { exportToExcel, TableConfig } from "@/app/lib/utils/exportToExcel ";
import { L_Vendor } from "../definitions/nha-cung-cap.response";

export const exportDetailData = async (data: L_Vendor[]) => {
  const tableConfig: TableConfig = {
    columns: {
      Mã: { width: 30, alignment: "center" },
      Tên: { width: 40, alignment: "center" },
      MST: { width: 40, alignment: "left" },
      "Kho liên quan": { width: 100, alignment: "left" },
      SDT: { width: 20, alignment: "left" },
      "Địa chỉ": { width: 70, alignment: "left" },
      "Ngân hàng": { width: 50, alignment: "left" },
      "Số TK": { width: 20, alignment: "left" },
      Loại: { width: 30, alignment: "left" },
    },
    data:
      data && data.length > 0
        ? data.map((row) => [
            row.vendorNo,
            row.supplierName,
            row.taxID,
            row.khoLienQuan,
            row.phone,
            row.fullAddress,
            row.bankName,
            row.accountBank,
            row.type,
          ])
        : [],
    sheetName: "danh-sach-nha-cung-cap",
    fileName: "danh-sach-nha-cung-cap.xlsx",
  };
  await exportToExcel(tableConfig);
};
