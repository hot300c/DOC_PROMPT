export type ws_L_Vendor_Save_Params = {
  vendorId: string;
  vendorNo: string;
  name: string;
  phone: string;
  taxID: string;
  fullAddress: string;
  accountBank: string;
  bankName: string;
  bankAdress: string;
  bankAcountName: string;
  bankOfAddress: string;
};

export type ws_StoctVendorPermissions_Save_Params = {
  vendorId: string;
  stockIDs: string[];
};
