export type L_Vendor = {
  id: number;
  vendorNo: string;
  supplierName: string;
  phone: string;
  taxID: string;
  bankName: string;
  fullAddress: string;
  accountBank: string;
  bankAdress: string;
  bankAcountName: string;
  khoLienQuan: string;
  stocksID: string;
  type: string;
};

export type L_InventoryStock = {
  stockID: number;
  name: string;
  roomID: number;
  roomName: string;
};

export type NhaCungCapResponse = {
  l_Vendor: L_Vendor[];
  l_InventoryStock: L_InventoryStock[];
};

export type L_Vendor_By_ID = {
  id: number;
  facID: string;
  vendorNo: string;
  name: string;
  phone: string;
  taxID: string;
  street?: string;
  wardID?: number;
  districtID?: number;
  provinceID?: number;
  countryID?: number;
  bankName: string;
  fullAddress: string;
  accountBank: string;
  bankAdress: string;
  bankAcountName: string;
  createdBy: string;
  createdOn: string;
  modifiedBy: string;
  modifiedOn: string;
  bankOfAddress: string;
  customerID: number;
};

export type StockVendorPermissons_GetByVendorID = {
  stockID?: string;
};

export type NhaCungCapChiTiet = {
  l_Vendor_By_ID: L_Vendor_By_ID[];
  l_StockVendorPermissons_GetByVendorID: StockVendorPermissons_GetByVendorID[];
};

export type ws_L_Vendor_Save = {
  vendorID: number;
};
