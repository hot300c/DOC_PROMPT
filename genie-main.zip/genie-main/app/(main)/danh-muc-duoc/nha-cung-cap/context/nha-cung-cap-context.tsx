"use client";
import { createContext, useContext, useState } from "react";
import {
  L_Vendor,
  L_Vendor_By_ID,
} from "../_utils/definitions/nha-cung-cap.response";
import { NhaCungCapFormValues } from "../_utils/schemas/nha-cung-cap-schema";

type FormValuesWithNCC = NhaCungCapFormValues & {
  selectedNcc?: L_Vendor_By_ID;
};

type NhaCungCapContextType = {
  selectedRow: L_Vendor | null;
  setSelectedRow: (row: L_Vendor | null) => void;
  formValues: FormValuesWithNCC | null;
  setFormValues: (values: FormValuesWithNCC | null) => void;
};

const NhaCungCapContext = createContext<NhaCungCapContextType | undefined>(
  undefined,
);

export const useNhaCungCap = () => {
  const context = useContext(NhaCungCapContext);
  if (!context) {
    throw new Error(
      "useNhaCungCap must be used within a NhaCungCapGoiProvider",
    );
  }
  return context;
};

export const NhaCungCapGoiProvider: React.FC<{
  children: React.ReactNode;
}> = ({ children }) => {
  const [selectedRow, setSelectedRow] = useState<L_Vendor | null>(null);
  const [formValues, setFormValues] = useState<FormValuesWithNCC | null>(null);

  return (
    <NhaCungCapContext.Provider
      value={{
        selectedRow,
        setSelectedRow,
        formValues,
        setFormValues,
      }}
    >
      {children}
    </NhaCungCapContext.Provider>
  );
};
