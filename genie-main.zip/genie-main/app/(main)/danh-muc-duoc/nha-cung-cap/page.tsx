import NhaCungCapContainer from "./_components/nha-cung-cap-container";
import NhaCungCapHeader from "./_components/nha-cung-cap-header";
import { NhaCungCapFormValues } from "./_utils/schemas/nha-cung-cap-schema";
import { NhaCungCapGoiProvider } from "./context/nha-cung-cap-context";

export default async function Page(props: {
  searchParams?: Promise<NhaCungCapFormValues>;
}) {
  const searchParams = await props.searchParams;

  return (
    <NhaCungCapGoiProvider>
      <div className="flex flex-col overflow-y-hidden w-full h-full space-y-2">
        <NhaCungCapHeader />
        <NhaCungCapContainer searchParams={searchParams} />
      </div>
    </NhaCungCapGoiProvider>
  );
}
