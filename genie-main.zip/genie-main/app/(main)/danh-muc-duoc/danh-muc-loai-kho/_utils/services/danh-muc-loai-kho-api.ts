import { getUserSession } from "@/actions/get-user-session";
import * as httpService from "@/app/lib/network/http";
import { StockTypeInfo } from "../definitions/danh-muc-loai-kho.dto";

export const ws_L_INV_StockType_Get = async (): Promise<StockTypeInfo[]> => {
  try {
    const { customerId } = await getUserSession();
    const response = await httpService.post("/DataAccess", [
      {
        category: "QAHosGenericDB",
        command: "ws_L_INV_StockType_Get",
        parameters: {
          CustomerID: customerId,
        },
      },
    ]);
    return response.data.table;
  } catch (err) {
    return [];
  }
};
type StockTypeSaveREQ = {
  stockType: string;
  stockTypeName: string;
  description: string;
  isActive: boolean;
};

export const ws_L_INV_StockType_Save = async (req: StockTypeSaveREQ) => {
  const { customerId } = await getUserSession();
  await httpService.post("/DataAccess", [
    {
      category: "QAHosGenericDB",
      command: "ws_L_INV_StockType_Save",
      parameters: {
        CustomerID: customerId,
        StockType: req.stockType,
        StockTypeName: req.stockTypeName,
        Description: req.description,
        IsActive: req.isActive,
      },
    },
  ]);
};
