"use client";
import { z } from "zod";

export const StockTypeSchema = z.object({
  stockType: z.string(),
  stockTypeName: z.string(),
  description: z.string().optional(),
  isUsing: z.boolean(),
});
export type StockTypeFormData = z.infer<typeof StockTypeSchema>;
