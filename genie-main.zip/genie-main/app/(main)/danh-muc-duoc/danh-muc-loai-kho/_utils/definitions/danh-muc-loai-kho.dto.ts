export type StockTypeInfo = {
  stockType: string;
  customerID: string;
  stockTypeName: string;
  description: string;
  createdBy: string;
  createdOn: string;
  modifiedBy: string;
  modifiedOn: string | null;
  isActive: boolean;
};
