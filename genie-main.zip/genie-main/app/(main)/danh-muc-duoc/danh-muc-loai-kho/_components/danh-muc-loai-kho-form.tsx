"use client";

import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
} from "@/components/ui/form";

import { useFeedbackDialog } from "@/app/lib/feedback-dialog-provider";
import { notifySuccess } from "@/app/lib/utils";
import { getErrorMessage } from "@/app/lib/utils/errorUtils";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { zodResolver } from "@hookform/resolvers/zod";
import { useRouter } from "next/navigation";
import { useEffect, useMemo } from "react";
import { useForm } from "react-hook-form";
import { StockTypeInfo } from "../_utils/definitions/danh-muc-loai-kho.dto";
import { StockTypeFormData, StockTypeSchema } from "../_utils/schema";
import { ws_L_INV_StockType_Save } from "../_utils/services/danh-muc-loai-kho-api";

type DanhMucLoaiKhoFormProps = {
  onSave: (value: StockTypeFormData) => void;
  selectedStockType: StockTypeInfo | undefined;
  setSelectedStockType: (stockType: StockTypeInfo) => void;
};

export default function DanhMucLoaiKhoForm({
  onSave,
  selectedStockType,
  setSelectedStockType,
}: DanhMucLoaiKhoFormProps) {
  const { alert } = useFeedbackDialog();
  const router = useRouter();
  const defaultValues = useMemo(() => {
    return {
      stockType: selectedStockType?.stockType.toString(),
      stockTypeName: selectedStockType?.stockTypeName,
      description: selectedStockType?.description ?? "",
      isUsing: selectedStockType?.isActive ?? false,
    } as StockTypeFormData;
  }, [
    selectedStockType?.description,
    selectedStockType?.isActive,
    selectedStockType?.stockType,
    selectedStockType?.stockTypeName,
  ]);
  const form = useForm<StockTypeFormData>({
    resolver: zodResolver(StockTypeSchema),
    defaultValues: defaultValues,
  });

  useEffect(() => {
    form.reset(defaultValues);
  }, [defaultValues, form]);

  const onSubmit = async (value: StockTypeFormData) => {
    if (!value.stockTypeName) {
      await alert({
        title: "Cảnh báo",
        content: "Chưa nhập tên loại kho",
      });
      return;
    }
    try {
      await ws_L_INV_StockType_Save({
        description: value.description ?? "",
        isActive: value.isUsing,
        stockType: value.stockType,
        stockTypeName: value.stockTypeName,
      });
      notifySuccess("Lưu thành công");
      router.refresh();
    } catch (error) {
      await alert({
        title: "Lỗi",
        content: getErrorMessage(error),
      });
    }
  };
  const onAddNew = () => {
    form.reset({
      stockType: "0",
      stockTypeName: "",
      description: "",
      isUsing: false,
    });
  };
  return (
    <Form {...form}>
      <form
        className="bg-gray-100 p-2 rounded-lg m-1 flex flex-row space-x-4"
        onSubmit={form.handleSubmit(onSubmit)}
      >
        <FormField
          control={form.control}
          name="stockTypeName"
          render={({ field }) => (
            <FormItem className="flex items-center w-full sm:w-auto ">
              <FormLabel className="text-sm font-medium whitespace-nowrap w-26 mt-2 pr-2">
                Tên loại kho
              </FormLabel>
              <FormControl>
                <Input
                  className="w-70"
                  value={field.value}
                  onChange={(value) => {
                    field.onChange(value);
                  }}
                />
              </FormControl>
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="description"
          render={({ field }) => (
            <FormItem className="flex items-center w-full sm:w-auto">
              <FormLabel className="text-sm font-medium w-20 mt-2">
                Mô tả
              </FormLabel>
              <FormControl>
                <Input
                  className="w-70"
                  value={field.value || ""}
                  onChange={(value) => {
                    field.onChange(value);
                  }}
                />
              </FormControl>
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="isUsing"
          render={({ field }) => (
            <FormItem className="flex items-center w-full sm:w-auto space-x-2">
              <FormControl>
                <Checkbox
                  className="mt-2"
                  checked={field.value}
                  onCheckedChange={(value) => field.onChange(value === true)}
                />
              </FormControl>
              <Label className="text-sm font-medium w-32 mt-2">
                Đang sử dụng
              </Label>
            </FormItem>
          )}
        />
        <div className="flex items-center justify-end bg-muted w-full mt-2">
          <div className="flex gap-2">
            <Button variant="default" type="button" onClick={onAddNew}>
              Thêm Mới
            </Button>
            <Button variant="default" type="submit">
              Lưu
            </Button>
          </div>
        </div>
      </form>
    </Form>
  );
}
