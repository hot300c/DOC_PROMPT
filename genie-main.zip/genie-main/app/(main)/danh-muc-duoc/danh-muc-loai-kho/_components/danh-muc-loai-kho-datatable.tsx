"use client";
import {
  CheckboxCell,
  DataTable,
  DataTableColumnHeaderSort,
} from "@/components/ui/dataTable";
import { ColumnDef } from "@tanstack/react-table";
import { useMemo } from "react";
import { StockTypeInfo } from "../_utils/definitions/danh-muc-loai-kho.dto";

export interface DanhMucLoaiKhoDataTableProps {
  data: StockTypeInfo[];
  selectedStockType: StockTypeInfo | undefined;
  setSelectedStockType: (stockType: StockTypeInfo) => void;
}

const columns: ColumnDef<StockTypeInfo>[] = [
  {
    id: "stockType",
    accessorKey: "stockType",
    header: ({ column }) => (
      <DataTableColumnHeaderSort
        column={column}
        title="Mã loại kho"
        className="justify-start"
      />
    ),
    enableSorting: true,
  },
  {
    id: "stockTypeName",
    accessorKey: "stockTypeName",
    header: ({ column }) => (
      <DataTableColumnHeaderSort
        column={column}
        title="Tên loại kho"
        className="justify-start"
      />
    ),
    enableSorting: true,
  },
  {
    id: "description",
    accessorKey: "description",
    header: ({ column }) => (
      <DataTableColumnHeaderSort
        column={column}
        title="Mô tả"
        className="justify-start"
      />
    ),
    enableSorting: true,
  },
  {
    id: "isActive",
    accessorKey: "isActive",
    header: ({ column }) => (
      <DataTableColumnHeaderSort
        column={column}
        title="Đang sử dụng"
        className="justify-start"
      />
    ),
    cell: ({ row, getValue, column, table }) => (
      <CheckboxCell
        columnId={column.id}
        getValue={getValue}
        table={table}
        rowIndex={row.index}
      />
    ),
    enableSorting: true,
  },
];

const DanhMucLoaiKhoDataTable: React.FC<DanhMucLoaiKhoDataTableProps> = ({
  data,
  selectedStockType,
  setSelectedStockType,
}) => {
  const indexScrollTo = useMemo(
    () =>
      selectedStockType
        ? data.findIndex((row) => row.stockType == selectedStockType.stockType)
        : 0,
    [selectedStockType, data],
  );
  return (
    <div className="flex-1 flex flex-col h-full w-full">
      <DataTable
        className="w-full overflow-y-auto border"
        columns={columns}
        data={data}
        columnVisibilityInit={{ search: false }}
        enableColumnFilter={true}
        enablePaging={false}
        isSelectRowWhenUseArrowKey
        onRowClick={(row) => {
          setSelectedStockType(row);
        }}
        indexScrollTo={indexScrollTo}
      />
    </div>
  );
};

export default DanhMucLoaiKhoDataTable;
