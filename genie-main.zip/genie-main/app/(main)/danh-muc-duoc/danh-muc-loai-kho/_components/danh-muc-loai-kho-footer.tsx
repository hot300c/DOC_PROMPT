"use client";
import { Button } from "@/components/ui/button";

export function DanhMucLoaiKhoFooter() {
  return (
    <div className="flex items-center justify-end bg-muted p-2 w-full">
      <div className="flex gap-2">
        <Button variant="default">Thêm Mới</Button>
        <Button variant="default">Lưu</Button>
      </div>
    </div>
  );
}
