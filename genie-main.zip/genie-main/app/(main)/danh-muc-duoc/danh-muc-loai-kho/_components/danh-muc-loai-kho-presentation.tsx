"use client";

import { useState } from "react";
import { StockTypeInfo } from "../_utils/definitions/danh-muc-loai-kho.dto";
import DanhMucLoaiKhoDataTable from "./danh-muc-loai-kho-datatable";
import DanhMucLoaiKhoForm from "./danh-muc-loai-kho-form";

type DanhMucLoaiKhoPresentationProps = {
  data: StockTypeInfo[];
};
const DanhMucLoaiKhoPresentation = ({
  data,
}: DanhMucLoaiKhoPresentationProps) => {
  const [selectedStockType, setSelectedStockType] = useState<
    StockTypeInfo | undefined
  >(data[0]);

  const handleSave = () => {};

  return (
    <div className="flex flex-col h-full">
      <DanhMucLoaiKhoDataTable
        data={data}
        selectedStockType={selectedStockType}
        setSelectedStockType={setSelectedStockType}
      />
      <DanhMucLoaiKhoForm
        onSave={handleSave}
        selectedStockType={selectedStockType}
        setSelectedStockType={setSelectedStockType}
      />
      {/* <DanhMucLoaiKhoFooter /> */}
    </div>
  );
};
export default DanhMucLoaiKhoPresentation;
