import { ws_L_INV_StockType_Get } from "../_utils/services/danh-muc-loai-kho-api";
import DanhMucLoaiKhoPresentation from "./danh-muc-loai-kho-presentation";

const DanhMucLoaiKhoContainer = async () => {
  const data = await ws_L_INV_StockType_Get();
  return <DanhMucLoaiKhoPresentation data={data} />;
};

export default DanhMucLoaiKhoContainer;
