"use client";

import FacilityInfo from "@/components/facilityInfo";

const DanhMucLoaiKhoHeader = () => {
  return <FacilityInfo page={"DANH MỤC - DƯỢC | DANH MỤC LOẠI KHO"} />;
};

export default DanhMucLoaiKhoHeader;
