import DanhMucLoaiKhoContainer from "./_components/danh-muc-loai-kho-container";
import DanhMucLoaiKhoHeader from "./_components/danh-muc-loai-kho-header";

export default async function Page() {
  return (
    <div className="flex flex-col w-full h-full overflow-hidden">
      <DanhMucLoaiKhoHeader />
      <DanhMucLoaiKhoContainer />
    </div>
  );
}
