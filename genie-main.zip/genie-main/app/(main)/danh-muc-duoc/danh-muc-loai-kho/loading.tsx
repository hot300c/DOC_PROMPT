export { Loading as default } from "../../duoc/(base_components)/loading";
