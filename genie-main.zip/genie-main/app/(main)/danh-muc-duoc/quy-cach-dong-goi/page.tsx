import QuyCachDongGoiContainer from "./_components/quy-cach-dong-goi-container";
import QuyCachDongGoiHeader from "./_components/quy-cach-dong-goi-header";
import { QuyCachDongGoiFormValues } from "./_utils/schemas/quy-cach-dong-goi-schema";
import { QuyCachDongGoiProvider } from "./context/quy-cach-dong-goi-context";

export default async function Page(props: {
  searchParams?: Promise<QuyCachDongGoiFormValues>;
}) {
  const searchParams = await props.searchParams;

  return (
    <QuyCachDongGoiProvider>
      <div className="flex flex-col overflow-y-hidden w-full h-full space-y-2">
        <QuyCachDongGoiHeader />
        <QuyCachDongGoiContainer searchParams={searchParams} />
      </div>
    </QuyCachDongGoiProvider>
  );
}
