"use client";

import FacilityInfo from "@/components/facilityInfo";

export default function QuyCachDongGoiHeader() {
  return <FacilityInfo page={"DANH MỤC | QUY CÁCH ĐÓNG GÓI"} />;
}
