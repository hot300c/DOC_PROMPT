"use client";
import { compareInclude } from "@/app/lib/utils";
import { Checkbox } from "@/components/ui/checkbox";
import {
  DataTable,
  DataTableColumnHeaderSort,
} from "@/components/ui/dataTable";
import { ColumnDef, Row } from "@tanstack/react-table";
import { useEffect, useMemo } from "react";
import { INV_QuyCachDongGoi } from "../_utils/definitions/quy-cach-dong-goi.response";
import { useQuyCachDongGoi } from "../context/quy-cach-dong-goi-context";

const globalFilterFn = (
  row: Row<INV_QuyCachDongGoi>,
  columnId: string,
  filterValue: string,
) => {
  if (
    columnId === "hospitalCode" ||
    columnId === "hospitalName" ||
    columnId === "productID"
  ) {
    const originalValue = String(
      row.original[columnId as keyof INV_QuyCachDongGoi],
    );
    return compareInclude(filterValue, originalValue);
  }
  return false;
};

export type QuyCachDongGoiTableProps = {
  inv_QuyCachDongGois: INV_QuyCachDongGoi[];
};
const QuyCachDongGoiTable = ({
  inv_QuyCachDongGois,
}: QuyCachDongGoiTableProps) => {
  const { selectedRow, setSelectedRow } = useQuyCachDongGoi();

  useEffect(() => {
    if (inv_QuyCachDongGois && inv_QuyCachDongGois.length > 0) {
      setSelectedRow(inv_QuyCachDongGois[0] ?? null);
    }
  }, [inv_QuyCachDongGois, setSelectedRow]);

  const indexScrollTo = useMemo(
    () =>
      selectedRow
        ? inv_QuyCachDongGois.findIndex(
            (row) => row.productID == selectedRow?.productID,
          )
        : 0,
    [selectedRow, inv_QuyCachDongGois],
  );

  const columns = useMemo(() => {
    const result: ColumnDef<INV_QuyCachDongGoi>[] = [
      {
        id: "stt",
        accessorKey: "stt",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="STT"
            className="justify-start"
          />
        ),
        filterFn: "includesString",
        enableSorting: true,
      },
      {
        id: "hospitalCode",
        accessorKey: "hospitalCode",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Mã sản phẩm"
            className="justify-start"
          />
        ),
        filterFn: "includesString",
      },
      {
        id: "hospitalName",
        accessorKey: "hospitalName",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Tên sản phẩm"
            className="justify-start w-60"
          />
        ),
        filterFn: "includesString",
        enableSorting: true,
      },
      {
        id: "unitName",
        accessorKey: "unitName",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Đơn vị tính"
            className="justify-start w-40"
          />
        ),
        enableSorting: true,
      },
      {
        id: "heSoNCC",
        accessorKey: "heSoNCC",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Quy cách NCC (ĐVT / ĐV Đóng gói)"
            className="justify-start"
          />
        ),
        filterFn: "includesString",
        enableSorting: true,
      },
      {
        id: "heSo",
        accessorKey: "heSo",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Quy cách (ĐVT / ĐV Đóng gói)"
            className="justify-start"
          />
        ),
        filterFn: "includesString",
        enableSorting: true,
      },
      {
        id: "theo_HeSoNCC",
        accessorKey: "theo_HeSoNCC",
        enableColumnFilter: true,
        filterFn: (row, columnId, filterValue) => {
          const isChecked = row.original.theo_HeSoNCC;

          if (!filterValue || filterValue === "") {
            return true;
          }

          const normalized = String(filterValue).toLowerCase();

          if (normalized === "checked" || normalized === "true") {
            return isChecked === true;
          }

          if (normalized === "unchecked" || normalized === "false") {
            return isChecked === false;
          }

          return false;
        },
        meta: {
          enableColumnFilterDropdown: true,
        },
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Ưu tiên Quy cách NCC"
            className="justify-start"
          />
        ),
        cell: ({ row }) => <Checkbox checked={row.original.theo_HeSoNCC} />,
        accessorFn: (row) => (row.theo_HeSoNCC ? "Checked" : "Unchecked"),
        enableSorting: true,
      },
      {
        id: "coSoDongGoi",
        accessorKey: "coSoDongGoi",
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Cơ số đóng gói"
            className="justify-start"
          />
        ),
        filterFn: "includesString",
        enableSorting: true,
      },
      {
        id: "unActived",
        accessorKey: "unActived",
        enableColumnFilter: true,
        filterFn: (row, columnId, filterValue) => {
          const isChecked = row.original.unActived;

          if (!filterValue || filterValue === "") {
            return true;
          }

          const normalized = String(filterValue).toLowerCase();

          if (normalized === "checked" || normalized === "true") {
            return isChecked === true;
          }

          if (normalized === "unchecked" || normalized === "false") {
            return isChecked === false;
          }

          return false;
        },
        meta: {
          enableColumnFilterDropdown: true,
        },
        header: ({ column }) => (
          <DataTableColumnHeaderSort
            column={column}
            title="Không sử dụng"
            className="justify-start"
          />
        ),
        cell: ({ row }) => <Checkbox checked={row.original.unActived} />,
        accessorFn: (row) => (row.unActived ? "Checked" : "Unchecked"),
        enableSorting: true,
      },
    ];
    return result;
  }, []);

  return (
    <div className="flex-1 flex flex-col w-full h-full">
      <DataTable
        className="w-full overflow-auto border"
        tHeadClass="z-40"
        tRowClass="cursor-pointer"
        data={inv_QuyCachDongGois}
        columns={columns}
        enableFooter={true}
        enablePaging={true}
        enableColumnFilter={true}
        enableGlobalFilter={true}
        globalFilterFn={globalFilterFn}
        placeholderSearch="Nhập để tìm kiếm..."
        onRowClick={(row) => {
          setSelectedRow(row);
        }}
        indexScrollTo={indexScrollTo}
      />
    </div>
  );
};

export default QuyCachDongGoiTable;
