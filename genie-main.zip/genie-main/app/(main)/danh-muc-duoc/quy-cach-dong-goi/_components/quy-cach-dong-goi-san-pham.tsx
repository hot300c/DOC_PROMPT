"use client";

import { VirtualTableSelect } from "@/components/select/virtual-table-select/virtual-table-select";
import { Checkbox } from "@/components/ui/checkbox";
import { DataTableColumnHeaderSort } from "@/components/ui/dataTable";
import { Form, FormField } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { zodResolver } from "@hookform/resolvers/zod";
import { ColumnDef } from "@tanstack/react-table";
import { useEffect } from "react";
import { useForm } from "react-hook-form";
import { L_Product } from "../_utils/definitions/quy-cach-dong-goi.response";
import {
  QuyCachDongGoiFormSchema,
  QuyCachDongGoiFormValues,
} from "../_utils/schemas/quy-cach-dong-goi-schema";
import { useQuyCachDongGoi } from "../context/quy-cach-dong-goi-context";

export type QuyCachDongGoiTabProps = {
  l_Products: L_Product[];
};

export const QuyCachDongGoiChiTiet = ({
  l_Products,
}: QuyCachDongGoiTabProps) => {
  const { selectedRow, setFormValues } = useQuyCachDongGoi();
  const form = useForm<QuyCachDongGoiFormValues>({
    resolver: zodResolver(QuyCachDongGoiFormSchema),
    defaultValues: {
      hospitalName: "",
      heSoNCC: 0,
      heSo: 0,
      coSoDongGoi: 1,
      theo_HeSoNCC: false,
      unActived: false,
    },
  });

  useEffect(() => {
    const subscription = form.watch((values) => {
      const selectedProduct = l_Products.find(
        (product) => product.hospitalName === values.hospitalName,
      );
      setFormValues({
        hospitalName: values.hospitalName || "",
        heSoNCC: values.heSoNCC || 0,
        heSo: values.heSo || 0,
        coSoDongGoi: values.coSoDongGoi || 1,
        theo_HeSoNCC: values.theo_HeSoNCC || false,
        unActived: values.unActived || false,
        selectedProduct,
      });
    });
    return () => subscription.unsubscribe();
  }, [form, setFormValues, l_Products]);

  useEffect(() => {
    if (selectedRow) {
      form.reset({
        hospitalName: selectedRow.hospitalName || "",
        heSoNCC: selectedRow.heSoNCC || 0,
        heSo: selectedRow.heSo || 0,
        coSoDongGoi: selectedRow.coSoDongGoi || 1,
        theo_HeSoNCC: selectedRow.theo_HeSoNCC || false,
        unActived: selectedRow.unActived || false,
      });
    } else {
      form.reset({
        hospitalName: "",
        heSoNCC: 0,
        heSo: 0,
        coSoDongGoi: 1,
        theo_HeSoNCC: false,
        unActived: false,
      });
    }
  }, [selectedRow, form]);
  const COLUMN_DEFINITION_SAN_PHAM: ColumnDef<L_Product>[] = [
    {
      id: "hospitalCode",
      accessorKey: "hospitalCode",
      header: ({ column }) => (
        <DataTableColumnHeaderSort column={column} title="Mã" />
      ),
    },
    {
      id: "hospitalName",
      accessorKey: "hospitalName",
      header: ({ column }) => (
        <DataTableColumnHeaderSort column={column} title="Tên" />
      ),
    },
    {
      id: "unitName",
      accessorKey: "unitName",
      header: ({ column }) => (
        <DataTableColumnHeaderSort column={column} title="Đơn vị" />
      ),
    },
  ];

  return (
    <div className="px-4">
      <Form {...form}>
        <form className="flex flex-col w-full">
          <div className="flex-1 flex min-h-0 gap-2">
            <div className="w-1/2 space-y-3">
              <div className="flex items-center gap-2">
                <Label className="whitespace-nowrap w-24">Sản phẩm</Label>
                <FormField
                  control={form.control}
                  name="hospitalName"
                  render={({ field }) => {
                    const selectedProduct = l_Products.find(
                      (product) => product.hospitalName === field.value,
                    );
                    return (
                      <VirtualTableSelect
                        placeholderSearch="Nhập sản phẩm"
                        placeholder="--Chọn tên sản phẩm--"
                        className="flex-1"
                        classNamePopover="min-w-[960px]"
                        data={l_Products}
                        value={selectedProduct || null}
                        labelKey="hospitalName"
                        valueKey="productID"
                        disabled={!!selectedRow}
                        onChange={(value) => {
                          field.onChange(value?.hospitalName || "");
                        }}
                        columns={COLUMN_DEFINITION_SAN_PHAM}
                        alignPopover="start"
                      />
                    );
                  }}
                />
              </div>

              <div className="flex items-center gap-2">
                <Label className="whitespace-nowrap w-24">Quy cách NCC</Label>
                <FormField
                  control={form.control}
                  name="heSoNCC"
                  render={({ field }) => (
                    <Input
                      {...field}
                      type="number"
                      placeholder="0"
                      className="flex-1"
                      value={field.value}
                      onChange={(e) => field.onChange(Number(e.target.value))}
                    />
                  )}
                />
                <span className="text-sm text-gray-500">
                  (ĐVT / Đv Đóng gói)
                </span>
              </div>

              <div className="flex items-center gap-2">
                <Label className="whitespace-nowrap w-24">Quy cách</Label>
                <FormField
                  control={form.control}
                  name="heSo"
                  render={({ field }) => (
                    <Input
                      {...field}
                      type="number"
                      placeholder="0"
                      className="flex-1"
                      value={field.value}
                      onChange={(e) => field.onChange(Number(e.target.value))}
                    />
                  )}
                />
                <span className="text-sm text-gray-500">
                  (ĐVT / Đv Đóng gói)
                </span>
              </div>

              <div className="flex items-center gap-2">
                <Label className="whitespace-nowrap w-24">Cơ số đóng gói</Label>
                <FormField
                  control={form.control}
                  name="coSoDongGoi"
                  render={({ field }) => (
                    <Input
                      {...field}
                      type="number"
                      placeholder="1"
                      className="flex-1"
                      value={field.value || 1}
                      onChange={(e) => field.onChange(Number(e.target.value))}
                    />
                  )}
                />
              </div>

              <div className="flex items-center gap-4 mt-4">
                <FormField
                  control={form.control}
                  name="theo_HeSoNCC"
                  render={({ field }) => (
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="theo_HeSoNCC"
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                      <Label
                        htmlFor="theo_HeSoNCC"
                        className="text-sm font-normal cursor-pointer"
                      >
                        Ưu tiên Quy cách NCC
                      </Label>
                    </div>
                  )}
                />

                <FormField
                  control={form.control}
                  name="unActived"
                  render={({ field }) => (
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="unActived"
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                      <Label
                        htmlFor="unActived"
                        className="text-sm font-normal cursor-pointer"
                      >
                        Không sử dụng
                      </Label>
                    </div>
                  )}
                />
              </div>
            </div>
          </div>
        </form>
      </Form>
    </div>
  );
};
