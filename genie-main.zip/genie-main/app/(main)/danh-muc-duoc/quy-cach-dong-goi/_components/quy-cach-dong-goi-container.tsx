import { QuyCachDongGoiFormValues } from "../_utils/schemas/quy-cach-dong-goi-schema";
import { quyCachDongGoiAsync } from "../_utils/services/quy-cach-dong-goi.api";
import QuyCachDongGoiPresentation from "./quy-cach-dong-goi-presentation";

export type QuyCachDongGoiContainerProps = {
  searchParams?: QuyCachDongGoiFormValues;
};

const QuyCachDongGoiContainer = async ({
  searchParams,
}: QuyCachDongGoiContainerProps) => {
  const quyCachDongGoi = await quyCachDongGoiAsync();
  return (
    <QuyCachDongGoiPresentation
      quyCachDongGoi={quyCachDongGoi}
      searchParams={searchParams}
    />
  );
};

export default QuyCachDongGoiContainer;
