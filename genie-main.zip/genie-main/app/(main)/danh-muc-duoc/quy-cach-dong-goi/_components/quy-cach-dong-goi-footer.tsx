import { useFeedbackDialog } from "@/app/lib/feedback-dialog-provider";
import useLoading from "@/components/loading";
import { Button } from "@/components/ui/button";
import { useRouter } from "next/navigation";
import {
  ws_INV_QuyCachDongGoi_DeleteByProductID_Async,
  ws_INV_QuyCachDongGoi_Save_Async,
} from "../_utils/services/quy-cach-dong-goi.api";
import { useQuyCachDongGoi } from "../context/quy-cach-dong-goi-context";
export type QuyCachDongGoiFooterProps = {};

const QuyCachDongGoiFooter = ({}: QuyCachDongGoiFooterProps) => {
  const { setSelectedRow, selectedRow, formValues } = useQuyCachDongGoi();
  const { alert } = useFeedbackDialog();
  const { showLoading, hideLoading } = useLoading();
  const router = useRouter();

  const handleSave = async () => {
    try {
      const loadingId = showLoading("Đang lưu...");
      if (!formValues?.selectedProduct) {
        hideLoading(loadingId);
        await alert({
          title: "Lỗi",
          content: "Vui lòng chọn sản phẩm!",
        });
        return;
      }

      if (selectedRow && !formValues?.heSoNCC && !formValues?.heSo) {
        hideLoading(loadingId);
        await alert({
          title: "Lỗi",
          content: "Vui lòng nhập Quy cách NCC > 0 hoặc Quy cách > 0",
        });
        return;
      }

      const saveParams = {
        productID: formValues.selectedProduct.productID,
        heSoNCC: formValues.heSoNCC || 0,
        heSo: formValues.heSo || 0,
        theo_HeSoNCC: formValues.theo_HeSoNCC || false,
        coSoDongGoi: (formValues.coSoDongGoi || 1).toString(),
        isActive: !formValues.unActived,
        isThemMoi: !!selectedRow ? "0" : "1", // "1" nếu là thêm mới, "0" nếu là cập nhật
      };
      console.log("Saving with params:", saveParams);
      const result = await ws_INV_QuyCachDongGoi_Save_Async(saveParams);
      hideLoading(loadingId);

      if (result && result.length > 0) {
        await alert({
          title: "Cảnh báo",
          content: result[0]?.resultMessage,
        });
        router.refresh();
      }
    } catch (error) {
      console.error("Error saving:", error);
      await alert({
        title: "Lỗi",
        content: "Có lỗi xảy ra khi lưu!",
      });
    }
  };

  const handleDeleteProduct = async () => {
    const loadingId = showLoading("Đang xóa...");
    const success = await ws_INV_QuyCachDongGoi_DeleteByProductID_Async(
      selectedRow?.productID,
    );
    hideLoading(loadingId);
    if (success) {
      await alert({
        title: "Cảnh báo",
        content: "Đã xóa, vui lòng kiểm tra lại !!!",
      });
      router.refresh();
    }
  };

  return (
    <div className="flex w-full p-2 bg-muted">
      <div className="flex items-end justify-end space-x-2 w-full">
        <div className="ml-auto flex space-x-2">
          <Button onClick={() => setSelectedRow(null)}>Thêm mới</Button>
          <Button onClick={handleSave}>Lưu</Button>
          <Button onClick={handleDeleteProduct}>Xóa</Button>
        </div>
      </div>
    </div>
  );
};

export default QuyCachDongGoiFooter;
