"use client";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { QuyCachDongGoiResponse } from "../_utils/definitions/quy-cach-dong-goi.response";
import { QuyCachDongGoiFormValues } from "../_utils/schemas/quy-cach-dong-goi-schema";
import QuyCachDongGoiFooter from "./quy-cach-dong-goi-footer";
import { QuyCachDongGoiChiTiet } from "./quy-cach-dong-goi-san-pham";
import QuyCachDongGoiTable from "./quy-cach-dong-goi-table";
export type QuyCachDongGoiPresentationProps = {
  quyCachDongGoi: QuyCachDongGoiResponse | undefined;
  searchParams?: QuyCachDongGoiFormValues;
};
const QuyCachDongGoiPresentation = ({
  quyCachDongGoi,
  searchParams,
}: QuyCachDongGoiPresentationProps) => {
  return (
    <div className="flex flex-col flex-1 w-full h-full overflow-y-hidden">
      <div className="flex-[2] overflow-hidden">
        <QuyCachDongGoiTable
          inv_QuyCachDongGois={quyCachDongGoi?.inv_QuyCachDongGoi ?? []}
        />
      </div>
      <div className="flex-[1] flex overflow-hidden min-h-0 bg-gray-100">
        <Tabs
          defaultValue="san-pham"
          className="flex flex-col items-start border overflow-hidden w-full h-full"
        >
          <TabsList>
            <TabsTrigger value="san-pham">Sản phẩm</TabsTrigger>
          </TabsList>
          <div className="flex-1 min-h-0 w-full overflow-hidden">
            <TabsContent value="san-pham" className="h-full">
              <QuyCachDongGoiChiTiet
                l_Products={quyCachDongGoi?.l_Product ?? []}
              />
            </TabsContent>
          </div>
        </Tabs>
      </div>
      <QuyCachDongGoiFooter />
    </div>
  );
};

export default QuyCachDongGoiPresentation;
