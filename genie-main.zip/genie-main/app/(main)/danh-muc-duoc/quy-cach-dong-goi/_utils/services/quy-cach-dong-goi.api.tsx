import { getUserSession } from "@/actions/get-user-session";
import { SequenceRequest } from "@/app/lib/definitions/setting";
import * as httpService from "@/app/lib/network/http";
import { executeTransaction } from "@/app/lib/services/system";
import { getErrorMessage } from "@/app/lib/utils/errorUtils";
import {
  IS_SP_KEM,
  PRODUCT_TYPE_VACCINE_ID,
} from "../constants/quy-cach-dong-goi.constant";
import { ws_INV_QuyCachDongGoi_Save_Params } from "../definitions/quy-cach-dong-goi.request";
import {
  INV_QuyCachDongGoi_Save,
  QuyCachDongGoiResponse,
} from "../definitions/quy-cach-dong-goi.response";

export const quyCachDongGoiAsync = async (): Promise<
  QuyCachDongGoiResponse | undefined
> => {
  const requests = [] as SequenceRequest[];
  const currentUser = await getUserSession();
  try {
    const facId = currentUser.facId;

    requests.push({
      category: "QAHosGenericDB",
      command: "ws_INV_QuyCachDongGoi_List",
      parameters: {
        FacID: facId,
      },
    });
    requests.push({
      category: "QAHosGenericDB",
      command: "ws_L_Product_List_ByLoaiProduct",
      parameters: {
        FacID: facId,
        ProductTypeID: PRODUCT_TYPE_VACCINE_ID,
        IsSPKem: IS_SP_KEM,
      },
    });

    const result = await executeTransaction({
      request: requests,
    });
    return {
      inv_QuyCachDongGoi: result.table,
      l_Product: result.table1,
    } as QuyCachDongGoiResponse;
  } catch (error) {
    const message = getErrorMessage(error);
    console.error("Error in quyCachDongGoiAsync:", message);
    return undefined;
  }
};

export async function ws_INV_QuyCachDongGoi_DeleteByProductID_Async(
  productID?: number,
): Promise<boolean> {
  try {
    const currentUser = await getUserSession();
    const response = await httpService.post("/DataAccess", [
      {
        category: "QAHosGenericDB",
        command: "ws_INV_QuyCachDongGoi_DeleteByProductID",
        parameters: {
          ProductID: productID,
          FacID: currentUser.facId,
        },
      },
    ]);

    return response && response.status == 200;
  } catch (error) {
    const message = getErrorMessage(error);
    console.error(
      "Error in ws_INV_QuyCachDongGoi_DeleteByProductID_Async:",
      message,
    );
    return false;
  }
}

export async function ws_INV_QuyCachDongGoi_Save_Async(
  params: ws_INV_QuyCachDongGoi_Save_Params,
): Promise<INV_QuyCachDongGoi_Save[]> {
  try {
    const currentUser = await getUserSession();
    const response = await httpService.post("/DataAccess", [
      {
        category: "QAHosGenericDB",
        command: "ws_INV_QuyCachDongGoi_Save",
        parameters: {
          FacID: currentUser.facId,
          ProductID: params.productID,
          HeSoNCC: params.heSoNCC,
          HeSo: params.heSo,
          Theo_HeSoNCC: params.theo_HeSoNCC,
          CoSoDongGoi: params.coSoDongGoi,
          IsActive: params.isActive,
          IsThemMoi: params.isThemMoi,
        },
      },
    ]);

    return response.data.table as INV_QuyCachDongGoi_Save[];
  } catch (error) {
    const message = getErrorMessage(error);
    console.error("Error in ws_INV_QuyCachDongGoi_Save_Async:", message);
    return [];
  }
}
