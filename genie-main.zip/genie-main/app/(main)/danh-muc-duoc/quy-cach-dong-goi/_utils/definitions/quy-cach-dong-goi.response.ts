export type INV_QuyCachDongGoi = {
  stt: number;
  customerID: number;
  productID: number;
  hospitalCode: string;
  hospitalName: string;
  unitName: string;
  heSoNCC: number;
  heSo: number;
  theo_HeSoNCC: boolean;
  coSoDongGoi: number;
  unActived: boolean;
  createdBy: string;
  createdOn: string;
  modifiedBy: string;
  modifiedOn: string;
};

export type L_Product = {
  maChung?: string;
  productID: number;
  hospitalCode: string;
  hospitalName: string;
  unitName: string;
  hospitalName1: string;
  formula?: string;
  content: string;
  duongDung?: string;
  isCheck: boolean;
  isProductMain: number;
};

export type INV_QuyCachDongGoi_Save = {
  resultCode: number;
  resultMessage: string;
};

export type QuyCachDongGoiResponse = {
  inv_QuyCachDongGoi: INV_QuyCachDongGoi[];
  l_Product: L_Product[];
};
