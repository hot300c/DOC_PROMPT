export type ws_INV_QuyCachDongGoi_Save_Params = {
  productID: number;
  heSoNCC: number;
  heSo: number;
  theo_HeSoNCC: boolean;
  coSoDongGoi: string;
  isActive: boolean;
  isThemMoi: string;
};
