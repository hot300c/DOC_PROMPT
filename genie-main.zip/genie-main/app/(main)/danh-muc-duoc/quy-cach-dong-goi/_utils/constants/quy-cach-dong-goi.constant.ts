export const IS_SP_KEM = 1;
export const PRODUCT_TYPE_VACCINE_ID = 17;
