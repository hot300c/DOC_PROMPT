import { z } from "zod";

export const QuyCachDongGoiFormSchema = z.object({
  hospitalName: z.string().optional(),
  heSoNCC: z.number().optional(), // Quy cách NCC
  heSo: z.number().optional(), // Quy cách
  coSoDongGoi: z.number().optional(),
  theo_HeSoNCC: z.boolean().optional(), // Ưu tiên quy cách đóng gói
  unActived: z.boolean().optional(),
});

export type QuyCachDongGoiFormValues = z.infer<typeof QuyCachDongGoiFormSchema>;
