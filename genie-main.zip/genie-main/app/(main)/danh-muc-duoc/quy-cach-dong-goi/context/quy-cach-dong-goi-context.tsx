"use client";
import { createContext, useContext, useState } from "react";
import {
  INV_QuyCachDongGoi,
  L_Product,
} from "../_utils/definitions/quy-cach-dong-goi.response";
import { QuyCachDongGoiFormValues } from "../_utils/schemas/quy-cach-dong-goi-schema";

type FormValuesWithProduct = QuyCachDongGoiFormValues & {
  selectedProduct?: L_Product;
};

type QuyCachDongGoiContextType = {
  selectedRow: INV_QuyCachDongGoi | null;
  setSelectedRow: (row: INV_QuyCachDongGoi | null) => void;
  formValues: FormValuesWithProduct | null;
  setFormValues: (values: FormValuesWithProduct | null) => void;
};

const QuyCachDongGoiContext = createContext<
  QuyCachDongGoiContextType | undefined
>(undefined);

export const useQuyCachDongGoi = () => {
  const context = useContext(QuyCachDongGoiContext);
  if (!context) {
    throw new Error(
      "useQuyCachDongGoi must be used within a QuyCachDongGoiProvider",
    );
  }
  return context;
};

export const QuyCachDongGoiProvider: React.FC<{
  children: React.ReactNode;
}> = ({ children }) => {
  const [selectedRow, setSelectedRow] = useState<INV_QuyCachDongGoi | null>(
    null,
  );
  const [formValues, setFormValues] = useState<FormValuesWithProduct | null>(
    null,
  );

  return (
    <QuyCachDongGoiContext.Provider
      value={{
        selectedRow,
        setSelectedRow,
        formValues,
        setFormValues,
      }}
    >
      {children}
    </QuyCachDongGoiContext.Provider>
  );
};
