import { differenceInDays } from "date-fns";

export const validateDateRangeLimit = (
  fromDate: Date,
  toDate: Date,
  maxNumOfDays: number,
): boolean => {
  const timeRange = differenceInDays(toDate, fromDate);
  if (timeRange > maxNumOfDays) {
    return false;
  }
  return true;
};
