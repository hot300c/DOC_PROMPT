export type CommonRESP = {
  id: number;
  name: string;
};

export type ProductTypeRESP = {
  productTypeID: number;
  name: string;
};

export type ComboValuesListCachDungThuocV2RESP = {
  comboName: string;
  comboValue: string;
};

export type UoMRESP = {
  createdBy: string | null;
  createdOn: string | null;
  factor: number | null;
  isDonViDichVu: boolean | null;
  isDonViSuDung: boolean;
  modifiedBy: string | null;
  modifiedOn: string | null;
  note: string;
  parentId: string;
  unitCode: string;
  unitID: number;
  unitName: string;
};

export type InventoryStockRESP = {
  stockID: number;
  name: string;
};
