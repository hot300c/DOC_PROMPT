const page = () => {
  return (
    <main>
      <div className="">
        <h1 className="m-24 text-center text-3xl font-bold">
          Welcome to Genie Danh mục - Dược
        </h1>
      </div>
    </main>
  );
};

export default page;
