Genie is a new webapp aimed to replace QAS.

## Installations

- Install [Node.js and npm](https://docs.npmjs.com/downloading-and-installing-node-js-and-npm)
- Following the instruction [here](https://yarnpkg.com/getting-started/install) to use `Corepack` to install `yarn`
- Run `yarn install --immutable` to install all npm dependencies.

Using `--immutable` is recommended for normal workflow to avoid unintended changes in `yarn.lock`. Any dependencies update (reflected in `package.json` and `yarn.lock`) should be scoped into a separate PR to ensure the changes are deterministic and intended.

To add new dependencies, use [`yarn add`](https://yarnpkg.com/cli/add) and create a separate PR.

## Local Development

By default, the frontend assumes the backend to be hosted at `localhost:5272`. If you do not have the backend running in local, you can route the data requests to the test instance hosted at `https://test-aladdin.vnvc.info`.

To do so, either run

```
export NEXT_PUBLIC_API_PREFIX=/aladdin
export ALADDIN_API_URL=https://test-aladdin.vnvc.info
```

on your terminal or add a file named `.env.development` to the root folder with

```
NEXT_PUBLIC_API_PREFIX=/aladdin
ALADDIN_API_URL=https://test-aladdin.vnvc.info
```

Finally, run `yarn dev` to start the frontend web server.

Open [http://localhost:3000](http://localhost:3000) with your browser to see the webapp.

## Debugging production

The version deployed at [https://dev-genie.vnvc.info](https://dev-genie.vnvc.info) is a [standalone build](https://nextjs.org/docs/pages/api-reference/next-config-js/output#automatically-copying-traced-files).

This [`Dockerfile`](./Dockerfile) would generate a build that mirrors the build deployed at the aforementioned test environment. To debug issues relating to this build, either use this Dockerfile or repeat the steps in this Dockerfile.

To use the Dockerfile:

```bash
docker build -t genie:latest .
docker run --it --rm -p 3000:3000 genie:latest
```

## Making Changes

To start developing a new feature or fix a bug:

### 1. Sync your local with remote main

```bash
git checkout main && git pull
```

### 2. Check out a new branch

```bash
git checkout -b <your_new_branch>
```

### 3. Make your changes. Then commit your branch

```bash
git commit
```

### 4. Keep making changes, but after the 1st commit, use commit --amend instead

```bash
git commit --amend
```

This will avoid creating a new commit ID.

### 5. When ready, push to review

```bash
git push origin <your_new_branch>
```

This will also create a merge request

### 6. When main branch is updated, make sure your branch stay in sync with main

```bash
git fetch origin main
git rebase origin/main
```

Resolve conflict if needed, then commit and push to review again.

## Launching Storybook

Run this command:

```bash
yarn storybook
```

This will start Storybook server.

# Upgrade an Transitive dependencies

Sometimes you have to upgrade an indirect dependency, i.e., a package used by another package. In this case, `yarn add` alone may not work. You should follow these steps:

- `yarn add <package>@<new_version>`
- Add that package to the `resolutions` section inside `package.json`

The last step is to instruct other libs to use this new version if necessary.

# Print Service Integration

This document explains how to use the `httpService.print` method to send print requests to different printers, specifically for printing PDF files.

## Overview

The `httpService.print` method allows you to send print requests to various printers defined in the `PrintType` enum. The method accepts a payload containing the type of printer and an array of files (e.g., PDF files) that you want to print.

## Setup

On your `.env.development` add

```
NEXT_PUBLIC_PRINTER_API_URL=http://localhost:5207/api
NEXT_PUBLIC_PRINTER_API_KEY=vLOwK9Iq6Z4qExvzn9pzM8UBZKrkUoQ73Vsk++TfCjM=
```

`http://localhost:5207/api` if your have Print WebService run at your localhost, else can contact with WebService maker to change accordingly

## Available Printers

The available printers are defined in the `PrintType` enum as follows:

- `Pdf`: Represents the pdf.
- `Barcode`: Represents the Barcode

You can choose the printer you want to use by specifying one of these printer types in your print request.

## `httpService.print` Method

The `httpService.print` method is used to send print requests to the server. It requires a payload containing:

- **`type`**: The printer type (e.g., `Pdf`).
- **`files`**: An array of files to print (e.g., a PDF file).

### Print Type

```ts
export enum PrintType {
  PDF,
  BARCODE,
}
```

### Payload Structure

#### PDF

```ts
export type PrintPdfPayload = {
  files: File[];
};
```

#### Barcode

```ts
export type PrintBarcodePayload = {
  barcodeContent: string;
  barcodeValue: string;
};
```

### Sample

#### Below is sample for integrating printer service, runReport function in `app/lib/utils`

```ts
await utils.runReport(
  appendixContractId,
  facID,
  {
    FacID: facID,
    MaHopDong: contractId,
  },
  baseSettings,
  {
    printDirect: true,
    type: PrintType.PDF,
  },
);
```
